#pragma once
#include "../memory.h"
#include "../types/QAngle.h"

class ViewAngleServerChange_t  {
public:
    uintptr_t baseAddr;

    ViewAngleServerChange_t() { baseAddr = client_base(); }
    ViewAngleServerChange_t(uintptr_t base) : baseAddr(base) {}

    uintptr_t nType() { return read<uintptr_t>(baseAddr + offsets_instance.get("ViewAngleServerChange_t", "nType")); }
    QAngle qAngle() { return read<QAngle>(baseAddr + offsets_instance.get("ViewAngleServerChange_t", "qAngle")); }
    int nIndex() { return read<int>(baseAddr + offsets_instance.get("ViewAngleServerChange_t", "nIndex")); }
};
