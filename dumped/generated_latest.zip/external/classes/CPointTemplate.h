#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class CPointTemplate  {
public:
    uintptr_t baseAddr;

    CPointTemplate() { baseAddr = 0; }
    CPointTemplate(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_iszWorldName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPointTemplate", "m_iszWorldName")); }
    uintptr_t m_iszSource2EntityLumpName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPointTemplate", "m_iszSource2EntityLumpName")); }
    uintptr_t m_iszEntityFilterName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPointTemplate", "m_iszEntityFilterName")); }
    float m_flTimeoutInterval() { return read<float>(baseAddr + offsets_instance.get("CPointTemplate", "m_flTimeoutInterval")); }
    bool m_bAsynchronouslySpawnEntities() { return read<bool>(baseAddr + offsets_instance.get("CPointTemplate", "m_bAsynchronouslySpawnEntities")); }
    uintptr_t m_clientOnlyEntityBehavior() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPointTemplate", "m_clientOnlyEntityBehavior")); }
    uintptr_t m_ownerSpawnGroupType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPointTemplate", "m_ownerSpawnGroupType")); }
    int m_createdSpawnGroupHandles() { return read<int>(baseAddr + offsets_instance.get("CPointTemplate", "m_createdSpawnGroupHandles")); }
    Vector3 m_SpawnedEntityHandles() { return read<Vector3>(baseAddr + offsets_instance.get("CPointTemplate", "m_SpawnedEntityHandles")); }
    uintptr_t m_ScriptSpawnCallback() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPointTemplate", "m_ScriptSpawnCallback")); }
    uintptr_t m_ScriptCallbackScope() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPointTemplate", "m_ScriptCallbackScope")); }
};
