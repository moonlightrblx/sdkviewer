#pragma once
#include "../memory.h"

class C_ClientRagdoll  {
public:
    uintptr_t baseAddr;

    C_ClientRagdoll() { baseAddr = client_base(); }
    C_ClientRagdoll(uintptr_t base) : baseAddr(base) {}

    bool m_bFadeOut() { return read<bool>(baseAddr + offsets_instance.get("C_ClientRagdoll", "m_bFadeOut")); }
    bool m_bImportant() { return read<bool>(baseAddr + offsets_instance.get("C_ClientRagdoll", "m_bImportant")); }
    uintptr_t m_flEffectTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_ClientRagdoll", "m_flEffectTime")); }
    uintptr_t m_gibDespawnTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_ClientRagdoll", "m_gibDespawnTime")); }
    int m_iCurrentFriction() { return read<int>(baseAddr + offsets_instance.get("C_ClientRagdoll", "m_iCurrentFriction")); }
    int m_iMinFriction() { return read<int>(baseAddr + offsets_instance.get("C_ClientRagdoll", "m_iMinFriction")); }
    int m_iMaxFriction() { return read<int>(baseAddr + offsets_instance.get("C_ClientRagdoll", "m_iMaxFriction")); }
    int m_iFrictionAnimState() { return read<int>(baseAddr + offsets_instance.get("C_ClientRagdoll", "m_iFrictionAnimState")); }
    bool m_bReleaseRagdoll() { return read<bool>(baseAddr + offsets_instance.get("C_ClientRagdoll", "m_bReleaseRagdoll")); }
    uintptr_t m_iEyeAttachment() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_ClientRagdoll", "m_iEyeAttachment")); }
    bool m_bFadingOut() { return read<bool>(baseAddr + offsets_instance.get("C_ClientRagdoll", "m_bFadingOut")); }
    float m_flScaleEnd() { return read<float>(baseAddr + offsets_instance.get("C_ClientRagdoll", "m_flScaleEnd")); }
    uintptr_t m_flScaleTimeStart() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_ClientRagdoll", "m_flScaleTimeStart")); }
    uintptr_t m_flScaleTimeEnd() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_ClientRagdoll", "m_flScaleTimeEnd")); }
};
