#pragma once
#include "../memory.h"

class CHostageRescueZoneShim  {
public:
    uintptr_t baseAddr;

    CHostageRescueZoneShim() { baseAddr = 0; }
    CHostageRescueZoneShim(uintptr_t base) : baseAddr(base) {}

};
