#pragma once
#include "../memory.h"

class CFilterMultiple {
public:
 uintptr_t baseAddr;
 CFilterMultiple() : baseAddr(0){}
 CFilterMultiple(uintptr_t b):baseAddr(b){}
 uintptr_t m_nFilterType(){return SCHEMA_TYPE(uintptr_t,0x650);}
 uintptr_t m_iFilterName(){return SCHEMA_TYPE(uintptr_t,0x658);}
 uintptr_t m_hFilter(){return SCHEMA_TYPE(uintptr_t,0x6A8);}
};
