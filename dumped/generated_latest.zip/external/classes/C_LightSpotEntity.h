#pragma once
#include "../memory.h"

class C_LightSpotEntity  {
public:
    uintptr_t baseAddr;

    C_LightSpotEntity() { baseAddr = 0; }
    C_LightSpotEntity(uintptr_t base) : baseAddr(base) {}

};
