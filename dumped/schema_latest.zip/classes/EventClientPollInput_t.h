#pragma once
#include "../memory.h"

class EventClientPollInput_t {
public:
 uintptr_t baseAddr;
 EventClientPollInput_t() : baseAddr(0){}
 EventClientPollInput_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_LoopState(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_flRealTime(){return SCHEMA_TYPE(uintptr_t,0x28);}
};
