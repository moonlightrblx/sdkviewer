#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class PulseObservableBoolExpression_t  {
public:
    uintptr_t baseAddr;

    PulseObservableBoolExpression_t() { baseAddr = client_base(); }
    PulseObservableBoolExpression_t(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_EvaluateConnection() { return read<uintptr_t>(baseAddr + offsets_instance.get("PulseObservableBoolExpression_t", "m_EvaluateConnection")); }
    Vector3 m_DependentObservableVars() { return read<Vector3>(baseAddr + offsets_instance.get("PulseObservableBoolExpression_t", "m_DependentObservableVars")); }
    Vector3 m_DependentObservableBlackboardReferences() { return read<Vector3>(baseAddr + offsets_instance.get("PulseObservableBoolExpression_t", "m_DependentObservableBlackboardReferences")); }
};
