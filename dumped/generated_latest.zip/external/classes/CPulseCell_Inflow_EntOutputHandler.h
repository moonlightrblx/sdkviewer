#pragma once
#include "../memory.h"

class CPulseCell_Inflow_EntOutputHandler  {
public:
    uintptr_t baseAddr;

    CPulseCell_Inflow_EntOutputHandler() { baseAddr = 0; }
    CPulseCell_Inflow_EntOutputHandler(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_SourceEntity() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Inflow_EntOutputHandler", "m_SourceEntity")); }
    uintptr_t m_SourceOutput() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Inflow_EntOutputHandler", "m_SourceOutput")); }
    uintptr_t m_ExpectedParamType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Inflow_EntOutputHandler", "m_ExpectedParamType")); }
};
