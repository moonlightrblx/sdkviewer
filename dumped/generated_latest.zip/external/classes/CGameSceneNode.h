#pragma once
#include "../memory.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"

class CGameSceneNode  {
public:
    uintptr_t baseAddr;

    CGameSceneNode() { baseAddr = client_base(); }
    CGameSceneNode(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_nodeToWorld() { return read<uintptr_t>(baseAddr + offsets_instance.get("CGameSceneNode", "m_nodeToWorld")); }
    CEntityInstance* m_pOwner() { return read<CEntityInstance*>(baseAddr + offsets_instance.get("CGameSceneNode", "m_pOwner")); }
    CGameSceneNode* m_pParent() { return read<CGameSceneNode*>(baseAddr + offsets_instance.get("CGameSceneNode", "m_pParent")); }
    CGameSceneNode* m_pChild() { return read<CGameSceneNode*>(baseAddr + offsets_instance.get("CGameSceneNode", "m_pChild")); }
    CGameSceneNode* m_pNextSibling() { return read<CGameSceneNode*>(baseAddr + offsets_instance.get("CGameSceneNode", "m_pNextSibling")); }
    uintptr_t m_hParent() { return read<uintptr_t>(baseAddr + offsets_instance.get("CGameSceneNode", "m_hParent")); }
    Vector3 m_vecOrigin() { return read<Vector3>(baseAddr + offsets_instance.get("CGameSceneNode", "m_vecOrigin")); }
    QAngle m_angRotation() { return read<QAngle>(baseAddr + offsets_instance.get("CGameSceneNode", "m_angRotation")); }
    float m_flScale() { return read<float>(baseAddr + offsets_instance.get("CGameSceneNode", "m_flScale")); }
    Vector3 m_vecAbsOrigin() { return read<Vector3>(baseAddr + offsets_instance.get("CGameSceneNode", "m_vecAbsOrigin")); }
    QAngle m_angAbsRotation() { return read<QAngle>(baseAddr + offsets_instance.get("CGameSceneNode", "m_angAbsRotation")); }
    float m_flAbsScale() { return read<float>(baseAddr + offsets_instance.get("CGameSceneNode", "m_flAbsScale")); }
    Vector3 m_vecWrappedLocalOrigin() { return read<Vector3>(baseAddr + offsets_instance.get("CGameSceneNode", "m_vecWrappedLocalOrigin")); }
    QAngle m_angWrappedLocalRotation() { return read<QAngle>(baseAddr + offsets_instance.get("CGameSceneNode", "m_angWrappedLocalRotation")); }
    float m_flWrappedScale() { return read<float>(baseAddr + offsets_instance.get("CGameSceneNode", "m_flWrappedScale")); }
    uintptr_t m_nParentAttachmentOrBone() { return read<uintptr_t>(baseAddr + offsets_instance.get("CGameSceneNode", "m_nParentAttachmentOrBone")); }
    bool m_bDebugAbsOriginChanges() { return read<bool>(baseAddr + offsets_instance.get("CGameSceneNode", "m_bDebugAbsOriginChanges")); }
    bool m_bDormant() { return read<bool>(baseAddr + offsets_instance.get("CGameSceneNode", "m_bDormant")); }
    bool m_bForceParentToBeNetworked() { return read<bool>(baseAddr + offsets_instance.get("CGameSceneNode", "m_bForceParentToBeNetworked")); }
    uintptr_t m_bDirtyHierarchy() { return read<uintptr_t>(baseAddr + offsets_instance.get("CGameSceneNode", "m_bDirtyHierarchy")); }
    uintptr_t m_bDirtyBoneMergeInfo() { return read<uintptr_t>(baseAddr + offsets_instance.get("CGameSceneNode", "m_bDirtyBoneMergeInfo")); }
    uintptr_t m_bNetworkedPositionChanged() { return read<uintptr_t>(baseAddr + offsets_instance.get("CGameSceneNode", "m_bNetworkedPositionChanged")); }
    uintptr_t m_bNetworkedAnglesChanged() { return read<uintptr_t>(baseAddr + offsets_instance.get("CGameSceneNode", "m_bNetworkedAnglesChanged")); }
    uintptr_t m_bNetworkedScaleChanged() { return read<uintptr_t>(baseAddr + offsets_instance.get("CGameSceneNode", "m_bNetworkedScaleChanged")); }
    uintptr_t m_bWillBeCallingPostDataUpdate() { return read<uintptr_t>(baseAddr + offsets_instance.get("CGameSceneNode", "m_bWillBeCallingPostDataUpdate")); }
    uintptr_t m_bBoneMergeFlex() { return read<uintptr_t>(baseAddr + offsets_instance.get("CGameSceneNode", "m_bBoneMergeFlex")); }
    uintptr_t m_nLatchAbsOrigin() { return read<uintptr_t>(baseAddr + offsets_instance.get("CGameSceneNode", "m_nLatchAbsOrigin")); }
    uintptr_t m_bDirtyBoneMergeBoneToRoot() { return read<uintptr_t>(baseAddr + offsets_instance.get("CGameSceneNode", "m_bDirtyBoneMergeBoneToRoot")); }
    uint8_t m_nHierarchicalDepth() { return read<uint8_t>(baseAddr + offsets_instance.get("CGameSceneNode", "m_nHierarchicalDepth")); }
    uint8_t m_nHierarchyType() { return read<uint8_t>(baseAddr + offsets_instance.get("CGameSceneNode", "m_nHierarchyType")); }
    uint8_t m_nDoNotSetAnimTimeInInvalidatePhysicsCount() { return read<uint8_t>(baseAddr + offsets_instance.get("CGameSceneNode", "m_nDoNotSetAnimTimeInInvalidatePhysicsCount")); }
    uintptr_t m_name() { return read<uintptr_t>(baseAddr + offsets_instance.get("CGameSceneNode", "m_name")); }
    uintptr_t m_hierarchyAttachName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CGameSceneNode", "m_hierarchyAttachName")); }
    float m_flZOffset() { return read<float>(baseAddr + offsets_instance.get("CGameSceneNode", "m_flZOffset")); }
    float m_flClientLocalScale() { return read<float>(baseAddr + offsets_instance.get("CGameSceneNode", "m_flClientLocalScale")); }
    Vector3 m_vRenderOrigin() { return read<Vector3>(baseAddr + offsets_instance.get("CGameSceneNode", "m_vRenderOrigin")); }
};
