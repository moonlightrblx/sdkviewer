#pragma once
#include "../memory.h"

class C_EnvSky {
public:
 uintptr_t baseAddr;
 C_EnvSky() : baseAddr(0){}
 C_EnvSky(uintptr_t b):baseAddr(b){}
 uintptr_t m_hSkyMaterial(){return SCHEMA_TYPE(uintptr_t,0xEB0);}
 uintptr_t m_hSkyMaterialLightingOnly(){return SCHEMA_TYPE(uintptr_t,0xEB8);}
 uintptr_t m_bStartDisabled(){return SCHEMA_TYPE(uintptr_t,0xEC0);}
 uintptr_t m_vTintColor(){return SCHEMA_TYPE(uintptr_t,0xEC1);}
 uintptr_t m_vTintColorLightingOnly(){return SCHEMA_TYPE(uintptr_t,0xEC5);}
 uintptr_t m_flBrightnessScale(){return SCHEMA_TYPE(uintptr_t,0xECC);}
 uintptr_t m_nFogType(){return SCHEMA_TYPE(uintptr_t,0xED0);}
 uintptr_t m_flFogMinStart(){return SCHEMA_TYPE(uintptr_t,0xED4);}
 uintptr_t m_flFogMinEnd(){return SCHEMA_TYPE(uintptr_t,0xED8);}
 uintptr_t m_flFogMaxStart(){return SCHEMA_TYPE(uintptr_t,0xEDC);}
 uintptr_t m_flFogMaxEnd(){return SCHEMA_TYPE(uintptr_t,0xEE0);}
 uintptr_t m_bEnabled(){return SCHEMA_TYPE(uintptr_t,0xEE4);}
};
