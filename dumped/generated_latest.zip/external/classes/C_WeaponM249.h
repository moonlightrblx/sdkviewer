#pragma once
#include "../memory.h"

class C_WeaponM249  {
public:
    uintptr_t baseAddr;

    C_WeaponM249() { baseAddr = client_base(); }
    C_WeaponM249(uintptr_t base) : baseAddr(base) {}

};
