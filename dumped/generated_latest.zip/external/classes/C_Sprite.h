#pragma once
#include "../memory.h"

class C_Sprite  {
public:
    uintptr_t baseAddr;

    C_Sprite() { baseAddr = client_base(); }
    C_Sprite(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_hSpriteMaterial() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_Sprite", "m_hSpriteMaterial")); }
    C_BaseEntity* m_hAttachedToEntity() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_Sprite", "m_hAttachedToEntity")); }
    uintptr_t m_nAttachment() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_Sprite", "m_nAttachment")); }
    float m_flSpriteFramerate() { return read<float>(baseAddr + offsets_instance.get("C_Sprite", "m_flSpriteFramerate")); }
    float m_flFrame() { return read<float>(baseAddr + offsets_instance.get("C_Sprite", "m_flFrame")); }
    uintptr_t m_flDieTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_Sprite", "m_flDieTime")); }
    int m_nBrightness() { return read<int>(baseAddr + offsets_instance.get("C_Sprite", "m_nBrightness")); }
    float m_flBrightnessDuration() { return read<float>(baseAddr + offsets_instance.get("C_Sprite", "m_flBrightnessDuration")); }
    float m_flSpriteScale() { return read<float>(baseAddr + offsets_instance.get("C_Sprite", "m_flSpriteScale")); }
    float m_flScaleDuration() { return read<float>(baseAddr + offsets_instance.get("C_Sprite", "m_flScaleDuration")); }
    bool m_bWorldSpaceScale() { return read<bool>(baseAddr + offsets_instance.get("C_Sprite", "m_bWorldSpaceScale")); }
    float m_flGlowProxySize() { return read<float>(baseAddr + offsets_instance.get("C_Sprite", "m_flGlowProxySize")); }
    float m_flHDRColorScale() { return read<float>(baseAddr + offsets_instance.get("C_Sprite", "m_flHDRColorScale")); }
    uintptr_t m_flLastTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_Sprite", "m_flLastTime")); }
    float m_flMaxFrame() { return read<float>(baseAddr + offsets_instance.get("C_Sprite", "m_flMaxFrame")); }
    float m_flStartScale() { return read<float>(baseAddr + offsets_instance.get("C_Sprite", "m_flStartScale")); }
    float m_flDestScale() { return read<float>(baseAddr + offsets_instance.get("C_Sprite", "m_flDestScale")); }
    uintptr_t m_flScaleTimeStart() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_Sprite", "m_flScaleTimeStart")); }
    int m_nStartBrightness() { return read<int>(baseAddr + offsets_instance.get("C_Sprite", "m_nStartBrightness")); }
    int m_nDestBrightness() { return read<int>(baseAddr + offsets_instance.get("C_Sprite", "m_nDestBrightness")); }
    uintptr_t m_flBrightnessTimeStart() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_Sprite", "m_flBrightnessTimeStart")); }
    int m_nSpriteWidth() { return read<int>(baseAddr + offsets_instance.get("C_Sprite", "m_nSpriteWidth")); }
    int m_nSpriteHeight() { return read<int>(baseAddr + offsets_instance.get("C_Sprite", "m_nSpriteHeight")); }
};
