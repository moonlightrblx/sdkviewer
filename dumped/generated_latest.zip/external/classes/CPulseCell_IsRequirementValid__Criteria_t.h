#pragma once
#include "../memory.h"

class CPulseCell_IsRequirementValid__Criteria_t  {
public:
    uintptr_t baseAddr;

    CPulseCell_IsRequirementValid__Criteria_t() { baseAddr = client_base(); }
    CPulseCell_IsRequirementValid__Criteria_t(uintptr_t base) : baseAddr(base) {}

    bool m_bIsValid() { return read<bool>(baseAddr + offsets_instance.get("CPulseCell_IsRequirementValid__Criteria_t", "m_bIsValid")); }
};
