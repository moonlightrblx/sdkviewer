#pragma once
#include "../memory.h"
#include "../classes/CSkeletonInstance.h"

class CBodyComponentSkeletonInstance  {
public:
    uintptr_t baseAddr;

    CBodyComponentSkeletonInstance() { baseAddr = 0; }
    CBodyComponentSkeletonInstance(uintptr_t base) : baseAddr(base) {}

    CSkeletonInstance m_skeletonInstance() { return read<CSkeletonInstance>(baseAddr + offsets_instance.get("CBodyComponentSkeletonInstance", "m_skeletonInstance")); }
};
