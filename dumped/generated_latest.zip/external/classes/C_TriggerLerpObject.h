#pragma once
#include "../memory.h"

class C_TriggerLerpObject  {
public:
    uintptr_t baseAddr;

    C_TriggerLerpObject() { baseAddr = 0; }
    C_TriggerLerpObject(uintptr_t base) : baseAddr(base) {}

};
