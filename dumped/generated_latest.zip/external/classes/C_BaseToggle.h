#pragma once
#include "../memory.h"

class C_BaseToggle  {
public:
    uintptr_t baseAddr;

    C_BaseToggle() { baseAddr = client_base(); }
    C_BaseToggle(uintptr_t base) : baseAddr(base) {}

};
