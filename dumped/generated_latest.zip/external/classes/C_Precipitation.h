#pragma once
#include "../memory.h"

class C_Precipitation  {
public:
    uintptr_t baseAddr;

    C_Precipitation() { baseAddr = 0; }
    C_Precipitation(uintptr_t base) : baseAddr(base) {}

    float m_flDensity() { return read<float>(baseAddr + offsets_instance.get("C_Precipitation", "m_flDensity")); }
    float m_flParticleInnerDist() { return read<float>(baseAddr + offsets_instance.get("C_Precipitation", "m_flParticleInnerDist")); }
    uintptr_t* m_pParticleDef() { return read<uintptr_t*>(baseAddr + offsets_instance.get("C_Precipitation", "m_pParticleDef")); }
    uintptr_t m_tParticlePrecipTraceTimer() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_Precipitation", "m_tParticlePrecipTraceTimer")); }
    bool m_bActiveParticlePrecipEmitter() { return read<bool>(baseAddr + offsets_instance.get("C_Precipitation", "m_bActiveParticlePrecipEmitter")); }
    bool m_bParticlePrecipInitialized() { return read<bool>(baseAddr + offsets_instance.get("C_Precipitation", "m_bParticlePrecipInitialized")); }
    bool m_bHasSimulatedSinceLastSceneObjectUpdate() { return read<bool>(baseAddr + offsets_instance.get("C_Precipitation", "m_bHasSimulatedSinceLastSceneObjectUpdate")); }
    int m_nAvailableSheetSequencesMaxIndex() { return read<int>(baseAddr + offsets_instance.get("C_Precipitation", "m_nAvailableSheetSequencesMaxIndex")); }
};
