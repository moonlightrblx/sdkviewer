#pragma once
#include "../memory.h"

class C_CSGO_TerroristWingmanIntroCamera  {
public:
    uintptr_t baseAddr;

    C_CSGO_TerroristWingmanIntroCamera() { baseAddr = 0; }
    C_CSGO_TerroristWingmanIntroCamera(uintptr_t base) : baseAddr(base) {}

};
