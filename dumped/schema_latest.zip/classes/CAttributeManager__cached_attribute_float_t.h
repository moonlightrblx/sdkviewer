#pragma once
#include "../memory.h"

class CAttributeManager__cached_attribute_float_t {
public:
 uintptr_t baseAddr;
 CAttributeManager__cached_attribute_float_t() : baseAddr(0){}
 CAttributeManager__cached_attribute_float_t(uintptr_t b):baseAddr(b){}
 uintptr_t flIn(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t iAttribHook(){return SCHEMA_TYPE(uintptr_t,0x8);}
 uintptr_t flOut(){return SCHEMA_TYPE(uintptr_t,0x10);}
};
