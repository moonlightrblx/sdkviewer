#pragma once
#include "../memory.h"

class C_SoundEventEntity {
public:
 uintptr_t baseAddr;
 C_SoundEventEntity() : baseAddr(0){}
 C_SoundEventEntity(uintptr_t b):baseAddr(b){}
 uintptr_t m_bStartOnSpawn(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_bToLocalPlayer(){return SCHEMA_TYPE(uintptr_t,0x5F9);}
 uintptr_t m_bStopOnNew(){return SCHEMA_TYPE(uintptr_t,0x5FA);}
 uintptr_t m_bSaveRestore(){return SCHEMA_TYPE(uintptr_t,0x5FB);}
 uintptr_t m_bSavedIsPlaying(){return SCHEMA_TYPE(uintptr_t,0x5FC);}
 uintptr_t m_flSavedElapsedTime(){return SCHEMA_TYPE(uintptr_t,0x600);}
 uintptr_t m_iszSourceEntityName(){return SCHEMA_TYPE(uintptr_t,0x608);}
 uintptr_t m_iszAttachmentName(){return SCHEMA_TYPE(uintptr_t,0x610);}
 uintptr_t m_onGUIDChanged(){return SCHEMA_TYPE(uintptr_t,0x618);}
 uintptr_t m_onSoundFinished(){return SCHEMA_TYPE(uintptr_t,0x640);}
 uintptr_t m_flClientCullRadius(){return SCHEMA_TYPE(uintptr_t,0x668);}
 uintptr_t m_iszSoundName(){return SCHEMA_TYPE(uintptr_t,0x698);}
 uintptr_t m_hSource(){return SCHEMA_TYPE(uintptr_t,0x6B4);}
 uintptr_t m_nEntityIndexSelection(){return SCHEMA_TYPE(uintptr_t,0x6B8);}
 uintptr_t m_bClientSideOnly(){return SCHEMA_TYPE(uintptr_t,0x0);}
};
