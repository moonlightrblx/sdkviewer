#pragma once
#include "../memory.h"

class CPulse_BlackboardReference {
public:
 uintptr_t baseAddr;
 CPulse_BlackboardReference() : baseAddr(0){}
 CPulse_BlackboardReference(uintptr_t b):baseAddr(b){}
 uintptr_t m_hBlackboardResource(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_BlackboardResource(){return SCHEMA_TYPE(uintptr_t,0x8);}
 uintptr_t m_nNodeID(){return SCHEMA_TYPE(uintptr_t,0x18);}
 uintptr_t m_NodeName(){return SCHEMA_TYPE(uintptr_t,0x20);}
};
