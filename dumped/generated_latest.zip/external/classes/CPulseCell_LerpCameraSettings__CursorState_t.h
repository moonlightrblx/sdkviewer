#pragma once
#include "../memory.h"

class CPulseCell_LerpCameraSettings__CursorState_t  {
public:
    uintptr_t baseAddr;

    CPulseCell_LerpCameraSettings__CursorState_t() { baseAddr = client_base(); }
    CPulseCell_LerpCameraSettings__CursorState_t(uintptr_t base) : baseAddr(base) {}

    C_PointCamera* m_hCamera() { return read<C_PointCamera*>(baseAddr + offsets_instance.get("CPulseCell_LerpCameraSettings__CursorState_t", "m_hCamera")); }
    uintptr_t m_OverlaidStart() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_LerpCameraSettings__CursorState_t", "m_OverlaidStart")); }
    uintptr_t m_OverlaidEnd() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_LerpCameraSettings__CursorState_t", "m_OverlaidEnd")); }
};
