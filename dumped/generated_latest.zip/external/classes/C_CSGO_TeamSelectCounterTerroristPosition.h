#pragma once
#include "../memory.h"

class C_CSGO_TeamSelectCounterTerroristPosition  {
public:
    uintptr_t baseAddr;

    C_CSGO_TeamSelectCounterTerroristPosition() { baseAddr = client_base(); }
    C_CSGO_TeamSelectCounterTerroristPosition(uintptr_t base) : baseAddr(base) {}

};
