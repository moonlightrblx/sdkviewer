#pragma once
#include "../memory.h"

class CBuoyancyHelper  {
public:
    uintptr_t baseAddr;

    CBuoyancyHelper() { baseAddr = 0; }
    CBuoyancyHelper(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_nFluidType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBuoyancyHelper", "m_nFluidType")); }
    float m_flFluidDensity() { return read<float>(baseAddr + offsets_instance.get("CBuoyancyHelper", "m_flFluidDensity")); }
    float m_flNeutrallyBuoyantGravity() { return read<float>(baseAddr + offsets_instance.get("CBuoyancyHelper", "m_flNeutrallyBuoyantGravity")); }
    float m_flNeutrallyBuoyantLinearDamping() { return read<float>(baseAddr + offsets_instance.get("CBuoyancyHelper", "m_flNeutrallyBuoyantLinearDamping")); }
    float m_flNeutrallyBuoyantAngularDamping() { return read<float>(baseAddr + offsets_instance.get("CBuoyancyHelper", "m_flNeutrallyBuoyantAngularDamping")); }
    bool m_bNeutrallyBuoyant() { return read<bool>(baseAddr + offsets_instance.get("CBuoyancyHelper", "m_bNeutrallyBuoyant")); }
    float m_vecFractionOfWheelSubmergedForWheelFriction() { return read<float>(baseAddr + offsets_instance.get("CBuoyancyHelper", "m_vecFractionOfWheelSubmergedForWheelFriction")); }
    float m_vecWheelFrictionScales() { return read<float>(baseAddr + offsets_instance.get("CBuoyancyHelper", "m_vecWheelFrictionScales")); }
    float m_vecFractionOfWheelSubmergedForWheelDrag() { return read<float>(baseAddr + offsets_instance.get("CBuoyancyHelper", "m_vecFractionOfWheelSubmergedForWheelDrag")); }
    float m_vecWheelDrag() { return read<float>(baseAddr + offsets_instance.get("CBuoyancyHelper", "m_vecWheelDrag")); }
};
