#pragma once
#include "../memory.h"

class C_TextureBasedAnimatable {
public:
 uintptr_t baseAddr;
 C_TextureBasedAnimatable() : baseAddr(0){}
 C_TextureBasedAnimatable(uintptr_t b):baseAddr(b){}
 uintptr_t m_bLoop(){return SCHEMA_TYPE(uintptr_t,0xEB0);}
 uintptr_t m_flFPS(){return SCHEMA_TYPE(uintptr_t,0xEB4);}
 uintptr_t m_hPositionKeys(){return SCHEMA_TYPE(uintptr_t,0xEB8);}
 uintptr_t m_hRotationKeys(){return SCHEMA_TYPE(uintptr_t,0xEC0);}
 uintptr_t m_vAnimationBoundsMin(){return SCHEMA_TYPE(uintptr_t,0xEC8);}
 uintptr_t m_vAnimationBoundsMax(){return SCHEMA_TYPE(uintptr_t,0xED4);}
 uintptr_t m_flStartTime(){return SCHEMA_TYPE(uintptr_t,0xEE0);}
 uintptr_t m_flStartFrame(){return SCHEMA_TYPE(uintptr_t,0xEE4);}
};
