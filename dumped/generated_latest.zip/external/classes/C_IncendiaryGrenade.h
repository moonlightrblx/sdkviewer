#pragma once
#include "../memory.h"

class C_IncendiaryGrenade  {
public:
    uintptr_t baseAddr;

    C_IncendiaryGrenade() { baseAddr = client_base(); }
    C_IncendiaryGrenade(uintptr_t base) : baseAddr(base) {}

};
