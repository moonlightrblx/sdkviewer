#pragma once
#include "../memory.h"

class C_EnvCubemapBox  {
public:
    uintptr_t baseAddr;

    C_EnvCubemapBox() { baseAddr = 0; }
    C_EnvCubemapBox(uintptr_t base) : baseAddr(base) {}

};
