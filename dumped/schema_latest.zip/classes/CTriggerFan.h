#pragma once
#include "../memory.h"

class CTriggerFan {
public:
 uintptr_t baseAddr;
 CTriggerFan() : baseAddr(0){}
 CTriggerFan(uintptr_t b):baseAddr(b){}
 uintptr_t m_vFanOriginOffset(){return SCHEMA_TYPE(uintptr_t,0xFF0);}
 uintptr_t m_vDirection(){return SCHEMA_TYPE(uintptr_t,0xFFC);}
 uintptr_t m_bPushTowardsInfoTarget(){return SCHEMA_TYPE(uintptr_t,0x1008);}
 uintptr_t m_bPushAwayFromInfoTarget(){return SCHEMA_TYPE(uintptr_t,0x1009);}
 uintptr_t m_qNoiseDelta(){return SCHEMA_TYPE(uintptr_t,0x1010);}
 uintptr_t m_hInfoFan(){return SCHEMA_TYPE(uintptr_t,0x1020);}
 uintptr_t m_flForce(){return SCHEMA_TYPE(uintptr_t,0x1024);}
 uintptr_t m_bFalloff(){return SCHEMA_TYPE(uintptr_t,0x1028);}
 uintptr_t m_RampTimer(){return SCHEMA_TYPE(uintptr_t,0x1030);}
};
