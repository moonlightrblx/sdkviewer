#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class CGlowProperty  {
public:
    uintptr_t baseAddr;

    CGlowProperty() { baseAddr = 0; }
    CGlowProperty(uintptr_t base) : baseAddr(base) {}

    Vector3 m_fGlowColor() { return read<Vector3>(baseAddr + offsets_instance.get("CGlowProperty", "m_fGlowColor")); }
    int m_iGlowType() { return read<int>(baseAddr + offsets_instance.get("CGlowProperty", "m_iGlowType")); }
    int m_iGlowTeam() { return read<int>(baseAddr + offsets_instance.get("CGlowProperty", "m_iGlowTeam")); }
    int m_nGlowRange() { return read<int>(baseAddr + offsets_instance.get("CGlowProperty", "m_nGlowRange")); }
    int m_nGlowRangeMin() { return read<int>(baseAddr + offsets_instance.get("CGlowProperty", "m_nGlowRangeMin")); }
    uintptr_t m_glowColorOverride() { return read<uintptr_t>(baseAddr + offsets_instance.get("CGlowProperty", "m_glowColorOverride")); }
    bool m_bFlashing() { return read<bool>(baseAddr + offsets_instance.get("CGlowProperty", "m_bFlashing")); }
    float m_flGlowTime() { return read<float>(baseAddr + offsets_instance.get("CGlowProperty", "m_flGlowTime")); }
    float m_flGlowStartTime() { return read<float>(baseAddr + offsets_instance.get("CGlowProperty", "m_flGlowStartTime")); }
    bool m_bEligibleForScreenHighlight() { return read<bool>(baseAddr + offsets_instance.get("CGlowProperty", "m_bEligibleForScreenHighlight")); }
    bool m_bGlowing() { return read<bool>(baseAddr + offsets_instance.get("CGlowProperty", "m_bGlowing")); }
};
