#pragma once
#include "../memory.h"

class CPulseCell_Value_Curve  {
public:
    uintptr_t baseAddr;

    CPulseCell_Value_Curve() { baseAddr = 0; }
    CPulseCell_Value_Curve(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_Curve() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Value_Curve", "m_Curve")); }
};
