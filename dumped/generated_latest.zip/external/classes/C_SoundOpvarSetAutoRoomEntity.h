#pragma once
#include "../memory.h"

class C_SoundOpvarSetAutoRoomEntity  {
public:
    uintptr_t baseAddr;

    C_SoundOpvarSetAutoRoomEntity() { baseAddr = 0; }
    C_SoundOpvarSetAutoRoomEntity(uintptr_t base) : baseAddr(base) {}

};
