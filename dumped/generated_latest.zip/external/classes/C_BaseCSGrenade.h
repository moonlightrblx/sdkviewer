#pragma once
#include "../memory.h"
#include "../classes/GameTick_t.h"
#include "../classes/GameTime_t.h"
class C_CSWeaponBase;

class C_BaseCSGrenade  {
public:
    uintptr_t baseAddr;

    C_BaseCSGrenade() { baseAddr = 0; }
    C_BaseCSGrenade(uintptr_t base) : baseAddr(base) {}

    bool m_bClientPredictDelete() { return read<bool>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_bClientPredictDelete")); }
    bool m_bRedraw() { return read<bool>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_bRedraw")); }
    bool m_bIsHeldByPlayer() { return read<bool>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_bIsHeldByPlayer")); }
    bool m_bPinPulled() { return read<bool>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_bPinPulled")); }
    bool m_bJumpThrow() { return read<bool>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_bJumpThrow")); }
    bool m_bThrowAnimating() { return read<bool>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_bThrowAnimating")); }
    GameTime_t m_fThrowTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_fThrowTime")); }
    float m_flThrowStrength() { return read<float>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_flThrowStrength")); }
    GameTime_t m_fDropTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_fDropTime")); }
    GameTime_t m_fPinPullTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_fPinPullTime")); }
    bool m_bJustPulledPin() { return read<bool>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_bJustPulledPin")); }
    GameTick_t m_nNextHoldTick() { return read<GameTick_t>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_nNextHoldTick")); }
    float m_flNextHoldFrac() { return read<float>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_flNextHoldFrac")); }
    C_CSWeaponBase* m_hSwitchToWeaponAfterThrow() { return read<C_CSWeaponBase*>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_hSwitchToWeaponAfterThrow")); }
};
