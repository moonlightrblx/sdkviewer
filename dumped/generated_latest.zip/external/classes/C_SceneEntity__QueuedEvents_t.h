#pragma once
#include "../memory.h"

class C_SceneEntity__QueuedEvents_t  {
public:
    uintptr_t baseAddr;

    C_SceneEntity__QueuedEvents_t() { baseAddr = 0; }
    C_SceneEntity__QueuedEvents_t(uintptr_t base) : baseAddr(base) {}

    float starttime() { return read<float>(baseAddr + offsets_instance.get("C_SceneEntity__QueuedEvents_t", "starttime")); }
};
