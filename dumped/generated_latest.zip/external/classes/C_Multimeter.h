#pragma once
#include "../memory.h"

class C_Multimeter  {
public:
    uintptr_t baseAddr;

    C_Multimeter() { baseAddr = client_base(); }
    C_Multimeter(uintptr_t base) : baseAddr(base) {}

    C_PlantedC4* m_hTargetC4() { return read<C_PlantedC4*>(baseAddr + offsets_instance.get("C_Multimeter", "m_hTargetC4")); }
};
