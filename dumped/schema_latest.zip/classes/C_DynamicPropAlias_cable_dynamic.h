#pragma once
#include "../memory.h"

class C_DynamicPropAlias_cable_dynamic {
public:
 uintptr_t baseAddr;
 C_DynamicPropAlias_cable_dynamic() : baseAddr(0){}
 C_DynamicPropAlias_cable_dynamic(uintptr_t b):baseAddr(b){}
};
