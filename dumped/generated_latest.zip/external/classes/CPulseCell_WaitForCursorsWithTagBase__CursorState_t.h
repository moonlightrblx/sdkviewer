#pragma once
#include "../memory.h"

class CPulseCell_WaitForCursorsWithTagBase__CursorState_t  {
public:
    uintptr_t baseAddr;

    CPulseCell_WaitForCursorsWithTagBase__CursorState_t() { baseAddr = 0; }
    CPulseCell_WaitForCursorsWithTagBase__CursorState_t(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_TagName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_WaitForCursorsWithTagBase__CursorState_t", "m_TagName")); }
};
