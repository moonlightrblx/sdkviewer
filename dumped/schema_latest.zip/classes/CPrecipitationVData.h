#pragma once
#include "../memory.h"

class CPrecipitationVData {
public:
 uintptr_t baseAddr;
 CPrecipitationVData() : baseAddr(0){}
 CPrecipitationVData(uintptr_t b):baseAddr(b){}
 uintptr_t m_szParticlePrecipitationEffect(){return SCHEMA_TYPE(uintptr_t,0x28);}
 uintptr_t m_flInnerDistance(){return SCHEMA_TYPE(uintptr_t,0x108);}
 uintptr_t m_nAttachType(){return SCHEMA_TYPE(uintptr_t,0x10C);}
 uintptr_t m_bBatchSameVolumeType(){return SCHEMA_TYPE(uintptr_t,0x110);}
 uintptr_t m_nRTEnvCP(){return SCHEMA_TYPE(uintptr_t,0x114);}
 uintptr_t m_nRTEnvCPComponent(){return SCHEMA_TYPE(uintptr_t,0x118);}
 uintptr_t m_szModifier(){return SCHEMA_TYPE(uintptr_t,0x120);}
};
