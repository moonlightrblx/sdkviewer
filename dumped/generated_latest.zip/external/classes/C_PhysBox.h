#pragma once
#include "../memory.h"

class C_PhysBox  {
public:
    uintptr_t baseAddr;

    C_PhysBox() { baseAddr = 0; }
    C_PhysBox(uintptr_t base) : baseAddr(base) {}

};
