#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class CCSPlayer_MovementServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_MovementServices() { baseAddr = client_base(); }
    CCSPlayer_MovementServices(uintptr_t base) : baseAddr(base) {}

    Vector3 m_vecLadderNormal() { return read<Vector3>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_vecLadderNormal")); }
    int m_nLadderSurfacePropIndex() { return read<int>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_nLadderSurfacePropIndex")); }
    float m_flDuckAmount() { return read<float>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_flDuckAmount")); }
    float m_flDuckSpeed() { return read<float>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_flDuckSpeed")); }
    bool m_bDuckOverride() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_bDuckOverride")); }
    bool m_bDesiresDuck() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_bDesiresDuck")); }
    float m_flDuckOffset() { return read<float>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_flDuckOffset")); }
    int m_nDuckTimeMsecs() { return read<int>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_nDuckTimeMsecs")); }
    int m_nDuckJumpTimeMsecs() { return read<int>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_nDuckJumpTimeMsecs")); }
    int m_nJumpTimeMsecs() { return read<int>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_nJumpTimeMsecs")); }
    float m_flLastDuckTime() { return read<float>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_flLastDuckTime")); }
    Vector3 m_vecLastPositionAtFullCrouchSpeed() { return read<Vector3>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_vecLastPositionAtFullCrouchSpeed")); }
    bool m_duckUntilOnGround() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_duckUntilOnGround")); }
    bool m_bHasWalkMovedSinceLastJump() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_bHasWalkMovedSinceLastJump")); }
    bool m_bInStuckTest() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_bInStuckTest")); }
    int m_nTraceCount() { return read<int>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_nTraceCount")); }
    int m_StuckLast() { return read<int>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_StuckLast")); }
    bool m_bSpeedCropped() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_bSpeedCropped")); }
    int m_nOldWaterLevel() { return read<int>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_nOldWaterLevel")); }
    float m_flWaterEntryTime() { return read<float>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_flWaterEntryTime")); }
    Vector3 m_vecForward() { return read<Vector3>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_vecForward")); }
    Vector3 m_vecLeft() { return read<Vector3>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_vecLeft")); }
    Vector3 m_vecUp() { return read<Vector3>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_vecUp")); }
    int m_nGameCodeHasMovedPlayerAfterCommand() { return read<int>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_nGameCodeHasMovedPlayerAfterCommand")); }
    bool m_bOldJumpPressed() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_bOldJumpPressed")); }
    float m_flJumpPressedTime() { return read<float>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_flJumpPressedTime")); }
    uintptr_t m_fStashGrenadeParameterWhen() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_fStashGrenadeParameterWhen")); }
    uintptr_t m_nButtonDownMaskPrev() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_nButtonDownMaskPrev")); }
    float m_flOffsetTickCompleteTime() { return read<float>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_flOffsetTickCompleteTime")); }
    float m_flOffsetTickStashedSpeed() { return read<float>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_flOffsetTickStashedSpeed")); }
    float m_flStamina() { return read<float>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_flStamina")); }
    float m_flHeightAtJumpStart() { return read<float>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_flHeightAtJumpStart")); }
    float m_flMaxJumpHeightThisJump() { return read<float>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_flMaxJumpHeightThisJump")); }
    float m_flMaxJumpHeightLastJump() { return read<float>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_flMaxJumpHeightLastJump")); }
    float m_flStaminaAtJumpStart() { return read<float>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_flStaminaAtJumpStart")); }
    float m_flAccumulatedJumpError() { return read<float>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_flAccumulatedJumpError")); }
    float m_flTicksSinceLastSurfingDetected() { return read<float>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_flTicksSinceLastSurfingDetected")); }
    bool m_bWasSurfing() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_bWasSurfing")); }
    Vector3 m_vecInputRotated() { return read<Vector3>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_vecInputRotated")); }
    bool m_bJumpApexPending() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayer_MovementServices", "m_bJumpApexPending")); }
};
