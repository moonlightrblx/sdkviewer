#pragma once
#include "../memory.h"

class C_FuncMoveLinear  {
public:
    uintptr_t baseAddr;

    C_FuncMoveLinear() { baseAddr = client_base(); }
    C_FuncMoveLinear(uintptr_t base) : baseAddr(base) {}

};
