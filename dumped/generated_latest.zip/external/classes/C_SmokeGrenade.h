#pragma once
#include "../memory.h"

class C_SmokeGrenade  {
public:
    uintptr_t baseAddr;

    C_SmokeGrenade() { baseAddr = 0; }
    C_SmokeGrenade(uintptr_t base) : baseAddr(base) {}

};
