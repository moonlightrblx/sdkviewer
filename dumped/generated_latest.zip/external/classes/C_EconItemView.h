#pragma once
#include "../memory.h"
#include "../classes/CAttributeList.h"

class C_EconItemView  {
public:
    uintptr_t baseAddr;

    C_EconItemView() { baseAddr = 0; }
    C_EconItemView(uintptr_t base) : baseAddr(base) {}

    bool m_bInventoryImageRgbaRequested() { return read<bool>(baseAddr + offsets_instance.get("C_EconItemView", "m_bInventoryImageRgbaRequested")); }
    bool m_bInventoryImageTriedCache() { return read<bool>(baseAddr + offsets_instance.get("C_EconItemView", "m_bInventoryImageTriedCache")); }
    int m_nInventoryImageRgbaWidth() { return read<int>(baseAddr + offsets_instance.get("C_EconItemView", "m_nInventoryImageRgbaWidth")); }
    int m_nInventoryImageRgbaHeight() { return read<int>(baseAddr + offsets_instance.get("C_EconItemView", "m_nInventoryImageRgbaHeight")); }
    char* m_szCurrentLoadCachedFileName() { return read<char*>(baseAddr + offsets_instance.get("C_EconItemView", "m_szCurrentLoadCachedFileName")); }
    bool m_bRestoreCustomMaterialAfterPrecache() { return read<bool>(baseAddr + offsets_instance.get("C_EconItemView", "m_bRestoreCustomMaterialAfterPrecache")); }
    uint16_t m_iItemDefinitionIndex() { return read<uint16_t>(baseAddr + offsets_instance.get("C_EconItemView", "m_iItemDefinitionIndex")); }
    int m_iEntityQuality() { return read<int>(baseAddr + offsets_instance.get("C_EconItemView", "m_iEntityQuality")); }
    int m_iEntityLevel() { return read<int>(baseAddr + offsets_instance.get("C_EconItemView", "m_iEntityLevel")); }
    uintptr_t m_iItemID() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EconItemView", "m_iItemID")); }
    int m_iItemIDHigh() { return read<int>(baseAddr + offsets_instance.get("C_EconItemView", "m_iItemIDHigh")); }
    int m_iItemIDLow() { return read<int>(baseAddr + offsets_instance.get("C_EconItemView", "m_iItemIDLow")); }
    int m_iAccountID() { return read<int>(baseAddr + offsets_instance.get("C_EconItemView", "m_iAccountID")); }
    int m_iInventoryPosition() { return read<int>(baseAddr + offsets_instance.get("C_EconItemView", "m_iInventoryPosition")); }
    bool m_bInitialized() { return read<bool>(baseAddr + offsets_instance.get("C_EconItemView", "m_bInitialized")); }
    bool m_bDisallowSOC() { return read<bool>(baseAddr + offsets_instance.get("C_EconItemView", "m_bDisallowSOC")); }
    bool m_bIsStoreItem() { return read<bool>(baseAddr + offsets_instance.get("C_EconItemView", "m_bIsStoreItem")); }
    bool m_bIsTradeItem() { return read<bool>(baseAddr + offsets_instance.get("C_EconItemView", "m_bIsTradeItem")); }
    int m_iEntityQuantity() { return read<int>(baseAddr + offsets_instance.get("C_EconItemView", "m_iEntityQuantity")); }
    int m_iRarityOverride() { return read<int>(baseAddr + offsets_instance.get("C_EconItemView", "m_iRarityOverride")); }
    int m_iQualityOverride() { return read<int>(baseAddr + offsets_instance.get("C_EconItemView", "m_iQualityOverride")); }
    int m_iOriginOverride() { return read<int>(baseAddr + offsets_instance.get("C_EconItemView", "m_iOriginOverride")); }
    uint8_t m_ubStyleOverride() { return read<uint8_t>(baseAddr + offsets_instance.get("C_EconItemView", "m_ubStyleOverride")); }
    uint8_t m_unClientFlags() { return read<uint8_t>(baseAddr + offsets_instance.get("C_EconItemView", "m_unClientFlags")); }
    CAttributeList m_AttributeList() { return read<CAttributeList>(baseAddr + offsets_instance.get("C_EconItemView", "m_AttributeList")); }
    CAttributeList m_NetworkedDynamicAttributes() { return read<CAttributeList>(baseAddr + offsets_instance.get("C_EconItemView", "m_NetworkedDynamicAttributes")); }
    char* m_szCustomName() { return read<char*>(baseAddr + offsets_instance.get("C_EconItemView", "m_szCustomName")); }
    char* m_szCustomNameOverride() { return read<char*>(baseAddr + offsets_instance.get("C_EconItemView", "m_szCustomNameOverride")); }
    bool m_bInitializedTags() { return read<bool>(baseAddr + offsets_instance.get("C_EconItemView", "m_bInitializedTags")); }
};
