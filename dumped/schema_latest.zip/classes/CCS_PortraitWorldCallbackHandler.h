#pragma once
#include "../memory.h"

class CCS_PortraitWorldCallbackHandler {
public:
 uintptr_t baseAddr;
 CCS_PortraitWorldCallbackHandler() : baseAddr(0){}
 CCS_PortraitWorldCallbackHandler(uintptr_t b):baseAddr(b){}
};
