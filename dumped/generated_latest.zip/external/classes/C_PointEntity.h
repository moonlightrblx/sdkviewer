#pragma once
#include "../memory.h"

class C_PointEntity  {
public:
    uintptr_t baseAddr;

    C_PointEntity() { baseAddr = client_base(); }
    C_PointEntity(uintptr_t base) : baseAddr(base) {}

};
