#pragma once
#include "../memory.h"

class EventClientPollNetworking_t {
public:
 uintptr_t baseAddr;
 EventClientPollNetworking_t() : baseAddr(0){}
 EventClientPollNetworking_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_nTickCount(){return SCHEMA_TYPE(uintptr_t,0x0);}
};
