#pragma once
#include "../memory.h"

class C_CSTeam {
public:
 uintptr_t baseAddr;
 C_CSTeam() : baseAddr(0){}
 C_CSTeam(uintptr_t b):baseAddr(b){}
 uintptr_t m_szTeamMatchStat(){return SCHEMA_TYPE(uintptr_t,0x6B0);}
 uintptr_t m_numMapVictories(){return SCHEMA_TYPE(uintptr_t,0x8B0);}
 uintptr_t m_bSurrendered(){return SCHEMA_TYPE(uintptr_t,0x8B4);}
 uintptr_t m_scoreFirstHalf(){return SCHEMA_TYPE(uintptr_t,0x8B8);}
 uintptr_t m_scoreSecondHalf(){return SCHEMA_TYPE(uintptr_t,0x8BC);}
 uintptr_t m_scoreOvertime(){return SCHEMA_TYPE(uintptr_t,0x8C0);}
 uintptr_t m_szClanTeamname(){return SCHEMA_TYPE(uintptr_t,0x8C4);}
 uintptr_t m_iClanID(){return SCHEMA_TYPE(uintptr_t,0x948);}
 uintptr_t m_szTeamFlagImage(){return SCHEMA_TYPE(uintptr_t,0x94C);}
 uintptr_t m_szTeamLogoImage(){return SCHEMA_TYPE(uintptr_t,0x954);}
};
