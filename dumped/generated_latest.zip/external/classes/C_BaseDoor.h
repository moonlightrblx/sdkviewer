#pragma once
#include "../memory.h"

class C_BaseDoor  {
public:
    uintptr_t baseAddr;

    C_BaseDoor() { baseAddr = 0; }
    C_BaseDoor(uintptr_t base) : baseAddr(base) {}

    bool m_bIsUsable() { return read<bool>(baseAddr + offsets_instance.get("C_BaseDoor", "m_bIsUsable")); }
};
