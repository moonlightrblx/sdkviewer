#pragma once
#include "../memory.h"

class C_Item  {
public:
    uintptr_t baseAddr;

    C_Item() { baseAddr = 0; }
    C_Item(uintptr_t base) : baseAddr(base) {}

    char* m_pReticleHintTextName() { return read<char*>(baseAddr + offsets_instance.get("C_Item", "m_pReticleHintTextName")); }
};
