#pragma once
#include "../memory.h"

class C_CSGO_TeamIntroCharacterPosition  {
public:
    uintptr_t baseAddr;

    C_CSGO_TeamIntroCharacterPosition() { baseAddr = 0; }
    C_CSGO_TeamIntroCharacterPosition(uintptr_t base) : baseAddr(base) {}

};
