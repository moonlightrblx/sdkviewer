#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_EnvCubemap  {
public:
    uintptr_t baseAddr;

    C_EnvCubemap() { baseAddr = 0; }
    C_EnvCubemap(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_Entity_hCubemapTexture() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvCubemap", "m_Entity_hCubemapTexture")); }
    bool m_Entity_bCustomCubemapTexture() { return read<bool>(baseAddr + offsets_instance.get("C_EnvCubemap", "m_Entity_bCustomCubemapTexture")); }
    float m_Entity_flInfluenceRadius() { return read<float>(baseAddr + offsets_instance.get("C_EnvCubemap", "m_Entity_flInfluenceRadius")); }
    Vector3 m_Entity_vBoxProjectMins() { return read<Vector3>(baseAddr + offsets_instance.get("C_EnvCubemap", "m_Entity_vBoxProjectMins")); }
    Vector3 m_Entity_vBoxProjectMaxs() { return read<Vector3>(baseAddr + offsets_instance.get("C_EnvCubemap", "m_Entity_vBoxProjectMaxs")); }
    bool m_Entity_bMoveable() { return read<bool>(baseAddr + offsets_instance.get("C_EnvCubemap", "m_Entity_bMoveable")); }
    int m_Entity_nHandshake() { return read<int>(baseAddr + offsets_instance.get("C_EnvCubemap", "m_Entity_nHandshake")); }
    int m_Entity_nEnvCubeMapArrayIndex() { return read<int>(baseAddr + offsets_instance.get("C_EnvCubemap", "m_Entity_nEnvCubeMapArrayIndex")); }
    int m_Entity_nPriority() { return read<int>(baseAddr + offsets_instance.get("C_EnvCubemap", "m_Entity_nPriority")); }
    float m_Entity_flEdgeFadeDist() { return read<float>(baseAddr + offsets_instance.get("C_EnvCubemap", "m_Entity_flEdgeFadeDist")); }
    Vector3 m_Entity_vEdgeFadeDists() { return read<Vector3>(baseAddr + offsets_instance.get("C_EnvCubemap", "m_Entity_vEdgeFadeDists")); }
    float m_Entity_flDiffuseScale() { return read<float>(baseAddr + offsets_instance.get("C_EnvCubemap", "m_Entity_flDiffuseScale")); }
    bool m_Entity_bStartDisabled() { return read<bool>(baseAddr + offsets_instance.get("C_EnvCubemap", "m_Entity_bStartDisabled")); }
    bool m_Entity_bDefaultEnvMap() { return read<bool>(baseAddr + offsets_instance.get("C_EnvCubemap", "m_Entity_bDefaultEnvMap")); }
    bool m_Entity_bDefaultSpecEnvMap() { return read<bool>(baseAddr + offsets_instance.get("C_EnvCubemap", "m_Entity_bDefaultSpecEnvMap")); }
    bool m_Entity_bIndoorCubeMap() { return read<bool>(baseAddr + offsets_instance.get("C_EnvCubemap", "m_Entity_bIndoorCubeMap")); }
    bool m_Entity_bCopyDiffuseFromDefaultCubemap() { return read<bool>(baseAddr + offsets_instance.get("C_EnvCubemap", "m_Entity_bCopyDiffuseFromDefaultCubemap")); }
    bool m_Entity_bEnabled() { return read<bool>(baseAddr + offsets_instance.get("C_EnvCubemap", "m_Entity_bEnabled")); }
};
