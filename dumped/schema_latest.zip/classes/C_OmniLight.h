#pragma once
#include "../memory.h"

class C_OmniLight {
public:
 uintptr_t baseAddr;
 C_OmniLight() : baseAddr(0){}
 C_OmniLight(uintptr_t b):baseAddr(b){}
 uintptr_t m_flInnerAngle(){return SCHEMA_TYPE(uintptr_t,0x1200);}
 uintptr_t m_flOuterAngle(){return SCHEMA_TYPE(uintptr_t,0x1204);}
 uintptr_t m_bShowLight(){return SCHEMA_TYPE(uintptr_t,0x1208);}
};
