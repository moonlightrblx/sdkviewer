#pragma once
#include "../memory.h"

class CPulseCell_IsRequirementValid__Criteria_t {
public:
 uintptr_t baseAddr;
 CPulseCell_IsRequirementValid__Criteria_t() : baseAddr(0){}
 CPulseCell_IsRequirementValid__Criteria_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_bIsValid(){return SCHEMA_TYPE(uintptr_t,0x0);}
};
