#pragma once
#include "../memory.h"
class CCSPlayerController;
class C_CSPlayerPawn;

class CDamageRecord  {
public:
    uintptr_t baseAddr;

    CDamageRecord() { baseAddr = 0; }
    CDamageRecord(uintptr_t base) : baseAddr(base) {}

    C_CSPlayerPawn* m_PlayerDamager() { return read<C_CSPlayerPawn*>(baseAddr + offsets_instance.get("CDamageRecord", "m_PlayerDamager")); }
    C_CSPlayerPawn* m_PlayerRecipient() { return read<C_CSPlayerPawn*>(baseAddr + offsets_instance.get("CDamageRecord", "m_PlayerRecipient")); }
    CCSPlayerController* m_hPlayerControllerDamager() { return read<CCSPlayerController*>(baseAddr + offsets_instance.get("CDamageRecord", "m_hPlayerControllerDamager")); }
    CCSPlayerController* m_hPlayerControllerRecipient() { return read<CCSPlayerController*>(baseAddr + offsets_instance.get("CDamageRecord", "m_hPlayerControllerRecipient")); }
    uintptr_t m_szPlayerDamagerName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CDamageRecord", "m_szPlayerDamagerName")); }
    uintptr_t m_szPlayerRecipientName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CDamageRecord", "m_szPlayerRecipientName")); }
    uintptr_t m_DamagerXuid() { return read<uintptr_t>(baseAddr + offsets_instance.get("CDamageRecord", "m_DamagerXuid")); }
    uintptr_t m_RecipientXuid() { return read<uintptr_t>(baseAddr + offsets_instance.get("CDamageRecord", "m_RecipientXuid")); }
    float m_flBulletsDamage() { return read<float>(baseAddr + offsets_instance.get("CDamageRecord", "m_flBulletsDamage")); }
    float m_flDamage() { return read<float>(baseAddr + offsets_instance.get("CDamageRecord", "m_flDamage")); }
    float m_flActualHealthRemoved() { return read<float>(baseAddr + offsets_instance.get("CDamageRecord", "m_flActualHealthRemoved")); }
    int m_iNumHits() { return read<int>(baseAddr + offsets_instance.get("CDamageRecord", "m_iNumHits")); }
    int m_iLastBulletUpdate() { return read<int>(baseAddr + offsets_instance.get("CDamageRecord", "m_iLastBulletUpdate")); }
    bool m_bIsOtherEnemy() { return read<bool>(baseAddr + offsets_instance.get("CDamageRecord", "m_bIsOtherEnemy")); }
    uintptr_t m_killType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CDamageRecord", "m_killType")); }
};
