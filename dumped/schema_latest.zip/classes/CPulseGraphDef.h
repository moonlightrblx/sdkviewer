#pragma once
#include "../memory.h"

class CPulseGraphDef {
public:
 uintptr_t baseAddr;
 CPulseGraphDef() : baseAddr(0){}
 CPulseGraphDef(uintptr_t b):baseAddr(b){}
 uintptr_t m_DomainIdentifier(){return SCHEMA_TYPE(uintptr_t,0x8);}
 uintptr_t m_DomainSubType(){return SCHEMA_TYPE(uintptr_t,0x18);}
 uintptr_t m_ParentMapName(){return SCHEMA_TYPE(uintptr_t,0x30);}
 uintptr_t m_ParentXmlName(){return SCHEMA_TYPE(uintptr_t,0x40);}
 uintptr_t m_Chunks(){return SCHEMA_TYPE(uintptr_t,0x50);}
 uintptr_t m_Cells(){return SCHEMA_TYPE(uintptr_t,0x68);}
 uintptr_t m_Vars(){return SCHEMA_TYPE(uintptr_t,0x80);}
 uintptr_t m_PublicOutputs(){return SCHEMA_TYPE(uintptr_t,0x98);}
 uintptr_t m_InvokeBindings(){return SCHEMA_TYPE(uintptr_t,0xB0);}
 uintptr_t m_CallInfos(){return SCHEMA_TYPE(uintptr_t,0xC8);}
 uintptr_t m_Constants(){return SCHEMA_TYPE(uintptr_t,0xE0);}
 uintptr_t m_DomainValues(){return SCHEMA_TYPE(uintptr_t,0xF8);}
 uintptr_t m_BlackboardReferences(){return SCHEMA_TYPE(uintptr_t,0x110);}
 uintptr_t m_OutputConnections(){return SCHEMA_TYPE(uintptr_t,0x128);}
};
