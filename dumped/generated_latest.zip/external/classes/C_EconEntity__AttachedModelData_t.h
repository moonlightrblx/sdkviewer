#pragma once
#include "../memory.h"

class C_EconEntity__AttachedModelData_t  {
public:
    uintptr_t baseAddr;

    C_EconEntity__AttachedModelData_t() { baseAddr = client_base(); }
    C_EconEntity__AttachedModelData_t(uintptr_t base) : baseAddr(base) {}

    int m_iModelDisplayFlags() { return read<int>(baseAddr + offsets_instance.get("C_EconEntity__AttachedModelData_t", "m_iModelDisplayFlags")); }
};
