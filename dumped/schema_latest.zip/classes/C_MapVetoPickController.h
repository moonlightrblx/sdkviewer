#pragma once
#include "../memory.h"

class C_MapVetoPickController {
public:
 uintptr_t baseAddr;
 C_MapVetoPickController() : baseAddr(0){}
 C_MapVetoPickController(uintptr_t b):baseAddr(b){}
 uintptr_t m_nDraftType(){return SCHEMA_TYPE(uintptr_t,0x608);}
 uintptr_t m_nTeamWinningCoinToss(){return SCHEMA_TYPE(uintptr_t,0x60C);}
 uintptr_t m_nTeamWithFirstChoice(){return SCHEMA_TYPE(uintptr_t,0x610);}
 uintptr_t m_nVoteMapIdsList(){return SCHEMA_TYPE(uintptr_t,0x710);}
 uintptr_t m_nAccountIDs(){return SCHEMA_TYPE(uintptr_t,0x72C);}
 uintptr_t m_nMapId0(){return SCHEMA_TYPE(uintptr_t,0x82C);}
 uintptr_t m_nMapId1(){return SCHEMA_TYPE(uintptr_t,0x92C);}
 uintptr_t m_nMapId2(){return SCHEMA_TYPE(uintptr_t,0xA2C);}
 uintptr_t m_nMapId3(){return SCHEMA_TYPE(uintptr_t,0xB2C);}
 uintptr_t m_nMapId4(){return SCHEMA_TYPE(uintptr_t,0xC2C);}
 uintptr_t m_nMapId5(){return SCHEMA_TYPE(uintptr_t,0xD2C);}
 uintptr_t m_nStartingSide0(){return SCHEMA_TYPE(uintptr_t,0xE2C);}
 uintptr_t m_nCurrentPhase(){return SCHEMA_TYPE(uintptr_t,0xF2C);}
 uintptr_t m_nPhaseStartTick(){return SCHEMA_TYPE(uintptr_t,0xF30);}
 uintptr_t m_nPhaseDurationTicks(){return SCHEMA_TYPE(uintptr_t,0xF34);}
 uintptr_t m_nPostDataUpdateTick(){return SCHEMA_TYPE(uintptr_t,0xF38);}
 uintptr_t m_bDisabledHud(){return SCHEMA_TYPE(uintptr_t,0xF3C);}
};
