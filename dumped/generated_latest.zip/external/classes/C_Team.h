#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_Team  {
public:
    uintptr_t baseAddr;

    C_Team() { baseAddr = 0; }
    C_Team(uintptr_t base) : baseAddr(base) {}

    Vector3 m_aPlayerControllers() { return read<Vector3>(baseAddr + offsets_instance.get("C_Team", "m_aPlayerControllers")); }
    Vector3 m_aPlayers() { return read<Vector3>(baseAddr + offsets_instance.get("C_Team", "m_aPlayers")); }
    int m_iScore() { return read<int>(baseAddr + offsets_instance.get("C_Team", "m_iScore")); }
    char* m_szTeamname() { return read<char*>(baseAddr + offsets_instance.get("C_Team", "m_szTeamname")); }
};
