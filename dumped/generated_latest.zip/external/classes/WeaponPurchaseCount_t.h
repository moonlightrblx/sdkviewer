#pragma once
#include "../memory.h"

class WeaponPurchaseCount_t  {
public:
    uintptr_t baseAddr;

    WeaponPurchaseCount_t() { baseAddr = client_base(); }
    WeaponPurchaseCount_t(uintptr_t base) : baseAddr(base) {}

    uint16_t m_nItemDefIndex() { return read<uint16_t>(baseAddr + offsets_instance.get("WeaponPurchaseCount_t", "m_nItemDefIndex")); }
    uint16_t m_nCount() { return read<uint16_t>(baseAddr + offsets_instance.get("WeaponPurchaseCount_t", "m_nCount")); }
};
