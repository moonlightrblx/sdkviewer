#pragma once
#include "../memory.h"

class C_Knife  {
public:
    uintptr_t baseAddr;

    C_Knife() { baseAddr = 0; }
    C_Knife(uintptr_t base) : baseAddr(base) {}

    bool m_bFirstAttack() { return read<bool>(baseAddr + offsets_instance.get("C_Knife", "m_bFirstAttack")); }
};
