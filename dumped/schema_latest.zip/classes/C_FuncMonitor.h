#pragma once
#include "../memory.h"

class C_FuncMonitor {
public:
 uintptr_t baseAddr;
 C_FuncMonitor() : baseAddr(0){}
 C_FuncMonitor(uintptr_t b):baseAddr(b){}
 uintptr_t m_targetCamera(){return SCHEMA_TYPE(uintptr_t,0xEB0);}
 uintptr_t m_nResolutionEnum(){return SCHEMA_TYPE(uintptr_t,0xEB8);}
 uintptr_t m_bRenderShadows(){return SCHEMA_TYPE(uintptr_t,0xEBC);}
 uintptr_t m_bUseUniqueColorTarget(){return SCHEMA_TYPE(uintptr_t,0xEBD);}
 uintptr_t m_brushModelName(){return SCHEMA_TYPE(uintptr_t,0xEC0);}
 uintptr_t m_hTargetCamera(){return SCHEMA_TYPE(uintptr_t,0xEC8);}
 uintptr_t m_bEnabled(){return SCHEMA_TYPE(uintptr_t,0xECC);}
 uintptr_t m_bDraw3DSkybox(){return SCHEMA_TYPE(uintptr_t,0xECD);}
};
