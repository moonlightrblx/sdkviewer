#pragma once
#include "../memory.h"

class CBasePulseGraphInstance {
public:
 uintptr_t baseAddr;
 CBasePulseGraphInstance() : baseAddr(0){}
 CBasePulseGraphInstance(uintptr_t b):baseAddr(b){}
};
