#pragma once
#include "../memory.h"

class C_CS2HudModelBase {
public:
 uintptr_t baseAddr;
 C_CS2HudModelBase() : baseAddr(0){}
 C_CS2HudModelBase(uintptr_t b):baseAddr(b){}
};
