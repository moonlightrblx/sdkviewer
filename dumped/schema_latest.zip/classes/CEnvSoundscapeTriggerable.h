#pragma once
#include "../memory.h"

class CEnvSoundscapeTriggerable {
public:
 uintptr_t baseAddr;
 CEnvSoundscapeTriggerable() : baseAddr(0){}
 CEnvSoundscapeTriggerable(uintptr_t b):baseAddr(b){}
};
