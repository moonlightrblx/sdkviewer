#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_BaseCombatCharacter  {
public:
    uintptr_t baseAddr;

    C_BaseCombatCharacter() { baseAddr = client_base(); }
    C_BaseCombatCharacter(uintptr_t base) : baseAddr(base) {}

    Vector3 m_hMyWearables() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseCombatCharacter", "m_hMyWearables")); }
    uintptr_t m_leftFootAttachment() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseCombatCharacter", "m_leftFootAttachment")); }
    uintptr_t m_rightFootAttachment() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseCombatCharacter", "m_rightFootAttachment")); }
    uintptr_t m_nWaterWakeMode() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseCombatCharacter", "m_nWaterWakeMode")); }
    float m_flWaterWorldZ() { return read<float>(baseAddr + offsets_instance.get("C_BaseCombatCharacter", "m_flWaterWorldZ")); }
    float m_flWaterNextTraceTime() { return read<float>(baseAddr + offsets_instance.get("C_BaseCombatCharacter", "m_flWaterNextTraceTime")); }
};
