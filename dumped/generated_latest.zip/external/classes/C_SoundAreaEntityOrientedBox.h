#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_SoundAreaEntityOrientedBox  {
public:
    uintptr_t baseAddr;

    C_SoundAreaEntityOrientedBox() { baseAddr = client_base(); }
    C_SoundAreaEntityOrientedBox(uintptr_t base) : baseAddr(base) {}

    Vector3 m_vMin() { return read<Vector3>(baseAddr + offsets_instance.get("C_SoundAreaEntityOrientedBox", "m_vMin")); }
    Vector3 m_vMax() { return read<Vector3>(baseAddr + offsets_instance.get("C_SoundAreaEntityOrientedBox", "m_vMax")); }
};
