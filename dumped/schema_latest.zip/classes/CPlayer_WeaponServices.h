#pragma once
#include "../memory.h"

class CPlayer_WeaponServices {
public:
 uintptr_t baseAddr;
 CPlayer_WeaponServices() : baseAddr(0){}
 CPlayer_WeaponServices(uintptr_t b):baseAddr(b){}
 uintptr_t m_hMyWeapons(){return SCHEMA_TYPE(uintptr_t,0x40);}
 uintptr_t m_hActiveWeapon(){return SCHEMA_TYPE(uintptr_t,0x58);}
 uintptr_t m_hLastWeapon(){return SCHEMA_TYPE(uintptr_t,0x5C);}
 uintptr_t m_iAmmo(){return SCHEMA_TYPE(uintptr_t,0x60);}
};
