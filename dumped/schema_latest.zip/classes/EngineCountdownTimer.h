#pragma once
#include "../memory.h"

class EngineCountdownTimer {
public:
 uintptr_t baseAddr;
 EngineCountdownTimer() : baseAddr(0){}
 EngineCountdownTimer(uintptr_t b):baseAddr(b){}
 uintptr_t m_duration(){return SCHEMA_TYPE(uintptr_t,0x8);}
 uintptr_t m_timestamp(){return SCHEMA_TYPE(uintptr_t,0xC);}
 uintptr_t m_timescale(){return SCHEMA_TYPE(uintptr_t,0x10);}
};
