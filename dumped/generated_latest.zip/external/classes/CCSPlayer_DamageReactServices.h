#pragma once
#include "../memory.h"

class CCSPlayer_DamageReactServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_DamageReactServices() { baseAddr = client_base(); }
    CCSPlayer_DamageReactServices(uintptr_t base) : baseAddr(base) {}

};
