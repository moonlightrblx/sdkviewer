#pragma once
#include "../memory.h"

class CEntityIdentity  {
public:
    uintptr_t baseAddr;

    CEntityIdentity() { baseAddr = 0; }
    CEntityIdentity(uintptr_t base) : baseAddr(base) {}

    int m_nameStringableIndex() { return read<int>(baseAddr + offsets_instance.get("CEntityIdentity", "m_nameStringableIndex")); }
    uintptr_t m_name() { return read<uintptr_t>(baseAddr + offsets_instance.get("CEntityIdentity", "m_name")); }
    uintptr_t m_designerName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CEntityIdentity", "m_designerName")); }
    int m_flags() { return read<int>(baseAddr + offsets_instance.get("CEntityIdentity", "m_flags")); }
    uintptr_t m_worldGroupId() { return read<uintptr_t>(baseAddr + offsets_instance.get("CEntityIdentity", "m_worldGroupId")); }
    int m_fDataObjectTypes() { return read<int>(baseAddr + offsets_instance.get("CEntityIdentity", "m_fDataObjectTypes")); }
    uintptr_t m_PathIndex() { return read<uintptr_t>(baseAddr + offsets_instance.get("CEntityIdentity", "m_PathIndex")); }
    CEntityIdentity* m_pPrev() { return read<CEntityIdentity*>(baseAddr + offsets_instance.get("CEntityIdentity", "m_pPrev")); }
    CEntityIdentity* m_pNext() { return read<CEntityIdentity*>(baseAddr + offsets_instance.get("CEntityIdentity", "m_pNext")); }
    CEntityIdentity* m_pPrevByClass() { return read<CEntityIdentity*>(baseAddr + offsets_instance.get("CEntityIdentity", "m_pPrevByClass")); }
    CEntityIdentity* m_pNextByClass() { return read<CEntityIdentity*>(baseAddr + offsets_instance.get("CEntityIdentity", "m_pNextByClass")); }
};
