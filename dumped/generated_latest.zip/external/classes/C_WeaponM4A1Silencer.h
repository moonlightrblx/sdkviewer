#pragma once
#include "../memory.h"

class C_WeaponM4A1Silencer  {
public:
    uintptr_t baseAddr;

    C_WeaponM4A1Silencer() { baseAddr = client_base(); }
    C_WeaponM4A1Silencer(uintptr_t base) : baseAddr(base) {}

};
