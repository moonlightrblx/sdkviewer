#pragma once
#include "../memory.h"

class CBaseAnimGraphController {
public:
 uintptr_t baseAddr;
 CBaseAnimGraphController() : baseAddr(0){}
 CBaseAnimGraphController(uintptr_t b):baseAddr(b){}
 uintptr_t m_animGraphNetworkedVars(){return SCHEMA_TYPE(uintptr_t,0x18);}
 uintptr_t m_bSequenceFinished(){return SCHEMA_TYPE(uintptr_t,0x14A8);}
 uintptr_t m_flSoundSyncTime(){return SCHEMA_TYPE(uintptr_t,0x14AC);}
 uintptr_t m_nActiveIKChainMask(){return SCHEMA_TYPE(uintptr_t,0x14B0);}
 uintptr_t m_hSequence(){return SCHEMA_TYPE(uintptr_t,0x14B4);}
 uintptr_t m_flSeqStartTime(){return SCHEMA_TYPE(uintptr_t,0x14B8);}
 uintptr_t m_flSeqFixedCycle(){return SCHEMA_TYPE(uintptr_t,0x14BC);}
 uintptr_t m_nAnimLoopMode(){return SCHEMA_TYPE(uintptr_t,0x14C0);}
 uintptr_t m_flPlaybackRate(){return SCHEMA_TYPE(uintptr_t,0x14C4);}
 uintptr_t m_nNotifyState(){return SCHEMA_TYPE(uintptr_t,0x14D0);}
 uintptr_t m_bNetworkedAnimationInputsChanged(){return SCHEMA_TYPE(uintptr_t,0x14D2);}
 uintptr_t m_bNetworkedSequenceChanged(){return SCHEMA_TYPE(uintptr_t,0x14D3);}
 uintptr_t m_bLastUpdateSkipped(){return SCHEMA_TYPE(uintptr_t,0x14D4);}
 uintptr_t m_flPrevAnimUpdateTime(){return SCHEMA_TYPE(uintptr_t,0x14D8);}
 uintptr_t m_hGraphDefinitionAG2(){return SCHEMA_TYPE(uintptr_t,0x1860);}
 uintptr_t m_bIsUsingAG2(){return SCHEMA_TYPE(uintptr_t,0x1868);}
 uintptr_t m_serializedPoseRecipeAG2(){return SCHEMA_TYPE(uintptr_t,0x1870);}
 uintptr_t m_nSerializePoseRecipeSizeAG2(){return SCHEMA_TYPE(uintptr_t,0x1888);}
 uintptr_t m_nSerializePoseRecipeVersionAG2(){return SCHEMA_TYPE(uintptr_t,0x188C);}
 uintptr_t m_nGraphCreationFlagsAG2(){return SCHEMA_TYPE(uintptr_t,0x1890);}
 uintptr_t m_nServerGraphDefReloadCountAG2(){return SCHEMA_TYPE(uintptr_t,0x1A7C);}
 uintptr_t m_nServerSerializationContextIteration(){return SCHEMA_TYPE(uintptr_t,0x1A84);}
};
