#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_EnvVolumetricFogController  {
public:
    uintptr_t baseAddr;

    C_EnvVolumetricFogController() { baseAddr = client_base(); }
    C_EnvVolumetricFogController(uintptr_t base) : baseAddr(base) {}

    float m_flScattering() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_flScattering")); }
    uintptr_t m_TintColor() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_TintColor")); }
    float m_flAnisotropy() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_flAnisotropy")); }
    float m_flFadeSpeed() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_flFadeSpeed")); }
    float m_flDrawDistance() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_flDrawDistance")); }
    float m_flFadeInStart() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_flFadeInStart")); }
    float m_flFadeInEnd() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_flFadeInEnd")); }
    float m_flIndirectStrength() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_flIndirectStrength")); }
    int m_nVolumeDepth() { return read<int>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_nVolumeDepth")); }
    float m_fFirstVolumeSliceThickness() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_fFirstVolumeSliceThickness")); }
    int m_nIndirectTextureDimX() { return read<int>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_nIndirectTextureDimX")); }
    int m_nIndirectTextureDimY() { return read<int>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_nIndirectTextureDimY")); }
    int m_nIndirectTextureDimZ() { return read<int>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_nIndirectTextureDimZ")); }
    Vector3 m_vBoxMins() { return read<Vector3>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_vBoxMins")); }
    Vector3 m_vBoxMaxs() { return read<Vector3>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_vBoxMaxs")); }
    bool m_bActive() { return read<bool>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_bActive")); }
    uintptr_t m_flStartAnisoTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_flStartAnisoTime")); }
    uintptr_t m_flStartScatterTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_flStartScatterTime")); }
    uintptr_t m_flStartDrawDistanceTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_flStartDrawDistanceTime")); }
    float m_flStartAnisotropy() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_flStartAnisotropy")); }
    float m_flStartScattering() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_flStartScattering")); }
    float m_flStartDrawDistance() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_flStartDrawDistance")); }
    float m_flDefaultAnisotropy() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_flDefaultAnisotropy")); }
    float m_flDefaultScattering() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_flDefaultScattering")); }
    float m_flDefaultDrawDistance() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_flDefaultDrawDistance")); }
    bool m_bStartDisabled() { return read<bool>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_bStartDisabled")); }
    bool m_bEnableIndirect() { return read<bool>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_bEnableIndirect")); }
    bool m_bIsMaster() { return read<bool>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_bIsMaster")); }
    uintptr_t m_hFogIndirectTexture() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_hFogIndirectTexture")); }
    int m_nForceRefreshCount() { return read<int>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_nForceRefreshCount")); }
    float m_fNoiseSpeed() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_fNoiseSpeed")); }
    float m_fNoiseStrength() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_fNoiseStrength")); }
    Vector3 m_vNoiseScale() { return read<Vector3>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_vNoiseScale")); }
    float m_fWindSpeed() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_fWindSpeed")); }
    Vector3 m_vWindDirection() { return read<Vector3>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_vWindDirection")); }
    bool m_bFirstTime() { return read<bool>(baseAddr + offsets_instance.get("C_EnvVolumetricFogController", "m_bFirstTime")); }
};
