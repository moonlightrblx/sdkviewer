#pragma once
#include "../memory.h"
#include "../classes/CountdownTimer.h"
#include "../types/Vector3.h"
class CInfoFan;

class CTriggerFan  {
public:
    uintptr_t baseAddr;

    CTriggerFan() { baseAddr = 0; }
    CTriggerFan(uintptr_t base) : baseAddr(base) {}

    Vector3 m_vFanOriginOffset() { return read<Vector3>(baseAddr + offsets_instance.get("CTriggerFan", "m_vFanOriginOffset")); }
    Vector3 m_vDirection() { return read<Vector3>(baseAddr + offsets_instance.get("CTriggerFan", "m_vDirection")); }
    bool m_bPushTowardsInfoTarget() { return read<bool>(baseAddr + offsets_instance.get("CTriggerFan", "m_bPushTowardsInfoTarget")); }
    bool m_bPushAwayFromInfoTarget() { return read<bool>(baseAddr + offsets_instance.get("CTriggerFan", "m_bPushAwayFromInfoTarget")); }
    uintptr_t m_qNoiseDelta() { return read<uintptr_t>(baseAddr + offsets_instance.get("CTriggerFan", "m_qNoiseDelta")); }
    CInfoFan* m_hInfoFan() { return read<CInfoFan*>(baseAddr + offsets_instance.get("CTriggerFan", "m_hInfoFan")); }
    float m_flForce() { return read<float>(baseAddr + offsets_instance.get("CTriggerFan", "m_flForce")); }
    bool m_bFalloff() { return read<bool>(baseAddr + offsets_instance.get("CTriggerFan", "m_bFalloff")); }
    CountdownTimer m_RampTimer() { return read<CountdownTimer>(baseAddr + offsets_instance.get("CTriggerFan", "m_RampTimer")); }
};
