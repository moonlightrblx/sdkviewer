#pragma once
#include "../memory.h"

class CLogicRelayAPI  {
public:
    uintptr_t baseAddr;

    CLogicRelayAPI() { baseAddr = client_base(); }
    CLogicRelayAPI(uintptr_t base) : baseAddr(base) {}

};
