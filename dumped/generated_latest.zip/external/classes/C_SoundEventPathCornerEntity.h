#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_SoundEventPathCornerEntity  {
public:
    uintptr_t baseAddr;

    C_SoundEventPathCornerEntity() { baseAddr = client_base(); }
    C_SoundEventPathCornerEntity(uintptr_t base) : baseAddr(base) {}

    Vector3 m_vecCornerPairsNetworked() { return read<Vector3>(baseAddr + offsets_instance.get("C_SoundEventPathCornerEntity", "m_vecCornerPairsNetworked")); }
};
