#pragma once
#include "../memory.h"

class C_FuncTrackTrain  {
public:
    uintptr_t baseAddr;

    C_FuncTrackTrain() { baseAddr = 0; }
    C_FuncTrackTrain(uintptr_t base) : baseAddr(base) {}

    int m_nLongAxis() { return read<int>(baseAddr + offsets_instance.get("C_FuncTrackTrain", "m_nLongAxis")); }
    float m_flRadius() { return read<float>(baseAddr + offsets_instance.get("C_FuncTrackTrain", "m_flRadius")); }
    float m_flLineLength() { return read<float>(baseAddr + offsets_instance.get("C_FuncTrackTrain", "m_flLineLength")); }
};
