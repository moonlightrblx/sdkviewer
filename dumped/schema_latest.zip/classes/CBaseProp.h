#pragma once
#include "../memory.h"

class CBaseProp {
public:
 uintptr_t baseAddr;
 CBaseProp() : baseAddr(0){}
 CBaseProp(uintptr_t b):baseAddr(b){}
 uintptr_t m_bModelOverrodeBlockLOS(){return SCHEMA_TYPE(uintptr_t,0x1158);}
 uintptr_t m_iShapeType(){return SCHEMA_TYPE(uintptr_t,0x115C);}
 uintptr_t m_bConformToCollisionBounds(){return SCHEMA_TYPE(uintptr_t,0x1160);}
 uintptr_t m_mPreferredCatchTransform(){return SCHEMA_TYPE(uintptr_t,0x1170);}
};
