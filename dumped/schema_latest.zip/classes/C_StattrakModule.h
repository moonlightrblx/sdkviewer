#pragma once
#include "../memory.h"

class C_StattrakModule {
public:
 uintptr_t baseAddr;
 C_StattrakModule() : baseAddr(0){}
 C_StattrakModule(uintptr_t b):baseAddr(b){}
 uintptr_t m_bKnife(){return SCHEMA_TYPE(uintptr_t,0x1160);}
};
