#pragma once
#include "../memory.h"

class CFilterProximity  {
public:
    uintptr_t baseAddr;

    CFilterProximity() { baseAddr = 0; }
    CFilterProximity(uintptr_t base) : baseAddr(base) {}

    float m_flRadius() { return read<float>(baseAddr + offsets_instance.get("CFilterProximity", "m_flRadius")); }
};
