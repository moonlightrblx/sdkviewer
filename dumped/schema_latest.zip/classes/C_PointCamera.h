#pragma once
#include "../memory.h"

class C_PointCamera {
public:
 uintptr_t baseAddr;
 C_PointCamera() : baseAddr(0){}
 C_PointCamera(uintptr_t b):baseAddr(b){}
 uintptr_t m_FOV(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_Resolution(){return SCHEMA_TYPE(uintptr_t,0x5FC);}
 uintptr_t m_bFogEnable(){return SCHEMA_TYPE(uintptr_t,0x600);}
 uintptr_t m_FogColor(){return SCHEMA_TYPE(uintptr_t,0x601);}
 uintptr_t m_flFogStart(){return SCHEMA_TYPE(uintptr_t,0x608);}
 uintptr_t m_flFogEnd(){return SCHEMA_TYPE(uintptr_t,0x60C);}
 uintptr_t m_flFogMaxDensity(){return SCHEMA_TYPE(uintptr_t,0x610);}
 uintptr_t m_bActive(){return SCHEMA_TYPE(uintptr_t,0x614);}
 uintptr_t m_bUseScreenAspectRatio(){return SCHEMA_TYPE(uintptr_t,0x615);}
 uintptr_t m_flAspectRatio(){return SCHEMA_TYPE(uintptr_t,0x618);}
 uintptr_t m_bNoSky(){return SCHEMA_TYPE(uintptr_t,0x61C);}
 uintptr_t m_fBrightness(){return SCHEMA_TYPE(uintptr_t,0x620);}
 uintptr_t m_flZFar(){return SCHEMA_TYPE(uintptr_t,0x624);}
 uintptr_t m_flZNear(){return SCHEMA_TYPE(uintptr_t,0x628);}
 uintptr_t m_bCanHLTVUse(){return SCHEMA_TYPE(uintptr_t,0x62C);}
 uintptr_t m_bAlignWithParent(){return SCHEMA_TYPE(uintptr_t,0x62D);}
 uintptr_t m_bDofEnabled(){return SCHEMA_TYPE(uintptr_t,0x62E);}
 uintptr_t m_flDofNearBlurry(){return SCHEMA_TYPE(uintptr_t,0x630);}
 uintptr_t m_flDofNearCrisp(){return SCHEMA_TYPE(uintptr_t,0x634);}
 uintptr_t m_flDofFarCrisp(){return SCHEMA_TYPE(uintptr_t,0x638);}
 uintptr_t m_flDofFarBlurry(){return SCHEMA_TYPE(uintptr_t,0x63C);}
 uintptr_t m_flDofTiltToGround(){return SCHEMA_TYPE(uintptr_t,0x640);}
 uintptr_t m_TargetFOV(){return SCHEMA_TYPE(uintptr_t,0x644);}
 uintptr_t m_DegreesPerSecond(){return SCHEMA_TYPE(uintptr_t,0x648);}
 uintptr_t m_bIsOn(){return SCHEMA_TYPE(uintptr_t,0x64C);}
 uintptr_t m_pNext(){return SCHEMA_TYPE(uintptr_t,0x650);}
};
