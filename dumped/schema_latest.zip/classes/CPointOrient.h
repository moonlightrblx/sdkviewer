#pragma once
#include "../memory.h"

class CPointOrient {
public:
 uintptr_t baseAddr;
 CPointOrient() : baseAddr(0){}
 CPointOrient(uintptr_t b):baseAddr(b){}
 uintptr_t m_iszSpawnTargetName(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_hTarget(){return SCHEMA_TYPE(uintptr_t,0x600);}
 uintptr_t m_bActive(){return SCHEMA_TYPE(uintptr_t,0x604);}
 uintptr_t m_nGoalDirection(){return SCHEMA_TYPE(uintptr_t,0x608);}
 uintptr_t m_nConstraint(){return SCHEMA_TYPE(uintptr_t,0x60C);}
 uintptr_t m_flMaxTurnRate(){return SCHEMA_TYPE(uintptr_t,0x610);}
 uintptr_t m_flLastGameTime(){return SCHEMA_TYPE(uintptr_t,0x614);}
};
