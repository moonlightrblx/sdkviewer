#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_BaseFlex  {
public:
    uintptr_t baseAddr;

    C_BaseFlex() { baseAddr = client_base(); }
    C_BaseFlex(uintptr_t base) : baseAddr(base) {}

    float m_flexWeight() { return read<float>(baseAddr + offsets_instance.get("C_BaseFlex", "m_flexWeight")); }
    Vector3 m_vLookTargetPosition() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseFlex", "m_vLookTargetPosition")); }
    bool m_blinktoggle() { return read<bool>(baseAddr + offsets_instance.get("C_BaseFlex", "m_blinktoggle")); }
    int m_nLastFlexUpdateFrameCount() { return read<int>(baseAddr + offsets_instance.get("C_BaseFlex", "m_nLastFlexUpdateFrameCount")); }
    Vector3 m_CachedViewTarget() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseFlex", "m_CachedViewTarget")); }
    uintptr_t m_nNextSceneEventId() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseFlex", "m_nNextSceneEventId")); }
    int m_iBlink() { return read<int>(baseAddr + offsets_instance.get("C_BaseFlex", "m_iBlink")); }
    float m_blinktime() { return read<float>(baseAddr + offsets_instance.get("C_BaseFlex", "m_blinktime")); }
    bool m_prevblinktoggle() { return read<bool>(baseAddr + offsets_instance.get("C_BaseFlex", "m_prevblinktoggle")); }
    int m_iJawOpen() { return read<int>(baseAddr + offsets_instance.get("C_BaseFlex", "m_iJawOpen")); }
    float m_flJawOpenAmount() { return read<float>(baseAddr + offsets_instance.get("C_BaseFlex", "m_flJawOpenAmount")); }
    float m_flBlinkAmount() { return read<float>(baseAddr + offsets_instance.get("C_BaseFlex", "m_flBlinkAmount")); }
    uintptr_t m_iMouthAttachment() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseFlex", "m_iMouthAttachment")); }
    uintptr_t m_iEyeAttachment() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseFlex", "m_iEyeAttachment")); }
    bool m_bResetFlexWeightsOnModelChange() { return read<bool>(baseAddr + offsets_instance.get("C_BaseFlex", "m_bResetFlexWeightsOnModelChange")); }
    int m_nEyeOcclusionRendererBone() { return read<int>(baseAddr + offsets_instance.get("C_BaseFlex", "m_nEyeOcclusionRendererBone")); }
    uintptr_t m_mEyeOcclusionRendererCameraToBoneTransform() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseFlex", "m_mEyeOcclusionRendererCameraToBoneTransform")); }
    Vector3 m_vEyeOcclusionRendererHalfExtent() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseFlex", "m_vEyeOcclusionRendererHalfExtent")); }
    uintptr_t m_PhonemeClasses() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseFlex", "m_PhonemeClasses")); }
};
