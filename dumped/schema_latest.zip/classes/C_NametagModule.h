#pragma once
#include "../memory.h"

class C_NametagModule {
public:
 uintptr_t baseAddr;
 C_NametagModule() : baseAddr(0){}
 C_NametagModule(uintptr_t b):baseAddr(b){}
 uintptr_t m_strNametagString(){return SCHEMA_TYPE(uintptr_t,0x1160);}
};
