#pragma once
#include "../memory.h"
class CEntityComponentHelper;

class EntComponentInfo_t  {
public:
    uintptr_t baseAddr;

    EntComponentInfo_t() { baseAddr = 0; }
    EntComponentInfo_t(uintptr_t base) : baseAddr(base) {}

    uintptr_t* m_pName() { return read<uintptr_t*>(baseAddr + offsets_instance.get("EntComponentInfo_t", "m_pName")); }
    uintptr_t* m_pCPPClassname() { return read<uintptr_t*>(baseAddr + offsets_instance.get("EntComponentInfo_t", "m_pCPPClassname")); }
    uintptr_t* m_pNetworkDataReferencedDescription() { return read<uintptr_t*>(baseAddr + offsets_instance.get("EntComponentInfo_t", "m_pNetworkDataReferencedDescription")); }
    uintptr_t* m_pNetworkDataReferencedPtrPropDescription() { return read<uintptr_t*>(baseAddr + offsets_instance.get("EntComponentInfo_t", "m_pNetworkDataReferencedPtrPropDescription")); }
    int m_nRuntimeIndex() { return read<int>(baseAddr + offsets_instance.get("EntComponentInfo_t", "m_nRuntimeIndex")); }
    int m_nFlags() { return read<int>(baseAddr + offsets_instance.get("EntComponentInfo_t", "m_nFlags")); }
    CEntityComponentHelper* m_pBaseClassComponentHelper() { return read<CEntityComponentHelper*>(baseAddr + offsets_instance.get("EntComponentInfo_t", "m_pBaseClassComponentHelper")); }
};
