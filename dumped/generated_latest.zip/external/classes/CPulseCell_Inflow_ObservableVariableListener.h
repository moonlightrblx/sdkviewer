#pragma once
#include "../memory.h"

class CPulseCell_Inflow_ObservableVariableListener  {
public:
    uintptr_t baseAddr;

    CPulseCell_Inflow_ObservableVariableListener() { baseAddr = 0; }
    CPulseCell_Inflow_ObservableVariableListener(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_nBlackboardReference() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Inflow_ObservableVariableListener", "m_nBlackboardReference")); }
    bool m_bSelfReference() { return read<bool>(baseAddr + offsets_instance.get("CPulseCell_Inflow_ObservableVariableListener", "m_bSelfReference")); }
};
