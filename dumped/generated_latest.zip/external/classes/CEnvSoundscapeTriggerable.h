#pragma once
#include "../memory.h"

class CEnvSoundscapeTriggerable  {
public:
    uintptr_t baseAddr;

    CEnvSoundscapeTriggerable() { baseAddr = client_base(); }
    CEnvSoundscapeTriggerable(uintptr_t base) : baseAddr(base) {}

};
