#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class CInfoDynamicShadowHintBox  {
public:
    uintptr_t baseAddr;

    CInfoDynamicShadowHintBox() { baseAddr = client_base(); }
    CInfoDynamicShadowHintBox(uintptr_t base) : baseAddr(base) {}

    Vector3 m_vBoxMins() { return read<Vector3>(baseAddr + offsets_instance.get("CInfoDynamicShadowHintBox", "m_vBoxMins")); }
    Vector3 m_vBoxMaxs() { return read<Vector3>(baseAddr + offsets_instance.get("CInfoDynamicShadowHintBox", "m_vBoxMaxs")); }
};
