#pragma once
#include "../memory.h"
class C_PointClientUIWorldPanel;

class CPointOffScreenIndicatorUi  {
public:
    uintptr_t baseAddr;

    CPointOffScreenIndicatorUi() { baseAddr = 0; }
    CPointOffScreenIndicatorUi(uintptr_t base) : baseAddr(base) {}

    bool m_bBeenEnabled() { return read<bool>(baseAddr + offsets_instance.get("CPointOffScreenIndicatorUi", "m_bBeenEnabled")); }
    bool m_bHide() { return read<bool>(baseAddr + offsets_instance.get("CPointOffScreenIndicatorUi", "m_bHide")); }
    float m_flSeenTargetTime() { return read<float>(baseAddr + offsets_instance.get("CPointOffScreenIndicatorUi", "m_flSeenTargetTime")); }
    C_PointClientUIWorldPanel* m_pTargetPanel() { return read<C_PointClientUIWorldPanel*>(baseAddr + offsets_instance.get("CPointOffScreenIndicatorUi", "m_pTargetPanel")); }
};
