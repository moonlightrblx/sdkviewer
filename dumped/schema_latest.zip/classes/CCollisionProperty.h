#pragma once
#include "../memory.h"

class CCollisionProperty {
public:
 uintptr_t baseAddr;
 CCollisionProperty() : baseAddr(0){}
 CCollisionProperty(uintptr_t b):baseAddr(b){}
 uintptr_t m_collisionAttribute(){return SCHEMA_TYPE(uintptr_t,0x10);}
 uintptr_t m_vecMins(){return SCHEMA_TYPE(uintptr_t,0x40);}
 uintptr_t m_vecMaxs(){return SCHEMA_TYPE(uintptr_t,0x4C);}
 uintptr_t m_usSolidFlags(){return SCHEMA_TYPE(uintptr_t,0x5A);}
 uintptr_t m_nSolidType(){return SCHEMA_TYPE(uintptr_t,0x5B);}
 uintptr_t m_triggerBloat(){return SCHEMA_TYPE(uintptr_t,0x5C);}
 uintptr_t m_nSurroundType(){return SCHEMA_TYPE(uintptr_t,0x5D);}
 uintptr_t m_CollisionGroup(){return SCHEMA_TYPE(uintptr_t,0x5E);}
 uintptr_t m_nEnablePhysics(){return SCHEMA_TYPE(uintptr_t,0x5F);}
 uintptr_t m_flBoundingRadius(){return SCHEMA_TYPE(uintptr_t,0x60);}
 uintptr_t m_vecSpecifiedSurroundingMins(){return SCHEMA_TYPE(uintptr_t,0x64);}
 uintptr_t m_vecSpecifiedSurroundingMaxs(){return SCHEMA_TYPE(uintptr_t,0x70);}
 uintptr_t m_vecSurroundingMaxs(){return SCHEMA_TYPE(uintptr_t,0x7C);}
 uintptr_t m_vecSurroundingMins(){return SCHEMA_TYPE(uintptr_t,0x88);}
 uintptr_t m_vCapsuleCenter1(){return SCHEMA_TYPE(uintptr_t,0x94);}
 uintptr_t m_vCapsuleCenter2(){return SCHEMA_TYPE(uintptr_t,0xA0);}
 uintptr_t m_flCapsuleRadius(){return SCHEMA_TYPE(uintptr_t,0xAC);}
};
