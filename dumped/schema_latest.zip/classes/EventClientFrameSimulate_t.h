#pragma once
#include "../memory.h"

class EventClientFrameSimulate_t {
public:
 uintptr_t baseAddr;
 EventClientFrameSimulate_t() : baseAddr(0){}
 EventClientFrameSimulate_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_LoopState(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_flRealTime(){return SCHEMA_TYPE(uintptr_t,0x28);}
 uintptr_t m_flFrameTime(){return SCHEMA_TYPE(uintptr_t,0x2C);}
 uintptr_t m_bScheduleSendTickPacket(){return SCHEMA_TYPE(uintptr_t,0x30);}
};
