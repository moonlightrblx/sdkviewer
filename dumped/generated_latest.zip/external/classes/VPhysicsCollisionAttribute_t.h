#pragma once
#include "../memory.h"

class VPhysicsCollisionAttribute_t  {
public:
    uintptr_t baseAddr;

    VPhysicsCollisionAttribute_t() { baseAddr = client_base(); }
    VPhysicsCollisionAttribute_t(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_nInteractsAs() { return read<uintptr_t>(baseAddr + offsets_instance.get("VPhysicsCollisionAttribute_t", "m_nInteractsAs")); }
    uintptr_t m_nInteractsWith() { return read<uintptr_t>(baseAddr + offsets_instance.get("VPhysicsCollisionAttribute_t", "m_nInteractsWith")); }
    uintptr_t m_nInteractsExclude() { return read<uintptr_t>(baseAddr + offsets_instance.get("VPhysicsCollisionAttribute_t", "m_nInteractsExclude")); }
    int m_nEntityId() { return read<int>(baseAddr + offsets_instance.get("VPhysicsCollisionAttribute_t", "m_nEntityId")); }
    int m_nOwnerId() { return read<int>(baseAddr + offsets_instance.get("VPhysicsCollisionAttribute_t", "m_nOwnerId")); }
    uint16_t m_nHierarchyId() { return read<uint16_t>(baseAddr + offsets_instance.get("VPhysicsCollisionAttribute_t", "m_nHierarchyId")); }
    uint8_t m_nCollisionGroup() { return read<uint8_t>(baseAddr + offsets_instance.get("VPhysicsCollisionAttribute_t", "m_nCollisionGroup")); }
    uint8_t m_nCollisionFunctionMask() { return read<uint8_t>(baseAddr + offsets_instance.get("VPhysicsCollisionAttribute_t", "m_nCollisionFunctionMask")); }
};
