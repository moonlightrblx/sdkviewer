#pragma once
#include "../memory.h"

class CModelState  {
public:
    uintptr_t baseAddr;

    CModelState() { baseAddr = 0; }
    CModelState(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_hModel() { return read<uintptr_t>(baseAddr + offsets_instance.get("CModelState", "m_hModel")); }
    uintptr_t m_ModelName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CModelState", "m_ModelName")); }
    bool m_bClientClothCreationSuppressed() { return read<bool>(baseAddr + offsets_instance.get("CModelState", "m_bClientClothCreationSuppressed")); }
    uintptr_t m_MeshGroupMask() { return read<uintptr_t>(baseAddr + offsets_instance.get("CModelState", "m_MeshGroupMask")); }
    int m_nBodyGroupChoices() { return read<int>(baseAddr + offsets_instance.get("CModelState", "m_nBodyGroupChoices")); }
    uintptr_t m_nIdealMotionType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CModelState", "m_nIdealMotionType")); }
    uintptr_t m_nForceLOD() { return read<uintptr_t>(baseAddr + offsets_instance.get("CModelState", "m_nForceLOD")); }
    uintptr_t m_nClothUpdateFlags() { return read<uintptr_t>(baseAddr + offsets_instance.get("CModelState", "m_nClothUpdateFlags")); }
};
