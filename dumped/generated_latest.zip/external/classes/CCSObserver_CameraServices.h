#pragma once
#include "../memory.h"

class CCSObserver_CameraServices  {
public:
    uintptr_t baseAddr;

    CCSObserver_CameraServices() { baseAddr = 0; }
    CCSObserver_CameraServices(uintptr_t base) : baseAddr(base) {}

};
