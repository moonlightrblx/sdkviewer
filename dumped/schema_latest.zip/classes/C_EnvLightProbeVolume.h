#pragma once
#include "../memory.h"

class C_EnvLightProbeVolume {
public:
 uintptr_t baseAddr;
 C_EnvLightProbeVolume() : baseAddr(0){}
 C_EnvLightProbeVolume(uintptr_t b):baseAddr(b){}
 uintptr_t m_Entity_hLightProbeTexture_AmbientCube(){return SCHEMA_TYPE(uintptr_t,0x15F0);}
 uintptr_t m_Entity_hLightProbeTexture_SDF(){return SCHEMA_TYPE(uintptr_t,0x15F8);}
 uintptr_t m_Entity_hLightProbeTexture_SH2_DC(){return SCHEMA_TYPE(uintptr_t,0x1600);}
 uintptr_t m_Entity_hLightProbeTexture_SH2_R(){return SCHEMA_TYPE(uintptr_t,0x1608);}
 uintptr_t m_Entity_hLightProbeTexture_SH2_G(){return SCHEMA_TYPE(uintptr_t,0x1610);}
 uintptr_t m_Entity_hLightProbeTexture_SH2_B(){return SCHEMA_TYPE(uintptr_t,0x1618);}
 uintptr_t m_Entity_hLightProbeDirectLightIndicesTexture(){return SCHEMA_TYPE(uintptr_t,0x1620);}
 uintptr_t m_Entity_hLightProbeDirectLightScalarsTexture(){return SCHEMA_TYPE(uintptr_t,0x1628);}
 uintptr_t m_Entity_hLightProbeDirectLightShadowsTexture(){return SCHEMA_TYPE(uintptr_t,0x1630);}
 uintptr_t m_Entity_vBoxMins(){return SCHEMA_TYPE(uintptr_t,0x1638);}
 uintptr_t m_Entity_vBoxMaxs(){return SCHEMA_TYPE(uintptr_t,0x1644);}
 uintptr_t m_Entity_bMoveable(){return SCHEMA_TYPE(uintptr_t,0x1650);}
 uintptr_t m_Entity_nHandshake(){return SCHEMA_TYPE(uintptr_t,0x1654);}
 uintptr_t m_Entity_nPriority(){return SCHEMA_TYPE(uintptr_t,0x1658);}
 uintptr_t m_Entity_bStartDisabled(){return SCHEMA_TYPE(uintptr_t,0x165C);}
 uintptr_t m_Entity_nLightProbeSizeX(){return SCHEMA_TYPE(uintptr_t,0x1660);}
 uintptr_t m_Entity_nLightProbeSizeY(){return SCHEMA_TYPE(uintptr_t,0x1664);}
 uintptr_t m_Entity_nLightProbeSizeZ(){return SCHEMA_TYPE(uintptr_t,0x1668);}
 uintptr_t m_Entity_nLightProbeAtlasX(){return SCHEMA_TYPE(uintptr_t,0x166C);}
 uintptr_t m_Entity_nLightProbeAtlasY(){return SCHEMA_TYPE(uintptr_t,0x1670);}
 uintptr_t m_Entity_nLightProbeAtlasZ(){return SCHEMA_TYPE(uintptr_t,0x1674);}
 uintptr_t m_Entity_bEnabled(){return SCHEMA_TYPE(uintptr_t,0x1681);}
};
