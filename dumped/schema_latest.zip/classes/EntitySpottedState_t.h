#pragma once
#include "../memory.h"

class EntitySpottedState_t {
public:
 uintptr_t baseAddr;
 EntitySpottedState_t() : baseAddr(0){}
 EntitySpottedState_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_bSpotted(){return SCHEMA_TYPE(uintptr_t,0x8);}
 uintptr_t m_bSpottedByMask(){return SCHEMA_TYPE(uintptr_t,0xC);}
};
