#pragma once
#include "../memory.h"

class CRagdollManager  {
public:
    uintptr_t baseAddr;

    CRagdollManager() { baseAddr = client_base(); }
    CRagdollManager(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_iCurrentMaxRagdollCount() { return read<uintptr_t>(baseAddr + offsets_instance.get("CRagdollManager", "m_iCurrentMaxRagdollCount")); }
};
