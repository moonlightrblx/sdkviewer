#pragma once
#include "../memory.h"
#include "../classes/C_EnvWindShared.h"

class C_EnvWind  {
public:
    uintptr_t baseAddr;

    C_EnvWind() { baseAddr = 0; }
    C_EnvWind(uintptr_t base) : baseAddr(base) {}

    C_EnvWindShared m_EnvWindShared() { return read<C_EnvWindShared>(baseAddr + offsets_instance.get("C_EnvWind", "m_EnvWindShared")); }
};
