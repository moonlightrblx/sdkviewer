#pragma once
#include "../memory.h"

class CPlayer_CameraServices {
public:
 uintptr_t baseAddr;
 CPlayer_CameraServices() : baseAddr(0){}
 CPlayer_CameraServices(uintptr_t b):baseAddr(b){}
 uintptr_t m_vecCsViewPunchAngle(){return SCHEMA_TYPE(uintptr_t,0x40);}
 uintptr_t m_nCsViewPunchAngleTick(){return SCHEMA_TYPE(uintptr_t,0x4C);}
 uintptr_t m_flCsViewPunchAngleTickRatio(){return SCHEMA_TYPE(uintptr_t,0x50);}
 uintptr_t m_PlayerFog(){return SCHEMA_TYPE(uintptr_t,0x58);}
 uintptr_t m_hColorCorrectionCtrl(){return SCHEMA_TYPE(uintptr_t,0x98);}
 uintptr_t m_hViewEntity(){return SCHEMA_TYPE(uintptr_t,0x9C);}
 uintptr_t m_hTonemapController(){return SCHEMA_TYPE(uintptr_t,0xA0);}
 uintptr_t m_audio(){return SCHEMA_TYPE(uintptr_t,0xA8);}
 uintptr_t m_PostProcessingVolumes(){return SCHEMA_TYPE(uintptr_t,0x120);}
 uintptr_t m_flOldPlayerZ(){return SCHEMA_TYPE(uintptr_t,0x138);}
 uintptr_t m_flOldPlayerViewOffsetZ(){return SCHEMA_TYPE(uintptr_t,0x13C);}
 uintptr_t m_CurrentFog(){return SCHEMA_TYPE(uintptr_t,0x140);}
 uintptr_t m_hOldFogController(){return SCHEMA_TYPE(uintptr_t,0x1A8);}
 uintptr_t m_bOverrideFogColor(){return SCHEMA_TYPE(uintptr_t,0x1AC);}
 uintptr_t m_OverrideFogColor(){return SCHEMA_TYPE(uintptr_t,0x1B1);}
 uintptr_t m_bOverrideFogStartEnd(){return SCHEMA_TYPE(uintptr_t,0x1C5);}
 uintptr_t m_fOverrideFogStart(){return SCHEMA_TYPE(uintptr_t,0x1CC);}
 uintptr_t m_fOverrideFogEnd(){return SCHEMA_TYPE(uintptr_t,0x1E0);}
 uintptr_t m_hActivePostProcessingVolume(){return SCHEMA_TYPE(uintptr_t,0x1F4);}
 uintptr_t m_angDemoViewAngles(){return SCHEMA_TYPE(uintptr_t,0x1F8);}
};
