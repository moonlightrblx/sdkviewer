#pragma once
#include "../memory.h"

class CLogicalEntity {
public:
 uintptr_t baseAddr;
 CLogicalEntity() : baseAddr(0){}
 CLogicalEntity(uintptr_t b):baseAddr(b){}
};
