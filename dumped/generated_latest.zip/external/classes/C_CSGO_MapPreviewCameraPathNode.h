#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_CSGO_MapPreviewCameraPathNode  {
public:
    uintptr_t baseAddr;

    C_CSGO_MapPreviewCameraPathNode() { baseAddr = 0; }
    C_CSGO_MapPreviewCameraPathNode(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_szParentPathUniqueID() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPathNode", "m_szParentPathUniqueID")); }
    int m_nPathIndex() { return read<int>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPathNode", "m_nPathIndex")); }
    Vector3 m_vInTangentLocal() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPathNode", "m_vInTangentLocal")); }
    Vector3 m_vOutTangentLocal() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPathNode", "m_vOutTangentLocal")); }
    float m_flFOV() { return read<float>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPathNode", "m_flFOV")); }
    float m_flCameraSpeed() { return read<float>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPathNode", "m_flCameraSpeed")); }
    float m_flEaseIn() { return read<float>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPathNode", "m_flEaseIn")); }
    float m_flEaseOut() { return read<float>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPathNode", "m_flEaseOut")); }
    Vector3 m_vInTangentWorld() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPathNode", "m_vInTangentWorld")); }
    Vector3 m_vOutTangentWorld() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPathNode", "m_vOutTangentWorld")); }
};
