#pragma once
#include "../memory.h"
#include "../classes/PhysicsRagdollPose_t.h"
#include "../types/Vector3.h"

class CBaseAnimGraph  {
public:
    uintptr_t baseAddr;

    CBaseAnimGraph() { baseAddr = 0; }
    CBaseAnimGraph(uintptr_t base) : baseAddr(base) {}

    bool m_bInitiallyPopulateInterpHistory() { return read<bool>(baseAddr + offsets_instance.get("CBaseAnimGraph", "m_bInitiallyPopulateInterpHistory")); }
    bool m_bSuppressAnimEventSounds() { return read<bool>(baseAddr + offsets_instance.get("CBaseAnimGraph", "m_bSuppressAnimEventSounds")); }
    bool m_bAnimGraphUpdateEnabled() { return read<bool>(baseAddr + offsets_instance.get("CBaseAnimGraph", "m_bAnimGraphUpdateEnabled")); }
    float m_flMaxSlopeDistance() { return read<float>(baseAddr + offsets_instance.get("CBaseAnimGraph", "m_flMaxSlopeDistance")); }
    Vector3 m_vLastSlopeCheckPos() { return read<Vector3>(baseAddr + offsets_instance.get("CBaseAnimGraph", "m_vLastSlopeCheckPos")); }
    bool m_bAnimationUpdateScheduled() { return read<bool>(baseAddr + offsets_instance.get("CBaseAnimGraph", "m_bAnimationUpdateScheduled")); }
    Vector3 m_vecForce() { return read<Vector3>(baseAddr + offsets_instance.get("CBaseAnimGraph", "m_vecForce")); }
    int m_nForceBone() { return read<int>(baseAddr + offsets_instance.get("CBaseAnimGraph", "m_nForceBone")); }
    CBaseAnimGraph* m_pClientsideRagdoll() { return read<CBaseAnimGraph*>(baseAddr + offsets_instance.get("CBaseAnimGraph", "m_pClientsideRagdoll")); }
    bool m_bBuiltRagdoll() { return read<bool>(baseAddr + offsets_instance.get("CBaseAnimGraph", "m_bBuiltRagdoll")); }
    PhysicsRagdollPose_t m_RagdollPose() { return read<PhysicsRagdollPose_t>(baseAddr + offsets_instance.get("CBaseAnimGraph", "m_RagdollPose")); }
    bool m_bRagdollEnabled() { return read<bool>(baseAddr + offsets_instance.get("CBaseAnimGraph", "m_bRagdollEnabled")); }
    bool m_bRagdollClientSide() { return read<bool>(baseAddr + offsets_instance.get("CBaseAnimGraph", "m_bRagdollClientSide")); }
    bool m_bHasAnimatedMaterialAttributes() { return read<bool>(baseAddr + offsets_instance.get("CBaseAnimGraph", "m_bHasAnimatedMaterialAttributes")); }
};
