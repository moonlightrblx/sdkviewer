#pragma once
#include "../memory.h"

class C_BulletHitModel {
public:
 uintptr_t baseAddr;
 C_BulletHitModel() : baseAddr(0){}
 C_BulletHitModel(uintptr_t b):baseAddr(b){}
 uintptr_t m_matLocal(){return SCHEMA_TYPE(uintptr_t,0x1158);}
 uintptr_t m_iBoneIndex(){return SCHEMA_TYPE(uintptr_t,0x1188);}
 uintptr_t m_hPlayerParent(){return SCHEMA_TYPE(uintptr_t,0x118C);}
 uintptr_t m_bIsHit(){return SCHEMA_TYPE(uintptr_t,0x1190);}
 uintptr_t m_flTimeCreated(){return SCHEMA_TYPE(uintptr_t,0x1194);}
 uintptr_t m_vecStartPos(){return SCHEMA_TYPE(uintptr_t,0x1198);}
};
