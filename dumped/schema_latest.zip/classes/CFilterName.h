#pragma once
#include "../memory.h"

class CFilterName {
public:
 uintptr_t baseAddr;
 CFilterName() : baseAddr(0){}
 CFilterName(uintptr_t b):baseAddr(b){}
 uintptr_t m_iFilterName(){return SCHEMA_TYPE(uintptr_t,0x650);}
};
