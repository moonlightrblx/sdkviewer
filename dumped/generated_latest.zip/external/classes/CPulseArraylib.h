#pragma once
#include "../memory.h"

class CPulseArraylib  {
public:
    uintptr_t baseAddr;

    CPulseArraylib() { baseAddr = 0; }
    CPulseArraylib(uintptr_t base) : baseAddr(base) {}

};
