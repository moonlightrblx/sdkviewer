#pragma once
#include "../memory.h"

class C_ItemDogtags  {
public:
    uintptr_t baseAddr;

    C_ItemDogtags() { baseAddr = client_base(); }
    C_ItemDogtags(uintptr_t base) : baseAddr(base) {}

    C_CSPlayerPawn* m_OwningPlayer() { return read<C_CSPlayerPawn*>(baseAddr + offsets_instance.get("C_ItemDogtags", "m_OwningPlayer")); }
    C_CSPlayerPawn* m_KillingPlayer() { return read<C_CSPlayerPawn*>(baseAddr + offsets_instance.get("C_ItemDogtags", "m_KillingPlayer")); }
};
