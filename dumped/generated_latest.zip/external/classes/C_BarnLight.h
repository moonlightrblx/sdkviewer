#pragma once
#include "../memory.h"
#include "../classes/GameTime_t.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"

class C_BarnLight  {
public:
    uintptr_t baseAddr;

    C_BarnLight() { baseAddr = 0; }
    C_BarnLight(uintptr_t base) : baseAddr(base) {}

    bool m_bEnabled() { return read<bool>(baseAddr + offsets_instance.get("C_BarnLight", "m_bEnabled")); }
    int m_nColorMode() { return read<int>(baseAddr + offsets_instance.get("C_BarnLight", "m_nColorMode")); }
    uintptr_t m_Color() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BarnLight", "m_Color")); }
    float m_flColorTemperature() { return read<float>(baseAddr + offsets_instance.get("C_BarnLight", "m_flColorTemperature")); }
    float m_flBrightness() { return read<float>(baseAddr + offsets_instance.get("C_BarnLight", "m_flBrightness")); }
    float m_flBrightnessScale() { return read<float>(baseAddr + offsets_instance.get("C_BarnLight", "m_flBrightnessScale")); }
    int m_nDirectLight() { return read<int>(baseAddr + offsets_instance.get("C_BarnLight", "m_nDirectLight")); }
    int m_nBakedShadowIndex() { return read<int>(baseAddr + offsets_instance.get("C_BarnLight", "m_nBakedShadowIndex")); }
    int m_nLightPathUniqueId() { return read<int>(baseAddr + offsets_instance.get("C_BarnLight", "m_nLightPathUniqueId")); }
    int m_nLightMapUniqueId() { return read<int>(baseAddr + offsets_instance.get("C_BarnLight", "m_nLightMapUniqueId")); }
    int m_nLuminaireShape() { return read<int>(baseAddr + offsets_instance.get("C_BarnLight", "m_nLuminaireShape")); }
    float m_flLuminaireSize() { return read<float>(baseAddr + offsets_instance.get("C_BarnLight", "m_flLuminaireSize")); }
    float m_flLuminaireAnisotropy() { return read<float>(baseAddr + offsets_instance.get("C_BarnLight", "m_flLuminaireAnisotropy")); }
    uintptr_t m_LightStyleString() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BarnLight", "m_LightStyleString")); }
    GameTime_t m_flLightStyleStartTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_BarnLight", "m_flLightStyleStartTime")); }
    Vector3 m_QueuedLightStyleStrings() { return read<Vector3>(baseAddr + offsets_instance.get("C_BarnLight", "m_QueuedLightStyleStrings")); }
    Vector3 m_LightStyleEvents() { return read<Vector3>(baseAddr + offsets_instance.get("C_BarnLight", "m_LightStyleEvents")); }
    Vector3 m_LightStyleTargets() { return read<Vector3>(baseAddr + offsets_instance.get("C_BarnLight", "m_LightStyleTargets")); }
    uintptr_t m_StyleEvent() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BarnLight", "m_StyleEvent")); }
    uintptr_t m_hLightCookie() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BarnLight", "m_hLightCookie")); }
    float m_flShape() { return read<float>(baseAddr + offsets_instance.get("C_BarnLight", "m_flShape")); }
    float m_flSoftX() { return read<float>(baseAddr + offsets_instance.get("C_BarnLight", "m_flSoftX")); }
    float m_flSoftY() { return read<float>(baseAddr + offsets_instance.get("C_BarnLight", "m_flSoftY")); }
    float m_flSkirt() { return read<float>(baseAddr + offsets_instance.get("C_BarnLight", "m_flSkirt")); }
    float m_flSkirtNear() { return read<float>(baseAddr + offsets_instance.get("C_BarnLight", "m_flSkirtNear")); }
    Vector3 m_vSizeParams() { return read<Vector3>(baseAddr + offsets_instance.get("C_BarnLight", "m_vSizeParams")); }
    float m_flRange() { return read<float>(baseAddr + offsets_instance.get("C_BarnLight", "m_flRange")); }
    Vector3 m_vShear() { return read<Vector3>(baseAddr + offsets_instance.get("C_BarnLight", "m_vShear")); }
    int m_nBakeSpecularToCubemaps() { return read<int>(baseAddr + offsets_instance.get("C_BarnLight", "m_nBakeSpecularToCubemaps")); }
    Vector3 m_vBakeSpecularToCubemapsSize() { return read<Vector3>(baseAddr + offsets_instance.get("C_BarnLight", "m_vBakeSpecularToCubemapsSize")); }
    int m_nCastShadows() { return read<int>(baseAddr + offsets_instance.get("C_BarnLight", "m_nCastShadows")); }
    int m_nShadowMapSize() { return read<int>(baseAddr + offsets_instance.get("C_BarnLight", "m_nShadowMapSize")); }
    int m_nShadowPriority() { return read<int>(baseAddr + offsets_instance.get("C_BarnLight", "m_nShadowPriority")); }
    bool m_bContactShadow() { return read<bool>(baseAddr + offsets_instance.get("C_BarnLight", "m_bContactShadow")); }
    bool m_bForceShadowsEnabled() { return read<bool>(baseAddr + offsets_instance.get("C_BarnLight", "m_bForceShadowsEnabled")); }
    int m_nBounceLight() { return read<int>(baseAddr + offsets_instance.get("C_BarnLight", "m_nBounceLight")); }
    float m_flBounceScale() { return read<float>(baseAddr + offsets_instance.get("C_BarnLight", "m_flBounceScale")); }
    float m_flMinRoughness() { return read<float>(baseAddr + offsets_instance.get("C_BarnLight", "m_flMinRoughness")); }
    Vector3 m_vAlternateColor() { return read<Vector3>(baseAddr + offsets_instance.get("C_BarnLight", "m_vAlternateColor")); }
    float m_fAlternateColorBrightness() { return read<float>(baseAddr + offsets_instance.get("C_BarnLight", "m_fAlternateColorBrightness")); }
    int m_nFog() { return read<int>(baseAddr + offsets_instance.get("C_BarnLight", "m_nFog")); }
    float m_flFogStrength() { return read<float>(baseAddr + offsets_instance.get("C_BarnLight", "m_flFogStrength")); }
    int m_nFogShadows() { return read<int>(baseAddr + offsets_instance.get("C_BarnLight", "m_nFogShadows")); }
    float m_flFogScale() { return read<float>(baseAddr + offsets_instance.get("C_BarnLight", "m_flFogScale")); }
    bool m_bFogMixedShadows() { return read<bool>(baseAddr + offsets_instance.get("C_BarnLight", "m_bFogMixedShadows")); }
    float m_flFadeSizeStart() { return read<float>(baseAddr + offsets_instance.get("C_BarnLight", "m_flFadeSizeStart")); }
    float m_flFadeSizeEnd() { return read<float>(baseAddr + offsets_instance.get("C_BarnLight", "m_flFadeSizeEnd")); }
    float m_flShadowFadeSizeStart() { return read<float>(baseAddr + offsets_instance.get("C_BarnLight", "m_flShadowFadeSizeStart")); }
    float m_flShadowFadeSizeEnd() { return read<float>(baseAddr + offsets_instance.get("C_BarnLight", "m_flShadowFadeSizeEnd")); }
    bool m_bPrecomputedFieldsValid() { return read<bool>(baseAddr + offsets_instance.get("C_BarnLight", "m_bPrecomputedFieldsValid")); }
    Vector3 m_vPrecomputedBoundsMins() { return read<Vector3>(baseAddr + offsets_instance.get("C_BarnLight", "m_vPrecomputedBoundsMins")); }
    Vector3 m_vPrecomputedBoundsMaxs() { return read<Vector3>(baseAddr + offsets_instance.get("C_BarnLight", "m_vPrecomputedBoundsMaxs")); }
    Vector3 m_vPrecomputedOBBOrigin() { return read<Vector3>(baseAddr + offsets_instance.get("C_BarnLight", "m_vPrecomputedOBBOrigin")); }
    QAngle m_vPrecomputedOBBAngles() { return read<QAngle>(baseAddr + offsets_instance.get("C_BarnLight", "m_vPrecomputedOBBAngles")); }
    Vector3 m_vPrecomputedOBBExtent() { return read<Vector3>(baseAddr + offsets_instance.get("C_BarnLight", "m_vPrecomputedOBBExtent")); }
    int m_nPrecomputedSubFrusta() { return read<int>(baseAddr + offsets_instance.get("C_BarnLight", "m_nPrecomputedSubFrusta")); }
    Vector3 m_vPrecomputedOBBOrigin0() { return read<Vector3>(baseAddr + offsets_instance.get("C_BarnLight", "m_vPrecomputedOBBOrigin0")); }
    QAngle m_vPrecomputedOBBAngles0() { return read<QAngle>(baseAddr + offsets_instance.get("C_BarnLight", "m_vPrecomputedOBBAngles0")); }
    Vector3 m_vPrecomputedOBBExtent0() { return read<Vector3>(baseAddr + offsets_instance.get("C_BarnLight", "m_vPrecomputedOBBExtent0")); }
    Vector3 m_vPrecomputedOBBOrigin1() { return read<Vector3>(baseAddr + offsets_instance.get("C_BarnLight", "m_vPrecomputedOBBOrigin1")); }
    QAngle m_vPrecomputedOBBAngles1() { return read<QAngle>(baseAddr + offsets_instance.get("C_BarnLight", "m_vPrecomputedOBBAngles1")); }
    Vector3 m_vPrecomputedOBBExtent1() { return read<Vector3>(baseAddr + offsets_instance.get("C_BarnLight", "m_vPrecomputedOBBExtent1")); }
    Vector3 m_vPrecomputedOBBOrigin2() { return read<Vector3>(baseAddr + offsets_instance.get("C_BarnLight", "m_vPrecomputedOBBOrigin2")); }
    QAngle m_vPrecomputedOBBAngles2() { return read<QAngle>(baseAddr + offsets_instance.get("C_BarnLight", "m_vPrecomputedOBBAngles2")); }
    Vector3 m_vPrecomputedOBBExtent2() { return read<Vector3>(baseAddr + offsets_instance.get("C_BarnLight", "m_vPrecomputedOBBExtent2")); }
    Vector3 m_vPrecomputedOBBOrigin3() { return read<Vector3>(baseAddr + offsets_instance.get("C_BarnLight", "m_vPrecomputedOBBOrigin3")); }
    QAngle m_vPrecomputedOBBAngles3() { return read<QAngle>(baseAddr + offsets_instance.get("C_BarnLight", "m_vPrecomputedOBBAngles3")); }
    Vector3 m_vPrecomputedOBBExtent3() { return read<Vector3>(baseAddr + offsets_instance.get("C_BarnLight", "m_vPrecomputedOBBExtent3")); }
    Vector3 m_vPrecomputedOBBOrigin4() { return read<Vector3>(baseAddr + offsets_instance.get("C_BarnLight", "m_vPrecomputedOBBOrigin4")); }
    QAngle m_vPrecomputedOBBAngles4() { return read<QAngle>(baseAddr + offsets_instance.get("C_BarnLight", "m_vPrecomputedOBBAngles4")); }
    Vector3 m_vPrecomputedOBBExtent4() { return read<Vector3>(baseAddr + offsets_instance.get("C_BarnLight", "m_vPrecomputedOBBExtent4")); }
    Vector3 m_vPrecomputedOBBOrigin5() { return read<Vector3>(baseAddr + offsets_instance.get("C_BarnLight", "m_vPrecomputedOBBOrigin5")); }
    QAngle m_vPrecomputedOBBAngles5() { return read<QAngle>(baseAddr + offsets_instance.get("C_BarnLight", "m_vPrecomputedOBBAngles5")); }
    Vector3 m_vPrecomputedOBBExtent5() { return read<Vector3>(baseAddr + offsets_instance.get("C_BarnLight", "m_vPrecomputedOBBExtent5")); }
    bool m_bInitialBoneSetup() { return read<bool>(baseAddr + offsets_instance.get("C_BarnLight", "m_bInitialBoneSetup")); }
    uint16_t m_VisClusters() { return read<uint16_t>(baseAddr + offsets_instance.get("C_BarnLight", "m_VisClusters")); }
};
