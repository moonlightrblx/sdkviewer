#pragma once
#include "../memory.h"
#include "../classes/shard_model_desc_t.h"

class C_ShatterGlassShardPhysics  {
public:
    uintptr_t baseAddr;

    C_ShatterGlassShardPhysics() { baseAddr = 0; }
    C_ShatterGlassShardPhysics(uintptr_t base) : baseAddr(base) {}

    shard_model_desc_t m_ShardDesc() { return read<shard_model_desc_t>(baseAddr + offsets_instance.get("C_ShatterGlassShardPhysics", "m_ShardDesc")); }
};
