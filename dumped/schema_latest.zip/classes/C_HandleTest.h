#pragma once
#include "../memory.h"

class C_HandleTest {
public:
 uintptr_t baseAddr;
 C_HandleTest() : baseAddr(0){}
 C_HandleTest(uintptr_t b):baseAddr(b){}
 uintptr_t m_Handle(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_bSendHandle(){return SCHEMA_TYPE(uintptr_t,0x5FC);}
};
