#pragma once
#include "../memory.h"

class C_MapPreviewParticleSystem {
public:
 uintptr_t baseAddr;
 C_MapPreviewParticleSystem() : baseAddr(0){}
 C_MapPreviewParticleSystem(uintptr_t b):baseAddr(b){}
};
