#pragma once
#include "../memory.h"

class C_WeaponSawedoff  {
public:
    uintptr_t baseAddr;

    C_WeaponSawedoff() { baseAddr = 0; }
    C_WeaponSawedoff(uintptr_t base) : baseAddr(base) {}

};
