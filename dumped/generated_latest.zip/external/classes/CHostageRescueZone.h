#pragma once
#include "../memory.h"

class CHostageRescueZone  {
public:
    uintptr_t baseAddr;

    CHostageRescueZone() { baseAddr = client_base(); }
    CHostageRescueZone(uintptr_t base) : baseAddr(base) {}

};
