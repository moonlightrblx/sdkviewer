#pragma once
#include "../memory.h"
#include "../classes/GameTime_t.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"

class C_LocalTempEntity  {
public:
    uintptr_t baseAddr;

    C_LocalTempEntity() { baseAddr = 0; }
    C_LocalTempEntity(uintptr_t base) : baseAddr(base) {}

    int flags() { return read<int>(baseAddr + offsets_instance.get("C_LocalTempEntity", "flags")); }
    GameTime_t die() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_LocalTempEntity", "die")); }
    float m_flFrameMax() { return read<float>(baseAddr + offsets_instance.get("C_LocalTempEntity", "m_flFrameMax")); }
    float x() { return read<float>(baseAddr + offsets_instance.get("C_LocalTempEntity", "x")); }
    float y() { return read<float>(baseAddr + offsets_instance.get("C_LocalTempEntity", "y")); }
    float fadeSpeed() { return read<float>(baseAddr + offsets_instance.get("C_LocalTempEntity", "fadeSpeed")); }
    float bounceFactor() { return read<float>(baseAddr + offsets_instance.get("C_LocalTempEntity", "bounceFactor")); }
    int hitSound() { return read<int>(baseAddr + offsets_instance.get("C_LocalTempEntity", "hitSound")); }
    int priority() { return read<int>(baseAddr + offsets_instance.get("C_LocalTempEntity", "priority")); }
    Vector3 tentOffset() { return read<Vector3>(baseAddr + offsets_instance.get("C_LocalTempEntity", "tentOffset")); }
    QAngle m_vecTempEntAngVelocity() { return read<QAngle>(baseAddr + offsets_instance.get("C_LocalTempEntity", "m_vecTempEntAngVelocity")); }
    int tempent_renderamt() { return read<int>(baseAddr + offsets_instance.get("C_LocalTempEntity", "tempent_renderamt")); }
    Vector3 m_vecNormal() { return read<Vector3>(baseAddr + offsets_instance.get("C_LocalTempEntity", "m_vecNormal")); }
    float m_flSpriteScale() { return read<float>(baseAddr + offsets_instance.get("C_LocalTempEntity", "m_flSpriteScale")); }
    int m_nFlickerFrame() { return read<int>(baseAddr + offsets_instance.get("C_LocalTempEntity", "m_nFlickerFrame")); }
    float m_flFrameRate() { return read<float>(baseAddr + offsets_instance.get("C_LocalTempEntity", "m_flFrameRate")); }
    float m_flFrame() { return read<float>(baseAddr + offsets_instance.get("C_LocalTempEntity", "m_flFrame")); }
    uintptr_t* m_pszImpactEffect() { return read<uintptr_t*>(baseAddr + offsets_instance.get("C_LocalTempEntity", "m_pszImpactEffect")); }
    uintptr_t* m_pszParticleEffect() { return read<uintptr_t*>(baseAddr + offsets_instance.get("C_LocalTempEntity", "m_pszParticleEffect")); }
    bool m_bParticleCollision() { return read<bool>(baseAddr + offsets_instance.get("C_LocalTempEntity", "m_bParticleCollision")); }
    int m_iLastCollisionFrame() { return read<int>(baseAddr + offsets_instance.get("C_LocalTempEntity", "m_iLastCollisionFrame")); }
    Vector3 m_vLastCollisionOrigin() { return read<Vector3>(baseAddr + offsets_instance.get("C_LocalTempEntity", "m_vLastCollisionOrigin")); }
    Vector3 m_vecTempEntVelocity() { return read<Vector3>(baseAddr + offsets_instance.get("C_LocalTempEntity", "m_vecTempEntVelocity")); }
    Vector3 m_vecPrevAbsOrigin() { return read<Vector3>(baseAddr + offsets_instance.get("C_LocalTempEntity", "m_vecPrevAbsOrigin")); }
    Vector3 m_vecTempEntAcceleration() { return read<Vector3>(baseAddr + offsets_instance.get("C_LocalTempEntity", "m_vecTempEntAcceleration")); }
};
