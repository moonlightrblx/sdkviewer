#pragma once
#include "../memory.h"

class C_EnvWindClientside {
public:
 uintptr_t baseAddr;
 C_EnvWindClientside() : baseAddr(0){}
 C_EnvWindClientside(uintptr_t b):baseAddr(b){}
 uintptr_t m_EnvWindShared(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
};
