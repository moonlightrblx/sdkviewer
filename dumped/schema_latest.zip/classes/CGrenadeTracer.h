#pragma once
#include "../memory.h"

class CGrenadeTracer {
public:
 uintptr_t baseAddr;
 CGrenadeTracer() : baseAddr(0){}
 CGrenadeTracer(uintptr_t b):baseAddr(b){}
 uintptr_t m_flTracerDuration(){return SCHEMA_TYPE(uintptr_t,0xEC8);}
 uintptr_t m_nType(){return SCHEMA_TYPE(uintptr_t,0xECC);}
};
