#pragma once
#include "../memory.h"

class SequenceHistory_t  {
public:
    uintptr_t baseAddr;

    SequenceHistory_t() { baseAddr = client_base(); }
    SequenceHistory_t(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_hSequence() { return read<uintptr_t>(baseAddr + offsets_instance.get("SequenceHistory_t", "m_hSequence")); }
    uintptr_t m_flSeqStartTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("SequenceHistory_t", "m_flSeqStartTime")); }
    float m_flSeqFixedCycle() { return read<float>(baseAddr + offsets_instance.get("SequenceHistory_t", "m_flSeqFixedCycle")); }
    uintptr_t m_nSeqLoopMode() { return read<uintptr_t>(baseAddr + offsets_instance.get("SequenceHistory_t", "m_nSeqLoopMode")); }
    float m_flPlaybackRate() { return read<float>(baseAddr + offsets_instance.get("SequenceHistory_t", "m_flPlaybackRate")); }
    float m_flCyclesPerSecond() { return read<float>(baseAddr + offsets_instance.get("SequenceHistory_t", "m_flCyclesPerSecond")); }
};
