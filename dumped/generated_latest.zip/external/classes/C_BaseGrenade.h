#pragma once
#include "../memory.h"

class C_BaseGrenade  {
public:
    uintptr_t baseAddr;

    C_BaseGrenade() { baseAddr = client_base(); }
    C_BaseGrenade(uintptr_t base) : baseAddr(base) {}

    bool m_bHasWarnedAI() { return read<bool>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_bHasWarnedAI")); }
    bool m_bIsSmokeGrenade() { return read<bool>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_bIsSmokeGrenade")); }
    bool m_bIsLive() { return read<bool>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_bIsLive")); }
    float m_DmgRadius() { return read<float>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_DmgRadius")); }
    uintptr_t m_flDetonateTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_flDetonateTime")); }
    float m_flWarnAITime() { return read<float>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_flWarnAITime")); }
    float m_flDamage() { return read<float>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_flDamage")); }
    uintptr_t m_iszBounceSound() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_iszBounceSound")); }
    uintptr_t m_ExplosionSound() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_ExplosionSound")); }
    C_CSPlayerPawn* m_hThrower() { return read<C_CSPlayerPawn*>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_hThrower")); }
    uintptr_t m_flNextAttack() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_flNextAttack")); }
    C_CSPlayerPawn* m_hOriginalThrower() { return read<C_CSPlayerPawn*>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_hOriginalThrower")); }
};
