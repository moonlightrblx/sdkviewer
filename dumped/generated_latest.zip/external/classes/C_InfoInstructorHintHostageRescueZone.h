#pragma once
#include "../memory.h"

class C_InfoInstructorHintHostageRescueZone  {
public:
    uintptr_t baseAddr;

    C_InfoInstructorHintHostageRescueZone() { baseAddr = 0; }
    C_InfoInstructorHintHostageRescueZone(uintptr_t base) : baseAddr(base) {}

};
