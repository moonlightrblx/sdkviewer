#pragma once
#include "../memory.h"

class CPulseCell_LerpCameraSettings  {
public:
    uintptr_t baseAddr;

    CPulseCell_LerpCameraSettings() { baseAddr = 0; }
    CPulseCell_LerpCameraSettings(uintptr_t base) : baseAddr(base) {}

    float m_flSeconds() { return read<float>(baseAddr + offsets_instance.get("CPulseCell_LerpCameraSettings", "m_flSeconds")); }
    uintptr_t m_Start() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_LerpCameraSettings", "m_Start")); }
    uintptr_t m_End() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_LerpCameraSettings", "m_End")); }
};
