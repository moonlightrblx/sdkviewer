#pragma once
#include "../memory.h"

class EventAdvanceTick_t {
public:
 uintptr_t baseAddr;
 EventAdvanceTick_t() : baseAddr(0){}
 EventAdvanceTick_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_nCurrentTick(){return SCHEMA_TYPE(uintptr_t,0x30);}
 uintptr_t m_nCurrentTickThisFrame(){return SCHEMA_TYPE(uintptr_t,0x34);}
 uintptr_t m_nTotalTicksThisFrame(){return SCHEMA_TYPE(uintptr_t,0x38);}
 uintptr_t m_nTotalTicks(){return SCHEMA_TYPE(uintptr_t,0x3C);}
};
