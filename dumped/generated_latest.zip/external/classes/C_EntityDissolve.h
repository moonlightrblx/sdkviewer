#pragma once
#include "../memory.h"
#include "../classes/GameTime_t.h"
#include "../types/Vector3.h"

class C_EntityDissolve  {
public:
    uintptr_t baseAddr;

    C_EntityDissolve() { baseAddr = 0; }
    C_EntityDissolve(uintptr_t base) : baseAddr(base) {}

    GameTime_t m_flStartTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_EntityDissolve", "m_flStartTime")); }
    float m_flFadeInStart() { return read<float>(baseAddr + offsets_instance.get("C_EntityDissolve", "m_flFadeInStart")); }
    float m_flFadeInLength() { return read<float>(baseAddr + offsets_instance.get("C_EntityDissolve", "m_flFadeInLength")); }
    float m_flFadeOutModelStart() { return read<float>(baseAddr + offsets_instance.get("C_EntityDissolve", "m_flFadeOutModelStart")); }
    float m_flFadeOutModelLength() { return read<float>(baseAddr + offsets_instance.get("C_EntityDissolve", "m_flFadeOutModelLength")); }
    float m_flFadeOutStart() { return read<float>(baseAddr + offsets_instance.get("C_EntityDissolve", "m_flFadeOutStart")); }
    float m_flFadeOutLength() { return read<float>(baseAddr + offsets_instance.get("C_EntityDissolve", "m_flFadeOutLength")); }
    GameTime_t m_flNextSparkTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_EntityDissolve", "m_flNextSparkTime")); }
    uintptr_t m_nDissolveType() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EntityDissolve", "m_nDissolveType")); }
    Vector3 m_vDissolverOrigin() { return read<Vector3>(baseAddr + offsets_instance.get("C_EntityDissolve", "m_vDissolverOrigin")); }
    int m_nMagnitude() { return read<int>(baseAddr + offsets_instance.get("C_EntityDissolve", "m_nMagnitude")); }
    bool m_bCoreExplode() { return read<bool>(baseAddr + offsets_instance.get("C_EntityDissolve", "m_bCoreExplode")); }
    bool m_bLinkedToServerEnt() { return read<bool>(baseAddr + offsets_instance.get("C_EntityDissolve", "m_bLinkedToServerEnt")); }
};
