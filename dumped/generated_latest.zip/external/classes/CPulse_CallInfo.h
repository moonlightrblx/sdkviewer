#pragma once
#include "../memory.h"

class CPulse_CallInfo  {
public:
    uintptr_t baseAddr;

    CPulse_CallInfo() { baseAddr = 0; }
    CPulse_CallInfo(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_PortName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulse_CallInfo", "m_PortName")); }
    uintptr_t m_nEditorNodeID() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulse_CallInfo", "m_nEditorNodeID")); }
    uintptr_t m_RegisterMap() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulse_CallInfo", "m_RegisterMap")); }
    uintptr_t m_CallMethodID() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulse_CallInfo", "m_CallMethodID")); }
    uintptr_t m_nSrcChunk() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulse_CallInfo", "m_nSrcChunk")); }
    int m_nSrcInstruction() { return read<int>(baseAddr + offsets_instance.get("CPulse_CallInfo", "m_nSrcInstruction")); }
};
