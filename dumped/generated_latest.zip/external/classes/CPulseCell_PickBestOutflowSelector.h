#pragma once
#include "../memory.h"

class CPulseCell_PickBestOutflowSelector  {
public:
    uintptr_t baseAddr;

    CPulseCell_PickBestOutflowSelector() { baseAddr = client_base(); }
    CPulseCell_PickBestOutflowSelector(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_nCheckType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_PickBestOutflowSelector", "m_nCheckType")); }
    uintptr_t m_OutflowList() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_PickBestOutflowSelector", "m_OutflowList")); }
};
