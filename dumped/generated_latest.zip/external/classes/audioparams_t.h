#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class audioparams_t  {
public:
    uintptr_t baseAddr;

    audioparams_t() { baseAddr = 0; }
    audioparams_t(uintptr_t base) : baseAddr(base) {}

    Vector3 localSound() { return read<Vector3>(baseAddr + offsets_instance.get("audioparams_t", "localSound")); }
    int soundscapeIndex() { return read<int>(baseAddr + offsets_instance.get("audioparams_t", "soundscapeIndex")); }
    uint8_t localBits() { return read<uint8_t>(baseAddr + offsets_instance.get("audioparams_t", "localBits")); }
    int soundscapeEntityListIndex() { return read<int>(baseAddr + offsets_instance.get("audioparams_t", "soundscapeEntityListIndex")); }
    int soundEventHash() { return read<int>(baseAddr + offsets_instance.get("audioparams_t", "soundEventHash")); }
};
