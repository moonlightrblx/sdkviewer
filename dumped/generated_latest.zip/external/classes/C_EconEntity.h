#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_EconEntity  {
public:
    uintptr_t baseAddr;

    C_EconEntity() { baseAddr = client_base(); }
    C_EconEntity(uintptr_t base) : baseAddr(base) {}

    float m_flFlexDelayTime() { return read<float>(baseAddr + offsets_instance.get("C_EconEntity", "m_flFlexDelayTime")); }
    uintptr_t* m_flFlexDelayedWeight() { return read<uintptr_t*>(baseAddr + offsets_instance.get("C_EconEntity", "m_flFlexDelayedWeight")); }
    bool m_bAttributesInitialized() { return read<bool>(baseAddr + offsets_instance.get("C_EconEntity", "m_bAttributesInitialized")); }
    uintptr_t m_AttributeManager() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EconEntity", "m_AttributeManager")); }
    int m_OriginalOwnerXuidLow() { return read<int>(baseAddr + offsets_instance.get("C_EconEntity", "m_OriginalOwnerXuidLow")); }
    int m_OriginalOwnerXuidHigh() { return read<int>(baseAddr + offsets_instance.get("C_EconEntity", "m_OriginalOwnerXuidHigh")); }
    int m_nFallbackPaintKit() { return read<int>(baseAddr + offsets_instance.get("C_EconEntity", "m_nFallbackPaintKit")); }
    int m_nFallbackSeed() { return read<int>(baseAddr + offsets_instance.get("C_EconEntity", "m_nFallbackSeed")); }
    float m_flFallbackWear() { return read<float>(baseAddr + offsets_instance.get("C_EconEntity", "m_flFallbackWear")); }
    int m_nFallbackStatTrak() { return read<int>(baseAddr + offsets_instance.get("C_EconEntity", "m_nFallbackStatTrak")); }
    bool m_bClientside() { return read<bool>(baseAddr + offsets_instance.get("C_EconEntity", "m_bClientside")); }
    bool m_bParticleSystemsCreated() { return read<bool>(baseAddr + offsets_instance.get("C_EconEntity", "m_bParticleSystemsCreated")); }
    int m_vecAttachedParticles() { return read<int>(baseAddr + offsets_instance.get("C_EconEntity", "m_vecAttachedParticles")); }
    CBaseAnimGraph* m_hViewmodelAttachment() { return read<CBaseAnimGraph*>(baseAddr + offsets_instance.get("C_EconEntity", "m_hViewmodelAttachment")); }
    int m_iOldTeam() { return read<int>(baseAddr + offsets_instance.get("C_EconEntity", "m_iOldTeam")); }
    bool m_bAttachmentDirty() { return read<bool>(baseAddr + offsets_instance.get("C_EconEntity", "m_bAttachmentDirty")); }
    int m_nUnloadedModelIndex() { return read<int>(baseAddr + offsets_instance.get("C_EconEntity", "m_nUnloadedModelIndex")); }
    int m_iNumOwnerValidationRetries() { return read<int>(baseAddr + offsets_instance.get("C_EconEntity", "m_iNumOwnerValidationRetries")); }
    C_BaseEntity* m_hOldProvidee() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_EconEntity", "m_hOldProvidee")); }
    Vector3 m_vecAttachedModels() { return read<Vector3>(baseAddr + offsets_instance.get("C_EconEntity", "m_vecAttachedModels")); }
};
