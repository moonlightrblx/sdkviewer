#pragma once
struct CUtlStringToken { uint32_t token; };
