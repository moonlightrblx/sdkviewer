#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class shard_model_desc_t  {
public:
    uintptr_t baseAddr;

    shard_model_desc_t() { baseAddr = client_base(); }
    shard_model_desc_t(uintptr_t base) : baseAddr(base) {}

    int m_nModelID() { return read<int>(baseAddr + offsets_instance.get("shard_model_desc_t", "m_nModelID")); }
    uintptr_t m_hMaterialBase() { return read<uintptr_t>(baseAddr + offsets_instance.get("shard_model_desc_t", "m_hMaterialBase")); }
    uintptr_t m_hMaterialDamageOverlay() { return read<uintptr_t>(baseAddr + offsets_instance.get("shard_model_desc_t", "m_hMaterialDamageOverlay")); }
    uintptr_t m_solid() { return read<uintptr_t>(baseAddr + offsets_instance.get("shard_model_desc_t", "m_solid")); }
    Vector3 m_vecPanelSize() { return read<Vector3>(baseAddr + offsets_instance.get("shard_model_desc_t", "m_vecPanelSize")); }
    Vector3 m_vecStressPositionA() { return read<Vector3>(baseAddr + offsets_instance.get("shard_model_desc_t", "m_vecStressPositionA")); }
    Vector3 m_vecStressPositionB() { return read<Vector3>(baseAddr + offsets_instance.get("shard_model_desc_t", "m_vecStressPositionB")); }
    Vector3 m_vecPanelVertices() { return read<Vector3>(baseAddr + offsets_instance.get("shard_model_desc_t", "m_vecPanelVertices")); }
    Vector3 m_vInitialPanelVertices() { return read<Vector3>(baseAddr + offsets_instance.get("shard_model_desc_t", "m_vInitialPanelVertices")); }
    float m_flGlassHalfThickness() { return read<float>(baseAddr + offsets_instance.get("shard_model_desc_t", "m_flGlassHalfThickness")); }
    bool m_bHasParent() { return read<bool>(baseAddr + offsets_instance.get("shard_model_desc_t", "m_bHasParent")); }
    bool m_bParentFrozen() { return read<bool>(baseAddr + offsets_instance.get("shard_model_desc_t", "m_bParentFrozen")); }
    uintptr_t m_SurfacePropStringToken() { return read<uintptr_t>(baseAddr + offsets_instance.get("shard_model_desc_t", "m_SurfacePropStringToken")); }
};
