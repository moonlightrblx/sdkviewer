#pragma once
#include "../memory.h"

class C_EnvVolumetricFogController {
public:
 uintptr_t baseAddr;
 C_EnvVolumetricFogController() : baseAddr(0){}
 C_EnvVolumetricFogController(uintptr_t b):baseAddr(b){}
 uintptr_t m_flScattering(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_TintColor(){return SCHEMA_TYPE(uintptr_t,0x5FC);}
 uintptr_t m_flAnisotropy(){return SCHEMA_TYPE(uintptr_t,0x600);}
 uintptr_t m_flFadeSpeed(){return SCHEMA_TYPE(uintptr_t,0x604);}
 uintptr_t m_flDrawDistance(){return SCHEMA_TYPE(uintptr_t,0x608);}
 uintptr_t m_flFadeInStart(){return SCHEMA_TYPE(uintptr_t,0x60C);}
 uintptr_t m_flFadeInEnd(){return SCHEMA_TYPE(uintptr_t,0x610);}
 uintptr_t m_flIndirectStrength(){return SCHEMA_TYPE(uintptr_t,0x614);}
 uintptr_t m_nVolumeDepth(){return SCHEMA_TYPE(uintptr_t,0x618);}
 uintptr_t m_fFirstVolumeSliceThickness(){return SCHEMA_TYPE(uintptr_t,0x61C);}
 uintptr_t m_nIndirectTextureDimX(){return SCHEMA_TYPE(uintptr_t,0x620);}
 uintptr_t m_nIndirectTextureDimY(){return SCHEMA_TYPE(uintptr_t,0x624);}
 uintptr_t m_nIndirectTextureDimZ(){return SCHEMA_TYPE(uintptr_t,0x628);}
 uintptr_t m_vBoxMins(){return SCHEMA_TYPE(uintptr_t,0x62C);}
 uintptr_t m_vBoxMaxs(){return SCHEMA_TYPE(uintptr_t,0x638);}
 uintptr_t m_bActive(){return SCHEMA_TYPE(uintptr_t,0x644);}
 uintptr_t m_flStartAnisoTime(){return SCHEMA_TYPE(uintptr_t,0x648);}
 uintptr_t m_flStartScatterTime(){return SCHEMA_TYPE(uintptr_t,0x64C);}
 uintptr_t m_flStartDrawDistanceTime(){return SCHEMA_TYPE(uintptr_t,0x650);}
 uintptr_t m_flStartAnisotropy(){return SCHEMA_TYPE(uintptr_t,0x654);}
 uintptr_t m_flStartScattering(){return SCHEMA_TYPE(uintptr_t,0x658);}
 uintptr_t m_flStartDrawDistance(){return SCHEMA_TYPE(uintptr_t,0x65C);}
 uintptr_t m_flDefaultAnisotropy(){return SCHEMA_TYPE(uintptr_t,0x660);}
 uintptr_t m_flDefaultScattering(){return SCHEMA_TYPE(uintptr_t,0x664);}
 uintptr_t m_flDefaultDrawDistance(){return SCHEMA_TYPE(uintptr_t,0x668);}
 uintptr_t m_bStartDisabled(){return SCHEMA_TYPE(uintptr_t,0x66C);}
 uintptr_t m_bEnableIndirect(){return SCHEMA_TYPE(uintptr_t,0x66D);}
 uintptr_t m_bIsMaster(){return SCHEMA_TYPE(uintptr_t,0x66E);}
 uintptr_t m_hFogIndirectTexture(){return SCHEMA_TYPE(uintptr_t,0x670);}
 uintptr_t m_nForceRefreshCount(){return SCHEMA_TYPE(uintptr_t,0x678);}
 uintptr_t m_fNoiseSpeed(){return SCHEMA_TYPE(uintptr_t,0x67C);}
 uintptr_t m_fNoiseStrength(){return SCHEMA_TYPE(uintptr_t,0x680);}
 uintptr_t m_vNoiseScale(){return SCHEMA_TYPE(uintptr_t,0x684);}
 uintptr_t m_fWindSpeed(){return SCHEMA_TYPE(uintptr_t,0x690);}
 uintptr_t m_vWindDirection(){return SCHEMA_TYPE(uintptr_t,0x694);}
 uintptr_t m_bFirstTime(){return SCHEMA_TYPE(uintptr_t,0x6A0);}
};
