#pragma once
#include "../memory.h"

class CEntityComponentHelper {
public:
 uintptr_t baseAddr;
 CEntityComponentHelper() : baseAddr(0){}
 CEntityComponentHelper(uintptr_t b):baseAddr(b){}
 uintptr_t m_flags(){return SCHEMA_TYPE(uintptr_t,0x8);}
 uintptr_t m_pInfo(){return SCHEMA_TYPE(uintptr_t,0x10);}
 uintptr_t m_nPriority(){return SCHEMA_TYPE(uintptr_t,0x18);}
 uintptr_t m_pNext(){return SCHEMA_TYPE(uintptr_t,0x20);}
};
