#pragma once
#include "../memory.h"
#include "../classes/CNetworkVarChainer.h"
class CGameSceneNode;

class CBodyComponent  {
public:
    uintptr_t baseAddr;

    CBodyComponent() { baseAddr = 0; }
    CBodyComponent(uintptr_t base) : baseAddr(base) {}

    CGameSceneNode* m_pSceneNode() { return read<CGameSceneNode*>(baseAddr + offsets_instance.get("CBodyComponent", "m_pSceneNode")); }
    CNetworkVarChainer __m_pChainEntity() { return read<CNetworkVarChainer>(baseAddr + offsets_instance.get("CBodyComponent", "__m_pChainEntity")); }
};
