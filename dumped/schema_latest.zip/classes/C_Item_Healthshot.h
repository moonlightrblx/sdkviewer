#pragma once
#include "../memory.h"

class C_Item_Healthshot {
public:
 uintptr_t baseAddr;
 C_Item_Healthshot() : baseAddr(0){}
 C_Item_Healthshot(uintptr_t b):baseAddr(b){}
};
