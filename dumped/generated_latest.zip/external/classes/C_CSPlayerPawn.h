#pragma once
#include "../memory.h"
#include "../classes/C_EconItemView.h"
#include "../classes/CountdownTimer.h"
#include "../classes/EntitySpottedState_t.h"
#include "../classes/GameTick_t.h"
#include "../classes/GameTime_t.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"
class CCSPlayer_ActionTrackingServices;
class CCSPlayer_BulletServices;
class CCSPlayer_BuyServices;
class CCSPlayer_DamageReactServices;
class CCSPlayer_GlowServices;
class CCSPlayer_HostageServices;
class C_CS2HudModelArms;
class C_CSWeaponBase;

class C_CSPlayerPawn  {
public:
    uintptr_t baseAddr;

    C_CSPlayerPawn() { baseAddr = 0; }
    C_CSPlayerPawn(uintptr_t base) : baseAddr(base) {}

    CCSPlayer_BulletServices* m_pBulletServices() { return read<CCSPlayer_BulletServices*>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_pBulletServices")); }
    CCSPlayer_HostageServices* m_pHostageServices() { return read<CCSPlayer_HostageServices*>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_pHostageServices")); }
    CCSPlayer_BuyServices* m_pBuyServices() { return read<CCSPlayer_BuyServices*>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_pBuyServices")); }
    CCSPlayer_GlowServices* m_pGlowServices() { return read<CCSPlayer_GlowServices*>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_pGlowServices")); }
    CCSPlayer_ActionTrackingServices* m_pActionTrackingServices() { return read<CCSPlayer_ActionTrackingServices*>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_pActionTrackingServices")); }
    CCSPlayer_DamageReactServices* m_pDamageReactServices() { return read<CCSPlayer_DamageReactServices*>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_pDamageReactServices")); }
    GameTime_t m_flHealthShotBoostExpirationTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_flHealthShotBoostExpirationTime")); }
    GameTime_t m_flLastFiredWeaponTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_flLastFiredWeaponTime")); }
    bool m_bHasFemaleVoice() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bHasFemaleVoice")); }
    float m_flLandingTimeSeconds() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_flLandingTimeSeconds")); }
    float m_flOldFallVelocity() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_flOldFallVelocity")); }
    char* m_szLastPlaceName() { return read<char*>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_szLastPlaceName")); }
    bool m_bPrevDefuser() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bPrevDefuser")); }
    bool m_bPrevHelmet() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bPrevHelmet")); }
    int m_nPrevArmorVal() { return read<int>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_nPrevArmorVal")); }
    int m_nPrevGrenadeAmmoCount() { return read<int>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_nPrevGrenadeAmmoCount")); }
    int m_unPreviousWeaponHash() { return read<int>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_unPreviousWeaponHash")); }
    int m_unWeaponHash() { return read<int>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_unWeaponHash")); }
    bool m_bInBuyZone() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bInBuyZone")); }
    bool m_bPreviouslyInBuyZone() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bPreviouslyInBuyZone")); }
    QAngle m_aimPunchAngle() { return read<QAngle>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_aimPunchAngle")); }
    QAngle m_aimPunchAngleVel() { return read<QAngle>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_aimPunchAngleVel")); }
    GameTick_t m_aimPunchTickBase() { return read<GameTick_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_aimPunchTickBase")); }
    float m_aimPunchTickFraction() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_aimPunchTickFraction")); }
    Vector3 m_aimPunchCache() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_aimPunchCache")); }
    bool m_bInLanding() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bInLanding")); }
    float m_flLandingStartTime() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_flLandingStartTime")); }
    bool m_bInHostageRescueZone() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bInHostageRescueZone")); }
    bool m_bInBombZone() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bInBombZone")); }
    bool m_bIsBuyMenuOpen() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bIsBuyMenuOpen")); }
    GameTime_t m_flTimeOfLastInjury() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_flTimeOfLastInjury")); }
    GameTime_t m_flNextSprayDecalTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_flNextSprayDecalTime")); }
    int m_iRetakesOffering() { return read<int>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_iRetakesOffering")); }
    int m_iRetakesOfferingCard() { return read<int>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_iRetakesOfferingCard")); }
    bool m_bRetakesHasDefuseKit() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bRetakesHasDefuseKit")); }
    bool m_bRetakesMVPLastRound() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bRetakesMVPLastRound")); }
    int m_iRetakesMVPBoostItem() { return read<int>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_iRetakesMVPBoostItem")); }
    uintptr_t m_RetakesMVPBoostExtraUtility() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_RetakesMVPBoostExtraUtility")); }
    bool m_bNeedToReApplyGloves() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bNeedToReApplyGloves")); }
    C_EconItemView m_EconGloves() { return read<C_EconItemView>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_EconGloves")); }
    uint8_t m_nEconGlovesChanged() { return read<uint8_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_nEconGlovesChanged")); }
    bool m_bMustSyncRagdollState() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bMustSyncRagdollState")); }
    int m_nRagdollDamageBone() { return read<int>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_nRagdollDamageBone")); }
    Vector3 m_vRagdollDamageForce() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_vRagdollDamageForce")); }
    Vector3 m_vRagdollDamagePosition() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_vRagdollDamagePosition")); }
    char* m_szRagdollDamageWeaponName() { return read<char*>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_szRagdollDamageWeaponName")); }
    bool m_bRagdollDamageHeadshot() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bRagdollDamageHeadshot")); }
    Vector3 m_vRagdollServerOrigin() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_vRagdollServerOrigin")); }
    GameTime_t m_lastLandTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_lastLandTime")); }
    bool m_bOnGroundLastTick() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bOnGroundLastTick")); }
    C_CS2HudModelArms* m_hHudModelArms() { return read<C_CS2HudModelArms*>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_hHudModelArms")); }
    QAngle m_qDeathEyeAngles() { return read<QAngle>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_qDeathEyeAngles")); }
    bool m_bSkipOneHeadConstraintUpdate() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bSkipOneHeadConstraintUpdate")); }
    bool m_bLeftHanded() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bLeftHanded")); }
    GameTime_t m_fSwitchedHandednessTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_fSwitchedHandednessTime")); }
    float m_flViewmodelOffsetX() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_flViewmodelOffsetX")); }
    float m_flViewmodelOffsetY() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_flViewmodelOffsetY")); }
    float m_flViewmodelOffsetZ() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_flViewmodelOffsetZ")); }
    float m_flViewmodelFOV() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_flViewmodelFOV")); }
    int m_vecPlayerPatchEconIndices() { return read<int>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_vecPlayerPatchEconIndices")); }
    uintptr_t m_GunGameImmunityColor() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_GunGameImmunityColor")); }
    Vector3 m_vecBulletHitModels() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_vecBulletHitModels")); }
    bool m_bIsWalking() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bIsWalking")); }
    QAngle m_thirdPersonHeading() { return read<QAngle>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_thirdPersonHeading")); }
    float m_flSlopeDropOffset() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_flSlopeDropOffset")); }
    float m_flSlopeDropHeight() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_flSlopeDropHeight")); }
    Vector3 m_vHeadConstraintOffset() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_vHeadConstraintOffset")); }
    EntitySpottedState_t m_entitySpottedState() { return read<EntitySpottedState_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_entitySpottedState")); }
    bool m_bIsScoped() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bIsScoped")); }
    bool m_bResumeZoom() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bResumeZoom")); }
    bool m_bIsDefusing() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bIsDefusing")); }
    bool m_bIsGrabbingHostage() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bIsGrabbingHostage")); }
    uintptr_t m_iBlockingUseActionInProgress() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_iBlockingUseActionInProgress")); }
    GameTime_t m_flEmitSoundTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_flEmitSoundTime")); }
    bool m_bInNoDefuseArea() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bInNoDefuseArea")); }
    int m_nWhichBombZone() { return read<int>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_nWhichBombZone")); }
    int m_iShotsFired() { return read<int>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_iShotsFired")); }
    float m_flFlinchStack() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_flFlinchStack")); }
    float m_flVelocityModifier() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_flVelocityModifier")); }
    float m_flHitHeading() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_flHitHeading")); }
    int m_nHitBodyPart() { return read<int>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_nHitBodyPart")); }
    bool m_bWaitForNoAttack() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bWaitForNoAttack")); }
    float m_ignoreLadderJumpTime() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_ignoreLadderJumpTime")); }
    bool m_bKilledByHeadshot() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bKilledByHeadshot")); }
    int m_ArmorValue() { return read<int>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_ArmorValue")); }
    uint16_t m_unCurrentEquipmentValue() { return read<uint16_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_unCurrentEquipmentValue")); }
    uint16_t m_unRoundStartEquipmentValue() { return read<uint16_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_unRoundStartEquipmentValue")); }
    uint16_t m_unFreezetimeEndEquipmentValue() { return read<uint16_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_unFreezetimeEndEquipmentValue")); }
    uintptr_t m_nLastKillerIndex() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_nLastKillerIndex")); }
    bool m_bOldIsScoped() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bOldIsScoped")); }
    bool m_bHasDeathInfo() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bHasDeathInfo")); }
    float m_flDeathInfoTime() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_flDeathInfoTime")); }
    Vector3 m_vecDeathInfoOrigin() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_vecDeathInfoOrigin")); }
    GameTime_t m_grenadeParameterStashTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_grenadeParameterStashTime")); }
    bool m_bGrenadeParametersStashed() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bGrenadeParametersStashed")); }
    QAngle m_angStashedShootAngles() { return read<QAngle>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_angStashedShootAngles")); }
    Vector3 m_vecStashedGrenadeThrowPosition() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_vecStashedGrenadeThrowPosition")); }
    Vector3 m_vecStashedVelocity() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_vecStashedVelocity")); }
    QAngle m_angShootAngleHistory() { return read<QAngle>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_angShootAngleHistory")); }
    Vector3 m_vecThrowPositionHistory() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_vecThrowPositionHistory")); }
    Vector3 m_vecVelocityHistory() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_vecVelocityHistory")); }
    Vector3 m_PredictedDamageTags() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_PredictedDamageTags")); }
    GameTick_t m_nPrevHighestReceivedDamageTagTick() { return read<GameTick_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_nPrevHighestReceivedDamageTagTick")); }
    int m_nHighestAppliedDamageTagTick() { return read<int>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_nHighestAppliedDamageTagTick")); }
    bool m_bShouldAutobuyDMWeapons() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bShouldAutobuyDMWeapons")); }
    GameTime_t m_fImmuneToGunGameDamageTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_fImmuneToGunGameDamageTime")); }
    bool m_bGunGameImmunity() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bGunGameImmunity")); }
    GameTime_t m_fImmuneToGunGameDamageTimeLast() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_fImmuneToGunGameDamageTimeLast")); }
    float m_fMolotovDamageTime() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_fMolotovDamageTime")); }
    Vector3 m_vecLastAliveLocalVelocity() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_vecLastAliveLocalVelocity")); }
    float m_fRenderingClipPlane() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_fRenderingClipPlane")); }
    int m_nLastClipPlaneSetupFrame() { return read<int>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_nLastClipPlaneSetupFrame")); }
    Vector3 m_vecLastClipCameraPos() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_vecLastClipCameraPos")); }
    Vector3 m_vecLastClipCameraForward() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_vecLastClipCameraForward")); }
    bool m_bClipHitStaticWorld() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bClipHitStaticWorld")); }
    bool m_bCachedPlaneIsValid() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_bCachedPlaneIsValid")); }
    C_CSWeaponBase* m_pClippingWeapon() { return read<C_CSWeaponBase*>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_pClippingWeapon")); }
    uintptr_t m_nPlayerInfernoBodyFx() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_nPlayerInfernoBodyFx")); }
    QAngle m_angEyeAngles() { return read<QAngle>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_angEyeAngles")); }
    uintptr_t m_arrOldEyeAnglesTimes() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_arrOldEyeAnglesTimes")); }
    QAngle m_arrOldEyeAngles() { return read<QAngle>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_arrOldEyeAngles")); }
    QAngle m_angEyeAnglesVelocity() { return read<QAngle>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_angEyeAnglesVelocity")); }
    uintptr_t m_iIDEntIndex() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_iIDEntIndex")); }
    CountdownTimer m_delayTargetIDTimer() { return read<CountdownTimer>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_delayTargetIDTimer")); }
    uintptr_t m_iTargetItemEntIdx() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_iTargetItemEntIdx")); }
    uintptr_t m_iOldIDEntIndex() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_iOldIDEntIndex")); }
    CountdownTimer m_holdTargetIDTimer() { return read<CountdownTimer>(baseAddr + offsets_instance.get("C_CSPlayerPawn", "m_holdTargetIDTimer")); }
};
