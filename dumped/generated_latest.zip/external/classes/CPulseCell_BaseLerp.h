#pragma once
#include "../memory.h"

class CPulseCell_BaseLerp  {
public:
    uintptr_t baseAddr;

    CPulseCell_BaseLerp() { baseAddr = client_base(); }
    CPulseCell_BaseLerp(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_WakeResume() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_BaseLerp", "m_WakeResume")); }
};
