#pragma once
#include "../memory.h"
class C_BaseEntity;

class C_EntityFlame  {
public:
    uintptr_t baseAddr;

    C_EntityFlame() { baseAddr = 0; }
    C_EntityFlame(uintptr_t base) : baseAddr(base) {}

    C_BaseEntity* m_hEntAttached() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_EntityFlame", "m_hEntAttached")); }
    C_BaseEntity* m_hOldAttached() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_EntityFlame", "m_hOldAttached")); }
    bool m_bCheapEffect() { return read<bool>(baseAddr + offsets_instance.get("C_EntityFlame", "m_bCheapEffect")); }
};
