#pragma once
#include "../memory.h"

class CEnvSoundscape {
public:
 uintptr_t baseAddr;
 CEnvSoundscape() : baseAddr(0){}
 CEnvSoundscape(uintptr_t b):baseAddr(b){}
 uintptr_t m_OnPlay(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_flRadius(){return SCHEMA_TYPE(uintptr_t,0x620);}
 uintptr_t m_soundEventName(){return SCHEMA_TYPE(uintptr_t,0x628);}
 uintptr_t m_bOverrideWithEvent(){return SCHEMA_TYPE(uintptr_t,0x630);}
 uintptr_t m_soundscapeIndex(){return SCHEMA_TYPE(uintptr_t,0x634);}
 uintptr_t m_soundscapeEntityListId(){return SCHEMA_TYPE(uintptr_t,0x638);}
 uintptr_t m_positionNames(){return SCHEMA_TYPE(uintptr_t,0x640);}
 uintptr_t m_hProxySoundscape(){return SCHEMA_TYPE(uintptr_t,0x680);}
 uintptr_t m_bDisabled(){return SCHEMA_TYPE(uintptr_t,0x684);}
 uintptr_t m_soundscapeName(){return SCHEMA_TYPE(uintptr_t,0x688);}
 uintptr_t m_soundEventHash(){return SCHEMA_TYPE(uintptr_t,0x690);}
};
