#pragma once
#include "../memory.h"
#include "../classes/CBaseAnimGraphController.h"

class CBodyComponentBaseAnimGraph  {
public:
    uintptr_t baseAddr;

    CBodyComponentBaseAnimGraph() { baseAddr = 0; }
    CBodyComponentBaseAnimGraph(uintptr_t base) : baseAddr(base) {}

    CBaseAnimGraphController m_animationController() { return read<CBaseAnimGraphController>(baseAddr + offsets_instance.get("CBodyComponentBaseAnimGraph", "m_animationController")); }
};
