#pragma once
#include "../memory.h"
#include "../classes/CEntityIOOutput.h"

class C_SoundEventEntity  {
public:
    uintptr_t baseAddr;

    C_SoundEventEntity() { baseAddr = 0; }
    C_SoundEventEntity(uintptr_t base) : baseAddr(base) {}

    bool m_bStartOnSpawn() { return read<bool>(baseAddr + offsets_instance.get("C_SoundEventEntity", "m_bStartOnSpawn")); }
    bool m_bToLocalPlayer() { return read<bool>(baseAddr + offsets_instance.get("C_SoundEventEntity", "m_bToLocalPlayer")); }
    bool m_bStopOnNew() { return read<bool>(baseAddr + offsets_instance.get("C_SoundEventEntity", "m_bStopOnNew")); }
    bool m_bSaveRestore() { return read<bool>(baseAddr + offsets_instance.get("C_SoundEventEntity", "m_bSaveRestore")); }
    bool m_bSavedIsPlaying() { return read<bool>(baseAddr + offsets_instance.get("C_SoundEventEntity", "m_bSavedIsPlaying")); }
    float m_flSavedElapsedTime() { return read<float>(baseAddr + offsets_instance.get("C_SoundEventEntity", "m_flSavedElapsedTime")); }
    uintptr_t m_iszSourceEntityName() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_SoundEventEntity", "m_iszSourceEntityName")); }
    uintptr_t m_iszAttachmentName() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_SoundEventEntity", "m_iszAttachmentName")); }
    uintptr_t m_onGUIDChanged() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_SoundEventEntity", "m_onGUIDChanged")); }
    CEntityIOOutput m_onSoundFinished() { return read<CEntityIOOutput>(baseAddr + offsets_instance.get("C_SoundEventEntity", "m_onSoundFinished")); }
    float m_flClientCullRadius() { return read<float>(baseAddr + offsets_instance.get("C_SoundEventEntity", "m_flClientCullRadius")); }
    uintptr_t m_iszSoundName() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_SoundEventEntity", "m_iszSoundName")); }
    uintptr_t m_hSource() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_SoundEventEntity", "m_hSource")); }
    int m_nEntityIndexSelection() { return read<int>(baseAddr + offsets_instance.get("C_SoundEventEntity", "m_nEntityIndexSelection")); }
    uintptr_t m_bClientSideOnly() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_SoundEventEntity", "m_bClientSideOnly")); }
};
