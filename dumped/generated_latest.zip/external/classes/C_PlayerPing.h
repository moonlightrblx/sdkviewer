#pragma once
#include "../memory.h"

class C_PlayerPing  {
public:
    uintptr_t baseAddr;

    C_PlayerPing() { baseAddr = client_base(); }
    C_PlayerPing(uintptr_t base) : baseAddr(base) {}

    C_CSPlayerPawn* m_hPlayer() { return read<C_CSPlayerPawn*>(baseAddr + offsets_instance.get("C_PlayerPing", "m_hPlayer")); }
    C_BaseEntity* m_hPingedEntity() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_PlayerPing", "m_hPingedEntity")); }
    int m_iType() { return read<int>(baseAddr + offsets_instance.get("C_PlayerPing", "m_iType")); }
    bool m_bUrgent() { return read<bool>(baseAddr + offsets_instance.get("C_PlayerPing", "m_bUrgent")); }
    char* m_szPlaceName() { return read<char*>(baseAddr + offsets_instance.get("C_PlayerPing", "m_szPlaceName")); }
};
