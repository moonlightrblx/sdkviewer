#pragma once
#include "../memory.h"

class cs2_dumper  {
public:
    uintptr_t baseAddr;

    cs2_dumper() { baseAddr = 0; }
    cs2_dumper(uintptr_t base) : baseAddr(base) {}

};
