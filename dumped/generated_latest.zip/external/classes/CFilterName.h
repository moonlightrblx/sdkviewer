#pragma once
#include "../memory.h"

class CFilterName  {
public:
    uintptr_t baseAddr;

    CFilterName() { baseAddr = client_base(); }
    CFilterName(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_iFilterName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CFilterName", "m_iFilterName")); }
};
