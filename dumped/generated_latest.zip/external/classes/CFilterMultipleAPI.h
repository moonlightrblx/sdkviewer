#pragma once
#include "../memory.h"

class CFilterMultipleAPI  {
public:
    uintptr_t baseAddr;

    CFilterMultipleAPI() { baseAddr = 0; }
    CFilterMultipleAPI(uintptr_t base) : baseAddr(base) {}

};
