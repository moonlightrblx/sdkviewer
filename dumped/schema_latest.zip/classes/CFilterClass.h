#pragma once
#include "../memory.h"

class CFilterClass {
public:
 uintptr_t baseAddr;
 CFilterClass() : baseAddr(0){}
 CFilterClass(uintptr_t b):baseAddr(b){}
 uintptr_t m_iFilterClass(){return SCHEMA_TYPE(uintptr_t,0x650);}
};
