#pragma once
#include "../memory.h"

class C_TriggerMultiple  {
public:
    uintptr_t baseAddr;

    C_TriggerMultiple() { baseAddr = client_base(); }
    C_TriggerMultiple(uintptr_t base) : baseAddr(base) {}

};
