#pragma once
#include "../memory.h"

class C_TeamplayRules  {
public:
    uintptr_t baseAddr;

    C_TeamplayRules() { baseAddr = client_base(); }
    C_TeamplayRules(uintptr_t base) : baseAddr(base) {}

};
