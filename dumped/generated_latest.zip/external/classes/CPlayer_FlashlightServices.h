#pragma once
#include "../memory.h"

class CPlayer_FlashlightServices  {
public:
    uintptr_t baseAddr;

    CPlayer_FlashlightServices() { baseAddr = client_base(); }
    CPlayer_FlashlightServices(uintptr_t base) : baseAddr(base) {}

};
