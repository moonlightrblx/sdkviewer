#pragma once
#include "../memory.h"

class C_PhysMagnet {
public:
 uintptr_t baseAddr;
 C_PhysMagnet() : baseAddr(0){}
 C_PhysMagnet(uintptr_t b):baseAddr(b){}
 uintptr_t m_aAttachedObjectsFromServer(){return SCHEMA_TYPE(uintptr_t,0x1158);}
 uintptr_t m_aAttachedObjects(){return SCHEMA_TYPE(uintptr_t,0x1170);}
};
