#pragma once
#include "../memory.h"

class CSMatchStats_t  {
public:
    uintptr_t baseAddr;

    CSMatchStats_t() { baseAddr = client_base(); }
    CSMatchStats_t(uintptr_t base) : baseAddr(base) {}

    int m_iEnemy5Ks() { return read<int>(baseAddr + offsets_instance.get("CSMatchStats_t", "m_iEnemy5Ks")); }
    int m_iEnemy4Ks() { return read<int>(baseAddr + offsets_instance.get("CSMatchStats_t", "m_iEnemy4Ks")); }
    int m_iEnemy3Ks() { return read<int>(baseAddr + offsets_instance.get("CSMatchStats_t", "m_iEnemy3Ks")); }
    int m_iEnemyKnifeKills() { return read<int>(baseAddr + offsets_instance.get("CSMatchStats_t", "m_iEnemyKnifeKills")); }
    int m_iEnemyTaserKills() { return read<int>(baseAddr + offsets_instance.get("CSMatchStats_t", "m_iEnemyTaserKills")); }
};
