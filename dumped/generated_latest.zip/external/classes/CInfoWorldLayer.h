#pragma once
#include "../memory.h"
#include "../classes/CEntityIOOutput.h"

class CInfoWorldLayer  {
public:
    uintptr_t baseAddr;

    CInfoWorldLayer() { baseAddr = 0; }
    CInfoWorldLayer(uintptr_t base) : baseAddr(base) {}

    CEntityIOOutput m_pOutputOnEntitiesSpawned() { return read<CEntityIOOutput>(baseAddr + offsets_instance.get("CInfoWorldLayer", "m_pOutputOnEntitiesSpawned")); }
    uintptr_t m_worldName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CInfoWorldLayer", "m_worldName")); }
    uintptr_t m_layerName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CInfoWorldLayer", "m_layerName")); }
    bool m_bWorldLayerVisible() { return read<bool>(baseAddr + offsets_instance.get("CInfoWorldLayer", "m_bWorldLayerVisible")); }
    bool m_bEntitiesSpawned() { return read<bool>(baseAddr + offsets_instance.get("CInfoWorldLayer", "m_bEntitiesSpawned")); }
    bool m_bCreateAsChildSpawnGroup() { return read<bool>(baseAddr + offsets_instance.get("CInfoWorldLayer", "m_bCreateAsChildSpawnGroup")); }
    int m_hLayerSpawnGroup() { return read<int>(baseAddr + offsets_instance.get("CInfoWorldLayer", "m_hLayerSpawnGroup")); }
    bool m_bWorldLayerActuallyVisible() { return read<bool>(baseAddr + offsets_instance.get("CInfoWorldLayer", "m_bWorldLayerActuallyVisible")); }
};
