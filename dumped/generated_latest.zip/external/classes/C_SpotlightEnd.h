#pragma once
#include "../memory.h"

class C_SpotlightEnd  {
public:
    uintptr_t baseAddr;

    C_SpotlightEnd() { baseAddr = 0; }
    C_SpotlightEnd(uintptr_t base) : baseAddr(base) {}

    float m_flLightScale() { return read<float>(baseAddr + offsets_instance.get("C_SpotlightEnd", "m_flLightScale")); }
    float m_Radius() { return read<float>(baseAddr + offsets_instance.get("C_SpotlightEnd", "m_Radius")); }
};
