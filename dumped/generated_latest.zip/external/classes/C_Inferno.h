#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_Inferno  {
public:
    uintptr_t baseAddr;

    C_Inferno() { baseAddr = 0; }
    C_Inferno(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_nfxFireDamageEffect() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_Inferno", "m_nfxFireDamageEffect")); }
    uintptr_t m_hInfernoPointsSnapshot() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_Inferno", "m_hInfernoPointsSnapshot")); }
    uintptr_t m_hInfernoFillerPointsSnapshot() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_Inferno", "m_hInfernoFillerPointsSnapshot")); }
    uintptr_t m_hInfernoOutlinePointsSnapshot() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_Inferno", "m_hInfernoOutlinePointsSnapshot")); }
    uintptr_t m_hInfernoClimbingOutlinePointsSnapshot() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_Inferno", "m_hInfernoClimbingOutlinePointsSnapshot")); }
    uintptr_t m_hInfernoDecalsSnapshot() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_Inferno", "m_hInfernoDecalsSnapshot")); }
    Vector3 m_firePositions() { return read<Vector3>(baseAddr + offsets_instance.get("C_Inferno", "m_firePositions")); }
    Vector3 m_fireParentPositions() { return read<Vector3>(baseAddr + offsets_instance.get("C_Inferno", "m_fireParentPositions")); }
    bool m_bFireIsBurning() { return read<bool>(baseAddr + offsets_instance.get("C_Inferno", "m_bFireIsBurning")); }
    Vector3 m_BurnNormal() { return read<Vector3>(baseAddr + offsets_instance.get("C_Inferno", "m_BurnNormal")); }
    int m_fireCount() { return read<int>(baseAddr + offsets_instance.get("C_Inferno", "m_fireCount")); }
    int m_nInfernoType() { return read<int>(baseAddr + offsets_instance.get("C_Inferno", "m_nInfernoType")); }
    float m_nFireLifetime() { return read<float>(baseAddr + offsets_instance.get("C_Inferno", "m_nFireLifetime")); }
    bool m_bInPostEffectTime() { return read<bool>(baseAddr + offsets_instance.get("C_Inferno", "m_bInPostEffectTime")); }
    int m_lastFireCount() { return read<int>(baseAddr + offsets_instance.get("C_Inferno", "m_lastFireCount")); }
    int m_nFireEffectTickBegin() { return read<int>(baseAddr + offsets_instance.get("C_Inferno", "m_nFireEffectTickBegin")); }
    int m_drawableCount() { return read<int>(baseAddr + offsets_instance.get("C_Inferno", "m_drawableCount")); }
    bool m_blosCheck() { return read<bool>(baseAddr + offsets_instance.get("C_Inferno", "m_blosCheck")); }
    int m_nlosperiod() { return read<int>(baseAddr + offsets_instance.get("C_Inferno", "m_nlosperiod")); }
    float m_maxFireHalfWidth() { return read<float>(baseAddr + offsets_instance.get("C_Inferno", "m_maxFireHalfWidth")); }
    float m_maxFireHeight() { return read<float>(baseAddr + offsets_instance.get("C_Inferno", "m_maxFireHeight")); }
    Vector3 m_minBounds() { return read<Vector3>(baseAddr + offsets_instance.get("C_Inferno", "m_minBounds")); }
    Vector3 m_maxBounds() { return read<Vector3>(baseAddr + offsets_instance.get("C_Inferno", "m_maxBounds")); }
    float m_flLastGrassBurnThink() { return read<float>(baseAddr + offsets_instance.get("C_Inferno", "m_flLastGrassBurnThink")); }
};
