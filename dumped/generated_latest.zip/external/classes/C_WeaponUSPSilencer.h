#pragma once
#include "../memory.h"

class C_WeaponUSPSilencer  {
public:
    uintptr_t baseAddr;

    C_WeaponUSPSilencer() { baseAddr = 0; }
    C_WeaponUSPSilencer(uintptr_t base) : baseAddr(base) {}

};
