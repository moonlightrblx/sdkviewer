#pragma once
#include "../memory.h"

class EventClientPostSimulate_t  {
public:
    uintptr_t baseAddr;

    EventClientPostSimulate_t() { baseAddr = 0; }
    EventClientPostSimulate_t(uintptr_t base) : baseAddr(base) {}

};
