#pragma once
#include "../memory.h"

class CPulseAnimFuncs  {
public:
    uintptr_t baseAddr;

    CPulseAnimFuncs() { baseAddr = client_base(); }
    CPulseAnimFuncs(uintptr_t base) : baseAddr(base) {}

};
