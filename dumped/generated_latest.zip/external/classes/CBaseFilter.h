#pragma once
#include "../memory.h"

class CBaseFilter  {
public:
    uintptr_t baseAddr;

    CBaseFilter() { baseAddr = client_base(); }
    CBaseFilter(uintptr_t base) : baseAddr(base) {}

    bool m_bNegated() { return read<bool>(baseAddr + offsets_instance.get("CBaseFilter", "m_bNegated")); }
    uintptr_t m_OnPass() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBaseFilter", "m_OnPass")); }
    uintptr_t m_OnFail() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBaseFilter", "m_OnFail")); }
};
