#pragma once
#include "../memory.h"

class CountdownTimer {
public:
 uintptr_t baseAddr;
 CountdownTimer() : baseAddr(0){}
 CountdownTimer(uintptr_t b):baseAddr(b){}
 uintptr_t m_duration(){return SCHEMA_TYPE(uintptr_t,0x8);}
 uintptr_t m_timestamp(){return SCHEMA_TYPE(uintptr_t,0xC);}
 uintptr_t m_timescale(){return SCHEMA_TYPE(uintptr_t,0x10);}
 uintptr_t m_nWorldGroupId(){return SCHEMA_TYPE(uintptr_t,0x14);}
};
