#pragma once
#include "../memory.h"

class CDamageRecord {
public:
 uintptr_t baseAddr;
 CDamageRecord() : baseAddr(0){}
 CDamageRecord(uintptr_t b):baseAddr(b){}
 uintptr_t m_PlayerDamager(){return SCHEMA_TYPE(uintptr_t,0x30);}
 uintptr_t m_PlayerRecipient(){return SCHEMA_TYPE(uintptr_t,0x34);}
 uintptr_t m_hPlayerControllerDamager(){return SCHEMA_TYPE(uintptr_t,0x38);}
 uintptr_t m_hPlayerControllerRecipient(){return SCHEMA_TYPE(uintptr_t,0x3C);}
 uintptr_t m_szPlayerDamagerName(){return SCHEMA_TYPE(uintptr_t,0x40);}
 uintptr_t m_szPlayerRecipientName(){return SCHEMA_TYPE(uintptr_t,0x48);}
 uintptr_t m_DamagerXuid(){return SCHEMA_TYPE(uintptr_t,0x50);}
 uintptr_t m_RecipientXuid(){return SCHEMA_TYPE(uintptr_t,0x58);}
 uintptr_t m_flBulletsDamage(){return SCHEMA_TYPE(uintptr_t,0x60);}
 uintptr_t m_flDamage(){return SCHEMA_TYPE(uintptr_t,0x64);}
 uintptr_t m_flActualHealthRemoved(){return SCHEMA_TYPE(uintptr_t,0x68);}
 uintptr_t m_iNumHits(){return SCHEMA_TYPE(uintptr_t,0x6C);}
 uintptr_t m_iLastBulletUpdate(){return SCHEMA_TYPE(uintptr_t,0x70);}
 uintptr_t m_bIsOtherEnemy(){return SCHEMA_TYPE(uintptr_t,0x74);}
 uintptr_t m_killType(){return SCHEMA_TYPE(uintptr_t,0x75);}
};
