#pragma once
#include "../memory.h"

class CPulseCell_BaseValue {
public:
 uintptr_t baseAddr;
 CPulseCell_BaseValue() : baseAddr(0){}
 CPulseCell_BaseValue(uintptr_t b):baseAddr(b){}
};
