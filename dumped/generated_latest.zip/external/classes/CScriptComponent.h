#pragma once
#include "../memory.h"

class CScriptComponent  {
public:
    uintptr_t baseAddr;

    CScriptComponent() { baseAddr = 0; }
    CScriptComponent(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_scriptClassName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CScriptComponent", "m_scriptClassName")); }
};
