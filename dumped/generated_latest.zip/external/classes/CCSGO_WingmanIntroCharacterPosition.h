#pragma once
#include "../memory.h"

class CCSGO_WingmanIntroCharacterPosition  {
public:
    uintptr_t baseAddr;

    CCSGO_WingmanIntroCharacterPosition() { baseAddr = client_base(); }
    CCSGO_WingmanIntroCharacterPosition(uintptr_t base) : baseAddr(base) {}

};
