#pragma once
#include "../memory.h"

class schemas  {
public:
    uintptr_t baseAddr;

    schemas() { baseAddr = client_base(); }
    schemas(uintptr_t base) : baseAddr(base) {}

};
