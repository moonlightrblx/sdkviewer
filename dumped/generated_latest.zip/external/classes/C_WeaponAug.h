#pragma once
#include "../memory.h"

class C_WeaponAug  {
public:
    uintptr_t baseAddr;

    C_WeaponAug() { baseAddr = client_base(); }
    C_WeaponAug(uintptr_t base) : baseAddr(base) {}

};
