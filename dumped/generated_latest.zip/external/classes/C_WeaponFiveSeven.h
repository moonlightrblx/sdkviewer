#pragma once
#include "../memory.h"

class C_WeaponFiveSeven  {
public:
    uintptr_t baseAddr;

    C_WeaponFiveSeven() { baseAddr = client_base(); }
    C_WeaponFiveSeven(uintptr_t base) : baseAddr(base) {}

};
