#pragma once
#include "../memory.h"

class C_PlayerSprayDecal {
public:
 uintptr_t baseAddr;
 C_PlayerSprayDecal() : baseAddr(0){}
 C_PlayerSprayDecal(uintptr_t b):baseAddr(b){}
 uintptr_t m_nUniqueID(){return SCHEMA_TYPE(uintptr_t,0xEB0);}
 uintptr_t m_unAccountID(){return SCHEMA_TYPE(uintptr_t,0xEB4);}
 uintptr_t m_unTraceID(){return SCHEMA_TYPE(uintptr_t,0xEB8);}
 uintptr_t m_rtGcTime(){return SCHEMA_TYPE(uintptr_t,0xEBC);}
 uintptr_t m_vecEndPos(){return SCHEMA_TYPE(uintptr_t,0xEC0);}
 uintptr_t m_vecStart(){return SCHEMA_TYPE(uintptr_t,0xECC);}
 uintptr_t m_vecLeft(){return SCHEMA_TYPE(uintptr_t,0xED8);}
 uintptr_t m_vecNormal(){return SCHEMA_TYPE(uintptr_t,0xEE4);}
 uintptr_t m_nPlayer(){return SCHEMA_TYPE(uintptr_t,0xEF0);}
 uintptr_t m_nEntity(){return SCHEMA_TYPE(uintptr_t,0xEF4);}
 uintptr_t m_nHitbox(){return SCHEMA_TYPE(uintptr_t,0xEF8);}
 uintptr_t m_flCreationTime(){return SCHEMA_TYPE(uintptr_t,0xEFC);}
 uintptr_t m_nTintID(){return SCHEMA_TYPE(uintptr_t,0xF00);}
 uintptr_t m_nVersion(){return SCHEMA_TYPE(uintptr_t,0xF04);}
 uintptr_t m_ubSignature(){return SCHEMA_TYPE(uintptr_t,0xF05);}
 uintptr_t m_SprayRenderHelper(){return SCHEMA_TYPE(uintptr_t,0xF90);}
};
