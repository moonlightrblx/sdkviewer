#pragma once
#include "../memory.h"

class CPlayer_ItemServices  {
public:
    uintptr_t baseAddr;

    CPlayer_ItemServices() { baseAddr = 0; }
    CPlayer_ItemServices(uintptr_t base) : baseAddr(base) {}

};
