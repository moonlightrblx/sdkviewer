#pragma once
#include "../memory.h"

class CWaterSplasher  {
public:
    uintptr_t baseAddr;

    CWaterSplasher() { baseAddr = client_base(); }
    CWaterSplasher(uintptr_t base) : baseAddr(base) {}

};
