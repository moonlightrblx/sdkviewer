#pragma once
#include "../memory.h"

class C_MolotovProjectile {
public:
 uintptr_t baseAddr;
 C_MolotovProjectile() : baseAddr(0){}
 C_MolotovProjectile(uintptr_t b):baseAddr(b){}
 uintptr_t m_bIsIncGrenade(){return SCHEMA_TYPE(uintptr_t,0x1450);}
};
