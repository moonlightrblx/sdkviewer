#pragma once
#include "../memory.h"

class CPulseTestScriptLib  {
public:
    uintptr_t baseAddr;

    CPulseTestScriptLib() { baseAddr = client_base(); }
    CPulseTestScriptLib(uintptr_t base) : baseAddr(base) {}

};
