#pragma once
#include "../memory.h"

class C_SoundOpvarSetAutoRoomEntity  {
public:
    uintptr_t baseAddr;

    C_SoundOpvarSetAutoRoomEntity() { baseAddr = client_base(); }
    C_SoundOpvarSetAutoRoomEntity(uintptr_t base) : baseAddr(base) {}

};
