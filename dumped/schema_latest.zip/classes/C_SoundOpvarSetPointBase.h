#pragma once
#include "../memory.h"

class C_SoundOpvarSetPointBase {
public:
 uintptr_t baseAddr;
 C_SoundOpvarSetPointBase() : baseAddr(0){}
 C_SoundOpvarSetPointBase(uintptr_t b):baseAddr(b){}
 uintptr_t m_iszStackName(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_iszOperatorName(){return SCHEMA_TYPE(uintptr_t,0x600);}
 uintptr_t m_iszOpvarName(){return SCHEMA_TYPE(uintptr_t,0x608);}
 uintptr_t m_iOpvarIndex(){return SCHEMA_TYPE(uintptr_t,0x610);}
 uintptr_t m_bUseAutoCompare(){return SCHEMA_TYPE(uintptr_t,0x614);}
};
