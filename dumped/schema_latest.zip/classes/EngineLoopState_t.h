#pragma once
#include "../memory.h"

class EngineLoopState_t {
public:
 uintptr_t baseAddr;
 EngineLoopState_t() : baseAddr(0){}
 EngineLoopState_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_nPlatWindowWidth(){return SCHEMA_TYPE(uintptr_t,0x18);}
 uintptr_t m_nPlatWindowHeight(){return SCHEMA_TYPE(uintptr_t,0x1C);}
 uintptr_t m_nRenderWidth(){return SCHEMA_TYPE(uintptr_t,0x20);}
 uintptr_t m_nRenderHeight(){return SCHEMA_TYPE(uintptr_t,0x24);}
};
