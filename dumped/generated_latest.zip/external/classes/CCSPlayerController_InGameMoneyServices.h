#pragma once
#include "../memory.h"

class CCSPlayerController_InGameMoneyServices  {
public:
    uintptr_t baseAddr;

    CCSPlayerController_InGameMoneyServices() { baseAddr = client_base(); }
    CCSPlayerController_InGameMoneyServices(uintptr_t base) : baseAddr(base) {}

    int m_iAccount() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController_InGameMoneyServices", "m_iAccount")); }
    int m_iStartAccount() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController_InGameMoneyServices", "m_iStartAccount")); }
    int m_iTotalCashSpent() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController_InGameMoneyServices", "m_iTotalCashSpent")); }
    int m_iCashSpentThisRound() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController_InGameMoneyServices", "m_iCashSpentThisRound")); }
};
