#pragma once
#include "../memory.h"

class C_SoundEventPathCornerEntity {
public:
 uintptr_t baseAddr;
 C_SoundEventPathCornerEntity() : baseAddr(0){}
 C_SoundEventPathCornerEntity(uintptr_t b):baseAddr(b){}
 uintptr_t m_vecCornerPairsNetworked(){return SCHEMA_TYPE(uintptr_t,0x6C0);}
};
