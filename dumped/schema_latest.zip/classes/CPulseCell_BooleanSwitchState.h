#pragma once
#include "../memory.h"

class CPulseCell_BooleanSwitchState {
public:
 uintptr_t baseAddr;
 CPulseCell_BooleanSwitchState() : baseAddr(0){}
 CPulseCell_BooleanSwitchState(uintptr_t b):baseAddr(b){}
 uintptr_t m_Condition(){return SCHEMA_TYPE(uintptr_t,0x48);}
 uintptr_t m_SubGraph(){return SCHEMA_TYPE(uintptr_t,0xC0);}
 uintptr_t m_WhenTrue(){return SCHEMA_TYPE(uintptr_t,0x108);}
 uintptr_t m_WhenFalse(){return SCHEMA_TYPE(uintptr_t,0x150);}
};
