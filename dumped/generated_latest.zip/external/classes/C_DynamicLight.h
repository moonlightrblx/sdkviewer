#pragma once
#include "../memory.h"

class C_DynamicLight  {
public:
    uintptr_t baseAddr;

    C_DynamicLight() { baseAddr = client_base(); }
    C_DynamicLight(uintptr_t base) : baseAddr(base) {}

    uint8_t m_Flags() { return read<uint8_t>(baseAddr + offsets_instance.get("C_DynamicLight", "m_Flags")); }
    uint8_t m_LightStyle() { return read<uint8_t>(baseAddr + offsets_instance.get("C_DynamicLight", "m_LightStyle")); }
    float m_Radius() { return read<float>(baseAddr + offsets_instance.get("C_DynamicLight", "m_Radius")); }
    int m_Exponent() { return read<int>(baseAddr + offsets_instance.get("C_DynamicLight", "m_Exponent")); }
    float m_InnerAngle() { return read<float>(baseAddr + offsets_instance.get("C_DynamicLight", "m_InnerAngle")); }
    float m_OuterAngle() { return read<float>(baseAddr + offsets_instance.get("C_DynamicLight", "m_OuterAngle")); }
    float m_SpotRadius() { return read<float>(baseAddr + offsets_instance.get("C_DynamicLight", "m_SpotRadius")); }
};
