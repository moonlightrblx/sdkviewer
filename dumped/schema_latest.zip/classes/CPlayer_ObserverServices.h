#pragma once
#include "../memory.h"

class CPlayer_ObserverServices {
public:
 uintptr_t baseAddr;
 CPlayer_ObserverServices() : baseAddr(0){}
 CPlayer_ObserverServices(uintptr_t b):baseAddr(b){}
 uintptr_t m_iObserverMode(){return SCHEMA_TYPE(uintptr_t,0x40);}
 uintptr_t m_hObserverTarget(){return SCHEMA_TYPE(uintptr_t,0x44);}
 uintptr_t m_iObserverLastMode(){return SCHEMA_TYPE(uintptr_t,0x48);}
 uintptr_t m_bForcedObserverMode(){return SCHEMA_TYPE(uintptr_t,0x4C);}
 uintptr_t m_flObserverChaseDistance(){return SCHEMA_TYPE(uintptr_t,0x50);}
 uintptr_t m_flObserverChaseDistanceCalcTime(){return SCHEMA_TYPE(uintptr_t,0x54);}
};
