#pragma once
#include "../memory.h"

class C_FuncLadder {
public:
 uintptr_t baseAddr;
 C_FuncLadder() : baseAddr(0){}
 C_FuncLadder(uintptr_t b):baseAddr(b){}
 uintptr_t m_vecLadderDir(){return SCHEMA_TYPE(uintptr_t,0xEB0);}
 uintptr_t m_Dismounts(){return SCHEMA_TYPE(uintptr_t,0xEC0);}
 uintptr_t m_vecLocalTop(){return SCHEMA_TYPE(uintptr_t,0xED8);}
 uintptr_t m_vecPlayerMountPositionTop(){return SCHEMA_TYPE(uintptr_t,0xEE4);}
 uintptr_t m_vecPlayerMountPositionBottom(){return SCHEMA_TYPE(uintptr_t,0xEF0);}
 uintptr_t m_flAutoRideSpeed(){return SCHEMA_TYPE(uintptr_t,0xEFC);}
 uintptr_t m_bDisabled(){return SCHEMA_TYPE(uintptr_t,0xF00);}
 uintptr_t m_bFakeLadder(){return SCHEMA_TYPE(uintptr_t,0xF01);}
 uintptr_t m_bHasSlack(){return SCHEMA_TYPE(uintptr_t,0xF02);}
};
