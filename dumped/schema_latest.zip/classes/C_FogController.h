#pragma once
#include "../memory.h"

class C_FogController {
public:
 uintptr_t baseAddr;
 C_FogController() : baseAddr(0){}
 C_FogController(uintptr_t b):baseAddr(b){}
 uintptr_t m_fog(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_bUseAngles(){return SCHEMA_TYPE(uintptr_t,0x660);}
 uintptr_t m_iChangedVariables(){return SCHEMA_TYPE(uintptr_t,0x664);}
};
