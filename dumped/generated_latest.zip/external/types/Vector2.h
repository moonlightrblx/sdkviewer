#pragma once
struct Vector2 { float x, y; };
