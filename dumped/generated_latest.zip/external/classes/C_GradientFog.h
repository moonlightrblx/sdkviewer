#pragma once
#include "../memory.h"

class C_GradientFog  {
public:
    uintptr_t baseAddr;

    C_GradientFog() { baseAddr = client_base(); }
    C_GradientFog(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_hGradientFogTexture() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_GradientFog", "m_hGradientFogTexture")); }
    float m_flFogStartDistance() { return read<float>(baseAddr + offsets_instance.get("C_GradientFog", "m_flFogStartDistance")); }
    float m_flFogEndDistance() { return read<float>(baseAddr + offsets_instance.get("C_GradientFog", "m_flFogEndDistance")); }
    bool m_bHeightFogEnabled() { return read<bool>(baseAddr + offsets_instance.get("C_GradientFog", "m_bHeightFogEnabled")); }
    float m_flFogStartHeight() { return read<float>(baseAddr + offsets_instance.get("C_GradientFog", "m_flFogStartHeight")); }
    float m_flFogEndHeight() { return read<float>(baseAddr + offsets_instance.get("C_GradientFog", "m_flFogEndHeight")); }
    float m_flFarZ() { return read<float>(baseAddr + offsets_instance.get("C_GradientFog", "m_flFarZ")); }
    float m_flFogMaxOpacity() { return read<float>(baseAddr + offsets_instance.get("C_GradientFog", "m_flFogMaxOpacity")); }
    float m_flFogFalloffExponent() { return read<float>(baseAddr + offsets_instance.get("C_GradientFog", "m_flFogFalloffExponent")); }
    float m_flFogVerticalExponent() { return read<float>(baseAddr + offsets_instance.get("C_GradientFog", "m_flFogVerticalExponent")); }
    uintptr_t m_fogColor() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_GradientFog", "m_fogColor")); }
    float m_flFogStrength() { return read<float>(baseAddr + offsets_instance.get("C_GradientFog", "m_flFogStrength")); }
    float m_flFadeTime() { return read<float>(baseAddr + offsets_instance.get("C_GradientFog", "m_flFadeTime")); }
    bool m_bStartDisabled() { return read<bool>(baseAddr + offsets_instance.get("C_GradientFog", "m_bStartDisabled")); }
    bool m_bIsEnabled() { return read<bool>(baseAddr + offsets_instance.get("C_GradientFog", "m_bIsEnabled")); }
    bool m_bGradientFogNeedsTextures() { return read<bool>(baseAddr + offsets_instance.get("C_GradientFog", "m_bGradientFogNeedsTextures")); }
};
