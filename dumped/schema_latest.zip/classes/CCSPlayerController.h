#pragma once
#include "../memory.h"

class CCSPlayerController {
public:
 uintptr_t baseAddr;
 CCSPlayerController() : baseAddr(0){}
 CCSPlayerController(uintptr_t b):baseAddr(b){}
 uintptr_t m_pInGameMoneyServices(){return SCHEMA_TYPE(uintptr_t,0x7F8);}
 uintptr_t m_pInventoryServices(){return SCHEMA_TYPE(uintptr_t,0x800);}
 uintptr_t m_pActionTrackingServices(){return SCHEMA_TYPE(uintptr_t,0x808);}
 uintptr_t m_pDamageServices(){return SCHEMA_TYPE(uintptr_t,0x810);}
 uintptr_t m_iPing(){return SCHEMA_TYPE(uintptr_t,0x818);}
 uintptr_t m_bHasCommunicationAbuseMute(){return SCHEMA_TYPE(uintptr_t,0x81C);}
 uintptr_t m_uiCommunicationMuteFlags(){return SCHEMA_TYPE(uintptr_t,0x820);}
 uintptr_t m_szCrosshairCodes(){return SCHEMA_TYPE(uintptr_t,0x828);}
 uintptr_t m_iPendingTeamNum(){return SCHEMA_TYPE(uintptr_t,0x830);}
 uintptr_t m_flForceTeamTime(){return SCHEMA_TYPE(uintptr_t,0x834);}
 uintptr_t m_iCompTeammateColor(){return SCHEMA_TYPE(uintptr_t,0x838);}
 uintptr_t m_bEverPlayedOnTeam(){return SCHEMA_TYPE(uintptr_t,0x83C);}
 uintptr_t m_flPreviousForceJoinTeamTime(){return SCHEMA_TYPE(uintptr_t,0x840);}
 uintptr_t m_szClan(){return SCHEMA_TYPE(uintptr_t,0x848);}
 uintptr_t m_sSanitizedPlayerName(){return SCHEMA_TYPE(uintptr_t,0x850);}
 uintptr_t m_iCoachingTeam(){return SCHEMA_TYPE(uintptr_t,0x858);}
 uintptr_t m_nPlayerDominated(){return SCHEMA_TYPE(uintptr_t,0x860);}
 uintptr_t m_nPlayerDominatingMe(){return SCHEMA_TYPE(uintptr_t,0x868);}
 uintptr_t m_iCompetitiveRanking(){return SCHEMA_TYPE(uintptr_t,0x870);}
 uintptr_t m_iCompetitiveWins(){return SCHEMA_TYPE(uintptr_t,0x874);}
 uintptr_t m_iCompetitiveRankType(){return SCHEMA_TYPE(uintptr_t,0x878);}
 uintptr_t m_iCompetitiveRankingPredicted_Win(){return SCHEMA_TYPE(uintptr_t,0x87C);}
 uintptr_t m_iCompetitiveRankingPredicted_Loss(){return SCHEMA_TYPE(uintptr_t,0x880);}
 uintptr_t m_iCompetitiveRankingPredicted_Tie(){return SCHEMA_TYPE(uintptr_t,0x884);}
 uintptr_t m_nEndMatchNextMapVote(){return SCHEMA_TYPE(uintptr_t,0x888);}
 uintptr_t m_unActiveQuestId(){return SCHEMA_TYPE(uintptr_t,0x88C);}
 uintptr_t m_rtActiveMissionPeriod(){return SCHEMA_TYPE(uintptr_t,0x890);}
 uintptr_t m_nQuestProgressReason(){return SCHEMA_TYPE(uintptr_t,0x894);}
 uintptr_t m_unPlayerTvControlFlags(){return SCHEMA_TYPE(uintptr_t,0x898);}
 uintptr_t m_iDraftIndex(){return SCHEMA_TYPE(uintptr_t,0x8C8);}
 uintptr_t m_msQueuedModeDisconnectionTimestamp(){return SCHEMA_TYPE(uintptr_t,0x8CC);}
 uintptr_t m_uiAbandonRecordedReason(){return SCHEMA_TYPE(uintptr_t,0x8D0);}
 uintptr_t m_eNetworkDisconnectionReason(){return SCHEMA_TYPE(uintptr_t,0x8D4);}
 uintptr_t m_bCannotBeKicked(){return SCHEMA_TYPE(uintptr_t,0x8D8);}
 uintptr_t m_bEverFullyConnected(){return SCHEMA_TYPE(uintptr_t,0x8D9);}
 uintptr_t m_bAbandonAllowsSurrender(){return SCHEMA_TYPE(uintptr_t,0x8DA);}
 uintptr_t m_bAbandonOffersInstantSurrender(){return SCHEMA_TYPE(uintptr_t,0x8DB);}
 uintptr_t m_bDisconnection1MinWarningPrinted(){return SCHEMA_TYPE(uintptr_t,0x8DC);}
 uintptr_t m_bScoreReported(){return SCHEMA_TYPE(uintptr_t,0x8DD);}
 uintptr_t m_nDisconnectionTick(){return SCHEMA_TYPE(uintptr_t,0x8E0);}
 uintptr_t m_bControllingBot(){return SCHEMA_TYPE(uintptr_t,0x8F0);}
 uintptr_t m_bHasControlledBotThisRound(){return SCHEMA_TYPE(uintptr_t,0x8F1);}
 uintptr_t m_bHasBeenControlledByPlayerThisRound(){return SCHEMA_TYPE(uintptr_t,0x8F2);}
 uintptr_t m_nBotsControlledThisRound(){return SCHEMA_TYPE(uintptr_t,0x8F4);}
 uintptr_t m_bCanControlObservedBot(){return SCHEMA_TYPE(uintptr_t,0x8F8);}
 uintptr_t m_hPlayerPawn(){return SCHEMA_TYPE(uintptr_t,0x8FC);}
 uintptr_t m_hObserverPawn(){return SCHEMA_TYPE(uintptr_t,0x900);}
 uintptr_t m_bPawnIsAlive(){return SCHEMA_TYPE(uintptr_t,0x904);}
 uintptr_t m_iPawnHealth(){return SCHEMA_TYPE(uintptr_t,0x908);}
 uintptr_t m_iPawnArmor(){return SCHEMA_TYPE(uintptr_t,0x90C);}
 uintptr_t m_bPawnHasDefuser(){return SCHEMA_TYPE(uintptr_t,0x910);}
 uintptr_t m_bPawnHasHelmet(){return SCHEMA_TYPE(uintptr_t,0x911);}
 uintptr_t m_nPawnCharacterDefIndex(){return SCHEMA_TYPE(uintptr_t,0x912);}
 uintptr_t m_iPawnLifetimeStart(){return SCHEMA_TYPE(uintptr_t,0x914);}
 uintptr_t m_iPawnLifetimeEnd(){return SCHEMA_TYPE(uintptr_t,0x918);}
 uintptr_t m_iPawnBotDifficulty(){return SCHEMA_TYPE(uintptr_t,0x91C);}
 uintptr_t m_hOriginalControllerOfCurrentPawn(){return SCHEMA_TYPE(uintptr_t,0x920);}
 uintptr_t m_iScore(){return SCHEMA_TYPE(uintptr_t,0x924);}
 uintptr_t m_recentKillQueue(){return SCHEMA_TYPE(uintptr_t,0x928);}
 uintptr_t m_nFirstKill(){return SCHEMA_TYPE(uintptr_t,0x930);}
 uintptr_t m_nKillCount(){return SCHEMA_TYPE(uintptr_t,0x931);}
 uintptr_t m_bMvpNoMusic(){return SCHEMA_TYPE(uintptr_t,0x932);}
 uintptr_t m_eMvpReason(){return SCHEMA_TYPE(uintptr_t,0x934);}
 uintptr_t m_iMusicKitID(){return SCHEMA_TYPE(uintptr_t,0x938);}
 uintptr_t m_iMusicKitMVPs(){return SCHEMA_TYPE(uintptr_t,0x93C);}
 uintptr_t m_iMVPs(){return SCHEMA_TYPE(uintptr_t,0x940);}
 uintptr_t m_bIsPlayerNameDirty(){return SCHEMA_TYPE(uintptr_t,0x944);}
 uintptr_t m_bFireBulletsSeedSynchronized(){return SCHEMA_TYPE(uintptr_t,0x945);}
};
