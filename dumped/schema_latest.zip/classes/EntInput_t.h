#pragma once
#include "../memory.h"

class EntInput_t {
public:
 uintptr_t baseAddr;
 EntInput_t() : baseAddr(0){}
 EntInput_t(uintptr_t b):baseAddr(b){}
};
