#pragma once
#include "../memory.h"

class C_WeaponHKP2000  {
public:
    uintptr_t baseAddr;

    C_WeaponHKP2000() { baseAddr = 0; }
    C_WeaponHKP2000(uintptr_t base) : baseAddr(base) {}

};
