#pragma once
#include "../memory.h"
#include "../classes/CPulse_OutflowConnection.h"
#include "../classes/PulseObservableBoolExpression_t.h"

class CPulseCell_BooleanSwitchState  {
public:
    uintptr_t baseAddr;

    CPulseCell_BooleanSwitchState() { baseAddr = 0; }
    CPulseCell_BooleanSwitchState(uintptr_t base) : baseAddr(base) {}

    PulseObservableBoolExpression_t m_Condition() { return read<PulseObservableBoolExpression_t>(baseAddr + offsets_instance.get("CPulseCell_BooleanSwitchState", "m_Condition")); }
    CPulse_OutflowConnection m_SubGraph() { return read<CPulse_OutflowConnection>(baseAddr + offsets_instance.get("CPulseCell_BooleanSwitchState", "m_SubGraph")); }
    CPulse_OutflowConnection m_WhenTrue() { return read<CPulse_OutflowConnection>(baseAddr + offsets_instance.get("CPulseCell_BooleanSwitchState", "m_WhenTrue")); }
    CPulse_OutflowConnection m_WhenFalse() { return read<CPulse_OutflowConnection>(baseAddr + offsets_instance.get("CPulseCell_BooleanSwitchState", "m_WhenFalse")); }
};
