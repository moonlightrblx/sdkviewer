#pragma once
#include "../memory.h"

class C_PointWorldText {
public:
 uintptr_t baseAddr;
 C_PointWorldText() : baseAddr(0){}
 C_PointWorldText(uintptr_t b):baseAddr(b){}
 uintptr_t m_bForceRecreateNextUpdate(){return SCHEMA_TYPE(uintptr_t,0xEB8);}
 uintptr_t m_messageText(){return SCHEMA_TYPE(uintptr_t,0xED0);}
 uintptr_t m_FontName(){return SCHEMA_TYPE(uintptr_t,0x10D0);}
 uintptr_t m_BackgroundMaterialName(){return SCHEMA_TYPE(uintptr_t,0x1110);}
 uintptr_t m_bEnabled(){return SCHEMA_TYPE(uintptr_t,0x1150);}
 uintptr_t m_bFullbright(){return SCHEMA_TYPE(uintptr_t,0x1151);}
 uintptr_t m_flWorldUnitsPerPx(){return SCHEMA_TYPE(uintptr_t,0x1154);}
 uintptr_t m_flFontSize(){return SCHEMA_TYPE(uintptr_t,0x1158);}
 uintptr_t m_flDepthOffset(){return SCHEMA_TYPE(uintptr_t,0x115C);}
 uintptr_t m_bDrawBackground(){return SCHEMA_TYPE(uintptr_t,0x1160);}
 uintptr_t m_flBackgroundBorderWidth(){return SCHEMA_TYPE(uintptr_t,0x1164);}
 uintptr_t m_flBackgroundBorderHeight(){return SCHEMA_TYPE(uintptr_t,0x1168);}
 uintptr_t m_flBackgroundWorldToUV(){return SCHEMA_TYPE(uintptr_t,0x116C);}
 uintptr_t m_Color(){return SCHEMA_TYPE(uintptr_t,0x1170);}
 uintptr_t m_nJustifyHorizontal(){return SCHEMA_TYPE(uintptr_t,0x1174);}
 uintptr_t m_nJustifyVertical(){return SCHEMA_TYPE(uintptr_t,0x1178);}
 uintptr_t m_nReorientMode(){return SCHEMA_TYPE(uintptr_t,0x117C);}
};
