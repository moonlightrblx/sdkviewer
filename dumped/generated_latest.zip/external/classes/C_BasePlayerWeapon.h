#pragma once
#include "../memory.h"

class C_BasePlayerWeapon  {
public:
    uintptr_t baseAddr;

    C_BasePlayerWeapon() { baseAddr = client_base(); }
    C_BasePlayerWeapon(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_nNextPrimaryAttackTick() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BasePlayerWeapon", "m_nNextPrimaryAttackTick")); }
    float m_flNextPrimaryAttackTickRatio() { return read<float>(baseAddr + offsets_instance.get("C_BasePlayerWeapon", "m_flNextPrimaryAttackTickRatio")); }
    uintptr_t m_nNextSecondaryAttackTick() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BasePlayerWeapon", "m_nNextSecondaryAttackTick")); }
    float m_flNextSecondaryAttackTickRatio() { return read<float>(baseAddr + offsets_instance.get("C_BasePlayerWeapon", "m_flNextSecondaryAttackTickRatio")); }
    int m_iClip1() { return read<int>(baseAddr + offsets_instance.get("C_BasePlayerWeapon", "m_iClip1")); }
    int m_iClip2() { return read<int>(baseAddr + offsets_instance.get("C_BasePlayerWeapon", "m_iClip2")); }
    int m_pReserveAmmo() { return read<int>(baseAddr + offsets_instance.get("C_BasePlayerWeapon", "m_pReserveAmmo")); }
};
