#pragma once
#include "../memory.h"

class CPlayer_ItemServices  {
public:
    uintptr_t baseAddr;

    CPlayer_ItemServices() { baseAddr = client_base(); }
    CPlayer_ItemServices(uintptr_t base) : baseAddr(base) {}

};
