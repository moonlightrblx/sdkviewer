#pragma once
#include "../memory.h"

class C_GlobalLight {
public:
 uintptr_t baseAddr;
 C_GlobalLight() : baseAddr(0){}
 C_GlobalLight(uintptr_t b):baseAddr(b){}
 uintptr_t m_WindClothForceHandle(){return SCHEMA_TYPE(uintptr_t,0xAC0);}
};
