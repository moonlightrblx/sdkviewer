#pragma once
#include "../memory.h"

class CPulseCell_BaseRequirement  {
public:
    uintptr_t baseAddr;

    CPulseCell_BaseRequirement() { baseAddr = client_base(); }
    CPulseCell_BaseRequirement(uintptr_t base) : baseAddr(base) {}

};
