#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class CPulseCell_Outflow_CycleShuffled  {
public:
    uintptr_t baseAddr;

    CPulseCell_Outflow_CycleShuffled() { baseAddr = 0; }
    CPulseCell_Outflow_CycleShuffled(uintptr_t base) : baseAddr(base) {}

    Vector3 m_Outputs() { return read<Vector3>(baseAddr + offsets_instance.get("CPulseCell_Outflow_CycleShuffled", "m_Outputs")); }
};
