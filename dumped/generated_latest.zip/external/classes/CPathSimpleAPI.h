#pragma once
#include "../memory.h"

class CPathSimpleAPI  {
public:
    uintptr_t baseAddr;

    CPathSimpleAPI() { baseAddr = client_base(); }
    CPathSimpleAPI(uintptr_t base) : baseAddr(base) {}

};
