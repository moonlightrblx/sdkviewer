#pragma once
#include "../memory.h"

class C_FuncMonitor  {
public:
    uintptr_t baseAddr;

    C_FuncMonitor() { baseAddr = client_base(); }
    C_FuncMonitor(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_targetCamera() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_FuncMonitor", "m_targetCamera")); }
    int m_nResolutionEnum() { return read<int>(baseAddr + offsets_instance.get("C_FuncMonitor", "m_nResolutionEnum")); }
    bool m_bRenderShadows() { return read<bool>(baseAddr + offsets_instance.get("C_FuncMonitor", "m_bRenderShadows")); }
    bool m_bUseUniqueColorTarget() { return read<bool>(baseAddr + offsets_instance.get("C_FuncMonitor", "m_bUseUniqueColorTarget")); }
    uintptr_t m_brushModelName() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_FuncMonitor", "m_brushModelName")); }
    C_BaseEntity* m_hTargetCamera() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_FuncMonitor", "m_hTargetCamera")); }
    bool m_bEnabled() { return read<bool>(baseAddr + offsets_instance.get("C_FuncMonitor", "m_bEnabled")); }
    bool m_bDraw3DSkybox() { return read<bool>(baseAddr + offsets_instance.get("C_FuncMonitor", "m_bDraw3DSkybox")); }
};
