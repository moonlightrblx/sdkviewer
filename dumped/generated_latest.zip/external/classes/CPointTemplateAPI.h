#pragma once
#include "../memory.h"

class CPointTemplateAPI  {
public:
    uintptr_t baseAddr;

    CPointTemplateAPI() { baseAddr = client_base(); }
    CPointTemplateAPI(uintptr_t base) : baseAddr(base) {}

};
