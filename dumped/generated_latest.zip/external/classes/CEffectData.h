#pragma once
#include "../memory.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"

class CEffectData  {
public:
    uintptr_t baseAddr;

    CEffectData() { baseAddr = client_base(); }
    CEffectData(uintptr_t base) : baseAddr(base) {}

    Vector3 m_vOrigin() { return read<Vector3>(baseAddr + offsets_instance.get("CEffectData", "m_vOrigin")); }
    Vector3 m_vStart() { return read<Vector3>(baseAddr + offsets_instance.get("CEffectData", "m_vStart")); }
    Vector3 m_vNormal() { return read<Vector3>(baseAddr + offsets_instance.get("CEffectData", "m_vNormal")); }
    QAngle m_vAngles() { return read<QAngle>(baseAddr + offsets_instance.get("CEffectData", "m_vAngles")); }
    uintptr_t m_hEntity() { return read<uintptr_t>(baseAddr + offsets_instance.get("CEffectData", "m_hEntity")); }
    uintptr_t m_hOtherEntity() { return read<uintptr_t>(baseAddr + offsets_instance.get("CEffectData", "m_hOtherEntity")); }
    float m_flScale() { return read<float>(baseAddr + offsets_instance.get("CEffectData", "m_flScale")); }
    float m_flMagnitude() { return read<float>(baseAddr + offsets_instance.get("CEffectData", "m_flMagnitude")); }
    float m_flRadius() { return read<float>(baseAddr + offsets_instance.get("CEffectData", "m_flRadius")); }
    uintptr_t m_nSurfaceProp() { return read<uintptr_t>(baseAddr + offsets_instance.get("CEffectData", "m_nSurfaceProp")); }
    uintptr_t m_nEffectIndex() { return read<uintptr_t>(baseAddr + offsets_instance.get("CEffectData", "m_nEffectIndex")); }
    int m_nDamageType() { return read<int>(baseAddr + offsets_instance.get("CEffectData", "m_nDamageType")); }
    uint8_t m_nPenetrate() { return read<uint8_t>(baseAddr + offsets_instance.get("CEffectData", "m_nPenetrate")); }
    uint16_t m_nMaterial() { return read<uint16_t>(baseAddr + offsets_instance.get("CEffectData", "m_nMaterial")); }
    uintptr_t m_nHitBox() { return read<uintptr_t>(baseAddr + offsets_instance.get("CEffectData", "m_nHitBox")); }
    uint8_t m_nColor() { return read<uint8_t>(baseAddr + offsets_instance.get("CEffectData", "m_nColor")); }
    uint8_t m_fFlags() { return read<uint8_t>(baseAddr + offsets_instance.get("CEffectData", "m_fFlags")); }
    uintptr_t m_nAttachmentIndex() { return read<uintptr_t>(baseAddr + offsets_instance.get("CEffectData", "m_nAttachmentIndex")); }
    uintptr_t m_nAttachmentName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CEffectData", "m_nAttachmentName")); }
    uint16_t m_iEffectName() { return read<uint16_t>(baseAddr + offsets_instance.get("CEffectData", "m_iEffectName")); }
    uint8_t m_nExplosionType() { return read<uint8_t>(baseAddr + offsets_instance.get("CEffectData", "m_nExplosionType")); }
};
