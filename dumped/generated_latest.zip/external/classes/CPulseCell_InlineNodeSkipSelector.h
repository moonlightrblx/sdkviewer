#pragma once
#include "../memory.h"
#include "../classes/CPulse_OutflowConnection.h"
#include "../classes/PulseSelectorOutflowList_t.h"

class CPulseCell_InlineNodeSkipSelector  {
public:
    uintptr_t baseAddr;

    CPulseCell_InlineNodeSkipSelector() { baseAddr = 0; }
    CPulseCell_InlineNodeSkipSelector(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_nFlowNodeID() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_InlineNodeSkipSelector", "m_nFlowNodeID")); }
    bool m_bAnd() { return read<bool>(baseAddr + offsets_instance.get("CPulseCell_InlineNodeSkipSelector", "m_bAnd")); }
    PulseSelectorOutflowList_t m_PassOutflow() { return read<PulseSelectorOutflowList_t>(baseAddr + offsets_instance.get("CPulseCell_InlineNodeSkipSelector", "m_PassOutflow")); }
    CPulse_OutflowConnection m_FailOutflow() { return read<CPulse_OutflowConnection>(baseAddr + offsets_instance.get("CPulseCell_InlineNodeSkipSelector", "m_FailOutflow")); }
};
