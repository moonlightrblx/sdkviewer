#pragma once
#include "../memory.h"
#include "../classes/GameTime_t.h"

class CPulseCell_IntervalTimer__CursorState_t  {
public:
    uintptr_t baseAddr;

    CPulseCell_IntervalTimer__CursorState_t() { baseAddr = 0; }
    CPulseCell_IntervalTimer__CursorState_t(uintptr_t base) : baseAddr(base) {}

    GameTime_t m_StartTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("CPulseCell_IntervalTimer__CursorState_t", "m_StartTime")); }
    GameTime_t m_EndTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("CPulseCell_IntervalTimer__CursorState_t", "m_EndTime")); }
    float m_flWaitInterval() { return read<float>(baseAddr + offsets_instance.get("CPulseCell_IntervalTimer__CursorState_t", "m_flWaitInterval")); }
    float m_flWaitIntervalHigh() { return read<float>(baseAddr + offsets_instance.get("CPulseCell_IntervalTimer__CursorState_t", "m_flWaitIntervalHigh")); }
    bool m_bCompleteOnNextWake() { return read<bool>(baseAddr + offsets_instance.get("CPulseCell_IntervalTimer__CursorState_t", "m_bCompleteOnNextWake")); }
};
