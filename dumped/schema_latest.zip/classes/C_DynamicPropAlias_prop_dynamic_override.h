#pragma once
#include "../memory.h"

class C_DynamicPropAlias_prop_dynamic_override {
public:
 uintptr_t baseAddr;
 C_DynamicPropAlias_prop_dynamic_override() : baseAddr(0){}
 C_DynamicPropAlias_prop_dynamic_override(uintptr_t b):baseAddr(b){}
};
