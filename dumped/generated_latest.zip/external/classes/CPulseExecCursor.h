#pragma once
#include "../memory.h"

class CPulseExecCursor  {
public:
    uintptr_t baseAddr;

    CPulseExecCursor() { baseAddr = 0; }
    CPulseExecCursor(uintptr_t base) : baseAddr(base) {}

};
