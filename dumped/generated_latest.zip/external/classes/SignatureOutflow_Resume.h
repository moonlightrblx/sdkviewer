#pragma once
#include "../memory.h"

class SignatureOutflow_Resume  {
public:
    uintptr_t baseAddr;

    SignatureOutflow_Resume() { baseAddr = client_base(); }
    SignatureOutflow_Resume(uintptr_t base) : baseAddr(base) {}

};
