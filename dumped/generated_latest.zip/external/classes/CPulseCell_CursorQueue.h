#pragma once
#include "../memory.h"

class CPulseCell_CursorQueue  {
public:
    uintptr_t baseAddr;

    CPulseCell_CursorQueue() { baseAddr = client_base(); }
    CPulseCell_CursorQueue(uintptr_t base) : baseAddr(base) {}

    int m_nCursorsAllowedToRunParallel() { return read<int>(baseAddr + offsets_instance.get("CPulseCell_CursorQueue", "m_nCursorsAllowedToRunParallel")); }
};
