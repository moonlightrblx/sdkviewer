#pragma once
#include "../memory.h"

class CAttributeManager {
public:
 uintptr_t baseAddr;
 CAttributeManager() : baseAddr(0){}
 CAttributeManager(uintptr_t b):baseAddr(b){}
 uintptr_t m_Providers(){return SCHEMA_TYPE(uintptr_t,0x8);}
 uintptr_t m_iReapplyProvisionParity(){return SCHEMA_TYPE(uintptr_t,0x20);}
 uintptr_t m_hOuter(){return SCHEMA_TYPE(uintptr_t,0x24);}
 uintptr_t m_bPreventLoopback(){return SCHEMA_TYPE(uintptr_t,0x28);}
 uintptr_t m_ProviderType(){return SCHEMA_TYPE(uintptr_t,0x2C);}
 uintptr_t m_CachedResults(){return SCHEMA_TYPE(uintptr_t,0x30);}
};
