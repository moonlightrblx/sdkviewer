#pragma once
#include "../memory.h"

class C_HEGrenade {
public:
 uintptr_t baseAddr;
 C_HEGrenade() : baseAddr(0){}
 C_HEGrenade(uintptr_t b):baseAddr(b){}
};
