#pragma once
#include "../memory.h"

class C_LightEntity {
public:
 uintptr_t baseAddr;
 C_LightEntity() : baseAddr(0){}
 C_LightEntity(uintptr_t b):baseAddr(b){}
 uintptr_t m_CLightComponent(){return SCHEMA_TYPE(uintptr_t,0xEB0);}
};
