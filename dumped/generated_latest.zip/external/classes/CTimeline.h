#pragma once
#include "../memory.h"

class CTimeline  {
public:
    uintptr_t baseAddr;

    CTimeline() { baseAddr = client_base(); }
    CTimeline(uintptr_t base) : baseAddr(base) {}

    float m_flValues() { return read<float>(baseAddr + offsets_instance.get("CTimeline", "m_flValues")); }
    int m_nValueCounts() { return read<int>(baseAddr + offsets_instance.get("CTimeline", "m_nValueCounts")); }
    int m_nBucketCount() { return read<int>(baseAddr + offsets_instance.get("CTimeline", "m_nBucketCount")); }
    float m_flInterval() { return read<float>(baseAddr + offsets_instance.get("CTimeline", "m_flInterval")); }
    float m_flFinalValue() { return read<float>(baseAddr + offsets_instance.get("CTimeline", "m_flFinalValue")); }
    uintptr_t m_nCompressionType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CTimeline", "m_nCompressionType")); }
    bool m_bStopped() { return read<bool>(baseAddr + offsets_instance.get("CTimeline", "m_bStopped")); }
};
