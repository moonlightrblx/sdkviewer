#pragma once
#include "../memory.h"

class CPulseCell_LerpCameraSettings__CursorState_t {
public:
 uintptr_t baseAddr;
 CPulseCell_LerpCameraSettings__CursorState_t() : baseAddr(0){}
 CPulseCell_LerpCameraSettings__CursorState_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_hCamera(){return SCHEMA_TYPE(uintptr_t,0x8);}
 uintptr_t m_OverlaidStart(){return SCHEMA_TYPE(uintptr_t,0xC);}
 uintptr_t m_OverlaidEnd(){return SCHEMA_TYPE(uintptr_t,0x1C);}
};
