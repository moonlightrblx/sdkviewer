#pragma once
#include "../memory.h"

class EventClientProcessInput_t {
public:
 uintptr_t baseAddr;
 EventClientProcessInput_t() : baseAddr(0){}
 EventClientProcessInput_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_LoopState(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_flRealTime(){return SCHEMA_TYPE(uintptr_t,0x28);}
 uintptr_t m_flTickInterval(){return SCHEMA_TYPE(uintptr_t,0x2C);}
 uintptr_t m_flTickStartTime(){return SCHEMA_TYPE(uintptr_t,0x30);}
};
