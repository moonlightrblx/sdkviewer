#pragma once
#include "../memory.h"

class C_CSGO_PreviewModel  {
public:
    uintptr_t baseAddr;

    C_CSGO_PreviewModel() { baseAddr = client_base(); }
    C_CSGO_PreviewModel(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_defaultAnim() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSGO_PreviewModel", "m_defaultAnim")); }
    uintptr_t m_nDefaultAnimLoopMode() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSGO_PreviewModel", "m_nDefaultAnimLoopMode")); }
    float m_flInitialModelScale() { return read<float>(baseAddr + offsets_instance.get("C_CSGO_PreviewModel", "m_flInitialModelScale")); }
    uintptr_t m_sInitialWeaponState() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSGO_PreviewModel", "m_sInitialWeaponState")); }
};
