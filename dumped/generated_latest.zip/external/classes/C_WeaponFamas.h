#pragma once
#include "../memory.h"

class C_WeaponFamas  {
public:
    uintptr_t baseAddr;

    C_WeaponFamas() { baseAddr = 0; }
    C_WeaponFamas(uintptr_t base) : baseAddr(base) {}

};
