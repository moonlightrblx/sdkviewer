#pragma once
#include "../memory.h"

class CInfoDynamicShadowHintBox {
public:
 uintptr_t baseAddr;
 CInfoDynamicShadowHintBox() : baseAddr(0){}
 CInfoDynamicShadowHintBox(uintptr_t b):baseAddr(b){}
 uintptr_t m_vBoxMins(){return SCHEMA_TYPE(uintptr_t,0x610);}
 uintptr_t m_vBoxMaxs(){return SCHEMA_TYPE(uintptr_t,0x61C);}
};
