#pragma once
#include "../memory.h"

class CEffectData {
public:
 uintptr_t baseAddr;
 CEffectData() : baseAddr(0){}
 CEffectData(uintptr_t b):baseAddr(b){}
 uintptr_t m_vOrigin(){return SCHEMA_TYPE(uintptr_t,0x8);}
 uintptr_t m_vStart(){return SCHEMA_TYPE(uintptr_t,0x14);}
 uintptr_t m_vNormal(){return SCHEMA_TYPE(uintptr_t,0x20);}
 uintptr_t m_vAngles(){return SCHEMA_TYPE(uintptr_t,0x2C);}
 uintptr_t m_hEntity(){return SCHEMA_TYPE(uintptr_t,0x38);}
 uintptr_t m_hOtherEntity(){return SCHEMA_TYPE(uintptr_t,0x3C);}
 uintptr_t m_flScale(){return SCHEMA_TYPE(uintptr_t,0x40);}
 uintptr_t m_flMagnitude(){return SCHEMA_TYPE(uintptr_t,0x44);}
 uintptr_t m_flRadius(){return SCHEMA_TYPE(uintptr_t,0x48);}
 uintptr_t m_nSurfaceProp(){return SCHEMA_TYPE(uintptr_t,0x4C);}
 uintptr_t m_nEffectIndex(){return SCHEMA_TYPE(uintptr_t,0x50);}
 uintptr_t m_nDamageType(){return SCHEMA_TYPE(uintptr_t,0x58);}
 uintptr_t m_nPenetrate(){return SCHEMA_TYPE(uintptr_t,0x5C);}
 uintptr_t m_nMaterial(){return SCHEMA_TYPE(uintptr_t,0x5E);}
 uintptr_t m_nHitBox(){return SCHEMA_TYPE(uintptr_t,0x60);}
 uintptr_t m_nColor(){return SCHEMA_TYPE(uintptr_t,0x62);}
 uintptr_t m_fFlags(){return SCHEMA_TYPE(uintptr_t,0x63);}
 uintptr_t m_nAttachmentIndex(){return SCHEMA_TYPE(uintptr_t,0x64);}
 uintptr_t m_nAttachmentName(){return SCHEMA_TYPE(uintptr_t,0x68);}
 uintptr_t m_iEffectName(){return SCHEMA_TYPE(uintptr_t,0x6C);}
 uintptr_t m_nExplosionType(){return SCHEMA_TYPE(uintptr_t,0x6E);}
};
