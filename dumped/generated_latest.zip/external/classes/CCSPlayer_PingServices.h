#pragma once
#include "../memory.h"

class CCSPlayer_PingServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_PingServices() { baseAddr = client_base(); }
    CCSPlayer_PingServices(uintptr_t base) : baseAddr(base) {}

    C_PlayerPing* m_hPlayerPing() { return read<C_PlayerPing*>(baseAddr + offsets_instance.get("CCSPlayer_PingServices", "m_hPlayerPing")); }
};
