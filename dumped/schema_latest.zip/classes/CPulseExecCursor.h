#pragma once
#include "../memory.h"

class CPulseExecCursor {
public:
 uintptr_t baseAddr;
 CPulseExecCursor() : baseAddr(0){}
 CPulseExecCursor(uintptr_t b):baseAddr(b){}
};
