#pragma once
#include "../memory.h"

class C_ShatterGlassShardPhysics  {
public:
    uintptr_t baseAddr;

    C_ShatterGlassShardPhysics() { baseAddr = client_base(); }
    C_ShatterGlassShardPhysics(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_ShardDesc() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_ShatterGlassShardPhysics", "m_ShardDesc")); }
};
