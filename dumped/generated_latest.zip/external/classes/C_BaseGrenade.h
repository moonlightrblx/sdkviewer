#pragma once
#include "../memory.h"
#include "../classes/GameTime_t.h"
class C_CSPlayerPawn;

class C_BaseGrenade  {
public:
    uintptr_t baseAddr;

    C_BaseGrenade() { baseAddr = 0; }
    C_BaseGrenade(uintptr_t base) : baseAddr(base) {}

    bool m_bHasWarnedAI() { return read<bool>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_bHasWarnedAI")); }
    bool m_bIsSmokeGrenade() { return read<bool>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_bIsSmokeGrenade")); }
    bool m_bIsLive() { return read<bool>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_bIsLive")); }
    float m_DmgRadius() { return read<float>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_DmgRadius")); }
    GameTime_t m_flDetonateTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_flDetonateTime")); }
    float m_flWarnAITime() { return read<float>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_flWarnAITime")); }
    float m_flDamage() { return read<float>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_flDamage")); }
    uintptr_t m_iszBounceSound() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_iszBounceSound")); }
    uintptr_t m_ExplosionSound() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_ExplosionSound")); }
    C_CSPlayerPawn* m_hThrower() { return read<C_CSPlayerPawn*>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_hThrower")); }
    GameTime_t m_flNextAttack() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_flNextAttack")); }
    C_CSPlayerPawn* m_hOriginalThrower() { return read<C_CSPlayerPawn*>(baseAddr + offsets_instance.get("C_BaseGrenade", "m_hOriginalThrower")); }
};
