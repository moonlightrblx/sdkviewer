#pragma once
#include "../memory.h"
#include "../classes/CPulse_ResumePoint.h"

class CPulseCell_Inflow_Yield  {
public:
    uintptr_t baseAddr;

    CPulseCell_Inflow_Yield() { baseAddr = 0; }
    CPulseCell_Inflow_Yield(uintptr_t base) : baseAddr(base) {}

    CPulse_ResumePoint m_UnyieldResume() { return read<CPulse_ResumePoint>(baseAddr + offsets_instance.get("CPulseCell_Inflow_Yield", "m_UnyieldResume")); }
};
