#pragma once
#include "../memory.h"

class C_WeaponMP5SD {
public:
 uintptr_t baseAddr;
 C_WeaponMP5SD() : baseAddr(0){}
 C_WeaponMP5SD(uintptr_t b):baseAddr(b){}
};
