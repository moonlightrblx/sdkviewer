#pragma once
#include "../memory.h"

class C_BasePropDoor {
public:
 uintptr_t baseAddr;
 C_BasePropDoor() : baseAddr(0){}
 C_BasePropDoor(uintptr_t b):baseAddr(b){}
 uintptr_t m_eDoorState(){return SCHEMA_TYPE(uintptr_t,0x1430);}
 uintptr_t m_modelChanged(){return SCHEMA_TYPE(uintptr_t,0x1434);}
 uintptr_t m_bLocked(){return SCHEMA_TYPE(uintptr_t,0x1435);}
 uintptr_t m_bNoNPCs(){return SCHEMA_TYPE(uintptr_t,0x1436);}
 uintptr_t m_closedPosition(){return SCHEMA_TYPE(uintptr_t,0x1438);}
 uintptr_t m_closedAngles(){return SCHEMA_TYPE(uintptr_t,0x1444);}
 uintptr_t m_hMaster(){return SCHEMA_TYPE(uintptr_t,0x1450);}
 uintptr_t m_vWhereToSetLightingOrigin(){return SCHEMA_TYPE(uintptr_t,0x1454);}
};
