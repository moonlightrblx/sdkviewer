#pragma once
#include "../memory.h"

class CEnvSoundscapeProxy {
public:
 uintptr_t baseAddr;
 CEnvSoundscapeProxy() : baseAddr(0){}
 CEnvSoundscapeProxy(uintptr_t b):baseAddr(b){}
 uintptr_t m_MainSoundscapeName(){return SCHEMA_TYPE(uintptr_t,0x698);}
};
