#pragma once
#include "../memory.h"

class CGrenadeTracer  {
public:
    uintptr_t baseAddr;

    CGrenadeTracer() { baseAddr = 0; }
    CGrenadeTracer(uintptr_t base) : baseAddr(base) {}

    float m_flTracerDuration() { return read<float>(baseAddr + offsets_instance.get("CGrenadeTracer", "m_flTracerDuration")); }
    uintptr_t m_nType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CGrenadeTracer", "m_nType")); }
};
