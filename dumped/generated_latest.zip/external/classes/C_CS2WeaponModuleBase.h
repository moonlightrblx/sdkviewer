#pragma once
#include "../memory.h"

class C_CS2WeaponModuleBase  {
public:
    uintptr_t baseAddr;

    C_CS2WeaponModuleBase() { baseAddr = 0; }
    C_CS2WeaponModuleBase(uintptr_t base) : baseAddr(base) {}

};
