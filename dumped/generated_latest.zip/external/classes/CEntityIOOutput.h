#pragma once
#include "../memory.h"

class CEntityIOOutput  {
public:
    uintptr_t baseAddr;

    CEntityIOOutput() { baseAddr = 0; }
    CEntityIOOutput(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_Value() { return read<uintptr_t>(baseAddr + offsets_instance.get("CEntityIOOutput", "m_Value")); }
};
