#pragma once
#include "../memory.h"

class C_EconEntity {
public:
 uintptr_t baseAddr;
 C_EconEntity() : baseAddr(0){}
 C_EconEntity(uintptr_t b):baseAddr(b){}
 uintptr_t m_flFlexDelayTime(){return SCHEMA_TYPE(uintptr_t,0x1378);}
 uintptr_t m_flFlexDelayedWeight(){return SCHEMA_TYPE(uintptr_t,0x1380);}
 uintptr_t m_bAttributesInitialized(){return SCHEMA_TYPE(uintptr_t,0x1388);}
 uintptr_t m_AttributeManager(){return SCHEMA_TYPE(uintptr_t,0x1390);}
 uintptr_t m_OriginalOwnerXuidLow(){return SCHEMA_TYPE(uintptr_t,0x1868);}
 uintptr_t m_OriginalOwnerXuidHigh(){return SCHEMA_TYPE(uintptr_t,0x186C);}
 uintptr_t m_nFallbackPaintKit(){return SCHEMA_TYPE(uintptr_t,0x1870);}
 uintptr_t m_nFallbackSeed(){return SCHEMA_TYPE(uintptr_t,0x1874);}
 uintptr_t m_flFallbackWear(){return SCHEMA_TYPE(uintptr_t,0x1878);}
 uintptr_t m_nFallbackStatTrak(){return SCHEMA_TYPE(uintptr_t,0x187C);}
 uintptr_t m_bClientside(){return SCHEMA_TYPE(uintptr_t,0x1880);}
 uintptr_t m_bParticleSystemsCreated(){return SCHEMA_TYPE(uintptr_t,0x1881);}
 uintptr_t m_vecAttachedParticles(){return SCHEMA_TYPE(uintptr_t,0x1888);}
 uintptr_t m_hViewmodelAttachment(){return SCHEMA_TYPE(uintptr_t,0x18A0);}
 uintptr_t m_iOldTeam(){return SCHEMA_TYPE(uintptr_t,0x18A4);}
 uintptr_t m_bAttachmentDirty(){return SCHEMA_TYPE(uintptr_t,0x18A8);}
 uintptr_t m_nUnloadedModelIndex(){return SCHEMA_TYPE(uintptr_t,0x18AC);}
 uintptr_t m_iNumOwnerValidationRetries(){return SCHEMA_TYPE(uintptr_t,0x18B0);}
 uintptr_t m_hOldProvidee(){return SCHEMA_TYPE(uintptr_t,0x18C0);}
 uintptr_t m_vecAttachedModels(){return SCHEMA_TYPE(uintptr_t,0x18C8);}
};
