#pragma once
#include "../memory.h"

class C_RectLight {
public:
 uintptr_t baseAddr;
 C_RectLight() : baseAddr(0){}
 C_RectLight(uintptr_t b):baseAddr(b){}
 uintptr_t m_bShowLight(){return SCHEMA_TYPE(uintptr_t,0x1200);}
};
