#pragma once
#include "../memory.h"

class CCSPlayer_HostageServices {
public:
 uintptr_t baseAddr;
 CCSPlayer_HostageServices() : baseAddr(0){}
 CCSPlayer_HostageServices(uintptr_t b):baseAddr(b){}
 uintptr_t m_hCarriedHostage(){return SCHEMA_TYPE(uintptr_t,0x40);}
 uintptr_t m_hCarriedHostageProp(){return SCHEMA_TYPE(uintptr_t,0x44);}
};
