#pragma once
#include "../memory.h"
#include "../classes/C_EconItemView.h"

class C_CSGO_TeamPreviewCharacterPosition  {
public:
    uintptr_t baseAddr;

    C_CSGO_TeamPreviewCharacterPosition() { baseAddr = 0; }
    C_CSGO_TeamPreviewCharacterPosition(uintptr_t base) : baseAddr(base) {}

    int m_nVariant() { return read<int>(baseAddr + offsets_instance.get("C_CSGO_TeamPreviewCharacterPosition", "m_nVariant")); }
    int m_nRandom() { return read<int>(baseAddr + offsets_instance.get("C_CSGO_TeamPreviewCharacterPosition", "m_nRandom")); }
    int m_nOrdinal() { return read<int>(baseAddr + offsets_instance.get("C_CSGO_TeamPreviewCharacterPosition", "m_nOrdinal")); }
    uintptr_t m_sWeaponName() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSGO_TeamPreviewCharacterPosition", "m_sWeaponName")); }
    uintptr_t m_xuid() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSGO_TeamPreviewCharacterPosition", "m_xuid")); }
    C_EconItemView m_agentItem() { return read<C_EconItemView>(baseAddr + offsets_instance.get("C_CSGO_TeamPreviewCharacterPosition", "m_agentItem")); }
    C_EconItemView m_glovesItem() { return read<C_EconItemView>(baseAddr + offsets_instance.get("C_CSGO_TeamPreviewCharacterPosition", "m_glovesItem")); }
    C_EconItemView m_weaponItem() { return read<C_EconItemView>(baseAddr + offsets_instance.get("C_CSGO_TeamPreviewCharacterPosition", "m_weaponItem")); }
};
