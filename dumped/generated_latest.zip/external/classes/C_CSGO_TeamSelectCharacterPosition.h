#pragma once
#include "../memory.h"

class C_CSGO_TeamSelectCharacterPosition  {
public:
    uintptr_t baseAddr;

    C_CSGO_TeamSelectCharacterPosition() { baseAddr = 0; }
    C_CSGO_TeamSelectCharacterPosition(uintptr_t base) : baseAddr(base) {}

};
