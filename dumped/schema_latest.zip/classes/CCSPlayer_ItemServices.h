#pragma once
#include "../memory.h"

class CCSPlayer_ItemServices {
public:
 uintptr_t baseAddr;
 CCSPlayer_ItemServices() : baseAddr(0){}
 CCSPlayer_ItemServices(uintptr_t b):baseAddr(b){}
 uintptr_t m_bHasDefuser(){return SCHEMA_TYPE(uintptr_t,0x40);}
 uintptr_t m_bHasHelmet(){return SCHEMA_TYPE(uintptr_t,0x41);}
};
