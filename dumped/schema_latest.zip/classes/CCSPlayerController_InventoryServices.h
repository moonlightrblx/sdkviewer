#pragma once
#include "../memory.h"

class CCSPlayerController_InventoryServices {
public:
 uintptr_t baseAddr;
 CCSPlayerController_InventoryServices() : baseAddr(0){}
 CCSPlayerController_InventoryServices(uintptr_t b):baseAddr(b){}
 uintptr_t m_vecNetworkableLoadout(){return SCHEMA_TYPE(uintptr_t,0x40);}
 uintptr_t m_unMusicID(){return SCHEMA_TYPE(uintptr_t,0x58);}
 uintptr_t m_rank(){return SCHEMA_TYPE(uintptr_t,0x5C);}
 uintptr_t m_nPersonaDataPublicLevel(){return SCHEMA_TYPE(uintptr_t,0x74);}
 uintptr_t m_nPersonaDataPublicCommendsLeader(){return SCHEMA_TYPE(uintptr_t,0x78);}
 uintptr_t m_nPersonaDataPublicCommendsTeacher(){return SCHEMA_TYPE(uintptr_t,0x7C);}
 uintptr_t m_nPersonaDataPublicCommendsFriendly(){return SCHEMA_TYPE(uintptr_t,0x80);}
 uintptr_t m_nPersonaDataXpTrailLevel(){return SCHEMA_TYPE(uintptr_t,0x84);}
 uintptr_t m_vecServerAuthoritativeWeaponSlots(){return SCHEMA_TYPE(uintptr_t,0x88);}
};
