#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_PhysMagnet  {
public:
    uintptr_t baseAddr;

    C_PhysMagnet() { baseAddr = client_base(); }
    C_PhysMagnet(uintptr_t base) : baseAddr(base) {}

    int m_aAttachedObjectsFromServer() { return read<int>(baseAddr + offsets_instance.get("C_PhysMagnet", "m_aAttachedObjectsFromServer")); }
    Vector3 m_aAttachedObjects() { return read<Vector3>(baseAddr + offsets_instance.get("C_PhysMagnet", "m_aAttachedObjects")); }
};
