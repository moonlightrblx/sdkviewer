#pragma once
#include "../memory.h"

class CBodyComponentSkeletonInstance  {
public:
    uintptr_t baseAddr;

    CBodyComponentSkeletonInstance() { baseAddr = client_base(); }
    CBodyComponentSkeletonInstance(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_skeletonInstance() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBodyComponentSkeletonInstance", "m_skeletonInstance")); }
};
