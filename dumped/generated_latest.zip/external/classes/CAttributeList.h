#pragma once
#include "../memory.h"
#include "../types/Vector3.h"
class CAttributeManager;

class CAttributeList  {
public:
    uintptr_t baseAddr;

    CAttributeList() { baseAddr = 0; }
    CAttributeList(uintptr_t base) : baseAddr(base) {}

    Vector3 m_Attributes() { return read<Vector3>(baseAddr + offsets_instance.get("CAttributeList", "m_Attributes")); }
    CAttributeManager* m_pManager() { return read<CAttributeManager*>(baseAddr + offsets_instance.get("CAttributeList", "m_pManager")); }
};
