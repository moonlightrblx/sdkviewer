#pragma once
#include "../memory.h"

class CBasePlayerVData  {
public:
    uintptr_t baseAddr;

    CBasePlayerVData() { baseAddr = 0; }
    CBasePlayerVData(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_sModelName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBasePlayerVData", "m_sModelName")); }
    uintptr_t m_flHeadDamageMultiplier() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBasePlayerVData", "m_flHeadDamageMultiplier")); }
    uintptr_t m_flChestDamageMultiplier() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBasePlayerVData", "m_flChestDamageMultiplier")); }
    uintptr_t m_flStomachDamageMultiplier() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBasePlayerVData", "m_flStomachDamageMultiplier")); }
    uintptr_t m_flArmDamageMultiplier() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBasePlayerVData", "m_flArmDamageMultiplier")); }
    uintptr_t m_flLegDamageMultiplier() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBasePlayerVData", "m_flLegDamageMultiplier")); }
    float m_flHoldBreathTime() { return read<float>(baseAddr + offsets_instance.get("CBasePlayerVData", "m_flHoldBreathTime")); }
    float m_flDrowningDamageInterval() { return read<float>(baseAddr + offsets_instance.get("CBasePlayerVData", "m_flDrowningDamageInterval")); }
    int m_nDrowningDamageInitial() { return read<int>(baseAddr + offsets_instance.get("CBasePlayerVData", "m_nDrowningDamageInitial")); }
    int m_nDrowningDamageMax() { return read<int>(baseAddr + offsets_instance.get("CBasePlayerVData", "m_nDrowningDamageMax")); }
    int m_nWaterSpeed() { return read<int>(baseAddr + offsets_instance.get("CBasePlayerVData", "m_nWaterSpeed")); }
    float m_flUseRange() { return read<float>(baseAddr + offsets_instance.get("CBasePlayerVData", "m_flUseRange")); }
    float m_flUseAngleTolerance() { return read<float>(baseAddr + offsets_instance.get("CBasePlayerVData", "m_flUseAngleTolerance")); }
    float m_flCrouchTime() { return read<float>(baseAddr + offsets_instance.get("CBasePlayerVData", "m_flCrouchTime")); }
};
