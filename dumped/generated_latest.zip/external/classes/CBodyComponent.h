#pragma once
#include "../memory.h"

class CBodyComponent  {
public:
    uintptr_t baseAddr;

    CBodyComponent() { baseAddr = client_base(); }
    CBodyComponent(uintptr_t base) : baseAddr(base) {}

    CGameSceneNode* m_pSceneNode() { return read<CGameSceneNode*>(baseAddr + offsets_instance.get("CBodyComponent", "m_pSceneNode")); }
    uintptr_t __m_pChainEntity() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBodyComponent", "__m_pChainEntity")); }
};
