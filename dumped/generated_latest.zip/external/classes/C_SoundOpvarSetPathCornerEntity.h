#pragma once
#include "../memory.h"

class C_SoundOpvarSetPathCornerEntity  {
public:
    uintptr_t baseAddr;

    C_SoundOpvarSetPathCornerEntity() { baseAddr = 0; }
    C_SoundOpvarSetPathCornerEntity(uintptr_t base) : baseAddr(base) {}

};
