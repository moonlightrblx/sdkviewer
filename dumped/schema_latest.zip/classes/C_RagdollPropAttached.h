#pragma once
#include "../memory.h"

class C_RagdollPropAttached {
public:
 uintptr_t baseAddr;
 C_RagdollPropAttached() : baseAddr(0){}
 C_RagdollPropAttached(uintptr_t b):baseAddr(b){}
 uintptr_t m_boneIndexAttached(){return SCHEMA_TYPE(uintptr_t,0x11E8);}
 uintptr_t m_ragdollAttachedObjectIndex(){return SCHEMA_TYPE(uintptr_t,0x11EC);}
 uintptr_t m_attachmentPointBoneSpace(){return SCHEMA_TYPE(uintptr_t,0x11F0);}
 uintptr_t m_attachmentPointRagdollSpace(){return SCHEMA_TYPE(uintptr_t,0x11FC);}
 uintptr_t m_vecOffset(){return SCHEMA_TYPE(uintptr_t,0x1208);}
 uintptr_t m_parentTime(){return SCHEMA_TYPE(uintptr_t,0x1214);}
 uintptr_t m_bHasParent(){return SCHEMA_TYPE(uintptr_t,0x1218);}
};
