#pragma once
#include "../memory.h"

class CPulseCell_Inflow_GraphHook  {
public:
    uintptr_t baseAddr;

    CPulseCell_Inflow_GraphHook() { baseAddr = 0; }
    CPulseCell_Inflow_GraphHook(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_HookName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Inflow_GraphHook", "m_HookName")); }
};
