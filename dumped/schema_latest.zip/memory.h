#pragma once
#include <cstdint>
#include <cstddef>
#include "../updater/updater.h"
template<typename T>inline T read(uintptr_t a){return*(T*)a;}
#define SCHEMA_TYPE(type,offset) read<type>(baseAddr+offset)
inline c_offsets offsets_instance;
