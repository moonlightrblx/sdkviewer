#pragma once
#include "../memory.h"

class C_FireCrackerBlast  {
public:
    uintptr_t baseAddr;

    C_FireCrackerBlast() { baseAddr = 0; }
    C_FireCrackerBlast(uintptr_t base) : baseAddr(base) {}

};
