#pragma once
#include "../memory.h"
#include "../classes/EntitySpottedState_t.h"
#include "../classes/GameTime_t.h"

class C_C4  {
public:
    uintptr_t baseAddr;

    C_C4() { baseAddr = 0; }
    C_C4(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_activeLightParticleIndex() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_C4", "m_activeLightParticleIndex")); }
    uintptr_t m_eActiveLightEffect() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_C4", "m_eActiveLightEffect")); }
    bool m_bStartedArming() { return read<bool>(baseAddr + offsets_instance.get("C_C4", "m_bStartedArming")); }
    GameTime_t m_fArmedTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_C4", "m_fArmedTime")); }
    bool m_bBombPlacedAnimation() { return read<bool>(baseAddr + offsets_instance.get("C_C4", "m_bBombPlacedAnimation")); }
    bool m_bIsPlantingViaUse() { return read<bool>(baseAddr + offsets_instance.get("C_C4", "m_bIsPlantingViaUse")); }
    EntitySpottedState_t m_entitySpottedState() { return read<EntitySpottedState_t>(baseAddr + offsets_instance.get("C_C4", "m_entitySpottedState")); }
    int m_nSpotRules() { return read<int>(baseAddr + offsets_instance.get("C_C4", "m_nSpotRules")); }
    bool m_bPlayedArmingBeeps() { return read<bool>(baseAddr + offsets_instance.get("C_C4", "m_bPlayedArmingBeeps")); }
    bool m_bBombPlanted() { return read<bool>(baseAddr + offsets_instance.get("C_C4", "m_bBombPlanted")); }
};
