#pragma once
#include "../memory.h"

class CCSPlayer_DamageReactServices {
public:
 uintptr_t baseAddr;
 CCSPlayer_DamageReactServices() : baseAddr(0){}
 CCSPlayer_DamageReactServices(uintptr_t b):baseAddr(b){}
};
