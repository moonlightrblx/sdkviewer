#pragma once
#include "../memory.h"

class CFuncWater  {
public:
    uintptr_t baseAddr;

    CFuncWater() { baseAddr = client_base(); }
    CFuncWater(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_BuoyancyHelper() { return read<uintptr_t>(baseAddr + offsets_instance.get("CFuncWater", "m_BuoyancyHelper")); }
};
