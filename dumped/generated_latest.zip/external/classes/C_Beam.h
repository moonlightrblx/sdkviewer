#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_Beam  {
public:
    uintptr_t baseAddr;

    C_Beam() { baseAddr = client_base(); }
    C_Beam(uintptr_t base) : baseAddr(base) {}

    float m_flFrameRate() { return read<float>(baseAddr + offsets_instance.get("C_Beam", "m_flFrameRate")); }
    float m_flHDRColorScale() { return read<float>(baseAddr + offsets_instance.get("C_Beam", "m_flHDRColorScale")); }
    uintptr_t m_flFireTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_Beam", "m_flFireTime")); }
    float m_flDamage() { return read<float>(baseAddr + offsets_instance.get("C_Beam", "m_flDamage")); }
    uint8_t m_nNumBeamEnts() { return read<uint8_t>(baseAddr + offsets_instance.get("C_Beam", "m_nNumBeamEnts")); }
    int m_queryHandleHalo() { return read<int>(baseAddr + offsets_instance.get("C_Beam", "m_queryHandleHalo")); }
    uintptr_t m_hBaseMaterial() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_Beam", "m_hBaseMaterial")); }
    uintptr_t m_nHaloIndex() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_Beam", "m_nHaloIndex")); }
    uintptr_t m_nBeamType() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_Beam", "m_nBeamType")); }
    int m_nBeamFlags() { return read<int>(baseAddr + offsets_instance.get("C_Beam", "m_nBeamFlags")); }
    C_BaseEntity* m_hAttachEntity() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_Beam", "m_hAttachEntity")); }
    uintptr_t m_nAttachIndex() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_Beam", "m_nAttachIndex")); }
    float m_fWidth() { return read<float>(baseAddr + offsets_instance.get("C_Beam", "m_fWidth")); }
    float m_fEndWidth() { return read<float>(baseAddr + offsets_instance.get("C_Beam", "m_fEndWidth")); }
    float m_fFadeLength() { return read<float>(baseAddr + offsets_instance.get("C_Beam", "m_fFadeLength")); }
    float m_fHaloScale() { return read<float>(baseAddr + offsets_instance.get("C_Beam", "m_fHaloScale")); }
    float m_fAmplitude() { return read<float>(baseAddr + offsets_instance.get("C_Beam", "m_fAmplitude")); }
    float m_fStartFrame() { return read<float>(baseAddr + offsets_instance.get("C_Beam", "m_fStartFrame")); }
    float m_fSpeed() { return read<float>(baseAddr + offsets_instance.get("C_Beam", "m_fSpeed")); }
    float m_flFrame() { return read<float>(baseAddr + offsets_instance.get("C_Beam", "m_flFrame")); }
    uintptr_t m_nClipStyle() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_Beam", "m_nClipStyle")); }
    bool m_bTurnedOff() { return read<bool>(baseAddr + offsets_instance.get("C_Beam", "m_bTurnedOff")); }
    Vector3 m_vecEndPos() { return read<Vector3>(baseAddr + offsets_instance.get("C_Beam", "m_vecEndPos")); }
    C_BaseEntity* m_hEndEntity() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_Beam", "m_hEndEntity")); }
};
