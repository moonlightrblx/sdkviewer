#pragma once
#include "../memory.h"

class C_WeaponSawedoff  {
public:
    uintptr_t baseAddr;

    C_WeaponSawedoff() { baseAddr = client_base(); }
    C_WeaponSawedoff(uintptr_t base) : baseAddr(base) {}

};
