#pragma once
#include "../memory.h"

class C_RectLight  {
public:
    uintptr_t baseAddr;

    C_RectLight() { baseAddr = 0; }
    C_RectLight(uintptr_t base) : baseAddr(base) {}

    bool m_bShowLight() { return read<bool>(baseAddr + offsets_instance.get("C_RectLight", "m_bShowLight")); }
};
