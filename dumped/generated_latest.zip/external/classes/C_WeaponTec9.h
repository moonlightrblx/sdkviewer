#pragma once
#include "../memory.h"

class C_WeaponTec9  {
public:
    uintptr_t baseAddr;

    C_WeaponTec9() { baseAddr = client_base(); }
    C_WeaponTec9(uintptr_t base) : baseAddr(base) {}

};
