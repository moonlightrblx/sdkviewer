#pragma once
#include "../memory.h"

class C_FlashbangProjectile  {
public:
    uintptr_t baseAddr;

    C_FlashbangProjectile() { baseAddr = client_base(); }
    C_FlashbangProjectile(uintptr_t base) : baseAddr(base) {}

};
