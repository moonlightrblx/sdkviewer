#pragma once
#include "../memory.h"

class CLogicRelay  {
public:
    uintptr_t baseAddr;

    CLogicRelay() { baseAddr = 0; }
    CLogicRelay(uintptr_t base) : baseAddr(base) {}

    bool m_bDisabled() { return read<bool>(baseAddr + offsets_instance.get("CLogicRelay", "m_bDisabled")); }
    bool m_bWaitForRefire() { return read<bool>(baseAddr + offsets_instance.get("CLogicRelay", "m_bWaitForRefire")); }
    bool m_bTriggerOnce() { return read<bool>(baseAddr + offsets_instance.get("CLogicRelay", "m_bTriggerOnce")); }
    bool m_bFastRetrigger() { return read<bool>(baseAddr + offsets_instance.get("CLogicRelay", "m_bFastRetrigger")); }
    bool m_bPassthoughCaller() { return read<bool>(baseAddr + offsets_instance.get("CLogicRelay", "m_bPassthoughCaller")); }
};
