#pragma once
#include "../memory.h"

class CPlayer_AutoaimServices {
public:
 uintptr_t baseAddr;
 CPlayer_AutoaimServices() : baseAddr(0){}
 CPlayer_AutoaimServices(uintptr_t b):baseAddr(b){}
};
