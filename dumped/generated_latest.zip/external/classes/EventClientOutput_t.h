#pragma once
#include "../memory.h"
#include "../classes/EngineLoopState_t.h"

class EventClientOutput_t  {
public:
    uintptr_t baseAddr;

    EventClientOutput_t() { baseAddr = 0; }
    EventClientOutput_t(uintptr_t base) : baseAddr(base) {}

    EngineLoopState_t m_LoopState() { return read<EngineLoopState_t>(baseAddr + offsets_instance.get("EventClientOutput_t", "m_LoopState")); }
    float m_flRenderTime() { return read<float>(baseAddr + offsets_instance.get("EventClientOutput_t", "m_flRenderTime")); }
    float m_flRealTime() { return read<float>(baseAddr + offsets_instance.get("EventClientOutput_t", "m_flRealTime")); }
    float m_flRenderFrameTimeUnbounded() { return read<float>(baseAddr + offsets_instance.get("EventClientOutput_t", "m_flRenderFrameTimeUnbounded")); }
    bool m_bRenderOnly() { return read<bool>(baseAddr + offsets_instance.get("EventClientOutput_t", "m_bRenderOnly")); }
};
