#pragma once
#include "../memory.h"

class C_EnvVolumetricFogVolume {
public:
 uintptr_t baseAddr;
 C_EnvVolumetricFogVolume() : baseAddr(0){}
 C_EnvVolumetricFogVolume(uintptr_t b):baseAddr(b){}
 uintptr_t m_bActive(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_vBoxMins(){return SCHEMA_TYPE(uintptr_t,0x5FC);}
 uintptr_t m_vBoxMaxs(){return SCHEMA_TYPE(uintptr_t,0x608);}
 uintptr_t m_bStartDisabled(){return SCHEMA_TYPE(uintptr_t,0x614);}
 uintptr_t m_bIndirectUseLPVs(){return SCHEMA_TYPE(uintptr_t,0x615);}
 uintptr_t m_flStrength(){return SCHEMA_TYPE(uintptr_t,0x618);}
 uintptr_t m_nFalloffShape(){return SCHEMA_TYPE(uintptr_t,0x61C);}
 uintptr_t m_flFalloffExponent(){return SCHEMA_TYPE(uintptr_t,0x620);}
 uintptr_t m_flHeightFogDepth(){return SCHEMA_TYPE(uintptr_t,0x624);}
 uintptr_t m_fHeightFogEdgeWidth(){return SCHEMA_TYPE(uintptr_t,0x628);}
 uintptr_t m_fIndirectLightStrength(){return SCHEMA_TYPE(uintptr_t,0x62C);}
 uintptr_t m_fSunLightStrength(){return SCHEMA_TYPE(uintptr_t,0x630);}
 uintptr_t m_fNoiseStrength(){return SCHEMA_TYPE(uintptr_t,0x634);}
 uintptr_t m_TintColor(){return SCHEMA_TYPE(uintptr_t,0x638);}
 uintptr_t m_bOverrideTintColor(){return SCHEMA_TYPE(uintptr_t,0x63C);}
 uintptr_t m_bOverrideIndirectLightStrength(){return SCHEMA_TYPE(uintptr_t,0x63D);}
 uintptr_t m_bOverrideSunLightStrength(){return SCHEMA_TYPE(uintptr_t,0x63E);}
 uintptr_t m_bOverrideNoiseStrength(){return SCHEMA_TYPE(uintptr_t,0x63F);}
};
