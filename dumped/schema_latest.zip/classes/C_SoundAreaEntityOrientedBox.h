#pragma once
#include "../memory.h"

class C_SoundAreaEntityOrientedBox {
public:
 uintptr_t baseAddr;
 C_SoundAreaEntityOrientedBox() : baseAddr(0){}
 C_SoundAreaEntityOrientedBox(uintptr_t b):baseAddr(b){}
 uintptr_t m_vMin(){return SCHEMA_TYPE(uintptr_t,0x620);}
 uintptr_t m_vMax(){return SCHEMA_TYPE(uintptr_t,0x62C);}
};
