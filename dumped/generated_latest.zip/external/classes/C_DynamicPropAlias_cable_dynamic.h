#pragma once
#include "../memory.h"

class C_DynamicPropAlias_cable_dynamic  {
public:
    uintptr_t baseAddr;

    C_DynamicPropAlias_cable_dynamic() { baseAddr = client_base(); }
    C_DynamicPropAlias_cable_dynamic(uintptr_t base) : baseAddr(base) {}

};
