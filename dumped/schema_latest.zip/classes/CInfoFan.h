#pragma once
#include "../memory.h"

class CInfoFan {
public:
 uintptr_t baseAddr;
 CInfoFan() : baseAddr(0){}
 CInfoFan(uintptr_t b):baseAddr(b){}
 uintptr_t m_fFanForceMaxRadius(){return SCHEMA_TYPE(uintptr_t,0x638);}
 uintptr_t m_fFanForceMinRadius(){return SCHEMA_TYPE(uintptr_t,0x63C);}
 uintptr_t m_flCurveDistRange(){return SCHEMA_TYPE(uintptr_t,0x640);}
 uintptr_t m_FanForceCurveString(){return SCHEMA_TYPE(uintptr_t,0x648);}
};
