#pragma once
#include "../memory.h"
#include "../classes/fogparams_t.h"

class C_FogController  {
public:
    uintptr_t baseAddr;

    C_FogController() { baseAddr = 0; }
    C_FogController(uintptr_t base) : baseAddr(base) {}

    fogparams_t m_fog() { return read<fogparams_t>(baseAddr + offsets_instance.get("C_FogController", "m_fog")); }
    bool m_bUseAngles() { return read<bool>(baseAddr + offsets_instance.get("C_FogController", "m_bUseAngles")); }
    int m_iChangedVariables() { return read<int>(baseAddr + offsets_instance.get("C_FogController", "m_iChangedVariables")); }
};
