#pragma once
#include "../memory.h"

class C_PointCameraVFOV {
public:
 uintptr_t baseAddr;
 C_PointCameraVFOV() : baseAddr(0){}
 C_PointCameraVFOV(uintptr_t b):baseAddr(b){}
 uintptr_t m_flVerticalFOV(){return SCHEMA_TYPE(uintptr_t,0x658);}
};
