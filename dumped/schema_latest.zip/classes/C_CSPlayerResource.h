#pragma once
#include "../memory.h"

class C_CSPlayerResource {
public:
 uintptr_t baseAddr;
 C_CSPlayerResource() : baseAddr(0){}
 C_CSPlayerResource(uintptr_t b):baseAddr(b){}
 uintptr_t m_bHostageAlive(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_isHostageFollowingSomeone(){return SCHEMA_TYPE(uintptr_t,0x604);}
 uintptr_t m_iHostageEntityIDs(){return SCHEMA_TYPE(uintptr_t,0x610);}
 uintptr_t m_bombsiteCenterA(){return SCHEMA_TYPE(uintptr_t,0x640);}
 uintptr_t m_bombsiteCenterB(){return SCHEMA_TYPE(uintptr_t,0x64C);}
 uintptr_t m_hostageRescueX(){return SCHEMA_TYPE(uintptr_t,0x658);}
 uintptr_t m_hostageRescueY(){return SCHEMA_TYPE(uintptr_t,0x668);}
 uintptr_t m_hostageRescueZ(){return SCHEMA_TYPE(uintptr_t,0x678);}
 uintptr_t m_bEndMatchNextMapAllVoted(){return SCHEMA_TYPE(uintptr_t,0x688);}
 uintptr_t m_foundGoalPositions(){return SCHEMA_TYPE(uintptr_t,0x689);}
};
