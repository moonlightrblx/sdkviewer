#pragma once
#include "../memory.h"

class CPulseGameBlackboard {
public:
 uintptr_t baseAddr;
 CPulseGameBlackboard() : baseAddr(0){}
 CPulseGameBlackboard(uintptr_t b):baseAddr(b){}
 uintptr_t m_strGraphName(){return SCHEMA_TYPE(uintptr_t,0x600);}
 uintptr_t m_strStateBlob(){return SCHEMA_TYPE(uintptr_t,0x608);}
};
