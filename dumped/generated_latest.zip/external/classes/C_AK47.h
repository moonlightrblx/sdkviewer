#pragma once
#include "../memory.h"

class C_AK47  {
public:
    uintptr_t baseAddr;

    C_AK47() { baseAddr = client_base(); }
    C_AK47(uintptr_t base) : baseAddr(base) {}

};
