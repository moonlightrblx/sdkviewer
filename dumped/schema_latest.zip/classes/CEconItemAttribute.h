#pragma once
#include "../memory.h"

class CEconItemAttribute {
public:
 uintptr_t baseAddr;
 CEconItemAttribute() : baseAddr(0){}
 CEconItemAttribute(uintptr_t b):baseAddr(b){}
 uintptr_t m_iAttributeDefinitionIndex(){return SCHEMA_TYPE(uintptr_t,0x30);}
 uintptr_t m_flValue(){return SCHEMA_TYPE(uintptr_t,0x34);}
 uintptr_t m_flInitialValue(){return SCHEMA_TYPE(uintptr_t,0x38);}
 uintptr_t m_nRefundableCurrency(){return SCHEMA_TYPE(uintptr_t,0x3C);}
 uintptr_t m_bSetBonus(){return SCHEMA_TYPE(uintptr_t,0x40);}
};
