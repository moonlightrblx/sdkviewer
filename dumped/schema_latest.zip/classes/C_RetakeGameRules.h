#pragma once
#include "../memory.h"

class C_RetakeGameRules {
public:
 uintptr_t baseAddr;
 C_RetakeGameRules() : baseAddr(0){}
 C_RetakeGameRules(uintptr_t b):baseAddr(b){}
 uintptr_t m_nMatchSeed(){return SCHEMA_TYPE(uintptr_t,0x138);}
 uintptr_t m_bBlockersPresent(){return SCHEMA_TYPE(uintptr_t,0x13C);}
 uintptr_t m_bRoundInProgress(){return SCHEMA_TYPE(uintptr_t,0x13D);}
 uintptr_t m_iFirstSecondHalfRound(){return SCHEMA_TYPE(uintptr_t,0x140);}
 uintptr_t m_iBombSite(){return SCHEMA_TYPE(uintptr_t,0x144);}
 uintptr_t m_hBombPlanter(){return SCHEMA_TYPE(uintptr_t,0x148);}
};
