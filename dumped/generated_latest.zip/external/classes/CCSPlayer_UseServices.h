#pragma once
#include "../memory.h"

class CCSPlayer_UseServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_UseServices() { baseAddr = 0; }
    CCSPlayer_UseServices(uintptr_t base) : baseAddr(base) {}

};
