#pragma once
#include "../memory.h"

class C_GameRulesProxy  {
public:
    uintptr_t baseAddr;

    C_GameRulesProxy() { baseAddr = client_base(); }
    C_GameRulesProxy(uintptr_t base) : baseAddr(base) {}

};
