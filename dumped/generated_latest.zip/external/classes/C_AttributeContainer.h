#pragma once
#include "../memory.h"

class C_AttributeContainer  {
public:
    uintptr_t baseAddr;

    C_AttributeContainer() { baseAddr = client_base(); }
    C_AttributeContainer(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_Item() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_AttributeContainer", "m_Item")); }
    int m_iExternalItemProviderRegisteredToken() { return read<int>(baseAddr + offsets_instance.get("C_AttributeContainer", "m_iExternalItemProviderRegisteredToken")); }
    uintptr_t m_ullRegisteredAsItemID() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_AttributeContainer", "m_ullRegisteredAsItemID")); }
};
