#pragma once
#include "../memory.h"

class CPulseCell_WaitForCursorsWithTag  {
public:
    uintptr_t baseAddr;

    CPulseCell_WaitForCursorsWithTag() { baseAddr = client_base(); }
    CPulseCell_WaitForCursorsWithTag(uintptr_t base) : baseAddr(base) {}

    bool m_bTagSelfWhenComplete() { return read<bool>(baseAddr + offsets_instance.get("CPulseCell_WaitForCursorsWithTag", "m_bTagSelfWhenComplete")); }
    uintptr_t m_nDesiredKillPriority() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_WaitForCursorsWithTag", "m_nDesiredKillPriority")); }
};
