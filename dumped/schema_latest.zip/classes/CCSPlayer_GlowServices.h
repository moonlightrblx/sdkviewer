#pragma once
#include "../memory.h"

class CCSPlayer_GlowServices {
public:
 uintptr_t baseAddr;
 CCSPlayer_GlowServices() : baseAddr(0){}
 CCSPlayer_GlowServices(uintptr_t b):baseAddr(b){}
};
