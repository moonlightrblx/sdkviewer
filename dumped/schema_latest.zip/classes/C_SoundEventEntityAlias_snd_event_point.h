#pragma once
#include "../memory.h"

class C_SoundEventEntityAlias_snd_event_point {
public:
 uintptr_t baseAddr;
 C_SoundEventEntityAlias_snd_event_point() : baseAddr(0){}
 C_SoundEventEntityAlias_snd_event_point(uintptr_t b):baseAddr(b){}
};
