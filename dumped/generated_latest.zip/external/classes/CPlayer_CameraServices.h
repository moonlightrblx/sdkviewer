#pragma once
#include "../memory.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"

class CPlayer_CameraServices  {
public:
    uintptr_t baseAddr;

    CPlayer_CameraServices() { baseAddr = client_base(); }
    CPlayer_CameraServices(uintptr_t base) : baseAddr(base) {}

    QAngle m_vecCsViewPunchAngle() { return read<QAngle>(baseAddr + offsets_instance.get("CPlayer_CameraServices", "m_vecCsViewPunchAngle")); }
    uintptr_t m_nCsViewPunchAngleTick() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPlayer_CameraServices", "m_nCsViewPunchAngleTick")); }
    float m_flCsViewPunchAngleTickRatio() { return read<float>(baseAddr + offsets_instance.get("CPlayer_CameraServices", "m_flCsViewPunchAngleTickRatio")); }
    uintptr_t m_PlayerFog() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPlayer_CameraServices", "m_PlayerFog")); }
    C_ColorCorrection* m_hColorCorrectionCtrl() { return read<C_ColorCorrection*>(baseAddr + offsets_instance.get("CPlayer_CameraServices", "m_hColorCorrectionCtrl")); }
    C_BaseEntity* m_hViewEntity() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("CPlayer_CameraServices", "m_hViewEntity")); }
    C_TonemapController2* m_hTonemapController() { return read<C_TonemapController2*>(baseAddr + offsets_instance.get("CPlayer_CameraServices", "m_hTonemapController")); }
    uintptr_t m_audio() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPlayer_CameraServices", "m_audio")); }
    Vector3 m_PostProcessingVolumes() { return read<Vector3>(baseAddr + offsets_instance.get("CPlayer_CameraServices", "m_PostProcessingVolumes")); }
    float m_flOldPlayerZ() { return read<float>(baseAddr + offsets_instance.get("CPlayer_CameraServices", "m_flOldPlayerZ")); }
    float m_flOldPlayerViewOffsetZ() { return read<float>(baseAddr + offsets_instance.get("CPlayer_CameraServices", "m_flOldPlayerViewOffsetZ")); }
    uintptr_t m_CurrentFog() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPlayer_CameraServices", "m_CurrentFog")); }
    C_FogController* m_hOldFogController() { return read<C_FogController*>(baseAddr + offsets_instance.get("CPlayer_CameraServices", "m_hOldFogController")); }
    bool m_bOverrideFogColor() { return read<bool>(baseAddr + offsets_instance.get("CPlayer_CameraServices", "m_bOverrideFogColor")); }
    uintptr_t m_OverrideFogColor() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPlayer_CameraServices", "m_OverrideFogColor")); }
    bool m_bOverrideFogStartEnd() { return read<bool>(baseAddr + offsets_instance.get("CPlayer_CameraServices", "m_bOverrideFogStartEnd")); }
    float m_fOverrideFogStart() { return read<float>(baseAddr + offsets_instance.get("CPlayer_CameraServices", "m_fOverrideFogStart")); }
    float m_fOverrideFogEnd() { return read<float>(baseAddr + offsets_instance.get("CPlayer_CameraServices", "m_fOverrideFogEnd")); }
    C_PostProcessingVolume* m_hActivePostProcessingVolume() { return read<C_PostProcessingVolume*>(baseAddr + offsets_instance.get("CPlayer_CameraServices", "m_hActivePostProcessingVolume")); }
    QAngle m_angDemoViewAngles() { return read<QAngle>(baseAddr + offsets_instance.get("CPlayer_CameraServices", "m_angDemoViewAngles")); }
};
