#pragma once
#include "../memory.h"

class CLogicRelayAPI  {
public:
    uintptr_t baseAddr;

    CLogicRelayAPI() { baseAddr = 0; }
    CLogicRelayAPI(uintptr_t base) : baseAddr(base) {}

};
