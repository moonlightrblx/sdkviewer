#pragma once
#include "../memory.h"

class C_ModelPointEntity {
public:
 uintptr_t baseAddr;
 C_ModelPointEntity() : baseAddr(0){}
 C_ModelPointEntity(uintptr_t b):baseAddr(b){}
};
