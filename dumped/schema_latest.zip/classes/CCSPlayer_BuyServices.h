#pragma once
#include "../memory.h"

class CCSPlayer_BuyServices {
public:
 uintptr_t baseAddr;
 CCSPlayer_BuyServices() : baseAddr(0){}
 CCSPlayer_BuyServices(uintptr_t b):baseAddr(b){}
 uintptr_t m_vecSellbackPurchaseEntries(){return SCHEMA_TYPE(uintptr_t,0x40);}
};
