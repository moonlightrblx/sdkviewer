#pragma once
#include "../memory.h"

class C_MolotovProjectile  {
public:
    uintptr_t baseAddr;

    C_MolotovProjectile() { baseAddr = 0; }
    C_MolotovProjectile(uintptr_t base) : baseAddr(base) {}

    bool m_bIsIncGrenade() { return read<bool>(baseAddr + offsets_instance.get("C_MolotovProjectile", "m_bIsIncGrenade")); }
};
