#pragma once
#include "../memory.h"

class CCSGameModeRules_Deathmatch {
public:
 uintptr_t baseAddr;
 CCSGameModeRules_Deathmatch() : baseAddr(0){}
 CCSGameModeRules_Deathmatch(uintptr_t b):baseAddr(b){}
 uintptr_t m_flDMBonusStartTime(){return SCHEMA_TYPE(uintptr_t,0x30);}
 uintptr_t m_flDMBonusTimeLength(){return SCHEMA_TYPE(uintptr_t,0x34);}
 uintptr_t m_sDMBonusWeapon(){return SCHEMA_TYPE(uintptr_t,0x38);}
};
