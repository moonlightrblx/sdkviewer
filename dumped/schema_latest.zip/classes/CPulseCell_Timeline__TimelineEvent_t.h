#pragma once
#include "../memory.h"

class CPulseCell_Timeline__TimelineEvent_t {
public:
 uintptr_t baseAddr;
 CPulseCell_Timeline__TimelineEvent_t() : baseAddr(0){}
 CPulseCell_Timeline__TimelineEvent_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_flTimeFromPrevious(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_EventOutflow(){return SCHEMA_TYPE(uintptr_t,0x8);}
};
