#pragma once
#include "../memory.h"

class CSkyboxReference  {
public:
    uintptr_t baseAddr;

    CSkyboxReference() { baseAddr = client_base(); }
    CSkyboxReference(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_worldGroupId() { return read<uintptr_t>(baseAddr + offsets_instance.get("CSkyboxReference", "m_worldGroupId")); }
    C_SkyCamera* m_hSkyCamera() { return read<C_SkyCamera*>(baseAddr + offsets_instance.get("CSkyboxReference", "m_hSkyCamera")); }
};
