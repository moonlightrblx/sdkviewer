#pragma once
#include "../memory.h"
#include "../classes/CPulse_ResumePoint.h"
#include "../classes/PulseObservableBoolExpression_t.h"

class CPulseCell_WaitForObservable  {
public:
    uintptr_t baseAddr;

    CPulseCell_WaitForObservable() { baseAddr = 0; }
    CPulseCell_WaitForObservable(uintptr_t base) : baseAddr(base) {}

    PulseObservableBoolExpression_t m_Condition() { return read<PulseObservableBoolExpression_t>(baseAddr + offsets_instance.get("CPulseCell_WaitForObservable", "m_Condition")); }
    CPulse_ResumePoint m_OnTrue() { return read<CPulse_ResumePoint>(baseAddr + offsets_instance.get("CPulseCell_WaitForObservable", "m_OnTrue")); }
};
