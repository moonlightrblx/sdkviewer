#pragma once
#include "../memory.h"

class C_BaseModelEntity {
public:
 uintptr_t baseAddr;
 C_BaseModelEntity() : baseAddr(0){}
 C_BaseModelEntity(uintptr_t b):baseAddr(b){}
 uintptr_t m_CRenderComponent(){return SCHEMA_TYPE(uintptr_t,0xAE0);}
 uintptr_t m_CHitboxComponent(){return SCHEMA_TYPE(uintptr_t,0xAE8);}
 uintptr_t m_pDestructiblePartsSystemComponent(){return SCHEMA_TYPE(uintptr_t,0xB00);}
 uintptr_t m_LastHitGroup(){return SCHEMA_TYPE(uintptr_t,0xB08);}
 uintptr_t m_sLastDamageSourceName(){return SCHEMA_TYPE(uintptr_t,0xB10);}
 uintptr_t m_vLastDamagePosition(){return SCHEMA_TYPE(uintptr_t,0xB18);}
 uintptr_t m_bInitModelEffects(){return SCHEMA_TYPE(uintptr_t,0xB40);}
 uintptr_t m_bIsStaticProp(){return SCHEMA_TYPE(uintptr_t,0xB41);}
 uintptr_t m_nLastAddDecal(){return SCHEMA_TYPE(uintptr_t,0xB44);}
 uintptr_t m_nDecalsAdded(){return SCHEMA_TYPE(uintptr_t,0xB48);}
 uintptr_t m_iOldHealth(){return SCHEMA_TYPE(uintptr_t,0xB4C);}
 uintptr_t m_nRenderMode(){return SCHEMA_TYPE(uintptr_t,0xB50);}
 uintptr_t m_nRenderFX(){return SCHEMA_TYPE(uintptr_t,0xB51);}
 uintptr_t m_bAllowFadeInView(){return SCHEMA_TYPE(uintptr_t,0xB52);}
 uintptr_t m_clrRender(){return SCHEMA_TYPE(uintptr_t,0xB70);}
 uintptr_t m_vecRenderAttributes(){return SCHEMA_TYPE(uintptr_t,0xB78);}
 uintptr_t m_bRenderToCubemaps(){return SCHEMA_TYPE(uintptr_t,0xBF8);}
 uintptr_t m_bNoInterpolate(){return SCHEMA_TYPE(uintptr_t,0xBF9);}
 uintptr_t m_Collision(){return SCHEMA_TYPE(uintptr_t,0xC00);}
 uintptr_t m_Glow(){return SCHEMA_TYPE(uintptr_t,0xCB0);}
 uintptr_t m_flGlowBackfaceMult(){return SCHEMA_TYPE(uintptr_t,0xD08);}
 uintptr_t m_fadeMinDist(){return SCHEMA_TYPE(uintptr_t,0xD0C);}
 uintptr_t m_fadeMaxDist(){return SCHEMA_TYPE(uintptr_t,0xD10);}
 uintptr_t m_flFadeScale(){return SCHEMA_TYPE(uintptr_t,0xD14);}
 uintptr_t m_flShadowStrength(){return SCHEMA_TYPE(uintptr_t,0xD18);}
 uintptr_t m_nObjectCulling(){return SCHEMA_TYPE(uintptr_t,0xD1C);}
 uintptr_t m_nAddDecal(){return SCHEMA_TYPE(uintptr_t,0xD20);}
 uintptr_t m_vDecalPosition(){return SCHEMA_TYPE(uintptr_t,0xD24);}
 uintptr_t m_vDecalForwardAxis(){return SCHEMA_TYPE(uintptr_t,0xD30);}
 uintptr_t m_nDecalMode(){return SCHEMA_TYPE(uintptr_t,0xD3C);}
 uintptr_t m_nRequiredDecalMode(){return SCHEMA_TYPE(uintptr_t,0xD3D);}
 uintptr_t m_ConfigEntitiesToPropagateMaterialDecalsTo(){return SCHEMA_TYPE(uintptr_t,0xD40);}
 uintptr_t m_vecViewOffset(){return SCHEMA_TYPE(uintptr_t,0xD80);}
 uintptr_t m_pClientAlphaProperty(){return SCHEMA_TYPE(uintptr_t,0xE60);}
 uintptr_t m_ClientOverrideTint(){return SCHEMA_TYPE(uintptr_t,0xE68);}
 uintptr_t m_bUseClientOverrideTint(){return SCHEMA_TYPE(uintptr_t,0xE6C);}
 uintptr_t m_bvDisabledHitGroups(){return SCHEMA_TYPE(uintptr_t,0xEA8);}
};
