#pragma once
#include "../memory.h"

class CSMatchStats_t {
public:
 uintptr_t baseAddr;
 CSMatchStats_t() : baseAddr(0){}
 CSMatchStats_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_iEnemy5Ks(){return SCHEMA_TYPE(uintptr_t,0x68);}
 uintptr_t m_iEnemy4Ks(){return SCHEMA_TYPE(uintptr_t,0x6C);}
 uintptr_t m_iEnemy3Ks(){return SCHEMA_TYPE(uintptr_t,0x70);}
 uintptr_t m_iEnemyKnifeKills(){return SCHEMA_TYPE(uintptr_t,0x74);}
 uintptr_t m_iEnemyTaserKills(){return SCHEMA_TYPE(uintptr_t,0x78);}
};
