#pragma once
#include "../memory.h"

class C_Knife {
public:
 uintptr_t baseAddr;
 C_Knife() : baseAddr(0){}
 C_Knife(uintptr_t b):baseAddr(b){}
 uintptr_t m_bFirstAttack(){return SCHEMA_TYPE(uintptr_t,0x1F80);}
};
