#pragma once
#include "../memory.h"

class CPlayer_AutoaimServices  {
public:
    uintptr_t baseAddr;

    CPlayer_AutoaimServices() { baseAddr = client_base(); }
    CPlayer_AutoaimServices(uintptr_t base) : baseAddr(base) {}

};
