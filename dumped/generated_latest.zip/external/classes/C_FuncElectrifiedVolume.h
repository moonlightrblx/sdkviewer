#pragma once
#include "../memory.h"

class C_FuncElectrifiedVolume  {
public:
    uintptr_t baseAddr;

    C_FuncElectrifiedVolume() { baseAddr = client_base(); }
    C_FuncElectrifiedVolume(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_nAmbientEffect() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_FuncElectrifiedVolume", "m_nAmbientEffect")); }
    uintptr_t m_EffectName() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_FuncElectrifiedVolume", "m_EffectName")); }
    bool m_bState() { return read<bool>(baseAddr + offsets_instance.get("C_FuncElectrifiedVolume", "m_bState")); }
};
