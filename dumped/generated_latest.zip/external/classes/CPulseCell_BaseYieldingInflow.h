#pragma once
#include "../memory.h"

class CPulseCell_BaseYieldingInflow  {
public:
    uintptr_t baseAddr;

    CPulseCell_BaseYieldingInflow() { baseAddr = client_base(); }
    CPulseCell_BaseYieldingInflow(uintptr_t base) : baseAddr(base) {}

};
