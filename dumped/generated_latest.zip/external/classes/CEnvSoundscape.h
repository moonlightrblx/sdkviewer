#pragma once
#include "../memory.h"

class CEnvSoundscape  {
public:
    uintptr_t baseAddr;

    CEnvSoundscape() { baseAddr = client_base(); }
    CEnvSoundscape(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_OnPlay() { return read<uintptr_t>(baseAddr + offsets_instance.get("CEnvSoundscape", "m_OnPlay")); }
    float m_flRadius() { return read<float>(baseAddr + offsets_instance.get("CEnvSoundscape", "m_flRadius")); }
    uintptr_t m_soundEventName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CEnvSoundscape", "m_soundEventName")); }
    bool m_bOverrideWithEvent() { return read<bool>(baseAddr + offsets_instance.get("CEnvSoundscape", "m_bOverrideWithEvent")); }
    int m_soundscapeIndex() { return read<int>(baseAddr + offsets_instance.get("CEnvSoundscape", "m_soundscapeIndex")); }
    int m_soundscapeEntityListId() { return read<int>(baseAddr + offsets_instance.get("CEnvSoundscape", "m_soundscapeEntityListId")); }
    uintptr_t m_positionNames() { return read<uintptr_t>(baseAddr + offsets_instance.get("CEnvSoundscape", "m_positionNames")); }
    CEnvSoundscape* m_hProxySoundscape() { return read<CEnvSoundscape*>(baseAddr + offsets_instance.get("CEnvSoundscape", "m_hProxySoundscape")); }
    bool m_bDisabled() { return read<bool>(baseAddr + offsets_instance.get("CEnvSoundscape", "m_bDisabled")); }
    uintptr_t m_soundscapeName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CEnvSoundscape", "m_soundscapeName")); }
    int m_soundEventHash() { return read<int>(baseAddr + offsets_instance.get("CEnvSoundscape", "m_soundEventHash")); }
};
