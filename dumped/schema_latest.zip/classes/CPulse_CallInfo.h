#pragma once
#include "../memory.h"

class CPulse_CallInfo {
public:
 uintptr_t baseAddr;
 CPulse_CallInfo() : baseAddr(0){}
 CPulse_CallInfo(uintptr_t b):baseAddr(b){}
 uintptr_t m_PortName(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_nEditorNodeID(){return SCHEMA_TYPE(uintptr_t,0x10);}
 uintptr_t m_RegisterMap(){return SCHEMA_TYPE(uintptr_t,0x18);}
 uintptr_t m_CallMethodID(){return SCHEMA_TYPE(uintptr_t,0x48);}
 uintptr_t m_nSrcChunk(){return SCHEMA_TYPE(uintptr_t,0x4C);}
 uintptr_t m_nSrcInstruction(){return SCHEMA_TYPE(uintptr_t,0x50);}
};
