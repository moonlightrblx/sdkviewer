#pragma once
#include "../memory.h"

class CGlowProperty {
public:
 uintptr_t baseAddr;
 CGlowProperty() : baseAddr(0){}
 CGlowProperty(uintptr_t b):baseAddr(b){}
 uintptr_t m_fGlowColor(){return SCHEMA_TYPE(uintptr_t,0x8);}
 uintptr_t m_iGlowType(){return SCHEMA_TYPE(uintptr_t,0x30);}
 uintptr_t m_iGlowTeam(){return SCHEMA_TYPE(uintptr_t,0x34);}
 uintptr_t m_nGlowRange(){return SCHEMA_TYPE(uintptr_t,0x38);}
 uintptr_t m_nGlowRangeMin(){return SCHEMA_TYPE(uintptr_t,0x3C);}
 uintptr_t m_glowColorOverride(){return SCHEMA_TYPE(uintptr_t,0x40);}
 uintptr_t m_bFlashing(){return SCHEMA_TYPE(uintptr_t,0x44);}
 uintptr_t m_flGlowTime(){return SCHEMA_TYPE(uintptr_t,0x48);}
 uintptr_t m_flGlowStartTime(){return SCHEMA_TYPE(uintptr_t,0x4C);}
 uintptr_t m_bEligibleForScreenHighlight(){return SCHEMA_TYPE(uintptr_t,0x50);}
 uintptr_t m_bGlowing(){return SCHEMA_TYPE(uintptr_t,0x51);}
};
