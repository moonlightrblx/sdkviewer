#pragma once
#include "../memory.h"

class C_PointClientUIHUD {
public:
 uintptr_t baseAddr;
 C_PointClientUIHUD() : baseAddr(0){}
 C_PointClientUIHUD(uintptr_t b):baseAddr(b){}
 uintptr_t m_bCheckCSSClasses(){return SCHEMA_TYPE(uintptr_t,0xEE8);}
 uintptr_t m_bIgnoreInput(){return SCHEMA_TYPE(uintptr_t,0x1060);}
 uintptr_t m_flWidth(){return SCHEMA_TYPE(uintptr_t,0x1064);}
 uintptr_t m_flHeight(){return SCHEMA_TYPE(uintptr_t,0x1068);}
 uintptr_t m_flDPI(){return SCHEMA_TYPE(uintptr_t,0x106C);}
 uintptr_t m_flInteractDistance(){return SCHEMA_TYPE(uintptr_t,0x1070);}
 uintptr_t m_flDepthOffset(){return SCHEMA_TYPE(uintptr_t,0x1074);}
 uintptr_t m_unOwnerContext(){return SCHEMA_TYPE(uintptr_t,0x1078);}
 uintptr_t m_unHorizontalAlign(){return SCHEMA_TYPE(uintptr_t,0x107C);}
 uintptr_t m_unVerticalAlign(){return SCHEMA_TYPE(uintptr_t,0x1080);}
 uintptr_t m_unOrientation(){return SCHEMA_TYPE(uintptr_t,0x1084);}
 uintptr_t m_bAllowInteractionFromAllSceneWorlds(){return SCHEMA_TYPE(uintptr_t,0x1088);}
 uintptr_t m_vecCSSClasses(){return SCHEMA_TYPE(uintptr_t,0x1090);}
};
