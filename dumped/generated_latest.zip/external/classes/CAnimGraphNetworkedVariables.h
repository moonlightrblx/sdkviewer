#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class CAnimGraphNetworkedVariables  {
public:
    uintptr_t baseAddr;

    CAnimGraphNetworkedVariables() { baseAddr = client_base(); }
    CAnimGraphNetworkedVariables(uintptr_t base) : baseAddr(base) {}

    int m_PredNetBoolVariables() { return read<int>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_PredNetBoolVariables")); }
    uint8_t m_PredNetByteVariables() { return read<uint8_t>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_PredNetByteVariables")); }
    uint16_t m_PredNetUInt16Variables() { return read<uint16_t>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_PredNetUInt16Variables")); }
    int m_PredNetIntVariables() { return read<int>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_PredNetIntVariables")); }
    int m_PredNetUInt32Variables() { return read<int>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_PredNetUInt32Variables")); }
    Vector3 m_PredNetUInt64Variables() { return read<Vector3>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_PredNetUInt64Variables")); }
    float m_PredNetFloatVariables() { return read<float>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_PredNetFloatVariables")); }
    Vector3 m_PredNetVectorVariables() { return read<Vector3>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_PredNetVectorVariables")); }
    Vector3 m_PredNetQuaternionVariables() { return read<Vector3>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_PredNetQuaternionVariables")); }
    Vector3 m_PredNetGlobalSymbolVariables() { return read<Vector3>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_PredNetGlobalSymbolVariables")); }
    int m_OwnerOnlyPredNetBoolVariables() { return read<int>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_OwnerOnlyPredNetBoolVariables")); }
    uint8_t m_OwnerOnlyPredNetByteVariables() { return read<uint8_t>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_OwnerOnlyPredNetByteVariables")); }
    uint16_t m_OwnerOnlyPredNetUInt16Variables() { return read<uint16_t>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_OwnerOnlyPredNetUInt16Variables")); }
    int m_OwnerOnlyPredNetIntVariables() { return read<int>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_OwnerOnlyPredNetIntVariables")); }
    int m_OwnerOnlyPredNetUInt32Variables() { return read<int>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_OwnerOnlyPredNetUInt32Variables")); }
    Vector3 m_OwnerOnlyPredNetUInt64Variables() { return read<Vector3>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_OwnerOnlyPredNetUInt64Variables")); }
    float m_OwnerOnlyPredNetFloatVariables() { return read<float>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_OwnerOnlyPredNetFloatVariables")); }
    Vector3 m_OwnerOnlyPredNetVectorVariables() { return read<Vector3>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_OwnerOnlyPredNetVectorVariables")); }
    Vector3 m_OwnerOnlyPredNetQuaternionVariables() { return read<Vector3>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_OwnerOnlyPredNetQuaternionVariables")); }
    Vector3 m_OwnerOnlyPredNetGlobalSymbolVariables() { return read<Vector3>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_OwnerOnlyPredNetGlobalSymbolVariables")); }
    int m_nBoolVariablesCount() { return read<int>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_nBoolVariablesCount")); }
    int m_nOwnerOnlyBoolVariablesCount() { return read<int>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_nOwnerOnlyBoolVariablesCount")); }
    int m_nRandomSeedOffset() { return read<int>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_nRandomSeedOffset")); }
    float m_flLastTeleportTime() { return read<float>(baseAddr + offsets_instance.get("CAnimGraphNetworkedVariables", "m_flLastTeleportTime")); }
};
