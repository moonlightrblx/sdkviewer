#pragma once
#include "../memory.h"

class C_PointCamera  {
public:
    uintptr_t baseAddr;

    C_PointCamera() { baseAddr = 0; }
    C_PointCamera(uintptr_t base) : baseAddr(base) {}

    float m_FOV() { return read<float>(baseAddr + offsets_instance.get("C_PointCamera", "m_FOV")); }
    float m_Resolution() { return read<float>(baseAddr + offsets_instance.get("C_PointCamera", "m_Resolution")); }
    bool m_bFogEnable() { return read<bool>(baseAddr + offsets_instance.get("C_PointCamera", "m_bFogEnable")); }
    uintptr_t m_FogColor() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_PointCamera", "m_FogColor")); }
    float m_flFogStart() { return read<float>(baseAddr + offsets_instance.get("C_PointCamera", "m_flFogStart")); }
    float m_flFogEnd() { return read<float>(baseAddr + offsets_instance.get("C_PointCamera", "m_flFogEnd")); }
    float m_flFogMaxDensity() { return read<float>(baseAddr + offsets_instance.get("C_PointCamera", "m_flFogMaxDensity")); }
    bool m_bActive() { return read<bool>(baseAddr + offsets_instance.get("C_PointCamera", "m_bActive")); }
    bool m_bUseScreenAspectRatio() { return read<bool>(baseAddr + offsets_instance.get("C_PointCamera", "m_bUseScreenAspectRatio")); }
    float m_flAspectRatio() { return read<float>(baseAddr + offsets_instance.get("C_PointCamera", "m_flAspectRatio")); }
    bool m_bNoSky() { return read<bool>(baseAddr + offsets_instance.get("C_PointCamera", "m_bNoSky")); }
    float m_fBrightness() { return read<float>(baseAddr + offsets_instance.get("C_PointCamera", "m_fBrightness")); }
    float m_flZFar() { return read<float>(baseAddr + offsets_instance.get("C_PointCamera", "m_flZFar")); }
    float m_flZNear() { return read<float>(baseAddr + offsets_instance.get("C_PointCamera", "m_flZNear")); }
    bool m_bCanHLTVUse() { return read<bool>(baseAddr + offsets_instance.get("C_PointCamera", "m_bCanHLTVUse")); }
    bool m_bAlignWithParent() { return read<bool>(baseAddr + offsets_instance.get("C_PointCamera", "m_bAlignWithParent")); }
    bool m_bDofEnabled() { return read<bool>(baseAddr + offsets_instance.get("C_PointCamera", "m_bDofEnabled")); }
    float m_flDofNearBlurry() { return read<float>(baseAddr + offsets_instance.get("C_PointCamera", "m_flDofNearBlurry")); }
    float m_flDofNearCrisp() { return read<float>(baseAddr + offsets_instance.get("C_PointCamera", "m_flDofNearCrisp")); }
    float m_flDofFarCrisp() { return read<float>(baseAddr + offsets_instance.get("C_PointCamera", "m_flDofFarCrisp")); }
    float m_flDofFarBlurry() { return read<float>(baseAddr + offsets_instance.get("C_PointCamera", "m_flDofFarBlurry")); }
    float m_flDofTiltToGround() { return read<float>(baseAddr + offsets_instance.get("C_PointCamera", "m_flDofTiltToGround")); }
    float m_TargetFOV() { return read<float>(baseAddr + offsets_instance.get("C_PointCamera", "m_TargetFOV")); }
    float m_DegreesPerSecond() { return read<float>(baseAddr + offsets_instance.get("C_PointCamera", "m_DegreesPerSecond")); }
    bool m_bIsOn() { return read<bool>(baseAddr + offsets_instance.get("C_PointCamera", "m_bIsOn")); }
    C_PointCamera* m_pNext() { return read<C_PointCamera*>(baseAddr + offsets_instance.get("C_PointCamera", "m_pNext")); }
};
