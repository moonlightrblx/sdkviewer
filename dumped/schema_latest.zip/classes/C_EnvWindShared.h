#pragma once
#include "../memory.h"

class C_EnvWindShared {
public:
 uintptr_t baseAddr;
 C_EnvWindShared() : baseAddr(0){}
 C_EnvWindShared(uintptr_t b):baseAddr(b){}
 uintptr_t m_flStartTime(){return SCHEMA_TYPE(uintptr_t,0x8);}
 uintptr_t m_iWindSeed(){return SCHEMA_TYPE(uintptr_t,0xC);}
 uintptr_t m_iMinWind(){return SCHEMA_TYPE(uintptr_t,0x10);}
 uintptr_t m_iMaxWind(){return SCHEMA_TYPE(uintptr_t,0x12);}
 uintptr_t m_windRadius(){return SCHEMA_TYPE(uintptr_t,0x14);}
 uintptr_t m_iMinGust(){return SCHEMA_TYPE(uintptr_t,0x18);}
 uintptr_t m_iMaxGust(){return SCHEMA_TYPE(uintptr_t,0x1A);}
 uintptr_t m_flMinGustDelay(){return SCHEMA_TYPE(uintptr_t,0x1C);}
 uintptr_t m_flMaxGustDelay(){return SCHEMA_TYPE(uintptr_t,0x20);}
 uintptr_t m_flGustDuration(){return SCHEMA_TYPE(uintptr_t,0x24);}
 uintptr_t m_iGustDirChange(){return SCHEMA_TYPE(uintptr_t,0x28);}
 uintptr_t m_iInitialWindDir(){return SCHEMA_TYPE(uintptr_t,0x2A);}
 uintptr_t m_flInitialWindSpeed(){return SCHEMA_TYPE(uintptr_t,0x2C);}
 uintptr_t m_location(){return SCHEMA_TYPE(uintptr_t,0x30);}
 uintptr_t m_hEntOwner(){return SCHEMA_TYPE(uintptr_t,0x3C);}
};
