#pragma once
#include "../memory.h"

class C_WeaponTaser  {
public:
    uintptr_t baseAddr;

    C_WeaponTaser() { baseAddr = client_base(); }
    C_WeaponTaser(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_fFireTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_WeaponTaser", "m_fFireTime")); }
    int m_nLastAttackTick() { return read<int>(baseAddr + offsets_instance.get("C_WeaponTaser", "m_nLastAttackTick")); }
};
