#pragma once
#include "../memory.h"

class C_EnvSky  {
public:
    uintptr_t baseAddr;

    C_EnvSky() { baseAddr = 0; }
    C_EnvSky(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_hSkyMaterial() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvSky", "m_hSkyMaterial")); }
    uintptr_t m_hSkyMaterialLightingOnly() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvSky", "m_hSkyMaterialLightingOnly")); }
    bool m_bStartDisabled() { return read<bool>(baseAddr + offsets_instance.get("C_EnvSky", "m_bStartDisabled")); }
    uintptr_t m_vTintColor() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvSky", "m_vTintColor")); }
    uintptr_t m_vTintColorLightingOnly() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvSky", "m_vTintColorLightingOnly")); }
    float m_flBrightnessScale() { return read<float>(baseAddr + offsets_instance.get("C_EnvSky", "m_flBrightnessScale")); }
    int m_nFogType() { return read<int>(baseAddr + offsets_instance.get("C_EnvSky", "m_nFogType")); }
    float m_flFogMinStart() { return read<float>(baseAddr + offsets_instance.get("C_EnvSky", "m_flFogMinStart")); }
    float m_flFogMinEnd() { return read<float>(baseAddr + offsets_instance.get("C_EnvSky", "m_flFogMinEnd")); }
    float m_flFogMaxStart() { return read<float>(baseAddr + offsets_instance.get("C_EnvSky", "m_flFogMaxStart")); }
    float m_flFogMaxEnd() { return read<float>(baseAddr + offsets_instance.get("C_EnvSky", "m_flFogMaxEnd")); }
    bool m_bEnabled() { return read<bool>(baseAddr + offsets_instance.get("C_EnvSky", "m_bEnabled")); }
};
