#pragma once
#include "../memory.h"

class CSpriteOriented {
public:
 uintptr_t baseAddr;
 CSpriteOriented() : baseAddr(0){}
 CSpriteOriented(uintptr_t b):baseAddr(b){}
};
