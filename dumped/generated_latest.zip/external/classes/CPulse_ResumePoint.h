#pragma once
#include "../memory.h"

class CPulse_ResumePoint  {
public:
    uintptr_t baseAddr;

    CPulse_ResumePoint() { baseAddr = client_base(); }
    CPulse_ResumePoint(uintptr_t base) : baseAddr(base) {}

};
