#pragma once
#include "../memory.h"

class CPulseCell_Timeline__TimelineEvent_t  {
public:
    uintptr_t baseAddr;

    CPulseCell_Timeline__TimelineEvent_t() { baseAddr = client_base(); }
    CPulseCell_Timeline__TimelineEvent_t(uintptr_t base) : baseAddr(base) {}

    float m_flTimeFromPrevious() { return read<float>(baseAddr + offsets_instance.get("CPulseCell_Timeline__TimelineEvent_t", "m_flTimeFromPrevious")); }
    uintptr_t m_EventOutflow() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Timeline__TimelineEvent_t", "m_EventOutflow")); }
};
