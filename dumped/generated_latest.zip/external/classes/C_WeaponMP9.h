#pragma once
#include "../memory.h"

class C_WeaponMP9  {
public:
    uintptr_t baseAddr;

    C_WeaponMP9() { baseAddr = 0; }
    C_WeaponMP9(uintptr_t base) : baseAddr(base) {}

};
