#pragma once
#include "../memory.h"

class C_SkyCamera {
public:
 uintptr_t baseAddr;
 C_SkyCamera() : baseAddr(0){}
 C_SkyCamera(uintptr_t b):baseAddr(b){}
 uintptr_t m_skyboxData(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_skyboxSlotToken(){return SCHEMA_TYPE(uintptr_t,0x688);}
 uintptr_t m_bUseAngles(){return SCHEMA_TYPE(uintptr_t,0x68C);}
 uintptr_t m_pNext(){return SCHEMA_TYPE(uintptr_t,0x690);}
};
