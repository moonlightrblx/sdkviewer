#pragma once
#include "../memory.h"

class C_WeaponMP7 {
public:
 uintptr_t baseAddr;
 C_WeaponMP7() : baseAddr(0){}
 C_WeaponMP7(uintptr_t b):baseAddr(b){}
};
