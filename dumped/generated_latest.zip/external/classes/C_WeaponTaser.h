#pragma once
#include "../memory.h"
#include "../classes/GameTime_t.h"

class C_WeaponTaser  {
public:
    uintptr_t baseAddr;

    C_WeaponTaser() { baseAddr = 0; }
    C_WeaponTaser(uintptr_t base) : baseAddr(base) {}

    GameTime_t m_fFireTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_WeaponTaser", "m_fFireTime")); }
    int m_nLastAttackTick() { return read<int>(baseAddr + offsets_instance.get("C_WeaponTaser", "m_nLastAttackTick")); }
};
