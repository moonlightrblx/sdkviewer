#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class CAttributeManager  {
public:
    uintptr_t baseAddr;

    CAttributeManager() { baseAddr = client_base(); }
    CAttributeManager(uintptr_t base) : baseAddr(base) {}

    Vector3 m_Providers() { return read<Vector3>(baseAddr + offsets_instance.get("CAttributeManager", "m_Providers")); }
    int m_iReapplyProvisionParity() { return read<int>(baseAddr + offsets_instance.get("CAttributeManager", "m_iReapplyProvisionParity")); }
    C_BaseEntity* m_hOuter() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("CAttributeManager", "m_hOuter")); }
    bool m_bPreventLoopback() { return read<bool>(baseAddr + offsets_instance.get("CAttributeManager", "m_bPreventLoopback")); }
    uintptr_t m_ProviderType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CAttributeManager", "m_ProviderType")); }
    Vector3 m_CachedResults() { return read<Vector3>(baseAddr + offsets_instance.get("CAttributeManager", "m_CachedResults")); }
};
