#pragma once
#include "../memory.h"

class C_Flashbang  {
public:
    uintptr_t baseAddr;

    C_Flashbang() { baseAddr = client_base(); }
    C_Flashbang(uintptr_t base) : baseAddr(base) {}

};
