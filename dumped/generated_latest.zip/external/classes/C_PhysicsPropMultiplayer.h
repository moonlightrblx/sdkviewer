#pragma once
#include "../memory.h"

class C_PhysicsPropMultiplayer  {
public:
    uintptr_t baseAddr;

    C_PhysicsPropMultiplayer() { baseAddr = 0; }
    C_PhysicsPropMultiplayer(uintptr_t base) : baseAddr(base) {}

};
