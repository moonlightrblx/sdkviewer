#pragma once
#include "../memory.h"
#include "../classes/GameTime_t.h"
#include "../types/Vector3.h"
class CCSPlayerController;
class CCSPlayer_PingServices;

class C_CSPlayerPawnBase  {
public:
    uintptr_t baseAddr;

    C_CSPlayerPawnBase() { baseAddr = 0; }
    C_CSPlayerPawnBase(uintptr_t base) : baseAddr(base) {}

    CCSPlayer_PingServices* m_pPingServices() { return read<CCSPlayer_PingServices*>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_pPingServices")); }
    uintptr_t m_previousPlayerState() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_previousPlayerState")); }
    uintptr_t m_iPlayerState() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_iPlayerState")); }
    bool m_bHasMovedSinceSpawn() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_bHasMovedSinceSpawn")); }
    GameTime_t m_flLastSpawnTimeIndex() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_flLastSpawnTimeIndex")); }
    int m_iProgressBarDuration() { return read<int>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_iProgressBarDuration")); }
    float m_flProgressBarStartTime() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_flProgressBarStartTime")); }
    GameTime_t m_flClientDeathTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_flClientDeathTime")); }
    float m_flFlashBangTime() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_flFlashBangTime")); }
    float m_flFlashScreenshotAlpha() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_flFlashScreenshotAlpha")); }
    float m_flFlashOverlayAlpha() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_flFlashOverlayAlpha")); }
    bool m_bFlashBuildUp() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_bFlashBuildUp")); }
    bool m_bFlashDspHasBeenCleared() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_bFlashDspHasBeenCleared")); }
    bool m_bFlashScreenshotHasBeenGrabbed() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_bFlashScreenshotHasBeenGrabbed")); }
    float m_flFlashMaxAlpha() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_flFlashMaxAlpha")); }
    float m_flFlashDuration() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_flFlashDuration")); }
    GameTime_t m_flClientHealthFadeChangeTimestamp() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_flClientHealthFadeChangeTimestamp")); }
    int m_nClientHealthFadeParityValue() { return read<int>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_nClientHealthFadeParityValue")); }
    float m_fNextThinkPushAway() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_fNextThinkPushAway")); }
    float m_flCurrentMusicStartTime() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_flCurrentMusicStartTime")); }
    float m_flMusicRoundStartTime() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_flMusicRoundStartTime")); }
    bool m_bDeferStartMusicOnWarmup() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_bDeferStartMusicOnWarmup")); }
    float m_flLastSmokeOverlayAlpha() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_flLastSmokeOverlayAlpha")); }
    float m_flLastSmokeAge() { return read<float>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_flLastSmokeAge")); }
    Vector3 m_vLastSmokeOverlayColor() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_vLastSmokeOverlayColor")); }
    CCSPlayerController* m_hOriginalController() { return read<CCSPlayerController*>(baseAddr + offsets_instance.get("C_CSPlayerPawnBase", "m_hOriginalController")); }
};
