#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_PathParticleRope  {
public:
    uintptr_t baseAddr;

    C_PathParticleRope() { baseAddr = 0; }
    C_PathParticleRope(uintptr_t base) : baseAddr(base) {}

    bool m_bStartActive() { return read<bool>(baseAddr + offsets_instance.get("C_PathParticleRope", "m_bStartActive")); }
    float m_flMaxSimulationTime() { return read<float>(baseAddr + offsets_instance.get("C_PathParticleRope", "m_flMaxSimulationTime")); }
    uintptr_t m_iszEffectName() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_PathParticleRope", "m_iszEffectName")); }
    Vector3 m_PathNodes_Name() { return read<Vector3>(baseAddr + offsets_instance.get("C_PathParticleRope", "m_PathNodes_Name")); }
    float m_flParticleSpacing() { return read<float>(baseAddr + offsets_instance.get("C_PathParticleRope", "m_flParticleSpacing")); }
    float m_flSlack() { return read<float>(baseAddr + offsets_instance.get("C_PathParticleRope", "m_flSlack")); }
    float m_flRadius() { return read<float>(baseAddr + offsets_instance.get("C_PathParticleRope", "m_flRadius")); }
    uintptr_t m_ColorTint() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_PathParticleRope", "m_ColorTint")); }
    int m_nEffectState() { return read<int>(baseAddr + offsets_instance.get("C_PathParticleRope", "m_nEffectState")); }
    uintptr_t m_iEffectIndex() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_PathParticleRope", "m_iEffectIndex")); }
    Vector3 m_PathNodes_Position() { return read<Vector3>(baseAddr + offsets_instance.get("C_PathParticleRope", "m_PathNodes_Position")); }
    Vector3 m_PathNodes_TangentIn() { return read<Vector3>(baseAddr + offsets_instance.get("C_PathParticleRope", "m_PathNodes_TangentIn")); }
    Vector3 m_PathNodes_TangentOut() { return read<Vector3>(baseAddr + offsets_instance.get("C_PathParticleRope", "m_PathNodes_TangentOut")); }
    Vector3 m_PathNodes_Color() { return read<Vector3>(baseAddr + offsets_instance.get("C_PathParticleRope", "m_PathNodes_Color")); }
    bool m_PathNodes_PinEnabled() { return read<bool>(baseAddr + offsets_instance.get("C_PathParticleRope", "m_PathNodes_PinEnabled")); }
    float m_PathNodes_RadiusScale() { return read<float>(baseAddr + offsets_instance.get("C_PathParticleRope", "m_PathNodes_RadiusScale")); }
};
