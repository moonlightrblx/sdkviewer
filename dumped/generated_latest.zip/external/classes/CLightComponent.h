#pragma once
#include "../memory.h"
#include "../classes/CNetworkVarChainer.h"
#include "../classes/GameTime_t.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"

class CLightComponent  {
public:
    uintptr_t baseAddr;

    CLightComponent() { baseAddr = 0; }
    CLightComponent(uintptr_t base) : baseAddr(base) {}

    CNetworkVarChainer __m_pChainEntity() { return read<CNetworkVarChainer>(baseAddr + offsets_instance.get("CLightComponent", "__m_pChainEntity")); }
    uintptr_t m_Color() { return read<uintptr_t>(baseAddr + offsets_instance.get("CLightComponent", "m_Color")); }
    uintptr_t m_SecondaryColor() { return read<uintptr_t>(baseAddr + offsets_instance.get("CLightComponent", "m_SecondaryColor")); }
    float m_flBrightness() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flBrightness")); }
    float m_flBrightnessScale() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flBrightnessScale")); }
    float m_flBrightnessMult() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flBrightnessMult")); }
    float m_flRange() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flRange")); }
    float m_flFalloff() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flFalloff")); }
    float m_flAttenuation0() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flAttenuation0")); }
    float m_flAttenuation1() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flAttenuation1")); }
    float m_flAttenuation2() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flAttenuation2")); }
    float m_flTheta() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flTheta")); }
    float m_flPhi() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flPhi")); }
    uintptr_t m_hLightCookie() { return read<uintptr_t>(baseAddr + offsets_instance.get("CLightComponent", "m_hLightCookie")); }
    int m_nCascades() { return read<int>(baseAddr + offsets_instance.get("CLightComponent", "m_nCascades")); }
    int m_nCastShadows() { return read<int>(baseAddr + offsets_instance.get("CLightComponent", "m_nCastShadows")); }
    int m_nShadowWidth() { return read<int>(baseAddr + offsets_instance.get("CLightComponent", "m_nShadowWidth")); }
    int m_nShadowHeight() { return read<int>(baseAddr + offsets_instance.get("CLightComponent", "m_nShadowHeight")); }
    bool m_bRenderDiffuse() { return read<bool>(baseAddr + offsets_instance.get("CLightComponent", "m_bRenderDiffuse")); }
    int m_nRenderSpecular() { return read<int>(baseAddr + offsets_instance.get("CLightComponent", "m_nRenderSpecular")); }
    bool m_bRenderTransmissive() { return read<bool>(baseAddr + offsets_instance.get("CLightComponent", "m_bRenderTransmissive")); }
    float m_flOrthoLightWidth() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flOrthoLightWidth")); }
    float m_flOrthoLightHeight() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flOrthoLightHeight")); }
    int m_nStyle() { return read<int>(baseAddr + offsets_instance.get("CLightComponent", "m_nStyle")); }
    uintptr_t m_Pattern() { return read<uintptr_t>(baseAddr + offsets_instance.get("CLightComponent", "m_Pattern")); }
    int m_nCascadeRenderStaticObjects() { return read<int>(baseAddr + offsets_instance.get("CLightComponent", "m_nCascadeRenderStaticObjects")); }
    float m_flShadowCascadeCrossFade() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flShadowCascadeCrossFade")); }
    float m_flShadowCascadeDistanceFade() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flShadowCascadeDistanceFade")); }
    float m_flShadowCascadeDistance0() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flShadowCascadeDistance0")); }
    float m_flShadowCascadeDistance1() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flShadowCascadeDistance1")); }
    float m_flShadowCascadeDistance2() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flShadowCascadeDistance2")); }
    float m_flShadowCascadeDistance3() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flShadowCascadeDistance3")); }
    int m_nShadowCascadeResolution0() { return read<int>(baseAddr + offsets_instance.get("CLightComponent", "m_nShadowCascadeResolution0")); }
    int m_nShadowCascadeResolution1() { return read<int>(baseAddr + offsets_instance.get("CLightComponent", "m_nShadowCascadeResolution1")); }
    int m_nShadowCascadeResolution2() { return read<int>(baseAddr + offsets_instance.get("CLightComponent", "m_nShadowCascadeResolution2")); }
    int m_nShadowCascadeResolution3() { return read<int>(baseAddr + offsets_instance.get("CLightComponent", "m_nShadowCascadeResolution3")); }
    bool m_bUsesBakedShadowing() { return read<bool>(baseAddr + offsets_instance.get("CLightComponent", "m_bUsesBakedShadowing")); }
    int m_nShadowPriority() { return read<int>(baseAddr + offsets_instance.get("CLightComponent", "m_nShadowPriority")); }
    int m_nBakedShadowIndex() { return read<int>(baseAddr + offsets_instance.get("CLightComponent", "m_nBakedShadowIndex")); }
    int m_nLightPathUniqueId() { return read<int>(baseAddr + offsets_instance.get("CLightComponent", "m_nLightPathUniqueId")); }
    int m_nLightMapUniqueId() { return read<int>(baseAddr + offsets_instance.get("CLightComponent", "m_nLightMapUniqueId")); }
    bool m_bRenderToCubemaps() { return read<bool>(baseAddr + offsets_instance.get("CLightComponent", "m_bRenderToCubemaps")); }
    bool m_bAllowSSTGeneration() { return read<bool>(baseAddr + offsets_instance.get("CLightComponent", "m_bAllowSSTGeneration")); }
    int m_nDirectLight() { return read<int>(baseAddr + offsets_instance.get("CLightComponent", "m_nDirectLight")); }
    int m_nIndirectLight() { return read<int>(baseAddr + offsets_instance.get("CLightComponent", "m_nIndirectLight")); }
    float m_flFadeMinDist() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flFadeMinDist")); }
    float m_flFadeMaxDist() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flFadeMaxDist")); }
    float m_flShadowFadeMinDist() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flShadowFadeMinDist")); }
    float m_flShadowFadeMaxDist() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flShadowFadeMaxDist")); }
    bool m_bEnabled() { return read<bool>(baseAddr + offsets_instance.get("CLightComponent", "m_bEnabled")); }
    bool m_bFlicker() { return read<bool>(baseAddr + offsets_instance.get("CLightComponent", "m_bFlicker")); }
    bool m_bPrecomputedFieldsValid() { return read<bool>(baseAddr + offsets_instance.get("CLightComponent", "m_bPrecomputedFieldsValid")); }
    Vector3 m_vPrecomputedBoundsMins() { return read<Vector3>(baseAddr + offsets_instance.get("CLightComponent", "m_vPrecomputedBoundsMins")); }
    Vector3 m_vPrecomputedBoundsMaxs() { return read<Vector3>(baseAddr + offsets_instance.get("CLightComponent", "m_vPrecomputedBoundsMaxs")); }
    Vector3 m_vPrecomputedOBBOrigin() { return read<Vector3>(baseAddr + offsets_instance.get("CLightComponent", "m_vPrecomputedOBBOrigin")); }
    QAngle m_vPrecomputedOBBAngles() { return read<QAngle>(baseAddr + offsets_instance.get("CLightComponent", "m_vPrecomputedOBBAngles")); }
    Vector3 m_vPrecomputedOBBExtent() { return read<Vector3>(baseAddr + offsets_instance.get("CLightComponent", "m_vPrecomputedOBBExtent")); }
    float m_flPrecomputedMaxRange() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flPrecomputedMaxRange")); }
    int m_nFogLightingMode() { return read<int>(baseAddr + offsets_instance.get("CLightComponent", "m_nFogLightingMode")); }
    float m_flFogContributionStength() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flFogContributionStength")); }
    float m_flNearClipPlane() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flNearClipPlane")); }
    uintptr_t m_SkyColor() { return read<uintptr_t>(baseAddr + offsets_instance.get("CLightComponent", "m_SkyColor")); }
    float m_flSkyIntensity() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flSkyIntensity")); }
    uintptr_t m_SkyAmbientBounce() { return read<uintptr_t>(baseAddr + offsets_instance.get("CLightComponent", "m_SkyAmbientBounce")); }
    bool m_bUseSecondaryColor() { return read<bool>(baseAddr + offsets_instance.get("CLightComponent", "m_bUseSecondaryColor")); }
    bool m_bMixedShadows() { return read<bool>(baseAddr + offsets_instance.get("CLightComponent", "m_bMixedShadows")); }
    GameTime_t m_flLightStyleStartTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("CLightComponent", "m_flLightStyleStartTime")); }
    float m_flCapsuleLength() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flCapsuleLength")); }
    float m_flMinRoughness() { return read<float>(baseAddr + offsets_instance.get("CLightComponent", "m_flMinRoughness")); }
};
