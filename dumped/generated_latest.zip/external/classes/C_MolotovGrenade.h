#pragma once
#include "../memory.h"

class C_MolotovGrenade  {
public:
    uintptr_t baseAddr;

    C_MolotovGrenade() { baseAddr = 0; }
    C_MolotovGrenade(uintptr_t base) : baseAddr(base) {}

};
