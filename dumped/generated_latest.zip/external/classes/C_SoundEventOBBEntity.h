#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_SoundEventOBBEntity  {
public:
    uintptr_t baseAddr;

    C_SoundEventOBBEntity() { baseAddr = client_base(); }
    C_SoundEventOBBEntity(uintptr_t base) : baseAddr(base) {}

    Vector3 m_vMins() { return read<Vector3>(baseAddr + offsets_instance.get("C_SoundEventOBBEntity", "m_vMins")); }
    Vector3 m_vMaxs() { return read<Vector3>(baseAddr + offsets_instance.get("C_SoundEventOBBEntity", "m_vMaxs")); }
};
