#pragma once
#include "../memory.h"
#include "../classes/GameTick_t.h"
#include "../classes/GameTime_t.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"
class CBodyComponent;
class CCollisionProperty;
class CGameSceneNode;
class CRenderComponent;

class C_BaseEntity  {
public:
    uintptr_t baseAddr;

    C_BaseEntity() { baseAddr = 0; }
    C_BaseEntity(uintptr_t base) : baseAddr(base) {}

    CBodyComponent* m_CBodyComponent() { return read<CBodyComponent*>(baseAddr + offsets_instance.get("C_BaseEntity", "m_CBodyComponent")); }
    uintptr_t m_NetworkTransmitComponent() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_NetworkTransmitComponent")); }
    GameTick_t m_nLastThinkTick() { return read<GameTick_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_nLastThinkTick")); }
    CGameSceneNode* m_pGameSceneNode() { return read<CGameSceneNode*>(baseAddr + offsets_instance.get("C_BaseEntity", "m_pGameSceneNode")); }
    CRenderComponent* m_pRenderComponent() { return read<CRenderComponent*>(baseAddr + offsets_instance.get("C_BaseEntity", "m_pRenderComponent")); }
    CCollisionProperty* m_pCollision() { return read<CCollisionProperty*>(baseAddr + offsets_instance.get("C_BaseEntity", "m_pCollision")); }
    int m_iMaxHealth() { return read<int>(baseAddr + offsets_instance.get("C_BaseEntity", "m_iMaxHealth")); }
    int m_iHealth() { return read<int>(baseAddr + offsets_instance.get("C_BaseEntity", "m_iHealth")); }
    float m_flDamageAccumulator() { return read<float>(baseAddr + offsets_instance.get("C_BaseEntity", "m_flDamageAccumulator")); }
    uint8_t m_lifeState() { return read<uint8_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_lifeState")); }
    bool m_bTakesDamage() { return read<bool>(baseAddr + offsets_instance.get("C_BaseEntity", "m_bTakesDamage")); }
    uintptr_t m_nTakeDamageFlags() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_nTakeDamageFlags")); }
    uintptr_t m_nPlatformType() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_nPlatformType")); }
    uint8_t m_ubInterpolationFrame() { return read<uint8_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_ubInterpolationFrame")); }
    C_BaseEntity* m_hSceneObjectController() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_BaseEntity", "m_hSceneObjectController")); }
    int m_nNoInterpolationTick() { return read<int>(baseAddr + offsets_instance.get("C_BaseEntity", "m_nNoInterpolationTick")); }
    int m_nVisibilityNoInterpolationTick() { return read<int>(baseAddr + offsets_instance.get("C_BaseEntity", "m_nVisibilityNoInterpolationTick")); }
    float m_flProxyRandomValue() { return read<float>(baseAddr + offsets_instance.get("C_BaseEntity", "m_flProxyRandomValue")); }
    int m_iEFlags() { return read<int>(baseAddr + offsets_instance.get("C_BaseEntity", "m_iEFlags")); }
    uint8_t m_nWaterType() { return read<uint8_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_nWaterType")); }
    bool m_bInterpolateEvenWithNoModel() { return read<bool>(baseAddr + offsets_instance.get("C_BaseEntity", "m_bInterpolateEvenWithNoModel")); }
    bool m_bPredictionEligible() { return read<bool>(baseAddr + offsets_instance.get("C_BaseEntity", "m_bPredictionEligible")); }
    bool m_bApplyLayerMatchIDToModel() { return read<bool>(baseAddr + offsets_instance.get("C_BaseEntity", "m_bApplyLayerMatchIDToModel")); }
    uintptr_t m_tokLayerMatchID() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_tokLayerMatchID")); }
    uintptr_t m_nSubclassID() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_nSubclassID")); }
    int m_nSimulationTick() { return read<int>(baseAddr + offsets_instance.get("C_BaseEntity", "m_nSimulationTick")); }
    int m_iCurrentThinkContext() { return read<int>(baseAddr + offsets_instance.get("C_BaseEntity", "m_iCurrentThinkContext")); }
    Vector3 m_aThinkFunctions() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseEntity", "m_aThinkFunctions")); }
    bool m_bDisabledContextThinks() { return read<bool>(baseAddr + offsets_instance.get("C_BaseEntity", "m_bDisabledContextThinks")); }
    float m_flAnimTime() { return read<float>(baseAddr + offsets_instance.get("C_BaseEntity", "m_flAnimTime")); }
    float m_flSimulationTime() { return read<float>(baseAddr + offsets_instance.get("C_BaseEntity", "m_flSimulationTime")); }
    uint8_t m_nSceneObjectOverrideFlags() { return read<uint8_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_nSceneObjectOverrideFlags")); }
    bool m_bHasSuccessfullyInterpolated() { return read<bool>(baseAddr + offsets_instance.get("C_BaseEntity", "m_bHasSuccessfullyInterpolated")); }
    bool m_bHasAddedVarsToInterpolation() { return read<bool>(baseAddr + offsets_instance.get("C_BaseEntity", "m_bHasAddedVarsToInterpolation")); }
    bool m_bRenderEvenWhenNotSuccessfullyInterpolated() { return read<bool>(baseAddr + offsets_instance.get("C_BaseEntity", "m_bRenderEvenWhenNotSuccessfullyInterpolated")); }
    int m_nInterpolationLatchDirtyFlags() { return read<int>(baseAddr + offsets_instance.get("C_BaseEntity", "m_nInterpolationLatchDirtyFlags")); }
    uint16_t m_ListEntry() { return read<uint16_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_ListEntry")); }
    GameTime_t m_flCreateTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_flCreateTime")); }
    float m_flSpeed() { return read<float>(baseAddr + offsets_instance.get("C_BaseEntity", "m_flSpeed")); }
    uint16_t m_EntClientFlags() { return read<uint16_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_EntClientFlags")); }
    bool m_bClientSideRagdoll() { return read<bool>(baseAddr + offsets_instance.get("C_BaseEntity", "m_bClientSideRagdoll")); }
    uint8_t m_iTeamNum() { return read<uint8_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_iTeamNum")); }
    int m_spawnflags() { return read<int>(baseAddr + offsets_instance.get("C_BaseEntity", "m_spawnflags")); }
    GameTick_t m_nNextThinkTick() { return read<GameTick_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_nNextThinkTick")); }
    int m_fFlags() { return read<int>(baseAddr + offsets_instance.get("C_BaseEntity", "m_fFlags")); }
    Vector3 m_vecAbsVelocity() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseEntity", "m_vecAbsVelocity")); }
    Vector3 m_vecServerVelocity() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseEntity", "m_vecServerVelocity")); }
    Vector3 m_vecVelocity() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseEntity", "m_vecVelocity")); }
    Vector3 m_vecBaseVelocity() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseEntity", "m_vecBaseVelocity")); }
    C_BaseEntity* m_hEffectEntity() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_BaseEntity", "m_hEffectEntity")); }
    C_BaseEntity* m_hOwnerEntity() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_BaseEntity", "m_hOwnerEntity")); }
    uintptr_t m_MoveCollide() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_MoveCollide")); }
    uintptr_t m_MoveType() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_MoveType")); }
    uintptr_t m_nActualMoveType() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_nActualMoveType")); }
    float m_flWaterLevel() { return read<float>(baseAddr + offsets_instance.get("C_BaseEntity", "m_flWaterLevel")); }
    int m_fEffects() { return read<int>(baseAddr + offsets_instance.get("C_BaseEntity", "m_fEffects")); }
    C_BaseEntity* m_hGroundEntity() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_BaseEntity", "m_hGroundEntity")); }
    int m_nGroundBodyIndex() { return read<int>(baseAddr + offsets_instance.get("C_BaseEntity", "m_nGroundBodyIndex")); }
    float m_flFriction() { return read<float>(baseAddr + offsets_instance.get("C_BaseEntity", "m_flFriction")); }
    float m_flElasticity() { return read<float>(baseAddr + offsets_instance.get("C_BaseEntity", "m_flElasticity")); }
    float m_flGravityScale() { return read<float>(baseAddr + offsets_instance.get("C_BaseEntity", "m_flGravityScale")); }
    float m_flTimeScale() { return read<float>(baseAddr + offsets_instance.get("C_BaseEntity", "m_flTimeScale")); }
    bool m_bAnimatedEveryTick() { return read<bool>(baseAddr + offsets_instance.get("C_BaseEntity", "m_bAnimatedEveryTick")); }
    bool m_bGravityDisabled() { return read<bool>(baseAddr + offsets_instance.get("C_BaseEntity", "m_bGravityDisabled")); }
    GameTime_t m_flNavIgnoreUntilTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_flNavIgnoreUntilTime")); }
    uint16_t m_hThink() { return read<uint16_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_hThink")); }
    uint8_t m_fBBoxVisFlags() { return read<uint8_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_fBBoxVisFlags")); }
    float m_flActualGravityScale() { return read<float>(baseAddr + offsets_instance.get("C_BaseEntity", "m_flActualGravityScale")); }
    bool m_bGravityActuallyDisabled() { return read<bool>(baseAddr + offsets_instance.get("C_BaseEntity", "m_bGravityActuallyDisabled")); }
    bool m_bPredictable() { return read<bool>(baseAddr + offsets_instance.get("C_BaseEntity", "m_bPredictable")); }
    bool m_bRenderWithViewModels() { return read<bool>(baseAddr + offsets_instance.get("C_BaseEntity", "m_bRenderWithViewModels")); }
    int m_nFirstPredictableCommand() { return read<int>(baseAddr + offsets_instance.get("C_BaseEntity", "m_nFirstPredictableCommand")); }
    int m_nLastPredictableCommand() { return read<int>(baseAddr + offsets_instance.get("C_BaseEntity", "m_nLastPredictableCommand")); }
    C_BaseEntity* m_hOldMoveParent() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_BaseEntity", "m_hOldMoveParent")); }
    uintptr_t m_Particles() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_Particles")); }
    QAngle m_vecAngVelocity() { return read<QAngle>(baseAddr + offsets_instance.get("C_BaseEntity", "m_vecAngVelocity")); }
    int m_DataChangeEventRef() { return read<int>(baseAddr + offsets_instance.get("C_BaseEntity", "m_DataChangeEventRef")); }
    Vector3 m_dependencies() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseEntity", "m_dependencies")); }
    int m_nCreationTick() { return read<int>(baseAddr + offsets_instance.get("C_BaseEntity", "m_nCreationTick")); }
    bool m_bAnimTimeChanged() { return read<bool>(baseAddr + offsets_instance.get("C_BaseEntity", "m_bAnimTimeChanged")); }
    bool m_bSimulationTimeChanged() { return read<bool>(baseAddr + offsets_instance.get("C_BaseEntity", "m_bSimulationTimeChanged")); }
    uintptr_t m_sUniqueHammerID() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_sUniqueHammerID")); }
    uintptr_t m_nBloodType() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseEntity", "m_nBloodType")); }
};
