#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class WeaponPurchaseTracker_t  {
public:
    uintptr_t baseAddr;

    WeaponPurchaseTracker_t() { baseAddr = client_base(); }
    WeaponPurchaseTracker_t(uintptr_t base) : baseAddr(base) {}

    Vector3 m_weaponPurchases() { return read<Vector3>(baseAddr + offsets_instance.get("WeaponPurchaseTracker_t", "m_weaponPurchases")); }
};
