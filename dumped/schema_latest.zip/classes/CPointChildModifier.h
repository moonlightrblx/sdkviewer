#pragma once
#include "../memory.h"

class CPointChildModifier {
public:
 uintptr_t baseAddr;
 CPointChildModifier() : baseAddr(0){}
 CPointChildModifier(uintptr_t b):baseAddr(b){}
 uintptr_t m_bOrphanInsteadOfDeletingChildrenOnRemove(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
};
