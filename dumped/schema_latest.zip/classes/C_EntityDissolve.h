#pragma once
#include "../memory.h"

class C_EntityDissolve {
public:
 uintptr_t baseAddr;
 C_EntityDissolve() : baseAddr(0){}
 C_EntityDissolve(uintptr_t b):baseAddr(b){}
 uintptr_t m_flStartTime(){return SCHEMA_TYPE(uintptr_t,0xEB8);}
 uintptr_t m_flFadeInStart(){return SCHEMA_TYPE(uintptr_t,0xEBC);}
 uintptr_t m_flFadeInLength(){return SCHEMA_TYPE(uintptr_t,0xEC0);}
 uintptr_t m_flFadeOutModelStart(){return SCHEMA_TYPE(uintptr_t,0xEC4);}
 uintptr_t m_flFadeOutModelLength(){return SCHEMA_TYPE(uintptr_t,0xEC8);}
 uintptr_t m_flFadeOutStart(){return SCHEMA_TYPE(uintptr_t,0xECC);}
 uintptr_t m_flFadeOutLength(){return SCHEMA_TYPE(uintptr_t,0xED0);}
 uintptr_t m_flNextSparkTime(){return SCHEMA_TYPE(uintptr_t,0xED4);}
 uintptr_t m_nDissolveType(){return SCHEMA_TYPE(uintptr_t,0xED8);}
 uintptr_t m_vDissolverOrigin(){return SCHEMA_TYPE(uintptr_t,0xEDC);}
 uintptr_t m_nMagnitude(){return SCHEMA_TYPE(uintptr_t,0xEE8);}
 uintptr_t m_bCoreExplode(){return SCHEMA_TYPE(uintptr_t,0xEEC);}
 uintptr_t m_bLinkedToServerEnt(){return SCHEMA_TYPE(uintptr_t,0xEED);}
};
