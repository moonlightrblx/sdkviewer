#pragma once
#include "../memory.h"
#include "../classes/C_EconItemView.h"

class C_AttributeContainer  {
public:
    uintptr_t baseAddr;

    C_AttributeContainer() { baseAddr = 0; }
    C_AttributeContainer(uintptr_t base) : baseAddr(base) {}

    C_EconItemView m_Item() { return read<C_EconItemView>(baseAddr + offsets_instance.get("C_AttributeContainer", "m_Item")); }
    int m_iExternalItemProviderRegisteredToken() { return read<int>(baseAddr + offsets_instance.get("C_AttributeContainer", "m_iExternalItemProviderRegisteredToken")); }
    uintptr_t m_ullRegisteredAsItemID() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_AttributeContainer", "m_ullRegisteredAsItemID")); }
};
