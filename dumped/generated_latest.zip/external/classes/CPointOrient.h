#pragma once
#include "../memory.h"
#include "../classes/GameTime_t.h"
class C_BaseEntity;

class CPointOrient  {
public:
    uintptr_t baseAddr;

    CPointOrient() { baseAddr = 0; }
    CPointOrient(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_iszSpawnTargetName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPointOrient", "m_iszSpawnTargetName")); }
    C_BaseEntity* m_hTarget() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("CPointOrient", "m_hTarget")); }
    bool m_bActive() { return read<bool>(baseAddr + offsets_instance.get("CPointOrient", "m_bActive")); }
    uintptr_t m_nGoalDirection() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPointOrient", "m_nGoalDirection")); }
    uintptr_t m_nConstraint() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPointOrient", "m_nConstraint")); }
    float m_flMaxTurnRate() { return read<float>(baseAddr + offsets_instance.get("CPointOrient", "m_flMaxTurnRate")); }
    GameTime_t m_flLastGameTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("CPointOrient", "m_flLastGameTime")); }
};
