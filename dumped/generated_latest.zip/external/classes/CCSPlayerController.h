#pragma once
#include "../memory.h"

class CCSPlayerController  {
public:
    uintptr_t baseAddr;

    CCSPlayerController() { baseAddr = client_base(); }
    CCSPlayerController(uintptr_t base) : baseAddr(base) {}

    CCSPlayerController_InGameMoneyServices* m_pInGameMoneyServices() { return read<CCSPlayerController_InGameMoneyServices*>(baseAddr + offsets_instance.get("CCSPlayerController", "m_pInGameMoneyServices")); }
    CCSPlayerController_InventoryServices* m_pInventoryServices() { return read<CCSPlayerController_InventoryServices*>(baseAddr + offsets_instance.get("CCSPlayerController", "m_pInventoryServices")); }
    CCSPlayerController_ActionTrackingServices* m_pActionTrackingServices() { return read<CCSPlayerController_ActionTrackingServices*>(baseAddr + offsets_instance.get("CCSPlayerController", "m_pActionTrackingServices")); }
    CCSPlayerController_DamageServices* m_pDamageServices() { return read<CCSPlayerController_DamageServices*>(baseAddr + offsets_instance.get("CCSPlayerController", "m_pDamageServices")); }
    int m_iPing() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_iPing")); }
    bool m_bHasCommunicationAbuseMute() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayerController", "m_bHasCommunicationAbuseMute")); }
    int m_uiCommunicationMuteFlags() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_uiCommunicationMuteFlags")); }
    uintptr_t m_szCrosshairCodes() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSPlayerController", "m_szCrosshairCodes")); }
    uint8_t m_iPendingTeamNum() { return read<uint8_t>(baseAddr + offsets_instance.get("CCSPlayerController", "m_iPendingTeamNum")); }
    uintptr_t m_flForceTeamTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSPlayerController", "m_flForceTeamTime")); }
    int m_iCompTeammateColor() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_iCompTeammateColor")); }
    bool m_bEverPlayedOnTeam() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayerController", "m_bEverPlayedOnTeam")); }
    uintptr_t m_flPreviousForceJoinTeamTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSPlayerController", "m_flPreviousForceJoinTeamTime")); }
    uintptr_t m_szClan() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSPlayerController", "m_szClan")); }
    uintptr_t m_sSanitizedPlayerName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSPlayerController", "m_sSanitizedPlayerName")); }
    int m_iCoachingTeam() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_iCoachingTeam")); }
    uintptr_t m_nPlayerDominated() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSPlayerController", "m_nPlayerDominated")); }
    uintptr_t m_nPlayerDominatingMe() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSPlayerController", "m_nPlayerDominatingMe")); }
    int m_iCompetitiveRanking() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_iCompetitiveRanking")); }
    int m_iCompetitiveWins() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_iCompetitiveWins")); }
    uintptr_t m_iCompetitiveRankType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSPlayerController", "m_iCompetitiveRankType")); }
    int m_iCompetitiveRankingPredicted_Win() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_iCompetitiveRankingPredicted_Win")); }
    int m_iCompetitiveRankingPredicted_Loss() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_iCompetitiveRankingPredicted_Loss")); }
    int m_iCompetitiveRankingPredicted_Tie() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_iCompetitiveRankingPredicted_Tie")); }
    int m_nEndMatchNextMapVote() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_nEndMatchNextMapVote")); }
    uint16_t m_unActiveQuestId() { return read<uint16_t>(baseAddr + offsets_instance.get("CCSPlayerController", "m_unActiveQuestId")); }
    int m_rtActiveMissionPeriod() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_rtActiveMissionPeriod")); }
    uintptr_t m_nQuestProgressReason() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSPlayerController", "m_nQuestProgressReason")); }
    int m_unPlayerTvControlFlags() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_unPlayerTvControlFlags")); }
    int m_iDraftIndex() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_iDraftIndex")); }
    int m_msQueuedModeDisconnectionTimestamp() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_msQueuedModeDisconnectionTimestamp")); }
    int m_uiAbandonRecordedReason() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_uiAbandonRecordedReason")); }
    int m_eNetworkDisconnectionReason() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_eNetworkDisconnectionReason")); }
    bool m_bCannotBeKicked() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayerController", "m_bCannotBeKicked")); }
    bool m_bEverFullyConnected() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayerController", "m_bEverFullyConnected")); }
    bool m_bAbandonAllowsSurrender() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayerController", "m_bAbandonAllowsSurrender")); }
    bool m_bAbandonOffersInstantSurrender() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayerController", "m_bAbandonOffersInstantSurrender")); }
    bool m_bDisconnection1MinWarningPrinted() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayerController", "m_bDisconnection1MinWarningPrinted")); }
    bool m_bScoreReported() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayerController", "m_bScoreReported")); }
    int m_nDisconnectionTick() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_nDisconnectionTick")); }
    bool m_bControllingBot() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayerController", "m_bControllingBot")); }
    bool m_bHasControlledBotThisRound() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayerController", "m_bHasControlledBotThisRound")); }
    bool m_bHasBeenControlledByPlayerThisRound() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayerController", "m_bHasBeenControlledByPlayerThisRound")); }
    int m_nBotsControlledThisRound() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_nBotsControlledThisRound")); }
    bool m_bCanControlObservedBot() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayerController", "m_bCanControlObservedBot")); }
    C_CSPlayerPawn* m_hPlayerPawn() { return read<C_CSPlayerPawn*>(baseAddr + offsets_instance.get("CCSPlayerController", "m_hPlayerPawn")); }
    C_CSObserverPawn* m_hObserverPawn() { return read<C_CSObserverPawn*>(baseAddr + offsets_instance.get("CCSPlayerController", "m_hObserverPawn")); }
    bool m_bPawnIsAlive() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayerController", "m_bPawnIsAlive")); }
    int m_iPawnHealth() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_iPawnHealth")); }
    int m_iPawnArmor() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_iPawnArmor")); }
    bool m_bPawnHasDefuser() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayerController", "m_bPawnHasDefuser")); }
    bool m_bPawnHasHelmet() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayerController", "m_bPawnHasHelmet")); }
    uint16_t m_nPawnCharacterDefIndex() { return read<uint16_t>(baseAddr + offsets_instance.get("CCSPlayerController", "m_nPawnCharacterDefIndex")); }
    int m_iPawnLifetimeStart() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_iPawnLifetimeStart")); }
    int m_iPawnLifetimeEnd() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_iPawnLifetimeEnd")); }
    int m_iPawnBotDifficulty() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_iPawnBotDifficulty")); }
    CCSPlayerController* m_hOriginalControllerOfCurrentPawn() { return read<CCSPlayerController*>(baseAddr + offsets_instance.get("CCSPlayerController", "m_hOriginalControllerOfCurrentPawn")); }
    int m_iScore() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_iScore")); }
    uint8_t m_recentKillQueue() { return read<uint8_t>(baseAddr + offsets_instance.get("CCSPlayerController", "m_recentKillQueue")); }
    uint8_t m_nFirstKill() { return read<uint8_t>(baseAddr + offsets_instance.get("CCSPlayerController", "m_nFirstKill")); }
    uint8_t m_nKillCount() { return read<uint8_t>(baseAddr + offsets_instance.get("CCSPlayerController", "m_nKillCount")); }
    bool m_bMvpNoMusic() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayerController", "m_bMvpNoMusic")); }
    int m_eMvpReason() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_eMvpReason")); }
    int m_iMusicKitID() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_iMusicKitID")); }
    int m_iMusicKitMVPs() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_iMusicKitMVPs")); }
    int m_iMVPs() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController", "m_iMVPs")); }
    bool m_bIsPlayerNameDirty() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayerController", "m_bIsPlayerNameDirty")); }
    bool m_bFireBulletsSeedSynchronized() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayerController", "m_bFireBulletsSeedSynchronized")); }
};
