#pragma once
#include "../memory.h"

class CPulseCell_WaitForObservable {
public:
 uintptr_t baseAddr;
 CPulseCell_WaitForObservable() : baseAddr(0){}
 CPulseCell_WaitForObservable(uintptr_t b):baseAddr(b){}
 uintptr_t m_Condition(){return SCHEMA_TYPE(uintptr_t,0x48);}
 uintptr_t m_OnTrue(){return SCHEMA_TYPE(uintptr_t,0xC0);}
};
