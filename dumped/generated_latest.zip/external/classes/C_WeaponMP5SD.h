#pragma once
#include "../memory.h"

class C_WeaponMP5SD  {
public:
    uintptr_t baseAddr;

    C_WeaponMP5SD() { baseAddr = client_base(); }
    C_WeaponMP5SD(uintptr_t base) : baseAddr(base) {}

};
