#pragma once
#include "../memory.h"

class CServerOnlyModelEntity  {
public:
    uintptr_t baseAddr;

    CServerOnlyModelEntity() { baseAddr = client_base(); }
    CServerOnlyModelEntity(uintptr_t base) : baseAddr(base) {}

};
