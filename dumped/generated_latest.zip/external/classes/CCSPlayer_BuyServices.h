#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class CCSPlayer_BuyServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_BuyServices() { baseAddr = 0; }
    CCSPlayer_BuyServices(uintptr_t base) : baseAddr(base) {}

    Vector3 m_vecSellbackPurchaseEntries() { return read<Vector3>(baseAddr + offsets_instance.get("CCSPlayer_BuyServices", "m_vecSellbackPurchaseEntries")); }
};
