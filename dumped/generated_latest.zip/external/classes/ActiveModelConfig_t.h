#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class ActiveModelConfig_t  {
public:
    uintptr_t baseAddr;

    ActiveModelConfig_t() { baseAddr = 0; }
    ActiveModelConfig_t(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_Handle() { return read<uintptr_t>(baseAddr + offsets_instance.get("ActiveModelConfig_t", "m_Handle")); }
    uintptr_t m_Name() { return read<uintptr_t>(baseAddr + offsets_instance.get("ActiveModelConfig_t", "m_Name")); }
    Vector3 m_AssociatedEntities() { return read<Vector3>(baseAddr + offsets_instance.get("ActiveModelConfig_t", "m_AssociatedEntities")); }
    Vector3 m_AssociatedEntityNames() { return read<Vector3>(baseAddr + offsets_instance.get("ActiveModelConfig_t", "m_AssociatedEntityNames")); }
};
