#pragma once
#include "../memory.h"

class C_BaseFlex {
public:
 uintptr_t baseAddr;
 C_BaseFlex() : baseAddr(0){}
 C_BaseFlex(uintptr_t b):baseAddr(b){}
 uintptr_t m_flexWeight(){return SCHEMA_TYPE(uintptr_t,0x1168);}
 uintptr_t m_vLookTargetPosition(){return SCHEMA_TYPE(uintptr_t,0x1180);}
 uintptr_t m_blinktoggle(){return SCHEMA_TYPE(uintptr_t,0x1210);}
 uintptr_t m_nLastFlexUpdateFrameCount(){return SCHEMA_TYPE(uintptr_t,0x1270);}
 uintptr_t m_CachedViewTarget(){return SCHEMA_TYPE(uintptr_t,0x1274);}
 uintptr_t m_nNextSceneEventId(){return SCHEMA_TYPE(uintptr_t,0x1280);}
 uintptr_t m_iBlink(){return SCHEMA_TYPE(uintptr_t,0x1284);}
 uintptr_t m_blinktime(){return SCHEMA_TYPE(uintptr_t,0x1288);}
 uintptr_t m_prevblinktoggle(){return SCHEMA_TYPE(uintptr_t,0x128C);}
 uintptr_t m_iJawOpen(){return SCHEMA_TYPE(uintptr_t,0x1290);}
 uintptr_t m_flJawOpenAmount(){return SCHEMA_TYPE(uintptr_t,0x1294);}
 uintptr_t m_flBlinkAmount(){return SCHEMA_TYPE(uintptr_t,0x1298);}
 uintptr_t m_iMouthAttachment(){return SCHEMA_TYPE(uintptr_t,0x129C);}
 uintptr_t m_iEyeAttachment(){return SCHEMA_TYPE(uintptr_t,0x129D);}
 uintptr_t m_bResetFlexWeightsOnModelChange(){return SCHEMA_TYPE(uintptr_t,0x129E);}
 uintptr_t m_nEyeOcclusionRendererBone(){return SCHEMA_TYPE(uintptr_t,0x12B8);}
 uintptr_t m_mEyeOcclusionRendererCameraToBoneTransform(){return SCHEMA_TYPE(uintptr_t,0x12BC);}
 uintptr_t m_vEyeOcclusionRendererHalfExtent(){return SCHEMA_TYPE(uintptr_t,0x12EC);}
 uintptr_t m_PhonemeClasses(){return SCHEMA_TYPE(uintptr_t,0x1308);}
};
