#pragma once
#include "../memory.h"

class C_PointCameraVFOV  {
public:
    uintptr_t baseAddr;

    C_PointCameraVFOV() { baseAddr = client_base(); }
    C_PointCameraVFOV(uintptr_t base) : baseAddr(base) {}

    float m_flVerticalFOV() { return read<float>(baseAddr + offsets_instance.get("C_PointCameraVFOV", "m_flVerticalFOV")); }
};
