#pragma once
#include "../memory.h"

class CEntityComponent {
public:
 uintptr_t baseAddr;
 CEntityComponent() : baseAddr(0){}
 CEntityComponent(uintptr_t b):baseAddr(b){}
};
