#pragma once
#include "../memory.h"

class CPulseCell_LimitCount__InstanceState_t {
public:
 uintptr_t baseAddr;
 CPulseCell_LimitCount__InstanceState_t() : baseAddr(0){}
 CPulseCell_LimitCount__InstanceState_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_nCurrentCount(){return SCHEMA_TYPE(uintptr_t,0x0);}
};
