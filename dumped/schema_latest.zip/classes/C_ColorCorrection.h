#pragma once
#include "../memory.h"

class C_ColorCorrection {
public:
 uintptr_t baseAddr;
 C_ColorCorrection() : baseAddr(0){}
 C_ColorCorrection(uintptr_t b):baseAddr(b){}
 uintptr_t m_vecOrigin(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_MinFalloff(){return SCHEMA_TYPE(uintptr_t,0x604);}
 uintptr_t m_MaxFalloff(){return SCHEMA_TYPE(uintptr_t,0x608);}
 uintptr_t m_flFadeInDuration(){return SCHEMA_TYPE(uintptr_t,0x60C);}
 uintptr_t m_flFadeOutDuration(){return SCHEMA_TYPE(uintptr_t,0x610);}
 uintptr_t m_flMaxWeight(){return SCHEMA_TYPE(uintptr_t,0x614);}
 uintptr_t m_flCurWeight(){return SCHEMA_TYPE(uintptr_t,0x618);}
 uintptr_t m_netlookupFilename(){return SCHEMA_TYPE(uintptr_t,0x61C);}
 uintptr_t m_bEnabled(){return SCHEMA_TYPE(uintptr_t,0x81C);}
 uintptr_t m_bMaster(){return SCHEMA_TYPE(uintptr_t,0x81D);}
 uintptr_t m_bClientSide(){return SCHEMA_TYPE(uintptr_t,0x81E);}
 uintptr_t m_bExclusive(){return SCHEMA_TYPE(uintptr_t,0x81F);}
 uintptr_t m_bEnabledOnClient(){return SCHEMA_TYPE(uintptr_t,0x820);}
 uintptr_t m_flCurWeightOnClient(){return SCHEMA_TYPE(uintptr_t,0x824);}
 uintptr_t m_bFadingIn(){return SCHEMA_TYPE(uintptr_t,0x828);}
 uintptr_t m_flFadeStartWeight(){return SCHEMA_TYPE(uintptr_t,0x82C);}
 uintptr_t m_flFadeStartTime(){return SCHEMA_TYPE(uintptr_t,0x830);}
 uintptr_t m_flFadeDuration(){return SCHEMA_TYPE(uintptr_t,0x834);}
};
