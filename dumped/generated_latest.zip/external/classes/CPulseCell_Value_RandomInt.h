#pragma once
#include "../memory.h"

class CPulseCell_Value_RandomInt  {
public:
    uintptr_t baseAddr;

    CPulseCell_Value_RandomInt() { baseAddr = 0; }
    CPulseCell_Value_RandomInt(uintptr_t base) : baseAddr(base) {}

};
