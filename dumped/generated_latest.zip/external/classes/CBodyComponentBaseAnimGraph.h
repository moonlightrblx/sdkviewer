#pragma once
#include "../memory.h"

class CBodyComponentBaseAnimGraph  {
public:
    uintptr_t baseAddr;

    CBodyComponentBaseAnimGraph() { baseAddr = client_base(); }
    CBodyComponentBaseAnimGraph(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_animationController() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBodyComponentBaseAnimGraph", "m_animationController")); }
};
