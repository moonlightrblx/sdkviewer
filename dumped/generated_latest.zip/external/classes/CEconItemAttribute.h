#pragma once
#include "../memory.h"

class CEconItemAttribute  {
public:
    uintptr_t baseAddr;

    CEconItemAttribute() { baseAddr = 0; }
    CEconItemAttribute(uintptr_t base) : baseAddr(base) {}

    uint16_t m_iAttributeDefinitionIndex() { return read<uint16_t>(baseAddr + offsets_instance.get("CEconItemAttribute", "m_iAttributeDefinitionIndex")); }
    float m_flValue() { return read<float>(baseAddr + offsets_instance.get("CEconItemAttribute", "m_flValue")); }
    float m_flInitialValue() { return read<float>(baseAddr + offsets_instance.get("CEconItemAttribute", "m_flInitialValue")); }
    int m_nRefundableCurrency() { return read<int>(baseAddr + offsets_instance.get("CEconItemAttribute", "m_nRefundableCurrency")); }
    bool m_bSetBonus() { return read<bool>(baseAddr + offsets_instance.get("CEconItemAttribute", "m_bSetBonus")); }
};
