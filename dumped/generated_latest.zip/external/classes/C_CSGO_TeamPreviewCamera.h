#pragma once
#include "../memory.h"

class C_CSGO_TeamPreviewCamera  {
public:
    uintptr_t baseAddr;

    C_CSGO_TeamPreviewCamera() { baseAddr = client_base(); }
    C_CSGO_TeamPreviewCamera(uintptr_t base) : baseAddr(base) {}

    int m_nVariant() { return read<int>(baseAddr + offsets_instance.get("C_CSGO_TeamPreviewCamera", "m_nVariant")); }
};
