#pragma once
#include "../memory.h"

class CVariantDefaultAllocator {
public:
 uintptr_t baseAddr;
 CVariantDefaultAllocator() : baseAddr(0){}
 CVariantDefaultAllocator(uintptr_t b):baseAddr(b){}
};
