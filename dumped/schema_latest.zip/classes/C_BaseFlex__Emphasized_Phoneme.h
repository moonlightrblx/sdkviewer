#pragma once
#include "../memory.h"

class C_BaseFlex__Emphasized_Phoneme {
public:
 uintptr_t baseAddr;
 C_BaseFlex__Emphasized_Phoneme() : baseAddr(0){}
 C_BaseFlex__Emphasized_Phoneme(uintptr_t b):baseAddr(b){}
 uintptr_t m_sClassName(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_flAmount(){return SCHEMA_TYPE(uintptr_t,0x18);}
 uintptr_t m_bRequired(){return SCHEMA_TYPE(uintptr_t,0x1C);}
 uintptr_t m_bBasechecked(){return SCHEMA_TYPE(uintptr_t,0x1D);}
 uintptr_t m_bValid(){return SCHEMA_TYPE(uintptr_t,0x1E);}
};
