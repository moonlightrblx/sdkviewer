#pragma once
#include "../memory.h"

class C_CSGO_MapPreviewCameraPath  {
public:
    uintptr_t baseAddr;

    C_CSGO_MapPreviewCameraPath() { baseAddr = client_base(); }
    C_CSGO_MapPreviewCameraPath(uintptr_t base) : baseAddr(base) {}

    float m_flZFar() { return read<float>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPath", "m_flZFar")); }
    float m_flZNear() { return read<float>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPath", "m_flZNear")); }
    bool m_bLoop() { return read<bool>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPath", "m_bLoop")); }
    bool m_bVerticalFOV() { return read<bool>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPath", "m_bVerticalFOV")); }
    bool m_bConstantSpeed() { return read<bool>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPath", "m_bConstantSpeed")); }
    float m_flDuration() { return read<float>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPath", "m_flDuration")); }
    float m_flPathLength() { return read<float>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPath", "m_flPathLength")); }
    float m_flPathDuration() { return read<float>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPath", "m_flPathDuration")); }
    bool m_bDofEnabled() { return read<bool>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPath", "m_bDofEnabled")); }
    float m_flDofNearBlurry() { return read<float>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPath", "m_flDofNearBlurry")); }
    float m_flDofNearCrisp() { return read<float>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPath", "m_flDofNearCrisp")); }
    float m_flDofFarCrisp() { return read<float>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPath", "m_flDofFarCrisp")); }
    float m_flDofFarBlurry() { return read<float>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPath", "m_flDofFarBlurry")); }
    float m_flDofTiltToGround() { return read<float>(baseAddr + offsets_instance.get("C_CSGO_MapPreviewCameraPath", "m_flDofTiltToGround")); }
};
