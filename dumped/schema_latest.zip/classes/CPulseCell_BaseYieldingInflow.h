#pragma once
#include "../memory.h"

class CPulseCell_BaseYieldingInflow {
public:
 uintptr_t baseAddr;
 CPulseCell_BaseYieldingInflow() : baseAddr(0){}
 CPulseCell_BaseYieldingInflow(uintptr_t b):baseAddr(b){}
};
