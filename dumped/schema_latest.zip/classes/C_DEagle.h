#pragma once
#include "../memory.h"

class C_DEagle {
public:
 uintptr_t baseAddr;
 C_DEagle() : baseAddr(0){}
 C_DEagle(uintptr_t b):baseAddr(b){}
};
