#pragma once
#include "../memory.h"

class CPulseCell_CursorQueue {
public:
 uintptr_t baseAddr;
 CPulseCell_CursorQueue() : baseAddr(0){}
 CPulseCell_CursorQueue(uintptr_t b):baseAddr(b){}
 uintptr_t m_nCursorsAllowedToRunParallel(){return SCHEMA_TYPE(uintptr_t,0x98);}
};
