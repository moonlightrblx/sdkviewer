#pragma once
#include "../memory.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"
class C_BaseEntity;

class C_RopeKeyframe  {
public:
    uintptr_t baseAddr;

    C_RopeKeyframe() { baseAddr = 0; }
    C_RopeKeyframe(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_LinksTouchingSomething() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_LinksTouchingSomething")); }
    int m_nLinksTouchingSomething() { return read<int>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_nLinksTouchingSomething")); }
    bool m_bApplyWind() { return read<bool>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_bApplyWind")); }
    int m_fPrevLockedPoints() { return read<int>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_fPrevLockedPoints")); }
    int m_iForcePointMoveCounter() { return read<int>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_iForcePointMoveCounter")); }
    bool m_bPrevEndPointPos() { return read<bool>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_bPrevEndPointPos")); }
    Vector3 m_vPrevEndPointPos() { return read<Vector3>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_vPrevEndPointPos")); }
    float m_flCurScroll() { return read<float>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_flCurScroll")); }
    float m_flScrollSpeed() { return read<float>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_flScrollSpeed")); }
    uint16_t m_RopeFlags() { return read<uint16_t>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_RopeFlags")); }
    uintptr_t m_iRopeMaterialModelIndex() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_iRopeMaterialModelIndex")); }
    uint8_t m_nSegments() { return read<uint8_t>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_nSegments")); }
    C_BaseEntity* m_hStartPoint() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_hStartPoint")); }
    C_BaseEntity* m_hEndPoint() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_hEndPoint")); }
    uintptr_t m_iStartAttachment() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_iStartAttachment")); }
    uintptr_t m_iEndAttachment() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_iEndAttachment")); }
    uint8_t m_Subdiv() { return read<uint8_t>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_Subdiv")); }
    uintptr_t m_RopeLength() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_RopeLength")); }
    uintptr_t m_Slack() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_Slack")); }
    float m_TextureScale() { return read<float>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_TextureScale")); }
    uint8_t m_fLockedPoints() { return read<uint8_t>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_fLockedPoints")); }
    uint8_t m_nChangeCount() { return read<uint8_t>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_nChangeCount")); }
    float m_Width() { return read<float>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_Width")); }
    uintptr_t m_PhysicsDelegate() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_PhysicsDelegate")); }
    uintptr_t m_hMaterial() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_hMaterial")); }
    int m_TextureHeight() { return read<int>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_TextureHeight")); }
    Vector3 m_vecImpulse() { return read<Vector3>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_vecImpulse")); }
    Vector3 m_vecPreviousImpulse() { return read<Vector3>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_vecPreviousImpulse")); }
    float m_flCurrentGustTimer() { return read<float>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_flCurrentGustTimer")); }
    float m_flCurrentGustLifetime() { return read<float>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_flCurrentGustLifetime")); }
    float m_flTimeToNextGust() { return read<float>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_flTimeToNextGust")); }
    Vector3 m_vWindDir() { return read<Vector3>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_vWindDir")); }
    Vector3 m_vColorMod() { return read<Vector3>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_vColorMod")); }
    Vector3 m_vCachedEndPointAttachmentPos() { return read<Vector3>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_vCachedEndPointAttachmentPos")); }
    QAngle m_vCachedEndPointAttachmentAngle() { return read<QAngle>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_vCachedEndPointAttachmentAngle")); }
    bool m_bConstrainBetweenEndpoints() { return read<bool>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_bConstrainBetweenEndpoints")); }
    uintptr_t m_bEndPointAttachmentPositionsDirty() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_bEndPointAttachmentPositionsDirty")); }
    uintptr_t m_bEndPointAttachmentAnglesDirty() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_bEndPointAttachmentAnglesDirty")); }
    uintptr_t m_bNewDataThisFrame() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_bNewDataThisFrame")); }
    uintptr_t m_bPhysicsInitted() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_RopeKeyframe", "m_bPhysicsInitted")); }
};
