#pragma once
#include "../memory.h"

class CBuoyancyHelper {
public:
 uintptr_t baseAddr;
 CBuoyancyHelper() : baseAddr(0){}
 CBuoyancyHelper(uintptr_t b):baseAddr(b){}
 uintptr_t m_nFluidType(){return SCHEMA_TYPE(uintptr_t,0x18);}
 uintptr_t m_flFluidDensity(){return SCHEMA_TYPE(uintptr_t,0x1C);}
 uintptr_t m_flNeutrallyBuoyantGravity(){return SCHEMA_TYPE(uintptr_t,0x20);}
 uintptr_t m_flNeutrallyBuoyantLinearDamping(){return SCHEMA_TYPE(uintptr_t,0x24);}
 uintptr_t m_flNeutrallyBuoyantAngularDamping(){return SCHEMA_TYPE(uintptr_t,0x28);}
 uintptr_t m_bNeutrallyBuoyant(){return SCHEMA_TYPE(uintptr_t,0x2C);}
 uintptr_t m_vecFractionOfWheelSubmergedForWheelFriction(){return SCHEMA_TYPE(uintptr_t,0x30);}
 uintptr_t m_vecWheelFrictionScales(){return SCHEMA_TYPE(uintptr_t,0x48);}
 uintptr_t m_vecFractionOfWheelSubmergedForWheelDrag(){return SCHEMA_TYPE(uintptr_t,0x60);}
 uintptr_t m_vecWheelDrag(){return SCHEMA_TYPE(uintptr_t,0x78);}
};
