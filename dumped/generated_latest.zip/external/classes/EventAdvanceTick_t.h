#pragma once
#include "../memory.h"

class EventAdvanceTick_t  {
public:
    uintptr_t baseAddr;

    EventAdvanceTick_t() { baseAddr = 0; }
    EventAdvanceTick_t(uintptr_t base) : baseAddr(base) {}

    int m_nCurrentTick() { return read<int>(baseAddr + offsets_instance.get("EventAdvanceTick_t", "m_nCurrentTick")); }
    int m_nCurrentTickThisFrame() { return read<int>(baseAddr + offsets_instance.get("EventAdvanceTick_t", "m_nCurrentTickThisFrame")); }
    int m_nTotalTicksThisFrame() { return read<int>(baseAddr + offsets_instance.get("EventAdvanceTick_t", "m_nTotalTicksThisFrame")); }
    int m_nTotalTicks() { return read<int>(baseAddr + offsets_instance.get("EventAdvanceTick_t", "m_nTotalTicks")); }
};
