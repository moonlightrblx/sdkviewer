#pragma once
#include "../memory.h"

class CPulseCell_Inflow_BaseEntrypoint {
public:
 uintptr_t baseAddr;
 CPulseCell_Inflow_BaseEntrypoint() : baseAddr(0){}
 CPulseCell_Inflow_BaseEntrypoint(uintptr_t b):baseAddr(b){}
 uintptr_t m_EntryChunk(){return SCHEMA_TYPE(uintptr_t,0x48);}
 uintptr_t m_RegisterMap(){return SCHEMA_TYPE(uintptr_t,0x50);}
};
