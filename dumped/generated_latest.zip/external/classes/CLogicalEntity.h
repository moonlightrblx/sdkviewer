#pragma once
#include "../memory.h"

class CLogicalEntity  {
public:
    uintptr_t baseAddr;

    CLogicalEntity() { baseAddr = client_base(); }
    CLogicalEntity(uintptr_t base) : baseAddr(base) {}

};
