#pragma once
#include "../memory.h"

class CInfoDynamicShadowHint  {
public:
    uintptr_t baseAddr;

    CInfoDynamicShadowHint() { baseAddr = client_base(); }
    CInfoDynamicShadowHint(uintptr_t base) : baseAddr(base) {}

    bool m_bDisabled() { return read<bool>(baseAddr + offsets_instance.get("CInfoDynamicShadowHint", "m_bDisabled")); }
    float m_flRange() { return read<float>(baseAddr + offsets_instance.get("CInfoDynamicShadowHint", "m_flRange")); }
    int m_nImportance() { return read<int>(baseAddr + offsets_instance.get("CInfoDynamicShadowHint", "m_nImportance")); }
    int m_nLightChoice() { return read<int>(baseAddr + offsets_instance.get("CInfoDynamicShadowHint", "m_nLightChoice")); }
    C_BaseEntity* m_hLight() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("CInfoDynamicShadowHint", "m_hLight")); }
};
