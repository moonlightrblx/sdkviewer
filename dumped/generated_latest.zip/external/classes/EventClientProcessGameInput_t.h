#pragma once
#include "../memory.h"
#include "../classes/EngineLoopState_t.h"

class EventClientProcessGameInput_t  {
public:
    uintptr_t baseAddr;

    EventClientProcessGameInput_t() { baseAddr = 0; }
    EventClientProcessGameInput_t(uintptr_t base) : baseAddr(base) {}

    EngineLoopState_t m_LoopState() { return read<EngineLoopState_t>(baseAddr + offsets_instance.get("EventClientProcessGameInput_t", "m_LoopState")); }
    float m_flRealTime() { return read<float>(baseAddr + offsets_instance.get("EventClientProcessGameInput_t", "m_flRealTime")); }
    float m_flFrameTime() { return read<float>(baseAddr + offsets_instance.get("EventClientProcessGameInput_t", "m_flFrameTime")); }
};
