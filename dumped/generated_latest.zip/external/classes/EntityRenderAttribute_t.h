#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class EntityRenderAttribute_t  {
public:
    uintptr_t baseAddr;

    EntityRenderAttribute_t() { baseAddr = client_base(); }
    EntityRenderAttribute_t(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_ID() { return read<uintptr_t>(baseAddr + offsets_instance.get("EntityRenderAttribute_t", "m_ID")); }
    Vector3 m_Values() { return read<Vector3>(baseAddr + offsets_instance.get("EntityRenderAttribute_t", "m_Values")); }
};
