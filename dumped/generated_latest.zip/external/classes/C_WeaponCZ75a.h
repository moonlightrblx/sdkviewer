#pragma once
#include "../memory.h"

class C_WeaponCZ75a  {
public:
    uintptr_t baseAddr;

    C_WeaponCZ75a() { baseAddr = 0; }
    C_WeaponCZ75a(uintptr_t base) : baseAddr(base) {}

    bool m_bMagazineRemoved() { return read<bool>(baseAddr + offsets_instance.get("C_WeaponCZ75a", "m_bMagazineRemoved")); }
};
