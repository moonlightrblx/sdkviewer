#pragma once
#include "../memory.h"

class C_CSGO_TeamSelectCamera  {
public:
    uintptr_t baseAddr;

    C_CSGO_TeamSelectCamera() { baseAddr = client_base(); }
    C_CSGO_TeamSelectCamera(uintptr_t base) : baseAddr(base) {}

};
