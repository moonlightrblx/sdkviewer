#pragma once
#include "../memory.h"
#include "../classes/WeaponPurchaseTracker_t.h"
class C_BasePlayerWeapon;

class CCSPlayer_ActionTrackingServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_ActionTrackingServices() { baseAddr = 0; }
    CCSPlayer_ActionTrackingServices(uintptr_t base) : baseAddr(base) {}

    C_BasePlayerWeapon* m_hLastWeaponBeforeC4AutoSwitch() { return read<C_BasePlayerWeapon*>(baseAddr + offsets_instance.get("CCSPlayer_ActionTrackingServices", "m_hLastWeaponBeforeC4AutoSwitch")); }
    bool m_bIsRescuing() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayer_ActionTrackingServices", "m_bIsRescuing")); }
    WeaponPurchaseTracker_t m_weaponPurchasesThisMatch() { return read<WeaponPurchaseTracker_t>(baseAddr + offsets_instance.get("CCSPlayer_ActionTrackingServices", "m_weaponPurchasesThisMatch")); }
    WeaponPurchaseTracker_t m_weaponPurchasesThisRound() { return read<WeaponPurchaseTracker_t>(baseAddr + offsets_instance.get("CCSPlayer_ActionTrackingServices", "m_weaponPurchasesThisRound")); }
};
