#pragma once
#include "../memory.h"

class C_SoundAreaEntitySphere  {
public:
    uintptr_t baseAddr;

    C_SoundAreaEntitySphere() { baseAddr = 0; }
    C_SoundAreaEntitySphere(uintptr_t base) : baseAddr(base) {}

    float m_flRadius() { return read<float>(baseAddr + offsets_instance.get("C_SoundAreaEntitySphere", "m_flRadius")); }
};
