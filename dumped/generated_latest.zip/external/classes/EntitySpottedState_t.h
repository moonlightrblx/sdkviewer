#pragma once
#include "../memory.h"

class EntitySpottedState_t  {
public:
    uintptr_t baseAddr;

    EntitySpottedState_t() { baseAddr = 0; }
    EntitySpottedState_t(uintptr_t base) : baseAddr(base) {}

    bool m_bSpotted() { return read<bool>(baseAddr + offsets_instance.get("EntitySpottedState_t", "m_bSpotted")); }
    int m_bSpottedByMask() { return read<int>(baseAddr + offsets_instance.get("EntitySpottedState_t", "m_bSpottedByMask")); }
};
