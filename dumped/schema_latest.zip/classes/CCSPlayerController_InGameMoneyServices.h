#pragma once
#include "../memory.h"

class CCSPlayerController_InGameMoneyServices {
public:
 uintptr_t baseAddr;
 CCSPlayerController_InGameMoneyServices() : baseAddr(0){}
 CCSPlayerController_InGameMoneyServices(uintptr_t b):baseAddr(b){}
 uintptr_t m_iAccount(){return SCHEMA_TYPE(uintptr_t,0x40);}
 uintptr_t m_iStartAccount(){return SCHEMA_TYPE(uintptr_t,0x44);}
 uintptr_t m_iTotalCashSpent(){return SCHEMA_TYPE(uintptr_t,0x48);}
 uintptr_t m_iCashSpentThisRound(){return SCHEMA_TYPE(uintptr_t,0x4C);}
};
