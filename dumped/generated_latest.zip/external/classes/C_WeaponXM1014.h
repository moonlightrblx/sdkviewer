#pragma once
#include "../memory.h"

class C_WeaponXM1014  {
public:
    uintptr_t baseAddr;

    C_WeaponXM1014() { baseAddr = client_base(); }
    C_WeaponXM1014(uintptr_t base) : baseAddr(base) {}

};
