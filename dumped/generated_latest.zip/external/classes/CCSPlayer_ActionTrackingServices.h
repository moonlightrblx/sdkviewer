#pragma once
#include "../memory.h"

class CCSPlayer_ActionTrackingServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_ActionTrackingServices() { baseAddr = client_base(); }
    CCSPlayer_ActionTrackingServices(uintptr_t base) : baseAddr(base) {}

    C_BasePlayerWeapon* m_hLastWeaponBeforeC4AutoSwitch() { return read<C_BasePlayerWeapon*>(baseAddr + offsets_instance.get("CCSPlayer_ActionTrackingServices", "m_hLastWeaponBeforeC4AutoSwitch")); }
    bool m_bIsRescuing() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayer_ActionTrackingServices", "m_bIsRescuing")); }
    uintptr_t m_weaponPurchasesThisMatch() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSPlayer_ActionTrackingServices", "m_weaponPurchasesThisMatch")); }
    uintptr_t m_weaponPurchasesThisRound() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSPlayer_ActionTrackingServices", "m_weaponPurchasesThisRound")); }
};
