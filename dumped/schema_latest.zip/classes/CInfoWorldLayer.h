#pragma once
#include "../memory.h"

class CInfoWorldLayer {
public:
 uintptr_t baseAddr;
 CInfoWorldLayer() : baseAddr(0){}
 CInfoWorldLayer(uintptr_t b):baseAddr(b){}
 uintptr_t m_pOutputOnEntitiesSpawned(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_worldName(){return SCHEMA_TYPE(uintptr_t,0x620);}
 uintptr_t m_layerName(){return SCHEMA_TYPE(uintptr_t,0x628);}
 uintptr_t m_bWorldLayerVisible(){return SCHEMA_TYPE(uintptr_t,0x630);}
 uintptr_t m_bEntitiesSpawned(){return SCHEMA_TYPE(uintptr_t,0x631);}
 uintptr_t m_bCreateAsChildSpawnGroup(){return SCHEMA_TYPE(uintptr_t,0x632);}
 uintptr_t m_hLayerSpawnGroup(){return SCHEMA_TYPE(uintptr_t,0x634);}
 uintptr_t m_bWorldLayerActuallyVisible(){return SCHEMA_TYPE(uintptr_t,0x638);}
};
