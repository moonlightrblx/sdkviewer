#pragma once
#include "../memory.h"

class CFilterLOS  {
public:
    uintptr_t baseAddr;

    CFilterLOS() { baseAddr = client_base(); }
    CFilterLOS(uintptr_t base) : baseAddr(base) {}

};
