#pragma once
#include "../memory.h"

class C_MolotovGrenade  {
public:
    uintptr_t baseAddr;

    C_MolotovGrenade() { baseAddr = client_base(); }
    C_MolotovGrenade(uintptr_t base) : baseAddr(base) {}

};
