#pragma once
#include "../memory.h"

class CLightComponent {
public:
 uintptr_t baseAddr;
 CLightComponent() : baseAddr(0){}
 CLightComponent(uintptr_t b):baseAddr(b){}
 uintptr_t __m_pChainEntity(){return SCHEMA_TYPE(uintptr_t,0x30);}
 uintptr_t m_Color(){return SCHEMA_TYPE(uintptr_t,0x6D);}
 uintptr_t m_SecondaryColor(){return SCHEMA_TYPE(uintptr_t,0x71);}
 uintptr_t m_flBrightness(){return SCHEMA_TYPE(uintptr_t,0x78);}
 uintptr_t m_flBrightnessScale(){return SCHEMA_TYPE(uintptr_t,0x7C);}
 uintptr_t m_flBrightnessMult(){return SCHEMA_TYPE(uintptr_t,0x80);}
 uintptr_t m_flRange(){return SCHEMA_TYPE(uintptr_t,0x84);}
 uintptr_t m_flFalloff(){return SCHEMA_TYPE(uintptr_t,0x88);}
 uintptr_t m_flAttenuation0(){return SCHEMA_TYPE(uintptr_t,0x8C);}
 uintptr_t m_flAttenuation1(){return SCHEMA_TYPE(uintptr_t,0x90);}
 uintptr_t m_flAttenuation2(){return SCHEMA_TYPE(uintptr_t,0x94);}
 uintptr_t m_flTheta(){return SCHEMA_TYPE(uintptr_t,0x98);}
 uintptr_t m_flPhi(){return SCHEMA_TYPE(uintptr_t,0x9C);}
 uintptr_t m_hLightCookie(){return SCHEMA_TYPE(uintptr_t,0xA0);}
 uintptr_t m_nCascades(){return SCHEMA_TYPE(uintptr_t,0xA8);}
 uintptr_t m_nCastShadows(){return SCHEMA_TYPE(uintptr_t,0xAC);}
 uintptr_t m_nShadowWidth(){return SCHEMA_TYPE(uintptr_t,0xB0);}
 uintptr_t m_nShadowHeight(){return SCHEMA_TYPE(uintptr_t,0xB4);}
 uintptr_t m_bRenderDiffuse(){return SCHEMA_TYPE(uintptr_t,0xB8);}
 uintptr_t m_nRenderSpecular(){return SCHEMA_TYPE(uintptr_t,0xBC);}
 uintptr_t m_bRenderTransmissive(){return SCHEMA_TYPE(uintptr_t,0xC0);}
 uintptr_t m_flOrthoLightWidth(){return SCHEMA_TYPE(uintptr_t,0xC4);}
 uintptr_t m_flOrthoLightHeight(){return SCHEMA_TYPE(uintptr_t,0xC8);}
 uintptr_t m_nStyle(){return SCHEMA_TYPE(uintptr_t,0xCC);}
 uintptr_t m_Pattern(){return SCHEMA_TYPE(uintptr_t,0xD0);}
 uintptr_t m_nCascadeRenderStaticObjects(){return SCHEMA_TYPE(uintptr_t,0xD8);}
 uintptr_t m_flShadowCascadeCrossFade(){return SCHEMA_TYPE(uintptr_t,0xDC);}
 uintptr_t m_flShadowCascadeDistanceFade(){return SCHEMA_TYPE(uintptr_t,0xE0);}
 uintptr_t m_flShadowCascadeDistance0(){return SCHEMA_TYPE(uintptr_t,0xE4);}
 uintptr_t m_flShadowCascadeDistance1(){return SCHEMA_TYPE(uintptr_t,0xE8);}
 uintptr_t m_flShadowCascadeDistance2(){return SCHEMA_TYPE(uintptr_t,0xEC);}
 uintptr_t m_flShadowCascadeDistance3(){return SCHEMA_TYPE(uintptr_t,0xF0);}
 uintptr_t m_nShadowCascadeResolution0(){return SCHEMA_TYPE(uintptr_t,0xF4);}
 uintptr_t m_nShadowCascadeResolution1(){return SCHEMA_TYPE(uintptr_t,0xF8);}
 uintptr_t m_nShadowCascadeResolution2(){return SCHEMA_TYPE(uintptr_t,0xFC);}
 uintptr_t m_nShadowCascadeResolution3(){return SCHEMA_TYPE(uintptr_t,0x100);}
 uintptr_t m_bUsesBakedShadowing(){return SCHEMA_TYPE(uintptr_t,0x104);}
 uintptr_t m_nShadowPriority(){return SCHEMA_TYPE(uintptr_t,0x108);}
 uintptr_t m_nBakedShadowIndex(){return SCHEMA_TYPE(uintptr_t,0x10C);}
 uintptr_t m_nLightPathUniqueId(){return SCHEMA_TYPE(uintptr_t,0x110);}
 uintptr_t m_nLightMapUniqueId(){return SCHEMA_TYPE(uintptr_t,0x114);}
 uintptr_t m_bRenderToCubemaps(){return SCHEMA_TYPE(uintptr_t,0x118);}
 uintptr_t m_bAllowSSTGeneration(){return SCHEMA_TYPE(uintptr_t,0x119);}
 uintptr_t m_nDirectLight(){return SCHEMA_TYPE(uintptr_t,0x11C);}
 uintptr_t m_nIndirectLight(){return SCHEMA_TYPE(uintptr_t,0x120);}
 uintptr_t m_flFadeMinDist(){return SCHEMA_TYPE(uintptr_t,0x124);}
 uintptr_t m_flFadeMaxDist(){return SCHEMA_TYPE(uintptr_t,0x128);}
 uintptr_t m_flShadowFadeMinDist(){return SCHEMA_TYPE(uintptr_t,0x12C);}
 uintptr_t m_flShadowFadeMaxDist(){return SCHEMA_TYPE(uintptr_t,0x130);}
 uintptr_t m_bEnabled(){return SCHEMA_TYPE(uintptr_t,0x134);}
 uintptr_t m_bFlicker(){return SCHEMA_TYPE(uintptr_t,0x135);}
 uintptr_t m_bPrecomputedFieldsValid(){return SCHEMA_TYPE(uintptr_t,0x136);}
 uintptr_t m_vPrecomputedBoundsMins(){return SCHEMA_TYPE(uintptr_t,0x138);}
 uintptr_t m_vPrecomputedBoundsMaxs(){return SCHEMA_TYPE(uintptr_t,0x144);}
 uintptr_t m_vPrecomputedOBBOrigin(){return SCHEMA_TYPE(uintptr_t,0x150);}
 uintptr_t m_vPrecomputedOBBAngles(){return SCHEMA_TYPE(uintptr_t,0x15C);}
 uintptr_t m_vPrecomputedOBBExtent(){return SCHEMA_TYPE(uintptr_t,0x168);}
 uintptr_t m_flPrecomputedMaxRange(){return SCHEMA_TYPE(uintptr_t,0x174);}
 uintptr_t m_nFogLightingMode(){return SCHEMA_TYPE(uintptr_t,0x178);}
 uintptr_t m_flFogContributionStength(){return SCHEMA_TYPE(uintptr_t,0x17C);}
 uintptr_t m_flNearClipPlane(){return SCHEMA_TYPE(uintptr_t,0x180);}
 uintptr_t m_SkyColor(){return SCHEMA_TYPE(uintptr_t,0x184);}
 uintptr_t m_flSkyIntensity(){return SCHEMA_TYPE(uintptr_t,0x188);}
 uintptr_t m_SkyAmbientBounce(){return SCHEMA_TYPE(uintptr_t,0x18C);}
 uintptr_t m_bUseSecondaryColor(){return SCHEMA_TYPE(uintptr_t,0x190);}
 uintptr_t m_bMixedShadows(){return SCHEMA_TYPE(uintptr_t,0x191);}
 uintptr_t m_flLightStyleStartTime(){return SCHEMA_TYPE(uintptr_t,0x194);}
 uintptr_t m_flCapsuleLength(){return SCHEMA_TYPE(uintptr_t,0x198);}
 uintptr_t m_flMinRoughness(){return SCHEMA_TYPE(uintptr_t,0x19C);}
};
