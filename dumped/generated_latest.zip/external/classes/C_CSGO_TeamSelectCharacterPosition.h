#pragma once
#include "../memory.h"

class C_CSGO_TeamSelectCharacterPosition  {
public:
    uintptr_t baseAddr;

    C_CSGO_TeamSelectCharacterPosition() { baseAddr = client_base(); }
    C_CSGO_TeamSelectCharacterPosition(uintptr_t base) : baseAddr(base) {}

};
