#pragma once
#include "../memory.h"

class CPulseArraylib  {
public:
    uintptr_t baseAddr;

    CPulseArraylib() { baseAddr = client_base(); }
    CPulseArraylib(uintptr_t base) : baseAddr(base) {}

};
