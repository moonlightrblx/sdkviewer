#pragma once
#include "../memory.h"

class CPathSimple  {
public:
    uintptr_t baseAddr;

    CPathSimple() { baseAddr = client_base(); }
    CPathSimple(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_CPathQueryComponent() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPathSimple", "m_CPathQueryComponent")); }
    uintptr_t m_pathString() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPathSimple", "m_pathString")); }
    bool m_bClosedLoop() { return read<bool>(baseAddr + offsets_instance.get("CPathSimple", "m_bClosedLoop")); }
};
