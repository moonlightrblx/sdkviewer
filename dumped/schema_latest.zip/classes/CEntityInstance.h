#pragma once
#include "../memory.h"

class CEntityInstance {
public:
 uintptr_t baseAddr;
 CEntityInstance() : baseAddr(0){}
 CEntityInstance(uintptr_t b):baseAddr(b){}
 uintptr_t m_iszPrivateVScripts(){return SCHEMA_TYPE(uintptr_t,0x8);}
 uintptr_t m_pEntity(){return SCHEMA_TYPE(uintptr_t,0x10);}
 uintptr_t m_CScriptComponent(){return SCHEMA_TYPE(uintptr_t,0x30);}
};
