#pragma once
#include "../memory.h"

class C_LightSpotEntity  {
public:
    uintptr_t baseAddr;

    C_LightSpotEntity() { baseAddr = client_base(); }
    C_LightSpotEntity(uintptr_t base) : baseAddr(base) {}

};
