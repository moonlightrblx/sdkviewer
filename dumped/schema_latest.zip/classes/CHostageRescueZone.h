#pragma once
#include "../memory.h"

class CHostageRescueZone {
public:
 uintptr_t baseAddr;
 CHostageRescueZone() : baseAddr(0){}
 CHostageRescueZone(uintptr_t b):baseAddr(b){}
};
