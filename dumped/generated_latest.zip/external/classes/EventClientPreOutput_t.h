#pragma once
#include "../memory.h"
#include "../classes/EngineLoopState_t.h"

class EventClientPreOutput_t  {
public:
    uintptr_t baseAddr;

    EventClientPreOutput_t() { baseAddr = 0; }
    EventClientPreOutput_t(uintptr_t base) : baseAddr(base) {}

    EngineLoopState_t m_LoopState() { return read<EngineLoopState_t>(baseAddr + offsets_instance.get("EventClientPreOutput_t", "m_LoopState")); }
    uintptr_t m_flRenderTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("EventClientPreOutput_t", "m_flRenderTime")); }
    uintptr_t m_flRenderFrameTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("EventClientPreOutput_t", "m_flRenderFrameTime")); }
    uintptr_t m_flRenderFrameTimeUnbounded() { return read<uintptr_t>(baseAddr + offsets_instance.get("EventClientPreOutput_t", "m_flRenderFrameTimeUnbounded")); }
    float m_flRealTime() { return read<float>(baseAddr + offsets_instance.get("EventClientPreOutput_t", "m_flRealTime")); }
    bool m_bRenderOnly() { return read<bool>(baseAddr + offsets_instance.get("EventClientPreOutput_t", "m_bRenderOnly")); }
};
