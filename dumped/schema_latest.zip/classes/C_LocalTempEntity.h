#pragma once
#include "../memory.h"

class C_LocalTempEntity {
public:
 uintptr_t baseAddr;
 C_LocalTempEntity() : baseAddr(0){}
 C_LocalTempEntity(uintptr_t b):baseAddr(b){}
 uintptr_t flags(){return SCHEMA_TYPE(uintptr_t,0x1158);}
 uintptr_t die(){return SCHEMA_TYPE(uintptr_t,0x115C);}
 uintptr_t m_flFrameMax(){return SCHEMA_TYPE(uintptr_t,0x1160);}
 uintptr_t x(){return SCHEMA_TYPE(uintptr_t,0x1164);}
 uintptr_t y(){return SCHEMA_TYPE(uintptr_t,0x1168);}
 uintptr_t fadeSpeed(){return SCHEMA_TYPE(uintptr_t,0x116C);}
 uintptr_t bounceFactor(){return SCHEMA_TYPE(uintptr_t,0x1170);}
 uintptr_t hitSound(){return SCHEMA_TYPE(uintptr_t,0x1174);}
 uintptr_t priority(){return SCHEMA_TYPE(uintptr_t,0x1178);}
 uintptr_t tentOffset(){return SCHEMA_TYPE(uintptr_t,0x117C);}
 uintptr_t m_vecTempEntAngVelocity(){return SCHEMA_TYPE(uintptr_t,0x1188);}
 uintptr_t tempent_renderamt(){return SCHEMA_TYPE(uintptr_t,0x1194);}
 uintptr_t m_vecNormal(){return SCHEMA_TYPE(uintptr_t,0x1198);}
 uintptr_t m_flSpriteScale(){return SCHEMA_TYPE(uintptr_t,0x11A4);}
 uintptr_t m_nFlickerFrame(){return SCHEMA_TYPE(uintptr_t,0x11A8);}
 uintptr_t m_flFrameRate(){return SCHEMA_TYPE(uintptr_t,0x11AC);}
 uintptr_t m_flFrame(){return SCHEMA_TYPE(uintptr_t,0x11B0);}
 uintptr_t m_pszImpactEffect(){return SCHEMA_TYPE(uintptr_t,0x11B8);}
 uintptr_t m_pszParticleEffect(){return SCHEMA_TYPE(uintptr_t,0x11C0);}
 uintptr_t m_bParticleCollision(){return SCHEMA_TYPE(uintptr_t,0x11C8);}
 uintptr_t m_iLastCollisionFrame(){return SCHEMA_TYPE(uintptr_t,0x11CC);}
 uintptr_t m_vLastCollisionOrigin(){return SCHEMA_TYPE(uintptr_t,0x11D0);}
 uintptr_t m_vecTempEntVelocity(){return SCHEMA_TYPE(uintptr_t,0x11DC);}
 uintptr_t m_vecPrevAbsOrigin(){return SCHEMA_TYPE(uintptr_t,0x11E8);}
 uintptr_t m_vecTempEntAcceleration(){return SCHEMA_TYPE(uintptr_t,0x11F4);}
};
