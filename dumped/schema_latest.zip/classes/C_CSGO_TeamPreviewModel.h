#pragma once
#include "../memory.h"

class C_CSGO_TeamPreviewModel {
public:
 uintptr_t baseAddr;
 C_CSGO_TeamPreviewModel() : baseAddr(0){}
 C_CSGO_TeamPreviewModel(uintptr_t b):baseAddr(b){}
};
