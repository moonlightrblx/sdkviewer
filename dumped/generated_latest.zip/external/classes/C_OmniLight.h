#pragma once
#include "../memory.h"

class C_OmniLight  {
public:
    uintptr_t baseAddr;

    C_OmniLight() { baseAddr = client_base(); }
    C_OmniLight(uintptr_t base) : baseAddr(base) {}

    float m_flInnerAngle() { return read<float>(baseAddr + offsets_instance.get("C_OmniLight", "m_flInnerAngle")); }
    float m_flOuterAngle() { return read<float>(baseAddr + offsets_instance.get("C_OmniLight", "m_flOuterAngle")); }
    bool m_bShowLight() { return read<bool>(baseAddr + offsets_instance.get("C_OmniLight", "m_bShowLight")); }
};
