#pragma once
#include "../memory.h"

class EventModInitialized_t {
public:
 uintptr_t baseAddr;
 EventModInitialized_t() : baseAddr(0){}
 EventModInitialized_t(uintptr_t b):baseAddr(b){}
};
