#pragma once
#include "../memory.h"

class C_Breakable  {
public:
    uintptr_t baseAddr;

    C_Breakable() { baseAddr = client_base(); }
    C_Breakable(uintptr_t base) : baseAddr(base) {}

};
