#pragma once
#include "../memory.h"

class CCSPlayerController_ActionTrackingServices {
public:
 uintptr_t baseAddr;
 CCSPlayerController_ActionTrackingServices() : baseAddr(0){}
 CCSPlayerController_ActionTrackingServices(uintptr_t b):baseAddr(b){}
 uintptr_t m_perRoundStats(){return SCHEMA_TYPE(uintptr_t,0x40);}
 uintptr_t m_matchStats(){return SCHEMA_TYPE(uintptr_t,0xA8);}
 uintptr_t m_iNumRoundKills(){return SCHEMA_TYPE(uintptr_t,0x128);}
 uintptr_t m_iNumRoundKillsHeadshots(){return SCHEMA_TYPE(uintptr_t,0x12C);}
 uintptr_t m_flTotalRoundDamageDealt(){return SCHEMA_TYPE(uintptr_t,0x130);}
};
