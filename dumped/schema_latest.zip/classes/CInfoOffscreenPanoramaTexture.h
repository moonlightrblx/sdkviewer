#pragma once
#include "../memory.h"

class CInfoOffscreenPanoramaTexture {
public:
 uintptr_t baseAddr;
 CInfoOffscreenPanoramaTexture() : baseAddr(0){}
 CInfoOffscreenPanoramaTexture(uintptr_t b):baseAddr(b){}
 uintptr_t m_bDisabled(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_nResolutionX(){return SCHEMA_TYPE(uintptr_t,0x5FC);}
 uintptr_t m_nResolutionY(){return SCHEMA_TYPE(uintptr_t,0x600);}
 uintptr_t m_szLayoutFileName(){return SCHEMA_TYPE(uintptr_t,0x608);}
 uintptr_t m_RenderAttrName(){return SCHEMA_TYPE(uintptr_t,0x610);}
 uintptr_t m_TargetEntities(){return SCHEMA_TYPE(uintptr_t,0x618);}
 uintptr_t m_nTargetChangeCount(){return SCHEMA_TYPE(uintptr_t,0x630);}
 uintptr_t m_vecCSSClasses(){return SCHEMA_TYPE(uintptr_t,0x638);}
 uintptr_t m_bCheckCSSClasses(){return SCHEMA_TYPE(uintptr_t,0x7B0);}
};
