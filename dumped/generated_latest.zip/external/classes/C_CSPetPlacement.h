#pragma once
#include "../memory.h"

class C_CSPetPlacement  {
public:
    uintptr_t baseAddr;

    C_CSPetPlacement() { baseAddr = 0; }
    C_CSPetPlacement(uintptr_t base) : baseAddr(base) {}

};
