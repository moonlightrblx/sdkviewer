#pragma once
#include "../memory.h"

class C_Team {
public:
 uintptr_t baseAddr;
 C_Team() : baseAddr(0){}
 C_Team(uintptr_t b):baseAddr(b){}
 uintptr_t m_aPlayerControllers(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_aPlayers(){return SCHEMA_TYPE(uintptr_t,0x610);}
 uintptr_t m_iScore(){return SCHEMA_TYPE(uintptr_t,0x628);}
 uintptr_t m_szTeamname(){return SCHEMA_TYPE(uintptr_t,0x62C);}
};
