#pragma once
#include "../memory.h"

class C_LateUpdatedAnimating  {
public:
    uintptr_t baseAddr;

    C_LateUpdatedAnimating() { baseAddr = 0; }
    C_LateUpdatedAnimating(uintptr_t base) : baseAddr(base) {}

};
