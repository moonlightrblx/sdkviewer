#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_SmokeGrenadeProjectile  {
public:
    uintptr_t baseAddr;

    C_SmokeGrenadeProjectile() { baseAddr = client_base(); }
    C_SmokeGrenadeProjectile(uintptr_t base) : baseAddr(base) {}

    int m_nSmokeEffectTickBegin() { return read<int>(baseAddr + offsets_instance.get("C_SmokeGrenadeProjectile", "m_nSmokeEffectTickBegin")); }
    bool m_bDidSmokeEffect() { return read<bool>(baseAddr + offsets_instance.get("C_SmokeGrenadeProjectile", "m_bDidSmokeEffect")); }
    int m_nRandomSeed() { return read<int>(baseAddr + offsets_instance.get("C_SmokeGrenadeProjectile", "m_nRandomSeed")); }
    Vector3 m_vSmokeColor() { return read<Vector3>(baseAddr + offsets_instance.get("C_SmokeGrenadeProjectile", "m_vSmokeColor")); }
    Vector3 m_vSmokeDetonationPos() { return read<Vector3>(baseAddr + offsets_instance.get("C_SmokeGrenadeProjectile", "m_vSmokeDetonationPos")); }
    uint8_t m_VoxelFrameData() { return read<uint8_t>(baseAddr + offsets_instance.get("C_SmokeGrenadeProjectile", "m_VoxelFrameData")); }
    int m_nVoxelFrameDataSize() { return read<int>(baseAddr + offsets_instance.get("C_SmokeGrenadeProjectile", "m_nVoxelFrameDataSize")); }
    int m_nVoxelUpdate() { return read<int>(baseAddr + offsets_instance.get("C_SmokeGrenadeProjectile", "m_nVoxelUpdate")); }
    bool m_bSmokeVolumeDataReceived() { return read<bool>(baseAddr + offsets_instance.get("C_SmokeGrenadeProjectile", "m_bSmokeVolumeDataReceived")); }
    bool m_bSmokeEffectSpawned() { return read<bool>(baseAddr + offsets_instance.get("C_SmokeGrenadeProjectile", "m_bSmokeEffectSpawned")); }
};
