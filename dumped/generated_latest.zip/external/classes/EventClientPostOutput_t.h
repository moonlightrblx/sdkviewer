#pragma once
#include "../memory.h"
#include "../classes/EngineLoopState_t.h"

class EventClientPostOutput_t  {
public:
    uintptr_t baseAddr;

    EventClientPostOutput_t() { baseAddr = 0; }
    EventClientPostOutput_t(uintptr_t base) : baseAddr(base) {}

    EngineLoopState_t m_LoopState() { return read<EngineLoopState_t>(baseAddr + offsets_instance.get("EventClientPostOutput_t", "m_LoopState")); }
    uintptr_t m_flRenderTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("EventClientPostOutput_t", "m_flRenderTime")); }
    float m_flRenderFrameTime() { return read<float>(baseAddr + offsets_instance.get("EventClientPostOutput_t", "m_flRenderFrameTime")); }
    float m_flRenderFrameTimeUnbounded() { return read<float>(baseAddr + offsets_instance.get("EventClientPostOutput_t", "m_flRenderFrameTimeUnbounded")); }
    bool m_bRenderOnly() { return read<bool>(baseAddr + offsets_instance.get("EventClientPostOutput_t", "m_bRenderOnly")); }
};
