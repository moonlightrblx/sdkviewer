#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class fogparams_t  {
public:
    uintptr_t baseAddr;

    fogparams_t() { baseAddr = client_base(); }
    fogparams_t(uintptr_t base) : baseAddr(base) {}

    Vector3 dirPrimary() { return read<Vector3>(baseAddr + offsets_instance.get("fogparams_t", "dirPrimary")); }
    uintptr_t colorPrimary() { return read<uintptr_t>(baseAddr + offsets_instance.get("fogparams_t", "colorPrimary")); }
    uintptr_t colorSecondary() { return read<uintptr_t>(baseAddr + offsets_instance.get("fogparams_t", "colorSecondary")); }
    uintptr_t colorPrimaryLerpTo() { return read<uintptr_t>(baseAddr + offsets_instance.get("fogparams_t", "colorPrimaryLerpTo")); }
    uintptr_t colorSecondaryLerpTo() { return read<uintptr_t>(baseAddr + offsets_instance.get("fogparams_t", "colorSecondaryLerpTo")); }
    float start() { return read<float>(baseAddr + offsets_instance.get("fogparams_t", "start")); }
    float end() { return read<float>(baseAddr + offsets_instance.get("fogparams_t", "end")); }
    float farz() { return read<float>(baseAddr + offsets_instance.get("fogparams_t", "farz")); }
    float maxdensity() { return read<float>(baseAddr + offsets_instance.get("fogparams_t", "maxdensity")); }
    float exponent() { return read<float>(baseAddr + offsets_instance.get("fogparams_t", "exponent")); }
    float HDRColorScale() { return read<float>(baseAddr + offsets_instance.get("fogparams_t", "HDRColorScale")); }
    float skyboxFogFactor() { return read<float>(baseAddr + offsets_instance.get("fogparams_t", "skyboxFogFactor")); }
    float skyboxFogFactorLerpTo() { return read<float>(baseAddr + offsets_instance.get("fogparams_t", "skyboxFogFactorLerpTo")); }
    float startLerpTo() { return read<float>(baseAddr + offsets_instance.get("fogparams_t", "startLerpTo")); }
    float endLerpTo() { return read<float>(baseAddr + offsets_instance.get("fogparams_t", "endLerpTo")); }
    float maxdensityLerpTo() { return read<float>(baseAddr + offsets_instance.get("fogparams_t", "maxdensityLerpTo")); }
    uintptr_t lerptime() { return read<uintptr_t>(baseAddr + offsets_instance.get("fogparams_t", "lerptime")); }
    float duration() { return read<float>(baseAddr + offsets_instance.get("fogparams_t", "duration")); }
    float blendtobackground() { return read<float>(baseAddr + offsets_instance.get("fogparams_t", "blendtobackground")); }
    float scattering() { return read<float>(baseAddr + offsets_instance.get("fogparams_t", "scattering")); }
    float locallightscale() { return read<float>(baseAddr + offsets_instance.get("fogparams_t", "locallightscale")); }
    bool enable() { return read<bool>(baseAddr + offsets_instance.get("fogparams_t", "enable")); }
    bool blend() { return read<bool>(baseAddr + offsets_instance.get("fogparams_t", "blend")); }
    bool m_bPadding2() { return read<bool>(baseAddr + offsets_instance.get("fogparams_t", "m_bPadding2")); }
    bool m_bPadding() { return read<bool>(baseAddr + offsets_instance.get("fogparams_t", "m_bPadding")); }
};
