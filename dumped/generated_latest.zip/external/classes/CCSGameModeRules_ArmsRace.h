#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class CCSGameModeRules_ArmsRace  {
public:
    uintptr_t baseAddr;

    CCSGameModeRules_ArmsRace() { baseAddr = client_base(); }
    CCSGameModeRules_ArmsRace(uintptr_t base) : baseAddr(base) {}

    Vector3 m_WeaponSequence() { return read<Vector3>(baseAddr + offsets_instance.get("CCSGameModeRules_ArmsRace", "m_WeaponSequence")); }
};
