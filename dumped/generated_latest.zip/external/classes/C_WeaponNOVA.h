#pragma once
#include "../memory.h"

class C_WeaponNOVA  {
public:
    uintptr_t baseAddr;

    C_WeaponNOVA() { baseAddr = 0; }
    C_WeaponNOVA(uintptr_t base) : baseAddr(base) {}

};
