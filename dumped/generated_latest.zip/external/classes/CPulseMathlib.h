#pragma once
#include "../memory.h"

class CPulseMathlib  {
public:
    uintptr_t baseAddr;

    CPulseMathlib() { baseAddr = 0; }
    CPulseMathlib(uintptr_t base) : baseAddr(base) {}

};
