#pragma once
#include "../memory.h"

class C_C4 {
public:
 uintptr_t baseAddr;
 C_C4() : baseAddr(0){}
 C_C4(uintptr_t b):baseAddr(b){}
 uintptr_t m_activeLightParticleIndex(){return SCHEMA_TYPE(uintptr_t,0x1F80);}
 uintptr_t m_eActiveLightEffect(){return SCHEMA_TYPE(uintptr_t,0x1F84);}
 uintptr_t m_bStartedArming(){return SCHEMA_TYPE(uintptr_t,0x1F88);}
 uintptr_t m_fArmedTime(){return SCHEMA_TYPE(uintptr_t,0x1F8C);}
 uintptr_t m_bBombPlacedAnimation(){return SCHEMA_TYPE(uintptr_t,0x1F90);}
 uintptr_t m_bIsPlantingViaUse(){return SCHEMA_TYPE(uintptr_t,0x1F91);}
 uintptr_t m_entitySpottedState(){return SCHEMA_TYPE(uintptr_t,0x1F98);}
 uintptr_t m_nSpotRules(){return SCHEMA_TYPE(uintptr_t,0x1FB0);}
 uintptr_t m_bPlayedArmingBeeps(){return SCHEMA_TYPE(uintptr_t,0x1FB4);}
 uintptr_t m_bBombPlanted(){return SCHEMA_TYPE(uintptr_t,0x1FBB);}
};
