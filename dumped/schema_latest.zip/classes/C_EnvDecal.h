#pragma once
#include "../memory.h"

class C_EnvDecal {
public:
 uintptr_t baseAddr;
 C_EnvDecal() : baseAddr(0){}
 C_EnvDecal(uintptr_t b):baseAddr(b){}
 uintptr_t m_hDecalMaterial(){return SCHEMA_TYPE(uintptr_t,0xEB0);}
 uintptr_t m_flWidth(){return SCHEMA_TYPE(uintptr_t,0xEB8);}
 uintptr_t m_flHeight(){return SCHEMA_TYPE(uintptr_t,0xEBC);}
 uintptr_t m_flDepth(){return SCHEMA_TYPE(uintptr_t,0xEC0);}
 uintptr_t m_nRenderOrder(){return SCHEMA_TYPE(uintptr_t,0xEC4);}
 uintptr_t m_bProjectOnWorld(){return SCHEMA_TYPE(uintptr_t,0xEC8);}
 uintptr_t m_bProjectOnCharacters(){return SCHEMA_TYPE(uintptr_t,0xEC9);}
 uintptr_t m_bProjectOnWater(){return SCHEMA_TYPE(uintptr_t,0xECA);}
 uintptr_t m_flDepthSortBias(){return SCHEMA_TYPE(uintptr_t,0xECC);}
};
