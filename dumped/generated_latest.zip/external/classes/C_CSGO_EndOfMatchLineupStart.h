#pragma once
#include "../memory.h"

class C_CSGO_EndOfMatchLineupStart  {
public:
    uintptr_t baseAddr;

    C_CSGO_EndOfMatchLineupStart() { baseAddr = client_base(); }
    C_CSGO_EndOfMatchLineupStart(uintptr_t base) : baseAddr(base) {}

};
