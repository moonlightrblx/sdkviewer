#pragma once
#include "../memory.h"

class CBaseAnimGraph {
public:
 uintptr_t baseAddr;
 CBaseAnimGraph() : baseAddr(0){}
 CBaseAnimGraph(uintptr_t b):baseAddr(b){}
 uintptr_t m_bInitiallyPopulateInterpHistory(){return SCHEMA_TYPE(uintptr_t,0xF30);}
 uintptr_t m_bSuppressAnimEventSounds(){return SCHEMA_TYPE(uintptr_t,0xF32);}
 uintptr_t m_bAnimGraphUpdateEnabled(){return SCHEMA_TYPE(uintptr_t,0xF40);}
 uintptr_t m_flMaxSlopeDistance(){return SCHEMA_TYPE(uintptr_t,0xF44);}
 uintptr_t m_vLastSlopeCheckPos(){return SCHEMA_TYPE(uintptr_t,0xF48);}
 uintptr_t m_bAnimationUpdateScheduled(){return SCHEMA_TYPE(uintptr_t,0xF54);}
 uintptr_t m_vecForce(){return SCHEMA_TYPE(uintptr_t,0xF58);}
 uintptr_t m_nForceBone(){return SCHEMA_TYPE(uintptr_t,0xF64);}
 uintptr_t m_pClientsideRagdoll(){return SCHEMA_TYPE(uintptr_t,0xF68);}
 uintptr_t m_bBuiltRagdoll(){return SCHEMA_TYPE(uintptr_t,0xF70);}
 uintptr_t m_RagdollPose(){return SCHEMA_TYPE(uintptr_t,0xF88);}
 uintptr_t m_bRagdollEnabled(){return SCHEMA_TYPE(uintptr_t,0xFD0);}
 uintptr_t m_bRagdollClientSide(){return SCHEMA_TYPE(uintptr_t,0xFD1);}
 uintptr_t m_bHasAnimatedMaterialAttributes(){return SCHEMA_TYPE(uintptr_t,0xFE0);}
};
