#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_ColorCorrection  {
public:
    uintptr_t baseAddr;

    C_ColorCorrection() { baseAddr = 0; }
    C_ColorCorrection(uintptr_t base) : baseAddr(base) {}

    Vector3 m_vecOrigin() { return read<Vector3>(baseAddr + offsets_instance.get("C_ColorCorrection", "m_vecOrigin")); }
    float m_MinFalloff() { return read<float>(baseAddr + offsets_instance.get("C_ColorCorrection", "m_MinFalloff")); }
    float m_MaxFalloff() { return read<float>(baseAddr + offsets_instance.get("C_ColorCorrection", "m_MaxFalloff")); }
    float m_flFadeInDuration() { return read<float>(baseAddr + offsets_instance.get("C_ColorCorrection", "m_flFadeInDuration")); }
    float m_flFadeOutDuration() { return read<float>(baseAddr + offsets_instance.get("C_ColorCorrection", "m_flFadeOutDuration")); }
    float m_flMaxWeight() { return read<float>(baseAddr + offsets_instance.get("C_ColorCorrection", "m_flMaxWeight")); }
    float m_flCurWeight() { return read<float>(baseAddr + offsets_instance.get("C_ColorCorrection", "m_flCurWeight")); }
    char* m_netlookupFilename() { return read<char*>(baseAddr + offsets_instance.get("C_ColorCorrection", "m_netlookupFilename")); }
    bool m_bEnabled() { return read<bool>(baseAddr + offsets_instance.get("C_ColorCorrection", "m_bEnabled")); }
    bool m_bMaster() { return read<bool>(baseAddr + offsets_instance.get("C_ColorCorrection", "m_bMaster")); }
    bool m_bClientSide() { return read<bool>(baseAddr + offsets_instance.get("C_ColorCorrection", "m_bClientSide")); }
    bool m_bExclusive() { return read<bool>(baseAddr + offsets_instance.get("C_ColorCorrection", "m_bExclusive")); }
    bool m_bEnabledOnClient() { return read<bool>(baseAddr + offsets_instance.get("C_ColorCorrection", "m_bEnabledOnClient")); }
    float m_flCurWeightOnClient() { return read<float>(baseAddr + offsets_instance.get("C_ColorCorrection", "m_flCurWeightOnClient")); }
    bool m_bFadingIn() { return read<bool>(baseAddr + offsets_instance.get("C_ColorCorrection", "m_bFadingIn")); }
    float m_flFadeStartWeight() { return read<float>(baseAddr + offsets_instance.get("C_ColorCorrection", "m_flFadeStartWeight")); }
    float m_flFadeStartTime() { return read<float>(baseAddr + offsets_instance.get("C_ColorCorrection", "m_flFadeStartTime")); }
    float m_flFadeDuration() { return read<float>(baseAddr + offsets_instance.get("C_ColorCorrection", "m_flFadeDuration")); }
};
