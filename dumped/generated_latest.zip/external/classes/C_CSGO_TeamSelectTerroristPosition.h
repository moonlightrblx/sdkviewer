#pragma once
#include "../memory.h"

class C_CSGO_TeamSelectTerroristPosition  {
public:
    uintptr_t baseAddr;

    C_CSGO_TeamSelectTerroristPosition() { baseAddr = 0; }
    C_CSGO_TeamSelectTerroristPosition(uintptr_t base) : baseAddr(base) {}

};
