#pragma once
#include "../memory.h"

class C_TriggerBuoyancy {
public:
 uintptr_t baseAddr;
 C_TriggerBuoyancy() : baseAddr(0){}
 C_TriggerBuoyancy(uintptr_t b):baseAddr(b){}
 uintptr_t m_BuoyancyHelper(){return SCHEMA_TYPE(uintptr_t,0xFF0);}
 uintptr_t m_flFluidDensity(){return SCHEMA_TYPE(uintptr_t,0x1108);}
};
