#pragma once
#include "../memory.h"

class C_WeaponM249  {
public:
    uintptr_t baseAddr;

    C_WeaponM249() { baseAddr = 0; }
    C_WeaponM249(uintptr_t base) : baseAddr(base) {}

};
