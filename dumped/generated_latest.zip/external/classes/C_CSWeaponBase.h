#pragma once
#include "../memory.h"
#include "../classes/CEntityIOOutput.h"
#include "../classes/GameTick_t.h"
#include "../classes/GameTime_t.h"
#include "../types/Vector3.h"
class C_CSPlayerPawn;

class C_CSWeaponBase  {
public:
    uintptr_t baseAddr;

    C_CSWeaponBase() { baseAddr = 0; }
    C_CSWeaponBase(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_iWeaponGameplayAnimState() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_iWeaponGameplayAnimState")); }
    GameTime_t m_flWeaponGameplayAnimStateTimestamp() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_flWeaponGameplayAnimStateTimestamp")); }
    GameTime_t m_flInspectCancelCompleteTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_flInspectCancelCompleteTime")); }
    bool m_bInspectPending() { return read<bool>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_bInspectPending")); }
    bool m_bInspectShouldLoop() { return read<bool>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_bInspectShouldLoop")); }
    float m_flCrosshairDistance() { return read<float>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_flCrosshairDistance")); }
    int m_iAmmoLastCheck() { return read<int>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_iAmmoLastCheck")); }
    int m_nLastEmptySoundCmdNum() { return read<int>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_nLastEmptySoundCmdNum")); }
    bool m_bFireOnEmpty() { return read<bool>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_bFireOnEmpty")); }
    CEntityIOOutput m_OnPlayerPickup() { return read<CEntityIOOutput>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_OnPlayerPickup")); }
    uintptr_t m_weaponMode() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_weaponMode")); }
    float m_flTurningInaccuracyDelta() { return read<float>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_flTurningInaccuracyDelta")); }
    Vector3 m_vecTurningInaccuracyEyeDirLast() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_vecTurningInaccuracyEyeDirLast")); }
    float m_flTurningInaccuracy() { return read<float>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_flTurningInaccuracy")); }
    float m_fAccuracyPenalty() { return read<float>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_fAccuracyPenalty")); }
    GameTime_t m_flLastAccuracyUpdateTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_flLastAccuracyUpdateTime")); }
    float m_fAccuracySmoothedForZoom() { return read<float>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_fAccuracySmoothedForZoom")); }
    int m_iRecoilIndex() { return read<int>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_iRecoilIndex")); }
    float m_flRecoilIndex() { return read<float>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_flRecoilIndex")); }
    bool m_bBurstMode() { return read<bool>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_bBurstMode")); }
    GameTime_t m_flLastBurstModeChangeTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_flLastBurstModeChangeTime")); }
    GameTick_t m_nPostponeFireReadyTicks() { return read<GameTick_t>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_nPostponeFireReadyTicks")); }
    float m_flPostponeFireReadyFrac() { return read<float>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_flPostponeFireReadyFrac")); }
    bool m_bInReload() { return read<bool>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_bInReload")); }
    GameTime_t m_flDroppedAtTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_flDroppedAtTime")); }
    bool m_bIsHauledBack() { return read<bool>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_bIsHauledBack")); }
    bool m_bSilencerOn() { return read<bool>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_bSilencerOn")); }
    GameTime_t m_flTimeSilencerSwitchComplete() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_flTimeSilencerSwitchComplete")); }
    int m_iOriginalTeamNumber() { return read<int>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_iOriginalTeamNumber")); }
    int m_iMostRecentTeamNumber() { return read<int>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_iMostRecentTeamNumber")); }
    bool m_bDroppedNearBuyZone() { return read<bool>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_bDroppedNearBuyZone")); }
    float m_flNextAttackRenderTimeOffset() { return read<float>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_flNextAttackRenderTimeOffset")); }
    bool m_bClearWeaponIdentifyingUGC() { return read<bool>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_bClearWeaponIdentifyingUGC")); }
    bool m_bVisualsDataSet() { return read<bool>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_bVisualsDataSet")); }
    bool m_bUIWeapon() { return read<bool>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_bUIWeapon")); }
    int m_nCustomEconReloadEventId() { return read<int>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_nCustomEconReloadEventId")); }
    GameTime_t m_nextPrevOwnerUseTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_nextPrevOwnerUseTime")); }
    C_CSPlayerPawn* m_hPrevOwner() { return read<C_CSPlayerPawn*>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_hPrevOwner")); }
    GameTick_t m_nDropTick() { return read<GameTick_t>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_nDropTick")); }
    bool m_bWasActiveWeaponWhenDropped() { return read<bool>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_bWasActiveWeaponWhenDropped")); }
    bool m_donated() { return read<bool>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_donated")); }
    GameTime_t m_fLastShotTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_fLastShotTime")); }
    bool m_bWasOwnedByCT() { return read<bool>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_bWasOwnedByCT")); }
    bool m_bWasOwnedByTerrorist() { return read<bool>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_bWasOwnedByTerrorist")); }
    float m_flNextClientFireBulletTime() { return read<float>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_flNextClientFireBulletTime")); }
    float m_flNextClientFireBulletTime_Repredict() { return read<float>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_flNextClientFireBulletTime_Repredict")); }
    uintptr_t m_IronSightController() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_IronSightController")); }
    int m_iIronSightMode() { return read<int>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_iIronSightMode")); }
    GameTime_t m_flLastLOSTraceFailureTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_flLastLOSTraceFailureTime")); }
    float m_flWatTickOffset() { return read<float>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_flWatTickOffset")); }
    GameTime_t m_flLastShakeTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_CSWeaponBase", "m_flLastShakeTime")); }
};
