#pragma once
#include "../memory.h"

class CHostageRescueZoneShim  {
public:
    uintptr_t baseAddr;

    CHostageRescueZoneShim() { baseAddr = client_base(); }
    CHostageRescueZoneShim(uintptr_t base) : baseAddr(base) {}

};
