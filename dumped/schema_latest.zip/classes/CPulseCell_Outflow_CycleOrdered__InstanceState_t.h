#pragma once
#include "../memory.h"

class CPulseCell_Outflow_CycleOrdered__InstanceState_t {
public:
 uintptr_t baseAddr;
 CPulseCell_Outflow_CycleOrdered__InstanceState_t() : baseAddr(0){}
 CPulseCell_Outflow_CycleOrdered__InstanceState_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_nNextIndex(){return SCHEMA_TYPE(uintptr_t,0x0);}
};
