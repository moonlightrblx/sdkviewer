#pragma once
#include "../memory.h"

class CCSPlayerController_InventoryServices__NetworkedLoadoutSlot_t  {
public:
    uintptr_t baseAddr;

    CCSPlayerController_InventoryServices__NetworkedLoadoutSlot_t() { baseAddr = client_base(); }
    CCSPlayerController_InventoryServices__NetworkedLoadoutSlot_t(uintptr_t base) : baseAddr(base) {}

    C_EconItemView* pItem() { return read<C_EconItemView*>(baseAddr + offsets_instance.get("CCSPlayerController_InventoryServices__NetworkedLoadoutSlot_t", "pItem")); }
    uint16_t team() { return read<uint16_t>(baseAddr + offsets_instance.get("CCSPlayerController_InventoryServices__NetworkedLoadoutSlot_t", "team")); }
    uint16_t slot() { return read<uint16_t>(baseAddr + offsets_instance.get("CCSPlayerController_InventoryServices__NetworkedLoadoutSlot_t", "slot")); }
};
