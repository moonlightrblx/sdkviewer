#pragma once
#include "../memory.h"
#include "../classes/CEntityIOOutput.h"

class CBaseFilter  {
public:
    uintptr_t baseAddr;

    CBaseFilter() { baseAddr = 0; }
    CBaseFilter(uintptr_t base) : baseAddr(base) {}

    bool m_bNegated() { return read<bool>(baseAddr + offsets_instance.get("CBaseFilter", "m_bNegated")); }
    CEntityIOOutput m_OnPass() { return read<CEntityIOOutput>(baseAddr + offsets_instance.get("CBaseFilter", "m_OnPass")); }
    CEntityIOOutput m_OnFail() { return read<CEntityIOOutput>(baseAddr + offsets_instance.get("CBaseFilter", "m_OnFail")); }
};
