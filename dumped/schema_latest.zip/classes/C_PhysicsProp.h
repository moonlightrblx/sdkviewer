#pragma once
#include "../memory.h"

class C_PhysicsProp {
public:
 uintptr_t baseAddr;
 C_PhysicsProp() : baseAddr(0){}
 C_PhysicsProp(uintptr_t b):baseAddr(b){}
 uintptr_t m_bAwake(){return SCHEMA_TYPE(uintptr_t,0x1300);}
};
