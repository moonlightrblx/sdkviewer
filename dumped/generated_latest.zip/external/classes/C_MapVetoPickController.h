#pragma once
#include "../memory.h"

class C_MapVetoPickController  {
public:
    uintptr_t baseAddr;

    C_MapVetoPickController() { baseAddr = 0; }
    C_MapVetoPickController(uintptr_t base) : baseAddr(base) {}

    int m_nDraftType() { return read<int>(baseAddr + offsets_instance.get("C_MapVetoPickController", "m_nDraftType")); }
    int m_nTeamWinningCoinToss() { return read<int>(baseAddr + offsets_instance.get("C_MapVetoPickController", "m_nTeamWinningCoinToss")); }
    int m_nTeamWithFirstChoice() { return read<int>(baseAddr + offsets_instance.get("C_MapVetoPickController", "m_nTeamWithFirstChoice")); }
    int m_nVoteMapIdsList() { return read<int>(baseAddr + offsets_instance.get("C_MapVetoPickController", "m_nVoteMapIdsList")); }
    int m_nAccountIDs() { return read<int>(baseAddr + offsets_instance.get("C_MapVetoPickController", "m_nAccountIDs")); }
    int m_nMapId0() { return read<int>(baseAddr + offsets_instance.get("C_MapVetoPickController", "m_nMapId0")); }
    int m_nMapId1() { return read<int>(baseAddr + offsets_instance.get("C_MapVetoPickController", "m_nMapId1")); }
    int m_nMapId2() { return read<int>(baseAddr + offsets_instance.get("C_MapVetoPickController", "m_nMapId2")); }
    int m_nMapId3() { return read<int>(baseAddr + offsets_instance.get("C_MapVetoPickController", "m_nMapId3")); }
    int m_nMapId4() { return read<int>(baseAddr + offsets_instance.get("C_MapVetoPickController", "m_nMapId4")); }
    int m_nMapId5() { return read<int>(baseAddr + offsets_instance.get("C_MapVetoPickController", "m_nMapId5")); }
    int m_nStartingSide0() { return read<int>(baseAddr + offsets_instance.get("C_MapVetoPickController", "m_nStartingSide0")); }
    int m_nCurrentPhase() { return read<int>(baseAddr + offsets_instance.get("C_MapVetoPickController", "m_nCurrentPhase")); }
    int m_nPhaseStartTick() { return read<int>(baseAddr + offsets_instance.get("C_MapVetoPickController", "m_nPhaseStartTick")); }
    int m_nPhaseDurationTicks() { return read<int>(baseAddr + offsets_instance.get("C_MapVetoPickController", "m_nPhaseDurationTicks")); }
    int m_nPostDataUpdateTick() { return read<int>(baseAddr + offsets_instance.get("C_MapVetoPickController", "m_nPostDataUpdateTick")); }
    bool m_bDisabledHud() { return read<bool>(baseAddr + offsets_instance.get("C_MapVetoPickController", "m_bDisabledHud")); }
};
