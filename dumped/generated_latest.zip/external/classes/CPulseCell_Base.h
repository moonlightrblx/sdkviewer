#pragma once
#include "../memory.h"

class CPulseCell_Base  {
public:
    uintptr_t baseAddr;

    CPulseCell_Base() { baseAddr = 0; }
    CPulseCell_Base(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_nEditorNodeID() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Base", "m_nEditorNodeID")); }
};
