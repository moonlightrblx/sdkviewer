#pragma once
#include "../memory.h"

class CPulseCell_WaitForCursorsWithTagBase {
public:
 uintptr_t baseAddr;
 CPulseCell_WaitForCursorsWithTagBase() : baseAddr(0){}
 CPulseCell_WaitForCursorsWithTagBase(uintptr_t b):baseAddr(b){}
 uintptr_t m_nCursorsAllowedToWait(){return SCHEMA_TYPE(uintptr_t,0x48);}
 uintptr_t m_WaitComplete(){return SCHEMA_TYPE(uintptr_t,0x50);}
};
