#pragma once
#include "../memory.h"

class C_BaseFlex__Emphasized_Phoneme  {
public:
    uintptr_t baseAddr;

    C_BaseFlex__Emphasized_Phoneme() { baseAddr = 0; }
    C_BaseFlex__Emphasized_Phoneme(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_sClassName() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseFlex__Emphasized_Phoneme", "m_sClassName")); }
    float m_flAmount() { return read<float>(baseAddr + offsets_instance.get("C_BaseFlex__Emphasized_Phoneme", "m_flAmount")); }
    bool m_bRequired() { return read<bool>(baseAddr + offsets_instance.get("C_BaseFlex__Emphasized_Phoneme", "m_bRequired")); }
    bool m_bBasechecked() { return read<bool>(baseAddr + offsets_instance.get("C_BaseFlex__Emphasized_Phoneme", "m_bBasechecked")); }
    bool m_bValid() { return read<bool>(baseAddr + offsets_instance.get("C_BaseFlex__Emphasized_Phoneme", "m_bValid")); }
};
