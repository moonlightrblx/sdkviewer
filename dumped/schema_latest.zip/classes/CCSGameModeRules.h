#pragma once
#include "../memory.h"

class CCSGameModeRules {
public:
 uintptr_t baseAddr;
 CCSGameModeRules() : baseAddr(0){}
 CCSGameModeRules(uintptr_t b):baseAddr(b){}
 uintptr_t __m_pChainEntity(){return SCHEMA_TYPE(uintptr_t,0x8);}
};
