#pragma once
#include "../memory.h"

class CFilterTeam  {
public:
    uintptr_t baseAddr;

    CFilterTeam() { baseAddr = 0; }
    CFilterTeam(uintptr_t base) : baseAddr(base) {}

    int m_iFilterTeam() { return read<int>(baseAddr + offsets_instance.get("CFilterTeam", "m_iFilterTeam")); }
};
