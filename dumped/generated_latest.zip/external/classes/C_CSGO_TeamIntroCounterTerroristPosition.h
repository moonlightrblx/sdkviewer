#pragma once
#include "../memory.h"

class C_CSGO_TeamIntroCounterTerroristPosition  {
public:
    uintptr_t baseAddr;

    C_CSGO_TeamIntroCounterTerroristPosition() { baseAddr = 0; }
    C_CSGO_TeamIntroCounterTerroristPosition(uintptr_t base) : baseAddr(base) {}

};
