#pragma once
#include "../memory.h"

class C_BreakableProp {
public:
 uintptr_t baseAddr;
 C_BreakableProp() : baseAddr(0){}
 C_BreakableProp(uintptr_t b):baseAddr(b){}
 uintptr_t m_CPropDataComponent(){return SCHEMA_TYPE(uintptr_t,0x1190);}
 uintptr_t m_OnStartDeath(){return SCHEMA_TYPE(uintptr_t,0x11D0);}
 uintptr_t m_OnBreak(){return SCHEMA_TYPE(uintptr_t,0x11F8);}
 uintptr_t m_OnHealthChanged(){return SCHEMA_TYPE(uintptr_t,0x1220);}
 uintptr_t m_OnTakeDamage(){return SCHEMA_TYPE(uintptr_t,0x1248);}
 uintptr_t m_impactEnergyScale(){return SCHEMA_TYPE(uintptr_t,0x1270);}
 uintptr_t m_iMinHealthDmg(){return SCHEMA_TYPE(uintptr_t,0x1274);}
 uintptr_t m_flPressureDelay(){return SCHEMA_TYPE(uintptr_t,0x1278);}
 uintptr_t m_flDefBurstScale(){return SCHEMA_TYPE(uintptr_t,0x127C);}
 uintptr_t m_vDefBurstOffset(){return SCHEMA_TYPE(uintptr_t,0x1280);}
 uintptr_t m_hBreaker(){return SCHEMA_TYPE(uintptr_t,0x128C);}
 uintptr_t m_PerformanceMode(){return SCHEMA_TYPE(uintptr_t,0x1290);}
 uintptr_t m_flPreventDamageBeforeTime(){return SCHEMA_TYPE(uintptr_t,0x1294);}
 uintptr_t m_BreakableContentsType(){return SCHEMA_TYPE(uintptr_t,0x1298);}
 uintptr_t m_strBreakableContentsPropGroupOverride(){return SCHEMA_TYPE(uintptr_t,0x12A0);}
 uintptr_t m_strBreakableContentsParticleOverride(){return SCHEMA_TYPE(uintptr_t,0x12A8);}
 uintptr_t m_bHasBreakPiecesOrCommands(){return SCHEMA_TYPE(uintptr_t,0x12B0);}
 uintptr_t m_explodeDamage(){return SCHEMA_TYPE(uintptr_t,0x12B4);}
 uintptr_t m_explodeRadius(){return SCHEMA_TYPE(uintptr_t,0x12B8);}
 uintptr_t m_explosionDelay(){return SCHEMA_TYPE(uintptr_t,0x12C0);}
 uintptr_t m_explosionBuildupSound(){return SCHEMA_TYPE(uintptr_t,0x12C8);}
 uintptr_t m_explosionCustomEffect(){return SCHEMA_TYPE(uintptr_t,0x12D0);}
 uintptr_t m_explosionCustomSound(){return SCHEMA_TYPE(uintptr_t,0x12D8);}
 uintptr_t m_explosionModifier(){return SCHEMA_TYPE(uintptr_t,0x12E0);}
 uintptr_t m_hPhysicsAttacker(){return SCHEMA_TYPE(uintptr_t,0x12E8);}
 uintptr_t m_flLastPhysicsInfluenceTime(){return SCHEMA_TYPE(uintptr_t,0x12EC);}
 uintptr_t m_flDefaultFadeScale(){return SCHEMA_TYPE(uintptr_t,0x12F0);}
 uintptr_t m_hLastAttacker(){return SCHEMA_TYPE(uintptr_t,0x12F4);}
};
