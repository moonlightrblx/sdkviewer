#pragma once
#include "../memory.h"

class C_WeaponGalilAR {
public:
 uintptr_t baseAddr;
 C_WeaponGalilAR() : baseAddr(0){}
 C_WeaponGalilAR(uintptr_t b):baseAddr(b){}
};
