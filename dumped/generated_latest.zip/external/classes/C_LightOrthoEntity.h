#pragma once
#include "../memory.h"

class C_LightOrthoEntity  {
public:
    uintptr_t baseAddr;

    C_LightOrthoEntity() { baseAddr = 0; }
    C_LightOrthoEntity(uintptr_t base) : baseAddr(base) {}

};
