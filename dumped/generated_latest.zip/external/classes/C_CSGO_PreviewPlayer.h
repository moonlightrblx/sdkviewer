#pragma once
#include "../memory.h"

class C_CSGO_PreviewPlayer  {
public:
    uintptr_t baseAddr;

    C_CSGO_PreviewPlayer() { baseAddr = 0; }
    C_CSGO_PreviewPlayer(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_animgraphCharacterModeString() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSGO_PreviewPlayer", "m_animgraphCharacterModeString")); }
    float m_flInitialModelScale() { return read<float>(baseAddr + offsets_instance.get("C_CSGO_PreviewPlayer", "m_flInitialModelScale")); }
};
