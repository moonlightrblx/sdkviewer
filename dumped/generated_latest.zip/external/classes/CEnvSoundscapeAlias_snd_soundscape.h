#pragma once
#include "../memory.h"

class CEnvSoundscapeAlias_snd_soundscape  {
public:
    uintptr_t baseAddr;

    CEnvSoundscapeAlias_snd_soundscape() { baseAddr = 0; }
    CEnvSoundscapeAlias_snd_soundscape(uintptr_t base) : baseAddr(base) {}

};
