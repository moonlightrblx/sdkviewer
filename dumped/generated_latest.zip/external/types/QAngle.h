#pragma once
struct QAngle { float pitch, yaw, roll; };
