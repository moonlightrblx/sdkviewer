#pragma once
#include "../memory.h"

class CCSPlayer_BulletServices {
public:
 uintptr_t baseAddr;
 CCSPlayer_BulletServices() : baseAddr(0){}
 CCSPlayer_BulletServices(uintptr_t b):baseAddr(b){}
 uintptr_t m_totalHitsOnServer(){return SCHEMA_TYPE(uintptr_t,0x40);}
};
