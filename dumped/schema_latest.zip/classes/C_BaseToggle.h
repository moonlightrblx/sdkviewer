#pragma once
#include "../memory.h"

class C_BaseToggle {
public:
 uintptr_t baseAddr;
 C_BaseToggle() : baseAddr(0){}
 C_BaseToggle(uintptr_t b):baseAddr(b){}
};
