#pragma once
#include "../memory.h"

class CFilterMultipleAPI  {
public:
    uintptr_t baseAddr;

    CFilterMultipleAPI() { baseAddr = client_base(); }
    CFilterMultipleAPI(uintptr_t base) : baseAddr(base) {}

};
