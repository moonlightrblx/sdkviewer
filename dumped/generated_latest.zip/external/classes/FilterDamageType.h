#pragma once
#include "../memory.h"

class FilterDamageType  {
public:
    uintptr_t baseAddr;

    FilterDamageType() { baseAddr = client_base(); }
    FilterDamageType(uintptr_t base) : baseAddr(base) {}

    int m_iDamageType() { return read<int>(baseAddr + offsets_instance.get("FilterDamageType", "m_iDamageType")); }
};
