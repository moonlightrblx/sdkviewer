#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class CCSPlayer_CameraServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_CameraServices() { baseAddr = client_base(); }
    CCSPlayer_CameraServices(uintptr_t base) : baseAddr(base) {}

    float m_flDeathCamTilt() { return read<float>(baseAddr + offsets_instance.get("CCSPlayer_CameraServices", "m_flDeathCamTilt")); }
    Vector3 m_vClientScopeInaccuracy() { return read<Vector3>(baseAddr + offsets_instance.get("CCSPlayer_CameraServices", "m_vClientScopeInaccuracy")); }
};
