#pragma once
#include "../memory.h"

class CPointTemplate {
public:
 uintptr_t baseAddr;
 CPointTemplate() : baseAddr(0){}
 CPointTemplate(uintptr_t b):baseAddr(b){}
 uintptr_t m_iszWorldName(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_iszSource2EntityLumpName(){return SCHEMA_TYPE(uintptr_t,0x600);}
 uintptr_t m_iszEntityFilterName(){return SCHEMA_TYPE(uintptr_t,0x608);}
 uintptr_t m_flTimeoutInterval(){return SCHEMA_TYPE(uintptr_t,0x610);}
 uintptr_t m_bAsynchronouslySpawnEntities(){return SCHEMA_TYPE(uintptr_t,0x614);}
 uintptr_t m_clientOnlyEntityBehavior(){return SCHEMA_TYPE(uintptr_t,0x618);}
 uintptr_t m_ownerSpawnGroupType(){return SCHEMA_TYPE(uintptr_t,0x61C);}
 uintptr_t m_createdSpawnGroupHandles(){return SCHEMA_TYPE(uintptr_t,0x620);}
 uintptr_t m_SpawnedEntityHandles(){return SCHEMA_TYPE(uintptr_t,0x638);}
 uintptr_t m_ScriptSpawnCallback(){return SCHEMA_TYPE(uintptr_t,0x650);}
 uintptr_t m_ScriptCallbackScope(){return SCHEMA_TYPE(uintptr_t,0x658);}
};
