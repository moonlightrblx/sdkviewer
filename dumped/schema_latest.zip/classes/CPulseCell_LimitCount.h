#pragma once
#include "../memory.h"

class CPulseCell_LimitCount {
public:
 uintptr_t baseAddr;
 CPulseCell_LimitCount() : baseAddr(0){}
 CPulseCell_LimitCount(uintptr_t b):baseAddr(b){}
 uintptr_t m_nLimitCount(){return SCHEMA_TYPE(uintptr_t,0x48);}
};
