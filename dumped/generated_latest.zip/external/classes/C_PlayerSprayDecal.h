#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_PlayerSprayDecal  {
public:
    uintptr_t baseAddr;

    C_PlayerSprayDecal() { baseAddr = 0; }
    C_PlayerSprayDecal(uintptr_t base) : baseAddr(base) {}

    int m_nUniqueID() { return read<int>(baseAddr + offsets_instance.get("C_PlayerSprayDecal", "m_nUniqueID")); }
    int m_unAccountID() { return read<int>(baseAddr + offsets_instance.get("C_PlayerSprayDecal", "m_unAccountID")); }
    int m_unTraceID() { return read<int>(baseAddr + offsets_instance.get("C_PlayerSprayDecal", "m_unTraceID")); }
    int m_rtGcTime() { return read<int>(baseAddr + offsets_instance.get("C_PlayerSprayDecal", "m_rtGcTime")); }
    Vector3 m_vecEndPos() { return read<Vector3>(baseAddr + offsets_instance.get("C_PlayerSprayDecal", "m_vecEndPos")); }
    Vector3 m_vecStart() { return read<Vector3>(baseAddr + offsets_instance.get("C_PlayerSprayDecal", "m_vecStart")); }
    Vector3 m_vecLeft() { return read<Vector3>(baseAddr + offsets_instance.get("C_PlayerSprayDecal", "m_vecLeft")); }
    Vector3 m_vecNormal() { return read<Vector3>(baseAddr + offsets_instance.get("C_PlayerSprayDecal", "m_vecNormal")); }
    int m_nPlayer() { return read<int>(baseAddr + offsets_instance.get("C_PlayerSprayDecal", "m_nPlayer")); }
    int m_nEntity() { return read<int>(baseAddr + offsets_instance.get("C_PlayerSprayDecal", "m_nEntity")); }
    int m_nHitbox() { return read<int>(baseAddr + offsets_instance.get("C_PlayerSprayDecal", "m_nHitbox")); }
    float m_flCreationTime() { return read<float>(baseAddr + offsets_instance.get("C_PlayerSprayDecal", "m_flCreationTime")); }
    int m_nTintID() { return read<int>(baseAddr + offsets_instance.get("C_PlayerSprayDecal", "m_nTintID")); }
    uint8_t m_nVersion() { return read<uint8_t>(baseAddr + offsets_instance.get("C_PlayerSprayDecal", "m_nVersion")); }
    uint8_t m_ubSignature() { return read<uint8_t>(baseAddr + offsets_instance.get("C_PlayerSprayDecal", "m_ubSignature")); }
    uintptr_t m_SprayRenderHelper() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_PlayerSprayDecal", "m_SprayRenderHelper")); }
};
