#pragma once
#include "../memory.h"

class CPulseCell_Value_RandomFloat {
public:
 uintptr_t baseAddr;
 CPulseCell_Value_RandomFloat() : baseAddr(0){}
 CPulseCell_Value_RandomFloat(uintptr_t b):baseAddr(b){}
};
