#pragma once
#include "../memory.h"

class CCSPlayerController_DamageServices {
public:
 uintptr_t baseAddr;
 CCSPlayerController_DamageServices() : baseAddr(0){}
 CCSPlayerController_DamageServices(uintptr_t b):baseAddr(b){}
 uintptr_t m_nSendUpdate(){return SCHEMA_TYPE(uintptr_t,0x40);}
 uintptr_t m_DamageList(){return SCHEMA_TYPE(uintptr_t,0x48);}
};
