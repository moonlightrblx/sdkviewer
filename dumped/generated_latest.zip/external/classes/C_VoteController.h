#pragma once
#include "../memory.h"

class C_VoteController  {
public:
    uintptr_t baseAddr;

    C_VoteController() { baseAddr = 0; }
    C_VoteController(uintptr_t base) : baseAddr(base) {}

    int m_iActiveIssueIndex() { return read<int>(baseAddr + offsets_instance.get("C_VoteController", "m_iActiveIssueIndex")); }
    int m_iOnlyTeamToVote() { return read<int>(baseAddr + offsets_instance.get("C_VoteController", "m_iOnlyTeamToVote")); }
    int m_nVoteOptionCount() { return read<int>(baseAddr + offsets_instance.get("C_VoteController", "m_nVoteOptionCount")); }
    int m_nPotentialVotes() { return read<int>(baseAddr + offsets_instance.get("C_VoteController", "m_nPotentialVotes")); }
    bool m_bVotesDirty() { return read<bool>(baseAddr + offsets_instance.get("C_VoteController", "m_bVotesDirty")); }
    bool m_bTypeDirty() { return read<bool>(baseAddr + offsets_instance.get("C_VoteController", "m_bTypeDirty")); }
    bool m_bIsYesNoVote() { return read<bool>(baseAddr + offsets_instance.get("C_VoteController", "m_bIsYesNoVote")); }
};
