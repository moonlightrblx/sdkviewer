#pragma once
#include "../memory.h"

class CPulseCell_BaseRequirement {
public:
 uintptr_t baseAddr;
 CPulseCell_BaseRequirement() : baseAddr(0){}
 CPulseCell_BaseRequirement(uintptr_t b):baseAddr(b){}
};
