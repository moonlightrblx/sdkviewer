#pragma once
#include "../memory.h"

class CBasePulseGraphInstance  {
public:
    uintptr_t baseAddr;

    CBasePulseGraphInstance() { baseAddr = client_base(); }
    CBasePulseGraphInstance(uintptr_t base) : baseAddr(base) {}

};
