#pragma once
#include "../memory.h"

class CPropDataComponent {
public:
 uintptr_t baseAddr;
 CPropDataComponent() : baseAddr(0){}
 CPropDataComponent(uintptr_t b):baseAddr(b){}
 uintptr_t m_flDmgModBullet(){return SCHEMA_TYPE(uintptr_t,0x10);}
 uintptr_t m_flDmgModClub(){return SCHEMA_TYPE(uintptr_t,0x14);}
 uintptr_t m_flDmgModExplosive(){return SCHEMA_TYPE(uintptr_t,0x18);}
 uintptr_t m_flDmgModFire(){return SCHEMA_TYPE(uintptr_t,0x1C);}
 uintptr_t m_iszPhysicsDamageTableName(){return SCHEMA_TYPE(uintptr_t,0x20);}
 uintptr_t m_iszBasePropData(){return SCHEMA_TYPE(uintptr_t,0x28);}
 uintptr_t m_nInteractions(){return SCHEMA_TYPE(uintptr_t,0x30);}
 uintptr_t m_bSpawnMotionDisabled(){return SCHEMA_TYPE(uintptr_t,0x34);}
 uintptr_t m_nDisableTakePhysicsDamageSpawnFlag(){return SCHEMA_TYPE(uintptr_t,0x38);}
 uintptr_t m_nMotionDisabledSpawnFlag(){return SCHEMA_TYPE(uintptr_t,0x3C);}
};
