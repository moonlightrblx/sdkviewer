#pragma once
#include "../memory.h"

class CPulseCell_IntervalTimer {
public:
 uintptr_t baseAddr;
 CPulseCell_IntervalTimer() : baseAddr(0){}
 CPulseCell_IntervalTimer(uintptr_t b):baseAddr(b){}
 uintptr_t m_Completed(){return SCHEMA_TYPE(uintptr_t,0x48);}
 uintptr_t m_OnInterval(){return SCHEMA_TYPE(uintptr_t,0x90);}
};
