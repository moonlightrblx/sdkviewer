#pragma once
#include "../memory.h"

class C_SoundOpvarSetAABBEntity  {
public:
    uintptr_t baseAddr;

    C_SoundOpvarSetAABBEntity() { baseAddr = 0; }
    C_SoundOpvarSetAABBEntity(uintptr_t base) : baseAddr(base) {}

};
