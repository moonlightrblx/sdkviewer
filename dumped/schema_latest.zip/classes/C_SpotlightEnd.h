#pragma once
#include "../memory.h"

class C_SpotlightEnd {
public:
 uintptr_t baseAddr;
 C_SpotlightEnd() : baseAddr(0){}
 C_SpotlightEnd(uintptr_t b):baseAddr(b){}
 uintptr_t m_flLightScale(){return SCHEMA_TYPE(uintptr_t,0xEB0);}
 uintptr_t m_Radius(){return SCHEMA_TYPE(uintptr_t,0xEB4);}
};
