#pragma once
#include "../memory.h"

class IntervalTimer  {
public:
    uintptr_t baseAddr;

    IntervalTimer() { baseAddr = client_base(); }
    IntervalTimer(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_timestamp() { return read<uintptr_t>(baseAddr + offsets_instance.get("IntervalTimer", "m_timestamp")); }
    uintptr_t m_nWorldGroupId() { return read<uintptr_t>(baseAddr + offsets_instance.get("IntervalTimer", "m_nWorldGroupId")); }
};
