#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class PhysicsRagdollPose_t  {
public:
    uintptr_t baseAddr;

    PhysicsRagdollPose_t() { baseAddr = client_base(); }
    PhysicsRagdollPose_t(uintptr_t base) : baseAddr(base) {}

    Vector3 m_Transforms() { return read<Vector3>(baseAddr + offsets_instance.get("PhysicsRagdollPose_t", "m_Transforms")); }
    C_BaseEntity* m_hOwner() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("PhysicsRagdollPose_t", "m_hOwner")); }
    bool m_bSetFromDebugHistory() { return read<bool>(baseAddr + offsets_instance.get("PhysicsRagdollPose_t", "m_bSetFromDebugHistory")); }
};
