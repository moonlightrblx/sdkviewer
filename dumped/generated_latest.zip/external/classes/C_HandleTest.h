#pragma once
#include "../memory.h"
class C_BaseEntity;

class C_HandleTest  {
public:
    uintptr_t baseAddr;

    C_HandleTest() { baseAddr = 0; }
    C_HandleTest(uintptr_t base) : baseAddr(base) {}

    C_BaseEntity* m_Handle() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_HandleTest", "m_Handle")); }
    bool m_bSendHandle() { return read<bool>(baseAddr + offsets_instance.get("C_HandleTest", "m_bSendHandle")); }
};
