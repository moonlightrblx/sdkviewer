#pragma once
#include "../memory.h"

class CSkyboxReference {
public:
 uintptr_t baseAddr;
 CSkyboxReference() : baseAddr(0){}
 CSkyboxReference(uintptr_t b):baseAddr(b){}
 uintptr_t m_worldGroupId(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_hSkyCamera(){return SCHEMA_TYPE(uintptr_t,0x5FC);}
};
