#pragma once
#include "../memory.h"

class CPulseCell_WaitForObservable  {
public:
    uintptr_t baseAddr;

    CPulseCell_WaitForObservable() { baseAddr = client_base(); }
    CPulseCell_WaitForObservable(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_Condition() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_WaitForObservable", "m_Condition")); }
    uintptr_t m_OnTrue() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_WaitForObservable", "m_OnTrue")); }
};
