#pragma once
#include "../memory.h"

class C_WeaponTaser {
public:
 uintptr_t baseAddr;
 C_WeaponTaser() : baseAddr(0){}
 C_WeaponTaser(uintptr_t b):baseAddr(b){}
 uintptr_t m_fFireTime(){return SCHEMA_TYPE(uintptr_t,0x1FB0);}
 uintptr_t m_nLastAttackTick(){return SCHEMA_TYPE(uintptr_t,0x1FB4);}
};
