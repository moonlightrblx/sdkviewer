#pragma once
#include "../memory.h"
#include "../classes/CountdownTimer.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"

class C_Fish  {
public:
    uintptr_t baseAddr;

    C_Fish() { baseAddr = 0; }
    C_Fish(uintptr_t base) : baseAddr(base) {}

    Vector3 m_pos() { return read<Vector3>(baseAddr + offsets_instance.get("C_Fish", "m_pos")); }
    Vector3 m_vel() { return read<Vector3>(baseAddr + offsets_instance.get("C_Fish", "m_vel")); }
    QAngle m_angles() { return read<QAngle>(baseAddr + offsets_instance.get("C_Fish", "m_angles")); }
    int m_localLifeState() { return read<int>(baseAddr + offsets_instance.get("C_Fish", "m_localLifeState")); }
    float m_deathDepth() { return read<float>(baseAddr + offsets_instance.get("C_Fish", "m_deathDepth")); }
    float m_deathAngle() { return read<float>(baseAddr + offsets_instance.get("C_Fish", "m_deathAngle")); }
    float m_buoyancy() { return read<float>(baseAddr + offsets_instance.get("C_Fish", "m_buoyancy")); }
    CountdownTimer m_wiggleTimer() { return read<CountdownTimer>(baseAddr + offsets_instance.get("C_Fish", "m_wiggleTimer")); }
    float m_wigglePhase() { return read<float>(baseAddr + offsets_instance.get("C_Fish", "m_wigglePhase")); }
    float m_wiggleRate() { return read<float>(baseAddr + offsets_instance.get("C_Fish", "m_wiggleRate")); }
    Vector3 m_actualPos() { return read<Vector3>(baseAddr + offsets_instance.get("C_Fish", "m_actualPos")); }
    QAngle m_actualAngles() { return read<QAngle>(baseAddr + offsets_instance.get("C_Fish", "m_actualAngles")); }
    Vector3 m_poolOrigin() { return read<Vector3>(baseAddr + offsets_instance.get("C_Fish", "m_poolOrigin")); }
    float m_waterLevel() { return read<float>(baseAddr + offsets_instance.get("C_Fish", "m_waterLevel")); }
    bool m_gotUpdate() { return read<bool>(baseAddr + offsets_instance.get("C_Fish", "m_gotUpdate")); }
    float m_x() { return read<float>(baseAddr + offsets_instance.get("C_Fish", "m_x")); }
    float m_y() { return read<float>(baseAddr + offsets_instance.get("C_Fish", "m_y")); }
    float m_z() { return read<float>(baseAddr + offsets_instance.get("C_Fish", "m_z")); }
    float m_angle() { return read<float>(baseAddr + offsets_instance.get("C_Fish", "m_angle")); }
    float m_errorHistory() { return read<float>(baseAddr + offsets_instance.get("C_Fish", "m_errorHistory")); }
    int m_errorHistoryIndex() { return read<int>(baseAddr + offsets_instance.get("C_Fish", "m_errorHistoryIndex")); }
    int m_errorHistoryCount() { return read<int>(baseAddr + offsets_instance.get("C_Fish", "m_errorHistoryCount")); }
    float m_averageError() { return read<float>(baseAddr + offsets_instance.get("C_Fish", "m_averageError")); }
};
