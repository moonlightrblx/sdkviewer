#pragma once
#include "../memory.h"

class CBodyComponentBaseModelEntity  {
public:
    uintptr_t baseAddr;

    CBodyComponentBaseModelEntity() { baseAddr = client_base(); }
    CBodyComponentBaseModelEntity(uintptr_t base) : baseAddr(base) {}

};
