#pragma once
#include "../memory.h"

class C_CS2HudModelWeapon {
public:
 uintptr_t baseAddr;
 C_CS2HudModelWeapon() : baseAddr(0){}
 C_CS2HudModelWeapon(uintptr_t b):baseAddr(b){}
};
