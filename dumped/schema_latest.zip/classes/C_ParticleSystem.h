#pragma once
#include "../memory.h"

class C_ParticleSystem {
public:
 uintptr_t baseAddr;
 C_ParticleSystem() : baseAddr(0){}
 C_ParticleSystem(uintptr_t b):baseAddr(b){}
 uintptr_t m_szSnapshotFileName(){return SCHEMA_TYPE(uintptr_t,0xEB0);}
 uintptr_t m_bActive(){return SCHEMA_TYPE(uintptr_t,0x10B0);}
 uintptr_t m_bFrozen(){return SCHEMA_TYPE(uintptr_t,0x10B1);}
 uintptr_t m_flFreezeTransitionDuration(){return SCHEMA_TYPE(uintptr_t,0x10B4);}
 uintptr_t m_nStopType(){return SCHEMA_TYPE(uintptr_t,0x10B8);}
 uintptr_t m_bAnimateDuringGameplayPause(){return SCHEMA_TYPE(uintptr_t,0x10BC);}
 uintptr_t m_iEffectIndex(){return SCHEMA_TYPE(uintptr_t,0x10C0);}
 uintptr_t m_flStartTime(){return SCHEMA_TYPE(uintptr_t,0x10C8);}
 uintptr_t m_flPreSimTime(){return SCHEMA_TYPE(uintptr_t,0x10CC);}
 uintptr_t m_vServerControlPoints(){return SCHEMA_TYPE(uintptr_t,0x10D0);}
 uintptr_t m_iServerControlPointAssignments(){return SCHEMA_TYPE(uintptr_t,0x1100);}
 uintptr_t m_hControlPointEnts(){return SCHEMA_TYPE(uintptr_t,0x1104);}
 uintptr_t m_bNoSave(){return SCHEMA_TYPE(uintptr_t,0x1204);}
 uintptr_t m_bNoFreeze(){return SCHEMA_TYPE(uintptr_t,0x1205);}
 uintptr_t m_bNoRamp(){return SCHEMA_TYPE(uintptr_t,0x1206);}
 uintptr_t m_bStartActive(){return SCHEMA_TYPE(uintptr_t,0x1207);}
 uintptr_t m_iszEffectName(){return SCHEMA_TYPE(uintptr_t,0x1208);}
 uintptr_t m_iszControlPointNames(){return SCHEMA_TYPE(uintptr_t,0x1210);}
 uintptr_t m_nDataCP(){return SCHEMA_TYPE(uintptr_t,0x1410);}
 uintptr_t m_vecDataCPValue(){return SCHEMA_TYPE(uintptr_t,0x1414);}
 uintptr_t m_nTintCP(){return SCHEMA_TYPE(uintptr_t,0x1420);}
 uintptr_t m_clrTint(){return SCHEMA_TYPE(uintptr_t,0x1424);}
 uintptr_t m_bOldActive(){return SCHEMA_TYPE(uintptr_t,0x1448);}
 uintptr_t m_bOldFrozen(){return SCHEMA_TYPE(uintptr_t,0x1449);}
};
