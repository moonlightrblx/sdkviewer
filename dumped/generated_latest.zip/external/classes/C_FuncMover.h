#pragma once
#include "../memory.h"

class C_FuncMover  {
public:
    uintptr_t baseAddr;

    C_FuncMover() { baseAddr = client_base(); }
    C_FuncMover(uintptr_t base) : baseAddr(base) {}

};
