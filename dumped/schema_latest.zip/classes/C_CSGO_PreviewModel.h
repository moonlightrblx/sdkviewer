#pragma once
#include "../memory.h"

class C_CSGO_PreviewModel {
public:
 uintptr_t baseAddr;
 C_CSGO_PreviewModel() : baseAddr(0){}
 C_CSGO_PreviewModel(uintptr_t b):baseAddr(b){}
 uintptr_t m_defaultAnim(){return SCHEMA_TYPE(uintptr_t,0x1368);}
 uintptr_t m_nDefaultAnimLoopMode(){return SCHEMA_TYPE(uintptr_t,0x1370);}
 uintptr_t m_flInitialModelScale(){return SCHEMA_TYPE(uintptr_t,0x1374);}
 uintptr_t m_sInitialWeaponState(){return SCHEMA_TYPE(uintptr_t,0x1378);}
};
