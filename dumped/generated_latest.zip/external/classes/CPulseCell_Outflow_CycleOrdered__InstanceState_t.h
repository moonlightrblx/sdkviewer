#pragma once
#include "../memory.h"

class CPulseCell_Outflow_CycleOrdered__InstanceState_t  {
public:
    uintptr_t baseAddr;

    CPulseCell_Outflow_CycleOrdered__InstanceState_t() { baseAddr = client_base(); }
    CPulseCell_Outflow_CycleOrdered__InstanceState_t(uintptr_t base) : baseAddr(base) {}

    int m_nNextIndex() { return read<int>(baseAddr + offsets_instance.get("CPulseCell_Outflow_CycleOrdered__InstanceState_t", "m_nNextIndex")); }
};
