#pragma once
#include "../memory.h"

class C_RopeKeyframe__CPhysicsDelegate {
public:
 uintptr_t baseAddr;
 C_RopeKeyframe__CPhysicsDelegate() : baseAddr(0){}
 C_RopeKeyframe__CPhysicsDelegate(uintptr_t b):baseAddr(b){}
 uintptr_t m_pKeyframe(){return SCHEMA_TYPE(uintptr_t,0x8);}
};
