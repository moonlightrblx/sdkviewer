#pragma once
#include "../memory.h"

class C_RopeKeyframe__CPhysicsDelegate  {
public:
    uintptr_t baseAddr;

    C_RopeKeyframe__CPhysicsDelegate() { baseAddr = client_base(); }
    C_RopeKeyframe__CPhysicsDelegate(uintptr_t base) : baseAddr(base) {}

    C_RopeKeyframe* m_pKeyframe() { return read<C_RopeKeyframe*>(baseAddr + offsets_instance.get("C_RopeKeyframe__CPhysicsDelegate", "m_pKeyframe")); }
};
