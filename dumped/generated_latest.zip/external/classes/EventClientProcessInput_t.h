#pragma once
#include "../memory.h"
#include "../classes/EngineLoopState_t.h"

class EventClientProcessInput_t  {
public:
    uintptr_t baseAddr;

    EventClientProcessInput_t() { baseAddr = 0; }
    EventClientProcessInput_t(uintptr_t base) : baseAddr(base) {}

    EngineLoopState_t m_LoopState() { return read<EngineLoopState_t>(baseAddr + offsets_instance.get("EventClientProcessInput_t", "m_LoopState")); }
    float m_flRealTime() { return read<float>(baseAddr + offsets_instance.get("EventClientProcessInput_t", "m_flRealTime")); }
    float m_flTickInterval() { return read<float>(baseAddr + offsets_instance.get("EventClientProcessInput_t", "m_flTickInterval")); }
    uintptr_t m_flTickStartTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("EventClientProcessInput_t", "m_flTickStartTime")); }
};
