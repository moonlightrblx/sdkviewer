#pragma once
#include "../memory.h"

class FilterHealth  {
public:
    uintptr_t baseAddr;

    FilterHealth() { baseAddr = client_base(); }
    FilterHealth(uintptr_t base) : baseAddr(base) {}

    bool m_bAdrenalineActive() { return read<bool>(baseAddr + offsets_instance.get("FilterHealth", "m_bAdrenalineActive")); }
    int m_iHealthMin() { return read<int>(baseAddr + offsets_instance.get("FilterHealth", "m_iHealthMin")); }
    int m_iHealthMax() { return read<int>(baseAddr + offsets_instance.get("FilterHealth", "m_iHealthMax")); }
};
