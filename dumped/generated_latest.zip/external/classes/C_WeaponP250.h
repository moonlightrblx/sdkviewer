#pragma once
#include "../memory.h"

class C_WeaponP250  {
public:
    uintptr_t baseAddr;

    C_WeaponP250() { baseAddr = client_base(); }
    C_WeaponP250(uintptr_t base) : baseAddr(base) {}

};
