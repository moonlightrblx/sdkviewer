#pragma once
#include "../memory.h"

class C_PhysBox  {
public:
    uintptr_t baseAddr;

    C_PhysBox() { baseAddr = client_base(); }
    C_PhysBox(uintptr_t base) : baseAddr(base) {}

};
