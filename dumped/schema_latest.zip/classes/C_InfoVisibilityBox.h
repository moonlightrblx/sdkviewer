#pragma once
#include "../memory.h"

class C_InfoVisibilityBox {
public:
 uintptr_t baseAddr;
 C_InfoVisibilityBox() : baseAddr(0){}
 C_InfoVisibilityBox(uintptr_t b):baseAddr(b){}
 uintptr_t m_nMode(){return SCHEMA_TYPE(uintptr_t,0x5FC);}
 uintptr_t m_vBoxSize(){return SCHEMA_TYPE(uintptr_t,0x600);}
 uintptr_t m_bEnabled(){return SCHEMA_TYPE(uintptr_t,0x60C);}
};
