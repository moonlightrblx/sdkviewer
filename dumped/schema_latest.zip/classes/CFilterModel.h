#pragma once
#include "../memory.h"

class CFilterModel {
public:
 uintptr_t baseAddr;
 CFilterModel() : baseAddr(0){}
 CFilterModel(uintptr_t b):baseAddr(b){}
 uintptr_t m_iFilterModel(){return SCHEMA_TYPE(uintptr_t,0x650);}
};
