#pragma once
#include "../memory.h"

class CPropDataComponent  {
public:
    uintptr_t baseAddr;

    CPropDataComponent() { baseAddr = 0; }
    CPropDataComponent(uintptr_t base) : baseAddr(base) {}

    float m_flDmgModBullet() { return read<float>(baseAddr + offsets_instance.get("CPropDataComponent", "m_flDmgModBullet")); }
    float m_flDmgModClub() { return read<float>(baseAddr + offsets_instance.get("CPropDataComponent", "m_flDmgModClub")); }
    float m_flDmgModExplosive() { return read<float>(baseAddr + offsets_instance.get("CPropDataComponent", "m_flDmgModExplosive")); }
    float m_flDmgModFire() { return read<float>(baseAddr + offsets_instance.get("CPropDataComponent", "m_flDmgModFire")); }
    uintptr_t m_iszPhysicsDamageTableName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPropDataComponent", "m_iszPhysicsDamageTableName")); }
    uintptr_t m_iszBasePropData() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPropDataComponent", "m_iszBasePropData")); }
    int m_nInteractions() { return read<int>(baseAddr + offsets_instance.get("CPropDataComponent", "m_nInteractions")); }
    bool m_bSpawnMotionDisabled() { return read<bool>(baseAddr + offsets_instance.get("CPropDataComponent", "m_bSpawnMotionDisabled")); }
    int m_nDisableTakePhysicsDamageSpawnFlag() { return read<int>(baseAddr + offsets_instance.get("CPropDataComponent", "m_nDisableTakePhysicsDamageSpawnFlag")); }
    int m_nMotionDisabledSpawnFlag() { return read<int>(baseAddr + offsets_instance.get("CPropDataComponent", "m_nMotionDisabledSpawnFlag")); }
};
