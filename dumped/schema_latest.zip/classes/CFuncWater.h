#pragma once
#include "../memory.h"

class CFuncWater {
public:
 uintptr_t baseAddr;
 CFuncWater() : baseAddr(0){}
 CFuncWater(uintptr_t b):baseAddr(b){}
 uintptr_t m_BuoyancyHelper(){return SCHEMA_TYPE(uintptr_t,0xEB0);}
};
