#pragma once
#include "../memory.h"

class C_PostProcessingVolume {
public:
 uintptr_t baseAddr;
 C_PostProcessingVolume() : baseAddr(0){}
 C_PostProcessingVolume(uintptr_t b):baseAddr(b){}
 uintptr_t m_hPostSettings(){return SCHEMA_TYPE(uintptr_t,0x1000);}
 uintptr_t m_flFadeDuration(){return SCHEMA_TYPE(uintptr_t,0x1008);}
 uintptr_t m_flMinLogExposure(){return SCHEMA_TYPE(uintptr_t,0x100C);}
 uintptr_t m_flMaxLogExposure(){return SCHEMA_TYPE(uintptr_t,0x1010);}
 uintptr_t m_flMinExposure(){return SCHEMA_TYPE(uintptr_t,0x1014);}
 uintptr_t m_flMaxExposure(){return SCHEMA_TYPE(uintptr_t,0x1018);}
 uintptr_t m_flExposureCompensation(){return SCHEMA_TYPE(uintptr_t,0x101C);}
 uintptr_t m_flExposureFadeSpeedUp(){return SCHEMA_TYPE(uintptr_t,0x1020);}
 uintptr_t m_flExposureFadeSpeedDown(){return SCHEMA_TYPE(uintptr_t,0x1024);}
 uintptr_t m_flTonemapEVSmoothingRange(){return SCHEMA_TYPE(uintptr_t,0x1028);}
 uintptr_t m_bMaster(){return SCHEMA_TYPE(uintptr_t,0x102C);}
 uintptr_t m_bExposureControl(){return SCHEMA_TYPE(uintptr_t,0x102D);}
};
