#pragma once
#include "../memory.h"

class CCSObserver_ObserverServices  {
public:
    uintptr_t baseAddr;

    CCSObserver_ObserverServices() { baseAddr = 0; }
    CCSObserver_ObserverServices(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_obsInterpState() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSObserver_ObserverServices", "m_obsInterpState")); }
};
