#pragma once
#include "../memory.h"

class C_GameRules {
public:
 uintptr_t baseAddr;
 C_GameRules() : baseAddr(0){}
 C_GameRules(uintptr_t b):baseAddr(b){}
 uintptr_t __m_pChainEntity(){return SCHEMA_TYPE(uintptr_t,0x8);}
 uintptr_t m_nTotalPausedTicks(){return SCHEMA_TYPE(uintptr_t,0x30);}
 uintptr_t m_nPauseStartTick(){return SCHEMA_TYPE(uintptr_t,0x34);}
 uintptr_t m_bGamePaused(){return SCHEMA_TYPE(uintptr_t,0x38);}
};
