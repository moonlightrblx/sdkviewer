#pragma once
#include "../memory.h"

class C_WeaponM4A1  {
public:
    uintptr_t baseAddr;

    C_WeaponM4A1() { baseAddr = client_base(); }
    C_WeaponM4A1(uintptr_t base) : baseAddr(base) {}

};
