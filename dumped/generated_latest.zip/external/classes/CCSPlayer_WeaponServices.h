#pragma once
#include "../memory.h"

class CCSPlayer_WeaponServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_WeaponServices() { baseAddr = client_base(); }
    CCSPlayer_WeaponServices(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_flNextAttack() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSPlayer_WeaponServices", "m_flNextAttack")); }
    bool m_bIsLookingAtWeapon() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayer_WeaponServices", "m_bIsLookingAtWeapon")); }
    bool m_bIsHoldingLookAtWeapon() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayer_WeaponServices", "m_bIsHoldingLookAtWeapon")); }
    int m_nOldTotalShootPositionHistoryCount() { return read<int>(baseAddr + offsets_instance.get("CCSPlayer_WeaponServices", "m_nOldTotalShootPositionHistoryCount")); }
    int m_nOldTotalInputHistoryCount() { return read<int>(baseAddr + offsets_instance.get("CCSPlayer_WeaponServices", "m_nOldTotalInputHistoryCount")); }
    uint8_t m_networkAnimTiming() { return read<uint8_t>(baseAddr + offsets_instance.get("CCSPlayer_WeaponServices", "m_networkAnimTiming")); }
    bool m_bBlockInspectUntilNextGraphUpdate() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayer_WeaponServices", "m_bBlockInspectUntilNextGraphUpdate")); }
};
