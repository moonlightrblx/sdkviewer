#pragma once
#include "../memory.h"

class C_SoundAreaEntitySphere {
public:
 uintptr_t baseAddr;
 C_SoundAreaEntitySphere() : baseAddr(0){}
 C_SoundAreaEntitySphere(uintptr_t b):baseAddr(b){}
 uintptr_t m_flRadius(){return SCHEMA_TYPE(uintptr_t,0x620);}
};
