#pragma once
#include "../memory.h"

class EventClientProcessGameInput_t {
public:
 uintptr_t baseAddr;
 EventClientProcessGameInput_t() : baseAddr(0){}
 EventClientProcessGameInput_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_LoopState(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_flRealTime(){return SCHEMA_TYPE(uintptr_t,0x28);}
 uintptr_t m_flFrameTime(){return SCHEMA_TYPE(uintptr_t,0x2C);}
};
