#pragma once
#include "../memory.h"

class C_CsmFovOverride {
public:
 uintptr_t baseAddr;
 C_CsmFovOverride() : baseAddr(0){}
 C_CsmFovOverride(uintptr_t b):baseAddr(b){}
 uintptr_t m_cameraName(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_flCsmFovOverrideValue(){return SCHEMA_TYPE(uintptr_t,0x600);}
};
