#pragma once
#include "../memory.h"

class C_ModelPointEntity  {
public:
    uintptr_t baseAddr;

    C_ModelPointEntity() { baseAddr = client_base(); }
    C_ModelPointEntity(uintptr_t base) : baseAddr(base) {}

};
