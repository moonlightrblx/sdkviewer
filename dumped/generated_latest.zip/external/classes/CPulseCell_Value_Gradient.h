#pragma once
#include "../memory.h"

class CPulseCell_Value_Gradient  {
public:
    uintptr_t baseAddr;

    CPulseCell_Value_Gradient() { baseAddr = client_base(); }
    CPulseCell_Value_Gradient(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_Gradient() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Value_Gradient", "m_Gradient")); }
};
