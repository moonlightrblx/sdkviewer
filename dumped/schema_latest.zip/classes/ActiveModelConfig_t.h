#pragma once
#include "../memory.h"

class ActiveModelConfig_t {
public:
 uintptr_t baseAddr;
 ActiveModelConfig_t() : baseAddr(0){}
 ActiveModelConfig_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_Handle(){return SCHEMA_TYPE(uintptr_t,0x30);}
 uintptr_t m_Name(){return SCHEMA_TYPE(uintptr_t,0x38);}
 uintptr_t m_AssociatedEntities(){return SCHEMA_TYPE(uintptr_t,0x40);}
 uintptr_t m_AssociatedEntityNames(){return SCHEMA_TYPE(uintptr_t,0x58);}
};
