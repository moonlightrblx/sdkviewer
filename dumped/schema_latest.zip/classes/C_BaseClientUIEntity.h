#pragma once
#include "../memory.h"

class C_BaseClientUIEntity {
public:
 uintptr_t baseAddr;
 C_BaseClientUIEntity() : baseAddr(0){}
 C_BaseClientUIEntity(uintptr_t b):baseAddr(b){}
 uintptr_t m_bEnabled(){return SCHEMA_TYPE(uintptr_t,0xEB8);}
 uintptr_t m_DialogXMLName(){return SCHEMA_TYPE(uintptr_t,0xEC0);}
 uintptr_t m_PanelClassName(){return SCHEMA_TYPE(uintptr_t,0xEC8);}
 uintptr_t m_PanelID(){return SCHEMA_TYPE(uintptr_t,0xED0);}
};
