#pragma once
#include "../memory.h"

class CCSPlayer_WeaponServices {
public:
 uintptr_t baseAddr;
 CCSPlayer_WeaponServices() : baseAddr(0){}
 CCSPlayer_WeaponServices(uintptr_t b):baseAddr(b){}
 uintptr_t m_flNextAttack(){return SCHEMA_TYPE(uintptr_t,0xC8);}
 uintptr_t m_bIsLookingAtWeapon(){return SCHEMA_TYPE(uintptr_t,0xCC);}
 uintptr_t m_bIsHoldingLookAtWeapon(){return SCHEMA_TYPE(uintptr_t,0xCD);}
 uintptr_t m_nOldTotalShootPositionHistoryCount(){return SCHEMA_TYPE(uintptr_t,0xD0);}
 uintptr_t m_nOldTotalInputHistoryCount(){return SCHEMA_TYPE(uintptr_t,0x368);}
 uintptr_t m_networkAnimTiming(){return SCHEMA_TYPE(uintptr_t,0x18E0);}
 uintptr_t m_bBlockInspectUntilNextGraphUpdate(){return SCHEMA_TYPE(uintptr_t,0x18F8);}
};
