#pragma once
#include "../memory.h"

class CPulseCell_Inflow_Method {
public:
 uintptr_t baseAddr;
 CPulseCell_Inflow_Method() : baseAddr(0){}
 CPulseCell_Inflow_Method(uintptr_t b):baseAddr(b){}
 uintptr_t m_MethodName(){return SCHEMA_TYPE(uintptr_t,0x80);}
 uintptr_t m_Description(){return SCHEMA_TYPE(uintptr_t,0x90);}
 uintptr_t m_bIsPublic(){return SCHEMA_TYPE(uintptr_t,0x98);}
 uintptr_t m_ReturnType(){return SCHEMA_TYPE(uintptr_t,0xA0);}
 uintptr_t m_Args(){return SCHEMA_TYPE(uintptr_t,0xB8);}
};
