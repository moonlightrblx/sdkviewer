#pragma once
#include "../memory.h"
#include "../types/Vector3.h"
class C_BasePlayerWeapon;

class CPlayer_WeaponServices  {
public:
    uintptr_t baseAddr;

    CPlayer_WeaponServices() { baseAddr = 0; }
    CPlayer_WeaponServices(uintptr_t base) : baseAddr(base) {}

    Vector3 m_hMyWeapons() { return read<Vector3>(baseAddr + offsets_instance.get("CPlayer_WeaponServices", "m_hMyWeapons")); }
    C_BasePlayerWeapon* m_hActiveWeapon() { return read<C_BasePlayerWeapon*>(baseAddr + offsets_instance.get("CPlayer_WeaponServices", "m_hActiveWeapon")); }
    C_BasePlayerWeapon* m_hLastWeapon() { return read<C_BasePlayerWeapon*>(baseAddr + offsets_instance.get("CPlayer_WeaponServices", "m_hLastWeapon")); }
    uint16_t m_iAmmo() { return read<uint16_t>(baseAddr + offsets_instance.get("CPlayer_WeaponServices", "m_iAmmo")); }
};
