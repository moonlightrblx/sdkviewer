#pragma once
#include "../memory.h"

class EntOutput_t  {
public:
    uintptr_t baseAddr;

    EntOutput_t() { baseAddr = 0; }
    EntOutput_t(uintptr_t base) : baseAddr(base) {}

};
