#pragma once
#include "../memory.h"

class CGameSceneNodeHandle {
public:
 uintptr_t baseAddr;
 CGameSceneNodeHandle() : baseAddr(0){}
 CGameSceneNodeHandle(uintptr_t b):baseAddr(b){}
 uintptr_t m_hOwner(){return SCHEMA_TYPE(uintptr_t,0x8);}
 uintptr_t m_name(){return SCHEMA_TYPE(uintptr_t,0xC);}
};
