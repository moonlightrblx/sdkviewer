#pragma once
#include "../memory.h"

class CCSPlayer_BulletServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_BulletServices() { baseAddr = client_base(); }
    CCSPlayer_BulletServices(uintptr_t base) : baseAddr(base) {}

    int m_totalHitsOnServer() { return read<int>(baseAddr + offsets_instance.get("CCSPlayer_BulletServices", "m_totalHitsOnServer")); }
};
