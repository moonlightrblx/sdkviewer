#pragma once
#include "../memory.h"

class C_PlayerPing {
public:
 uintptr_t baseAddr;
 C_PlayerPing() : baseAddr(0){}
 C_PlayerPing(uintptr_t b):baseAddr(b){}
 uintptr_t m_hPlayer(){return SCHEMA_TYPE(uintptr_t,0x628);}
 uintptr_t m_hPingedEntity(){return SCHEMA_TYPE(uintptr_t,0x62C);}
 uintptr_t m_iType(){return SCHEMA_TYPE(uintptr_t,0x630);}
 uintptr_t m_bUrgent(){return SCHEMA_TYPE(uintptr_t,0x634);}
 uintptr_t m_szPlaceName(){return SCHEMA_TYPE(uintptr_t,0x635);}
};
