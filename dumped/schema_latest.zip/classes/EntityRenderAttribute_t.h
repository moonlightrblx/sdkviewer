#pragma once
#include "../memory.h"

class EntityRenderAttribute_t {
public:
 uintptr_t baseAddr;
 EntityRenderAttribute_t() : baseAddr(0){}
 EntityRenderAttribute_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_ID(){return SCHEMA_TYPE(uintptr_t,0x30);}
 uintptr_t m_Values(){return SCHEMA_TYPE(uintptr_t,0x34);}
};
