#pragma once
#include "../memory.h"

class C_CSObserverPawn  {
public:
    uintptr_t baseAddr;

    C_CSObserverPawn() { baseAddr = client_base(); }
    C_CSObserverPawn(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_hDetectParentChange() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSObserverPawn", "m_hDetectParentChange")); }
};
