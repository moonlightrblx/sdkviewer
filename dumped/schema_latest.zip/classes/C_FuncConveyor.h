#pragma once
#include "../memory.h"

class C_FuncConveyor {
public:
 uintptr_t baseAddr;
 C_FuncConveyor() : baseAddr(0){}
 C_FuncConveyor(uintptr_t b):baseAddr(b){}
 uintptr_t m_vecMoveDirEntitySpace(){return SCHEMA_TYPE(uintptr_t,0xEB8);}
 uintptr_t m_flTargetSpeed(){return SCHEMA_TYPE(uintptr_t,0xEC4);}
 uintptr_t m_nTransitionStartTick(){return SCHEMA_TYPE(uintptr_t,0xEC8);}
 uintptr_t m_nTransitionDurationTicks(){return SCHEMA_TYPE(uintptr_t,0xECC);}
 uintptr_t m_flTransitionStartSpeed(){return SCHEMA_TYPE(uintptr_t,0xED0);}
 uintptr_t m_hConveyorModels(){return SCHEMA_TYPE(uintptr_t,0xED8);}
 uintptr_t m_flCurrentConveyorOffset(){return SCHEMA_TYPE(uintptr_t,0xEF0);}
 uintptr_t m_flCurrentConveyorSpeed(){return SCHEMA_TYPE(uintptr_t,0xEF4);}
};
