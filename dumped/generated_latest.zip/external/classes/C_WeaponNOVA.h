#pragma once
#include "../memory.h"

class C_WeaponNOVA  {
public:
    uintptr_t baseAddr;

    C_WeaponNOVA() { baseAddr = client_base(); }
    C_WeaponNOVA(uintptr_t base) : baseAddr(base) {}

};
