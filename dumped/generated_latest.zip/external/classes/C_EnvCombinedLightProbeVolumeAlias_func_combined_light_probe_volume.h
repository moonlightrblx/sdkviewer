#pragma once
#include "../memory.h"

class C_EnvCombinedLightProbeVolumeAlias_func_combined_light_probe_volume  {
public:
    uintptr_t baseAddr;

    C_EnvCombinedLightProbeVolumeAlias_func_combined_light_probe_volume() { baseAddr = client_base(); }
    C_EnvCombinedLightProbeVolumeAlias_func_combined_light_probe_volume(uintptr_t base) : baseAddr(base) {}

};
