#pragma once
#include "../memory.h"

class C_GameRulesProxy  {
public:
    uintptr_t baseAddr;

    C_GameRulesProxy() { baseAddr = 0; }
    C_GameRulesProxy(uintptr_t base) : baseAddr(base) {}

};
