#pragma once
#include "../memory.h"

class C_SmokeGrenadeProjectile {
public:
 uintptr_t baseAddr;
 C_SmokeGrenadeProjectile() : baseAddr(0){}
 C_SmokeGrenadeProjectile(uintptr_t b):baseAddr(b){}
 uintptr_t m_nSmokeEffectTickBegin(){return SCHEMA_TYPE(uintptr_t,0x1468);}
 uintptr_t m_bDidSmokeEffect(){return SCHEMA_TYPE(uintptr_t,0x146C);}
 uintptr_t m_nRandomSeed(){return SCHEMA_TYPE(uintptr_t,0x1470);}
 uintptr_t m_vSmokeColor(){return SCHEMA_TYPE(uintptr_t,0x1474);}
 uintptr_t m_vSmokeDetonationPos(){return SCHEMA_TYPE(uintptr_t,0x1480);}
 uintptr_t m_VoxelFrameData(){return SCHEMA_TYPE(uintptr_t,0x1490);}
 uintptr_t m_nVoxelFrameDataSize(){return SCHEMA_TYPE(uintptr_t,0x14A8);}
 uintptr_t m_nVoxelUpdate(){return SCHEMA_TYPE(uintptr_t,0x14AC);}
 uintptr_t m_bSmokeVolumeDataReceived(){return SCHEMA_TYPE(uintptr_t,0x14B0);}
 uintptr_t m_bSmokeEffectSpawned(){return SCHEMA_TYPE(uintptr_t,0x14B1);}
};
