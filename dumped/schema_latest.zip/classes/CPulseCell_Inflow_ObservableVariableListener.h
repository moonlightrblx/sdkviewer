#pragma once
#include "../memory.h"

class CPulseCell_Inflow_ObservableVariableListener {
public:
 uintptr_t baseAddr;
 CPulseCell_Inflow_ObservableVariableListener() : baseAddr(0){}
 CPulseCell_Inflow_ObservableVariableListener(uintptr_t b):baseAddr(b){}
 uintptr_t m_nBlackboardReference(){return SCHEMA_TYPE(uintptr_t,0x80);}
 uintptr_t m_bSelfReference(){return SCHEMA_TYPE(uintptr_t,0x82);}
};
