#pragma once
#include "../memory.h"

class CPulseCell_Step_EntFire {
public:
 uintptr_t baseAddr;
 CPulseCell_Step_EntFire() : baseAddr(0){}
 CPulseCell_Step_EntFire(uintptr_t b):baseAddr(b){}
 uintptr_t m_Input(){return SCHEMA_TYPE(uintptr_t,0x48);}
};
