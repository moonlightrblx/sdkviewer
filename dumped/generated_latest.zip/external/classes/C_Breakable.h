#pragma once
#include "../memory.h"

class C_Breakable  {
public:
    uintptr_t baseAddr;

    C_Breakable() { baseAddr = 0; }
    C_Breakable(uintptr_t base) : baseAddr(base) {}

};
