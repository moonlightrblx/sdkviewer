#pragma once
#include "../memory.h"

class C_DynamicPropAlias_prop_dynamic_override  {
public:
    uintptr_t baseAddr;

    C_DynamicPropAlias_prop_dynamic_override() { baseAddr = client_base(); }
    C_DynamicPropAlias_prop_dynamic_override(uintptr_t base) : baseAddr(base) {}

};
