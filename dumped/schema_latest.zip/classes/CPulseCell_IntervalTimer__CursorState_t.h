#pragma once
#include "../memory.h"

class CPulseCell_IntervalTimer__CursorState_t {
public:
 uintptr_t baseAddr;
 CPulseCell_IntervalTimer__CursorState_t() : baseAddr(0){}
 CPulseCell_IntervalTimer__CursorState_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_StartTime(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_EndTime(){return SCHEMA_TYPE(uintptr_t,0x4);}
 uintptr_t m_flWaitInterval(){return SCHEMA_TYPE(uintptr_t,0x8);}
 uintptr_t m_flWaitIntervalHigh(){return SCHEMA_TYPE(uintptr_t,0xC);}
 uintptr_t m_bCompleteOnNextWake(){return SCHEMA_TYPE(uintptr_t,0x10);}
};
