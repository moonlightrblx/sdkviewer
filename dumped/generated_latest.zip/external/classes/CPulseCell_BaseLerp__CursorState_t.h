#pragma once
#include "../memory.h"
#include "../classes/GameTime_t.h"

class CPulseCell_BaseLerp__CursorState_t  {
public:
    uintptr_t baseAddr;

    CPulseCell_BaseLerp__CursorState_t() { baseAddr = 0; }
    CPulseCell_BaseLerp__CursorState_t(uintptr_t base) : baseAddr(base) {}

    GameTime_t m_StartTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("CPulseCell_BaseLerp__CursorState_t", "m_StartTime")); }
    GameTime_t m_EndTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("CPulseCell_BaseLerp__CursorState_t", "m_EndTime")); }
};
