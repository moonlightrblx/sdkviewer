#pragma once
#include "../memory.h"

class C_BaseCSGrenade  {
public:
    uintptr_t baseAddr;

    C_BaseCSGrenade() { baseAddr = client_base(); }
    C_BaseCSGrenade(uintptr_t base) : baseAddr(base) {}

    bool m_bClientPredictDelete() { return read<bool>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_bClientPredictDelete")); }
    bool m_bRedraw() { return read<bool>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_bRedraw")); }
    bool m_bIsHeldByPlayer() { return read<bool>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_bIsHeldByPlayer")); }
    bool m_bPinPulled() { return read<bool>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_bPinPulled")); }
    bool m_bJumpThrow() { return read<bool>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_bJumpThrow")); }
    bool m_bThrowAnimating() { return read<bool>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_bThrowAnimating")); }
    uintptr_t m_fThrowTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_fThrowTime")); }
    float m_flThrowStrength() { return read<float>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_flThrowStrength")); }
    uintptr_t m_fDropTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_fDropTime")); }
    uintptr_t m_fPinPullTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_fPinPullTime")); }
    bool m_bJustPulledPin() { return read<bool>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_bJustPulledPin")); }
    uintptr_t m_nNextHoldTick() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_nNextHoldTick")); }
    float m_flNextHoldFrac() { return read<float>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_flNextHoldFrac")); }
    C_CSWeaponBase* m_hSwitchToWeaponAfterThrow() { return read<C_CSWeaponBase*>(baseAddr + offsets_instance.get("C_BaseCSGrenade", "m_hSwitchToWeaponAfterThrow")); }
};
