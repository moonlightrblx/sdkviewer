#pragma once
#include "../memory.h"

class C_PathParticleRopeAlias_path_particle_rope_clientside {
public:
 uintptr_t baseAddr;
 C_PathParticleRopeAlias_path_particle_rope_clientside() : baseAddr(0){}
 C_PathParticleRopeAlias_path_particle_rope_clientside(uintptr_t b):baseAddr(b){}
};
