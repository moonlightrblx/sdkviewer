#pragma once
#include "../memory.h"

class C_FogController  {
public:
    uintptr_t baseAddr;

    C_FogController() { baseAddr = client_base(); }
    C_FogController(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_fog() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_FogController", "m_fog")); }
    bool m_bUseAngles() { return read<bool>(baseAddr + offsets_instance.get("C_FogController", "m_bUseAngles")); }
    int m_iChangedVariables() { return read<int>(baseAddr + offsets_instance.get("C_FogController", "m_iChangedVariables")); }
};
