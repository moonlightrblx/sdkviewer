#pragma once
#include "../memory.h"

class C_PointCommentaryNode {
public:
 uintptr_t baseAddr;
 C_PointCommentaryNode() : baseAddr(0){}
 C_PointCommentaryNode(uintptr_t b):baseAddr(b){}
 uintptr_t m_bActive(){return SCHEMA_TYPE(uintptr_t,0x1170);}
 uintptr_t m_bWasActive(){return SCHEMA_TYPE(uintptr_t,0x1171);}
 uintptr_t m_flEndTime(){return SCHEMA_TYPE(uintptr_t,0x1174);}
 uintptr_t m_flStartTime(){return SCHEMA_TYPE(uintptr_t,0x1178);}
 uintptr_t m_flStartTimeInCommentary(){return SCHEMA_TYPE(uintptr_t,0x117C);}
 uintptr_t m_iszCommentaryFile(){return SCHEMA_TYPE(uintptr_t,0x1180);}
 uintptr_t m_iszTitle(){return SCHEMA_TYPE(uintptr_t,0x1188);}
 uintptr_t m_iszSpeakers(){return SCHEMA_TYPE(uintptr_t,0x1190);}
 uintptr_t m_iNodeNumber(){return SCHEMA_TYPE(uintptr_t,0x1198);}
 uintptr_t m_iNodeNumberMax(){return SCHEMA_TYPE(uintptr_t,0x119C);}
 uintptr_t m_bListenedTo(){return SCHEMA_TYPE(uintptr_t,0x11A0);}
 uintptr_t m_hViewPosition(){return SCHEMA_TYPE(uintptr_t,0x11B0);}
 uintptr_t m_bRestartAfterRestore(){return SCHEMA_TYPE(uintptr_t,0x11B4);}
};
