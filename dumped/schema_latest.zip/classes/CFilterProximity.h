#pragma once
#include "../memory.h"

class CFilterProximity {
public:
 uintptr_t baseAddr;
 CFilterProximity() : baseAddr(0){}
 CFilterProximity(uintptr_t b):baseAddr(b){}
 uintptr_t m_flRadius(){return SCHEMA_TYPE(uintptr_t,0x650);}
};
