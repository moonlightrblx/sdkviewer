#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class PulseNodeDynamicOutflows_t  {
public:
    uintptr_t baseAddr;

    PulseNodeDynamicOutflows_t() { baseAddr = client_base(); }
    PulseNodeDynamicOutflows_t(uintptr_t base) : baseAddr(base) {}

    Vector3 m_Outflows() { return read<Vector3>(baseAddr + offsets_instance.get("PulseNodeDynamicOutflows_t", "m_Outflows")); }
};
