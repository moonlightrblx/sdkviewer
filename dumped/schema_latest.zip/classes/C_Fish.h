#pragma once
#include "../memory.h"

class C_Fish {
public:
 uintptr_t baseAddr;
 C_Fish() : baseAddr(0){}
 C_Fish(uintptr_t b):baseAddr(b){}
 uintptr_t m_pos(){return SCHEMA_TYPE(uintptr_t,0x1158);}
 uintptr_t m_vel(){return SCHEMA_TYPE(uintptr_t,0x1164);}
 uintptr_t m_angles(){return SCHEMA_TYPE(uintptr_t,0x1170);}
 uintptr_t m_localLifeState(){return SCHEMA_TYPE(uintptr_t,0x117C);}
 uintptr_t m_deathDepth(){return SCHEMA_TYPE(uintptr_t,0x1180);}
 uintptr_t m_deathAngle(){return SCHEMA_TYPE(uintptr_t,0x1184);}
 uintptr_t m_buoyancy(){return SCHEMA_TYPE(uintptr_t,0x1188);}
 uintptr_t m_wiggleTimer(){return SCHEMA_TYPE(uintptr_t,0x1190);}
 uintptr_t m_wigglePhase(){return SCHEMA_TYPE(uintptr_t,0x11A8);}
 uintptr_t m_wiggleRate(){return SCHEMA_TYPE(uintptr_t,0x11AC);}
 uintptr_t m_actualPos(){return SCHEMA_TYPE(uintptr_t,0x11B0);}
 uintptr_t m_actualAngles(){return SCHEMA_TYPE(uintptr_t,0x11BC);}
 uintptr_t m_poolOrigin(){return SCHEMA_TYPE(uintptr_t,0x11C8);}
 uintptr_t m_waterLevel(){return SCHEMA_TYPE(uintptr_t,0x11D4);}
 uintptr_t m_gotUpdate(){return SCHEMA_TYPE(uintptr_t,0x11D8);}
 uintptr_t m_x(){return SCHEMA_TYPE(uintptr_t,0x11DC);}
 uintptr_t m_y(){return SCHEMA_TYPE(uintptr_t,0x11E0);}
 uintptr_t m_z(){return SCHEMA_TYPE(uintptr_t,0x11E4);}
 uintptr_t m_angle(){return SCHEMA_TYPE(uintptr_t,0x11E8);}
 uintptr_t m_errorHistory(){return SCHEMA_TYPE(uintptr_t,0x11EC);}
 uintptr_t m_errorHistoryIndex(){return SCHEMA_TYPE(uintptr_t,0x123C);}
 uintptr_t m_errorHistoryCount(){return SCHEMA_TYPE(uintptr_t,0x1240);}
 uintptr_t m_averageError(){return SCHEMA_TYPE(uintptr_t,0x1244);}
};
