#pragma once
#include "../memory.h"

class CAnimGraphNetworkedVariables {
public:
 uintptr_t baseAddr;
 CAnimGraphNetworkedVariables() : baseAddr(0){}
 CAnimGraphNetworkedVariables(uintptr_t b):baseAddr(b){}
 uintptr_t m_PredNetBoolVariables(){return SCHEMA_TYPE(uintptr_t,0x8);}
 uintptr_t m_PredNetByteVariables(){return SCHEMA_TYPE(uintptr_t,0x20);}
 uintptr_t m_PredNetUInt16Variables(){return SCHEMA_TYPE(uintptr_t,0x38);}
 uintptr_t m_PredNetIntVariables(){return SCHEMA_TYPE(uintptr_t,0x50);}
 uintptr_t m_PredNetUInt32Variables(){return SCHEMA_TYPE(uintptr_t,0x68);}
 uintptr_t m_PredNetUInt64Variables(){return SCHEMA_TYPE(uintptr_t,0x80);}
 uintptr_t m_PredNetFloatVariables(){return SCHEMA_TYPE(uintptr_t,0x98);}
 uintptr_t m_PredNetVectorVariables(){return SCHEMA_TYPE(uintptr_t,0xB0);}
 uintptr_t m_PredNetQuaternionVariables(){return SCHEMA_TYPE(uintptr_t,0xC8);}
 uintptr_t m_PredNetGlobalSymbolVariables(){return SCHEMA_TYPE(uintptr_t,0xE0);}
 uintptr_t m_OwnerOnlyPredNetBoolVariables(){return SCHEMA_TYPE(uintptr_t,0xF8);}
 uintptr_t m_OwnerOnlyPredNetByteVariables(){return SCHEMA_TYPE(uintptr_t,0x110);}
 uintptr_t m_OwnerOnlyPredNetUInt16Variables(){return SCHEMA_TYPE(uintptr_t,0x128);}
 uintptr_t m_OwnerOnlyPredNetIntVariables(){return SCHEMA_TYPE(uintptr_t,0x140);}
 uintptr_t m_OwnerOnlyPredNetUInt32Variables(){return SCHEMA_TYPE(uintptr_t,0x158);}
 uintptr_t m_OwnerOnlyPredNetUInt64Variables(){return SCHEMA_TYPE(uintptr_t,0x170);}
 uintptr_t m_OwnerOnlyPredNetFloatVariables(){return SCHEMA_TYPE(uintptr_t,0x188);}
 uintptr_t m_OwnerOnlyPredNetVectorVariables(){return SCHEMA_TYPE(uintptr_t,0x1A0);}
 uintptr_t m_OwnerOnlyPredNetQuaternionVariables(){return SCHEMA_TYPE(uintptr_t,0x1B8);}
 uintptr_t m_OwnerOnlyPredNetGlobalSymbolVariables(){return SCHEMA_TYPE(uintptr_t,0x1D0);}
 uintptr_t m_nBoolVariablesCount(){return SCHEMA_TYPE(uintptr_t,0x1E8);}
 uintptr_t m_nOwnerOnlyBoolVariablesCount(){return SCHEMA_TYPE(uintptr_t,0x1EC);}
 uintptr_t m_nRandomSeedOffset(){return SCHEMA_TYPE(uintptr_t,0x1F0);}
 uintptr_t m_flLastTeleportTime(){return SCHEMA_TYPE(uintptr_t,0x1F4);}
};
