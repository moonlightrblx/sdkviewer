#pragma once
#include "../memory.h"

class C_EnvDetailController {
public:
 uintptr_t baseAddr;
 C_EnvDetailController() : baseAddr(0){}
 C_EnvDetailController(uintptr_t b):baseAddr(b){}
 uintptr_t m_flFadeStartDist(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_flFadeEndDist(){return SCHEMA_TYPE(uintptr_t,0x5FC);}
};
