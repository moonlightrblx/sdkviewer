#pragma once
#include "../memory.h"

class C_CS2HudModelArms {
public:
 uintptr_t baseAddr;
 C_CS2HudModelArms() : baseAddr(0){}
 C_CS2HudModelArms(uintptr_t b):baseAddr(b){}
};
