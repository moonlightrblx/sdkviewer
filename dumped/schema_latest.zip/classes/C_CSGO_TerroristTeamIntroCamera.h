#pragma once
#include "../memory.h"

class C_CSGO_TerroristTeamIntroCamera {
public:
 uintptr_t baseAddr;
 C_CSGO_TerroristTeamIntroCamera() : baseAddr(0){}
 C_CSGO_TerroristTeamIntroCamera(uintptr_t b):baseAddr(b){}
};
