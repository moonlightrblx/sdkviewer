#pragma once
#include "../memory.h"

class EventClientPauseSimulate_t {
public:
 uintptr_t baseAddr;
 EventClientPauseSimulate_t() : baseAddr(0){}
 EventClientPauseSimulate_t(uintptr_t b):baseAddr(b){}
};
