#pragma once
#include "../memory.h"

class C_TonemapController2 {
public:
 uintptr_t baseAddr;
 C_TonemapController2() : baseAddr(0){}
 C_TonemapController2(uintptr_t b):baseAddr(b){}
 uintptr_t m_flAutoExposureMin(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_flAutoExposureMax(){return SCHEMA_TYPE(uintptr_t,0x5FC);}
 uintptr_t m_flExposureAdaptationSpeedUp(){return SCHEMA_TYPE(uintptr_t,0x600);}
 uintptr_t m_flExposureAdaptationSpeedDown(){return SCHEMA_TYPE(uintptr_t,0x604);}
 uintptr_t m_flTonemapEVSmoothingRange(){return SCHEMA_TYPE(uintptr_t,0x608);}
};
