#pragma once
#include "../memory.h"

class CPulseCell_Inflow_BaseEntrypoint  {
public:
    uintptr_t baseAddr;

    CPulseCell_Inflow_BaseEntrypoint() { baseAddr = client_base(); }
    CPulseCell_Inflow_BaseEntrypoint(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_EntryChunk() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Inflow_BaseEntrypoint", "m_EntryChunk")); }
    uintptr_t m_RegisterMap() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Inflow_BaseEntrypoint", "m_RegisterMap")); }
};
