#pragma once
#include "../memory.h"
#include "../classes/PulseSelectorOutflowList_t.h"

class CPulseCell_PickBestOutflowSelector  {
public:
    uintptr_t baseAddr;

    CPulseCell_PickBestOutflowSelector() { baseAddr = 0; }
    CPulseCell_PickBestOutflowSelector(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_nCheckType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_PickBestOutflowSelector", "m_nCheckType")); }
    PulseSelectorOutflowList_t m_OutflowList() { return read<PulseSelectorOutflowList_t>(baseAddr + offsets_instance.get("CPulseCell_PickBestOutflowSelector", "m_OutflowList")); }
};
