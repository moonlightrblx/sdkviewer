#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class CPulseGraphDef  {
public:
    uintptr_t baseAddr;

    CPulseGraphDef() { baseAddr = 0; }
    CPulseGraphDef(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_DomainIdentifier() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseGraphDef", "m_DomainIdentifier")); }
    uintptr_t m_DomainSubType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseGraphDef", "m_DomainSubType")); }
    uintptr_t m_ParentMapName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseGraphDef", "m_ParentMapName")); }
    uintptr_t m_ParentXmlName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseGraphDef", "m_ParentXmlName")); }
    Vector3 m_Chunks() { return read<Vector3>(baseAddr + offsets_instance.get("CPulseGraphDef", "m_Chunks")); }
    Vector3 m_Cells() { return read<Vector3>(baseAddr + offsets_instance.get("CPulseGraphDef", "m_Cells")); }
    Vector3 m_Vars() { return read<Vector3>(baseAddr + offsets_instance.get("CPulseGraphDef", "m_Vars")); }
    Vector3 m_PublicOutputs() { return read<Vector3>(baseAddr + offsets_instance.get("CPulseGraphDef", "m_PublicOutputs")); }
    Vector3 m_InvokeBindings() { return read<Vector3>(baseAddr + offsets_instance.get("CPulseGraphDef", "m_InvokeBindings")); }
    Vector3 m_CallInfos() { return read<Vector3>(baseAddr + offsets_instance.get("CPulseGraphDef", "m_CallInfos")); }
    Vector3 m_Constants() { return read<Vector3>(baseAddr + offsets_instance.get("CPulseGraphDef", "m_Constants")); }
    Vector3 m_DomainValues() { return read<Vector3>(baseAddr + offsets_instance.get("CPulseGraphDef", "m_DomainValues")); }
    Vector3 m_BlackboardReferences() { return read<Vector3>(baseAddr + offsets_instance.get("CPulseGraphDef", "m_BlackboardReferences")); }
    Vector3 m_OutputConnections() { return read<Vector3>(baseAddr + offsets_instance.get("CPulseGraphDef", "m_OutputConnections")); }
};
