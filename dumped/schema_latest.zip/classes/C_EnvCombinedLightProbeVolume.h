#pragma once
#include "../memory.h"

class C_EnvCombinedLightProbeVolume {
public:
 uintptr_t baseAddr;
 C_EnvCombinedLightProbeVolume() : baseAddr(0){}
 C_EnvCombinedLightProbeVolume(uintptr_t b):baseAddr(b){}
 uintptr_t m_Entity_Color(){return SCHEMA_TYPE(uintptr_t,0x1670);}
 uintptr_t m_Entity_flBrightness(){return SCHEMA_TYPE(uintptr_t,0x1674);}
 uintptr_t m_Entity_hCubemapTexture(){return SCHEMA_TYPE(uintptr_t,0x1678);}
 uintptr_t m_Entity_bCustomCubemapTexture(){return SCHEMA_TYPE(uintptr_t,0x1680);}
 uintptr_t m_Entity_hLightProbeTexture_AmbientCube(){return SCHEMA_TYPE(uintptr_t,0x1688);}
 uintptr_t m_Entity_hLightProbeTexture_SDF(){return SCHEMA_TYPE(uintptr_t,0x1690);}
 uintptr_t m_Entity_hLightProbeTexture_SH2_DC(){return SCHEMA_TYPE(uintptr_t,0x1698);}
 uintptr_t m_Entity_hLightProbeTexture_SH2_R(){return SCHEMA_TYPE(uintptr_t,0x16A0);}
 uintptr_t m_Entity_hLightProbeTexture_SH2_G(){return SCHEMA_TYPE(uintptr_t,0x16A8);}
 uintptr_t m_Entity_hLightProbeTexture_SH2_B(){return SCHEMA_TYPE(uintptr_t,0x16B0);}
 uintptr_t m_Entity_hLightProbeDirectLightIndicesTexture(){return SCHEMA_TYPE(uintptr_t,0x16B8);}
 uintptr_t m_Entity_hLightProbeDirectLightScalarsTexture(){return SCHEMA_TYPE(uintptr_t,0x16C0);}
 uintptr_t m_Entity_hLightProbeDirectLightShadowsTexture(){return SCHEMA_TYPE(uintptr_t,0x16C8);}
 uintptr_t m_Entity_vBoxMins(){return SCHEMA_TYPE(uintptr_t,0x16D0);}
 uintptr_t m_Entity_vBoxMaxs(){return SCHEMA_TYPE(uintptr_t,0x16DC);}
 uintptr_t m_Entity_bMoveable(){return SCHEMA_TYPE(uintptr_t,0x16E8);}
 uintptr_t m_Entity_nHandshake(){return SCHEMA_TYPE(uintptr_t,0x16EC);}
 uintptr_t m_Entity_nEnvCubeMapArrayIndex(){return SCHEMA_TYPE(uintptr_t,0x16F0);}
 uintptr_t m_Entity_nPriority(){return SCHEMA_TYPE(uintptr_t,0x16F4);}
 uintptr_t m_Entity_bStartDisabled(){return SCHEMA_TYPE(uintptr_t,0x16F8);}
 uintptr_t m_Entity_flEdgeFadeDist(){return SCHEMA_TYPE(uintptr_t,0x16FC);}
 uintptr_t m_Entity_vEdgeFadeDists(){return SCHEMA_TYPE(uintptr_t,0x1700);}
 uintptr_t m_Entity_nLightProbeSizeX(){return SCHEMA_TYPE(uintptr_t,0x170C);}
 uintptr_t m_Entity_nLightProbeSizeY(){return SCHEMA_TYPE(uintptr_t,0x1710);}
 uintptr_t m_Entity_nLightProbeSizeZ(){return SCHEMA_TYPE(uintptr_t,0x1714);}
 uintptr_t m_Entity_nLightProbeAtlasX(){return SCHEMA_TYPE(uintptr_t,0x1718);}
 uintptr_t m_Entity_nLightProbeAtlasY(){return SCHEMA_TYPE(uintptr_t,0x171C);}
 uintptr_t m_Entity_nLightProbeAtlasZ(){return SCHEMA_TYPE(uintptr_t,0x1720);}
 uintptr_t m_Entity_bEnabled(){return SCHEMA_TYPE(uintptr_t,0x1739);}
};
