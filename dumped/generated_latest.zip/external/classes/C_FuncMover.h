#pragma once
#include "../memory.h"

class C_FuncMover  {
public:
    uintptr_t baseAddr;

    C_FuncMover() { baseAddr = 0; }
    C_FuncMover(uintptr_t base) : baseAddr(base) {}

};
