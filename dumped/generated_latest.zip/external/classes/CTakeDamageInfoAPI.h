#pragma once
#include "../memory.h"

class CTakeDamageInfoAPI  {
public:
    uintptr_t baseAddr;

    CTakeDamageInfoAPI() { baseAddr = client_base(); }
    CTakeDamageInfoAPI(uintptr_t base) : baseAddr(base) {}

};
