#pragma once
#include "../memory.h"
#include "../classes/GameTime_t.h"
class C_BaseEntity;

class C_PointCommentaryNode  {
public:
    uintptr_t baseAddr;

    C_PointCommentaryNode() { baseAddr = 0; }
    C_PointCommentaryNode(uintptr_t base) : baseAddr(base) {}

    bool m_bActive() { return read<bool>(baseAddr + offsets_instance.get("C_PointCommentaryNode", "m_bActive")); }
    bool m_bWasActive() { return read<bool>(baseAddr + offsets_instance.get("C_PointCommentaryNode", "m_bWasActive")); }
    GameTime_t m_flEndTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_PointCommentaryNode", "m_flEndTime")); }
    GameTime_t m_flStartTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_PointCommentaryNode", "m_flStartTime")); }
    float m_flStartTimeInCommentary() { return read<float>(baseAddr + offsets_instance.get("C_PointCommentaryNode", "m_flStartTimeInCommentary")); }
    uintptr_t m_iszCommentaryFile() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_PointCommentaryNode", "m_iszCommentaryFile")); }
    uintptr_t m_iszTitle() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_PointCommentaryNode", "m_iszTitle")); }
    uintptr_t m_iszSpeakers() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_PointCommentaryNode", "m_iszSpeakers")); }
    int m_iNodeNumber() { return read<int>(baseAddr + offsets_instance.get("C_PointCommentaryNode", "m_iNodeNumber")); }
    int m_iNodeNumberMax() { return read<int>(baseAddr + offsets_instance.get("C_PointCommentaryNode", "m_iNodeNumberMax")); }
    bool m_bListenedTo() { return read<bool>(baseAddr + offsets_instance.get("C_PointCommentaryNode", "m_bListenedTo")); }
    C_BaseEntity* m_hViewPosition() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_PointCommentaryNode", "m_hViewPosition")); }
    bool m_bRestartAfterRestore() { return read<bool>(baseAddr + offsets_instance.get("C_PointCommentaryNode", "m_bRestartAfterRestore")); }
};
