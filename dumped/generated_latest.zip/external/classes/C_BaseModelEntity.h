#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_BaseModelEntity  {
public:
    uintptr_t baseAddr;

    C_BaseModelEntity() { baseAddr = client_base(); }
    C_BaseModelEntity(uintptr_t base) : baseAddr(base) {}

    CRenderComponent* m_CRenderComponent() { return read<CRenderComponent*>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_CRenderComponent")); }
    uintptr_t m_CHitboxComponent() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_CHitboxComponent")); }
    CDestructiblePartsComponent* m_pDestructiblePartsSystemComponent() { return read<CDestructiblePartsComponent*>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_pDestructiblePartsSystemComponent")); }
    uintptr_t m_LastHitGroup() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_LastHitGroup")); }
    uintptr_t m_sLastDamageSourceName() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_sLastDamageSourceName")); }
    Vector3 m_vLastDamagePosition() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_vLastDamagePosition")); }
    bool m_bInitModelEffects() { return read<bool>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_bInitModelEffects")); }
    bool m_bIsStaticProp() { return read<bool>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_bIsStaticProp")); }
    int m_nLastAddDecal() { return read<int>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_nLastAddDecal")); }
    int m_nDecalsAdded() { return read<int>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_nDecalsAdded")); }
    int m_iOldHealth() { return read<int>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_iOldHealth")); }
    uintptr_t m_nRenderMode() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_nRenderMode")); }
    uintptr_t m_nRenderFX() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_nRenderFX")); }
    bool m_bAllowFadeInView() { return read<bool>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_bAllowFadeInView")); }
    uintptr_t m_clrRender() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_clrRender")); }
    Vector3 m_vecRenderAttributes() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_vecRenderAttributes")); }
    bool m_bRenderToCubemaps() { return read<bool>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_bRenderToCubemaps")); }
    bool m_bNoInterpolate() { return read<bool>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_bNoInterpolate")); }
    uintptr_t m_Collision() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_Collision")); }
    uintptr_t m_Glow() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_Glow")); }
    float m_flGlowBackfaceMult() { return read<float>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_flGlowBackfaceMult")); }
    float m_fadeMinDist() { return read<float>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_fadeMinDist")); }
    float m_fadeMaxDist() { return read<float>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_fadeMaxDist")); }
    float m_flFadeScale() { return read<float>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_flFadeScale")); }
    float m_flShadowStrength() { return read<float>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_flShadowStrength")); }
    uint8_t m_nObjectCulling() { return read<uint8_t>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_nObjectCulling")); }
    int m_nAddDecal() { return read<int>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_nAddDecal")); }
    Vector3 m_vDecalPosition() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_vDecalPosition")); }
    Vector3 m_vDecalForwardAxis() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_vDecalForwardAxis")); }
    uintptr_t m_nDecalMode() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_nDecalMode")); }
    uintptr_t m_nRequiredDecalMode() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_nRequiredDecalMode")); }
    Vector3 m_ConfigEntitiesToPropagateMaterialDecalsTo() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_ConfigEntitiesToPropagateMaterialDecalsTo")); }
    Vector3 m_vecViewOffset() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_vecViewOffset")); }
    uintptr_t* m_pClientAlphaProperty() { return read<uintptr_t*>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_pClientAlphaProperty")); }
    uintptr_t m_ClientOverrideTint() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_ClientOverrideTint")); }
    bool m_bUseClientOverrideTint() { return read<bool>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_bUseClientOverrideTint")); }
    int m_bvDisabledHitGroups() { return read<int>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_bvDisabledHitGroups")); }
};
