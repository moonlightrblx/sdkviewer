#pragma once
#include "../memory.h"

class CCSPlayer_PingServices {
public:
 uintptr_t baseAddr;
 CCSPlayer_PingServices() : baseAddr(0){}
 CCSPlayer_PingServices(uintptr_t b):baseAddr(b){}
 uintptr_t m_hPlayerPing(){return SCHEMA_TYPE(uintptr_t,0x40);}
};
