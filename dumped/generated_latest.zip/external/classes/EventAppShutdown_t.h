#pragma once
#include "../memory.h"

class EventAppShutdown_t  {
public:
    uintptr_t baseAddr;

    EventAppShutdown_t() { baseAddr = 0; }
    EventAppShutdown_t(uintptr_t base) : baseAddr(base) {}

    int m_nDummy0() { return read<int>(baseAddr + offsets_instance.get("EventAppShutdown_t", "m_nDummy0")); }
};
