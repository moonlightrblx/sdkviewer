#pragma once
#include "../memory.h"

class CBasePlayerWeaponVData  {
public:
    uintptr_t baseAddr;

    CBasePlayerWeaponVData() { baseAddr = client_base(); }
    CBasePlayerWeaponVData(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_szWorldModel() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_szWorldModel")); }
    uintptr_t m_sToolsOnlyOwnerModelName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_sToolsOnlyOwnerModelName")); }
    bool m_bBuiltRightHanded() { return read<bool>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_bBuiltRightHanded")); }
    bool m_bAllowFlipping() { return read<bool>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_bAllowFlipping")); }
    uintptr_t m_sMuzzleAttachment() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_sMuzzleAttachment")); }
    uintptr_t m_szMuzzleFlashParticle() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_szMuzzleFlashParticle")); }
    uintptr_t m_szMuzzleFlashParticleConfig() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_szMuzzleFlashParticleConfig")); }
    uintptr_t m_szBarrelSmokeParticle() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_szBarrelSmokeParticle")); }
    uint8_t m_nMuzzleSmokeShotThreshold() { return read<uint8_t>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_nMuzzleSmokeShotThreshold")); }
    float m_flMuzzleSmokeTimeout() { return read<float>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_flMuzzleSmokeTimeout")); }
    float m_flMuzzleSmokeDecrementRate() { return read<float>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_flMuzzleSmokeDecrementRate")); }
    bool m_bLinkedCooldowns() { return read<bool>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_bLinkedCooldowns")); }
    uintptr_t m_iFlags() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_iFlags")); }
    uintptr_t m_nPrimaryAmmoType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_nPrimaryAmmoType")); }
    uintptr_t m_nSecondaryAmmoType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_nSecondaryAmmoType")); }
    int m_iMaxClip1() { return read<int>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_iMaxClip1")); }
    int m_iMaxClip2() { return read<int>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_iMaxClip2")); }
    int m_iDefaultClip1() { return read<int>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_iDefaultClip1")); }
    int m_iDefaultClip2() { return read<int>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_iDefaultClip2")); }
    bool m_bReserveAmmoAsClips() { return read<bool>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_bReserveAmmoAsClips")); }
    bool m_bTreatAsSingleClip() { return read<bool>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_bTreatAsSingleClip")); }
    bool m_bKeepLoadedAmmo() { return read<bool>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_bKeepLoadedAmmo")); }
    int m_iWeight() { return read<int>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_iWeight")); }
    bool m_bAutoSwitchTo() { return read<bool>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_bAutoSwitchTo")); }
    bool m_bAutoSwitchFrom() { return read<bool>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_bAutoSwitchFrom")); }
    uintptr_t m_iRumbleEffect() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_iRumbleEffect")); }
    float m_flDropSpeed() { return read<float>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_flDropSpeed")); }
    int m_iSlot() { return read<int>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_iSlot")); }
    int m_iPosition() { return read<int>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_iPosition")); }
    uintptr_t m_aShootSounds() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBasePlayerWeaponVData", "m_aShootSounds")); }
};
