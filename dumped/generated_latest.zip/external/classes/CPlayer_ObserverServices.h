#pragma once
#include "../memory.h"
#include "../classes/GameTime_t.h"
class C_BaseEntity;

class CPlayer_ObserverServices  {
public:
    uintptr_t baseAddr;

    CPlayer_ObserverServices() { baseAddr = 0; }
    CPlayer_ObserverServices(uintptr_t base) : baseAddr(base) {}

    uint8_t m_iObserverMode() { return read<uint8_t>(baseAddr + offsets_instance.get("CPlayer_ObserverServices", "m_iObserverMode")); }
    C_BaseEntity* m_hObserverTarget() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("CPlayer_ObserverServices", "m_hObserverTarget")); }
    uintptr_t m_iObserverLastMode() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPlayer_ObserverServices", "m_iObserverLastMode")); }
    bool m_bForcedObserverMode() { return read<bool>(baseAddr + offsets_instance.get("CPlayer_ObserverServices", "m_bForcedObserverMode")); }
    float m_flObserverChaseDistance() { return read<float>(baseAddr + offsets_instance.get("CPlayer_ObserverServices", "m_flObserverChaseDistance")); }
    GameTime_t m_flObserverChaseDistanceCalcTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("CPlayer_ObserverServices", "m_flObserverChaseDistanceCalcTime")); }
};
