#pragma once
#include "../memory.h"
#include "../classes/CBuoyancyHelper.h"

class C_TriggerBuoyancy  {
public:
    uintptr_t baseAddr;

    C_TriggerBuoyancy() { baseAddr = 0; }
    C_TriggerBuoyancy(uintptr_t base) : baseAddr(base) {}

    CBuoyancyHelper m_BuoyancyHelper() { return read<CBuoyancyHelper>(baseAddr + offsets_instance.get("C_TriggerBuoyancy", "m_BuoyancyHelper")); }
    float m_flFluidDensity() { return read<float>(baseAddr + offsets_instance.get("C_TriggerBuoyancy", "m_flFluidDensity")); }
};
