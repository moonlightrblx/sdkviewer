#pragma once
#include "../memory.h"

class CCSGameModeRules_ArmsRace {
public:
 uintptr_t baseAddr;
 CCSGameModeRules_ArmsRace() : baseAddr(0){}
 CCSGameModeRules_ArmsRace(uintptr_t b):baseAddr(b){}
 uintptr_t m_WeaponSequence(){return SCHEMA_TYPE(uintptr_t,0x30);}
};
