#pragma once
#include "../memory.h"

class C_WeaponSCAR20 {
public:
 uintptr_t baseAddr;
 C_WeaponSCAR20() : baseAddr(0){}
 C_WeaponSCAR20(uintptr_t b):baseAddr(b){}
};
