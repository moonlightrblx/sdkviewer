#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_CSGameRules  {
public:
    uintptr_t baseAddr;

    C_CSGameRules() { baseAddr = client_base(); }
    C_CSGameRules(uintptr_t base) : baseAddr(base) {}

    bool m_bFreezePeriod() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bFreezePeriod")); }
    bool m_bWarmupPeriod() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bWarmupPeriod")); }
    uintptr_t m_fWarmupPeriodEnd() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSGameRules", "m_fWarmupPeriodEnd")); }
    uintptr_t m_fWarmupPeriodStart() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSGameRules", "m_fWarmupPeriodStart")); }
    bool m_bTerroristTimeOutActive() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bTerroristTimeOutActive")); }
    bool m_bCTTimeOutActive() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bCTTimeOutActive")); }
    float m_flTerroristTimeOutRemaining() { return read<float>(baseAddr + offsets_instance.get("C_CSGameRules", "m_flTerroristTimeOutRemaining")); }
    float m_flCTTimeOutRemaining() { return read<float>(baseAddr + offsets_instance.get("C_CSGameRules", "m_flCTTimeOutRemaining")); }
    int m_nTerroristTimeOuts() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_nTerroristTimeOuts")); }
    int m_nCTTimeOuts() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_nCTTimeOuts")); }
    bool m_bTechnicalTimeOut() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bTechnicalTimeOut")); }
    bool m_bMatchWaitingForResume() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bMatchWaitingForResume")); }
    int m_iFreezeTime() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_iFreezeTime")); }
    int m_iRoundTime() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_iRoundTime")); }
    float m_fMatchStartTime() { return read<float>(baseAddr + offsets_instance.get("C_CSGameRules", "m_fMatchStartTime")); }
    uintptr_t m_fRoundStartTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSGameRules", "m_fRoundStartTime")); }
    uintptr_t m_flRestartRoundTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSGameRules", "m_flRestartRoundTime")); }
    bool m_bGameRestart() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bGameRestart")); }
    float m_flGameStartTime() { return read<float>(baseAddr + offsets_instance.get("C_CSGameRules", "m_flGameStartTime")); }
    float m_timeUntilNextPhaseStarts() { return read<float>(baseAddr + offsets_instance.get("C_CSGameRules", "m_timeUntilNextPhaseStarts")); }
    int m_gamePhase() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_gamePhase")); }
    int m_totalRoundsPlayed() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_totalRoundsPlayed")); }
    int m_nRoundsPlayedThisPhase() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_nRoundsPlayedThisPhase")); }
    int m_nOvertimePlaying() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_nOvertimePlaying")); }
    int m_iHostagesRemaining() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_iHostagesRemaining")); }
    bool m_bAnyHostageReached() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bAnyHostageReached")); }
    bool m_bMapHasBombTarget() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bMapHasBombTarget")); }
    bool m_bMapHasRescueZone() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bMapHasRescueZone")); }
    bool m_bMapHasBuyZone() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bMapHasBuyZone")); }
    bool m_bIsQueuedMatchmaking() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bIsQueuedMatchmaking")); }
    int m_nQueuedMatchmakingMode() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_nQueuedMatchmakingMode")); }
    bool m_bIsValveDS() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bIsValveDS")); }
    bool m_bLogoMap() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bLogoMap")); }
    bool m_bPlayAllStepSoundsOnServer() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bPlayAllStepSoundsOnServer")); }
    int m_iSpectatorSlotCount() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_iSpectatorSlotCount")); }
    int m_MatchDevice() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_MatchDevice")); }
    bool m_bHasMatchStarted() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bHasMatchStarted")); }
    int m_nNextMapInMapgroup() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_nNextMapInMapgroup")); }
    char* m_szTournamentEventName() { return read<char*>(baseAddr + offsets_instance.get("C_CSGameRules", "m_szTournamentEventName")); }
    char* m_szTournamentEventStage() { return read<char*>(baseAddr + offsets_instance.get("C_CSGameRules", "m_szTournamentEventStage")); }
    char* m_szMatchStatTxt() { return read<char*>(baseAddr + offsets_instance.get("C_CSGameRules", "m_szMatchStatTxt")); }
    char* m_szTournamentPredictionsTxt() { return read<char*>(baseAddr + offsets_instance.get("C_CSGameRules", "m_szTournamentPredictionsTxt")); }
    int m_nTournamentPredictionsPct() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_nTournamentPredictionsPct")); }
    uintptr_t m_flCMMItemDropRevealStartTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSGameRules", "m_flCMMItemDropRevealStartTime")); }
    uintptr_t m_flCMMItemDropRevealEndTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSGameRules", "m_flCMMItemDropRevealEndTime")); }
    bool m_bIsDroppingItems() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bIsDroppingItems")); }
    bool m_bIsQuestEligible() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bIsQuestEligible")); }
    bool m_bIsHltvActive() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bIsHltvActive")); }
    uint16_t m_arrProhibitedItemIndices() { return read<uint16_t>(baseAddr + offsets_instance.get("C_CSGameRules", "m_arrProhibitedItemIndices")); }
    int m_arrTournamentActiveCasterAccounts() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_arrTournamentActiveCasterAccounts")); }
    int m_numBestOfMaps() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_numBestOfMaps")); }
    int m_nHalloweenMaskListSeed() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_nHalloweenMaskListSeed")); }
    bool m_bBombDropped() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bBombDropped")); }
    bool m_bBombPlanted() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bBombPlanted")); }
    int m_iRoundWinStatus() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_iRoundWinStatus")); }
    int m_eRoundWinReason() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_eRoundWinReason")); }
    bool m_bTCantBuy() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bTCantBuy")); }
    bool m_bCTCantBuy() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bCTCantBuy")); }
    int m_iMatchStats_RoundResults() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_iMatchStats_RoundResults")); }
    int m_iMatchStats_PlayersAlive_CT() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_iMatchStats_PlayersAlive_CT")); }
    int m_iMatchStats_PlayersAlive_T() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_iMatchStats_PlayersAlive_T")); }
    float m_TeamRespawnWaveTimes() { return read<float>(baseAddr + offsets_instance.get("C_CSGameRules", "m_TeamRespawnWaveTimes")); }
    uintptr_t m_flNextRespawnWave() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSGameRules", "m_flNextRespawnWave")); }
    Vector3 m_vMinimapMins() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSGameRules", "m_vMinimapMins")); }
    Vector3 m_vMinimapMaxs() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSGameRules", "m_vMinimapMaxs")); }
    float m_MinimapVerticalSectionHeights() { return read<float>(baseAddr + offsets_instance.get("C_CSGameRules", "m_MinimapVerticalSectionHeights")); }
    uintptr_t m_ullLocalMatchID() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSGameRules", "m_ullLocalMatchID")); }
    int m_nEndMatchMapGroupVoteTypes() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_nEndMatchMapGroupVoteTypes")); }
    int m_nEndMatchMapGroupVoteOptions() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_nEndMatchMapGroupVoteOptions")); }
    int m_nEndMatchMapVoteWinner() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_nEndMatchMapVoteWinner")); }
    int m_iNumConsecutiveCTLoses() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_iNumConsecutiveCTLoses")); }
    int m_iNumConsecutiveTerroristLoses() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_iNumConsecutiveTerroristLoses")); }
    int m_nMatchAbortedEarlyReason() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_nMatchAbortedEarlyReason")); }
    bool m_bHasTriggeredRoundStartMusic() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bHasTriggeredRoundStartMusic")); }
    bool m_bSwitchingTeamsAtRoundReset() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bSwitchingTeamsAtRoundReset")); }
    CCSGameModeRules* m_pGameModeRules() { return read<CCSGameModeRules*>(baseAddr + offsets_instance.get("C_CSGameRules", "m_pGameModeRules")); }
    uintptr_t m_RetakeRules() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSGameRules", "m_RetakeRules")); }
    uint8_t m_nMatchEndCount() { return read<uint8_t>(baseAddr + offsets_instance.get("C_CSGameRules", "m_nMatchEndCount")); }
    int m_nTTeamIntroVariant() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_nTTeamIntroVariant")); }
    int m_nCTTeamIntroVariant() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_nCTTeamIntroVariant")); }
    bool m_bTeamIntroPeriod() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bTeamIntroPeriod")); }
    int m_iRoundEndWinnerTeam() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_iRoundEndWinnerTeam")); }
    int m_eRoundEndReason() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_eRoundEndReason")); }
    bool m_bRoundEndShowTimerDefend() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bRoundEndShowTimerDefend")); }
    int m_iRoundEndTimerTime() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_iRoundEndTimerTime")); }
    uintptr_t m_sRoundEndFunFactToken() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSGameRules", "m_sRoundEndFunFactToken")); }
    uintptr_t m_iRoundEndFunFactPlayerSlot() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSGameRules", "m_iRoundEndFunFactPlayerSlot")); }
    int m_iRoundEndFunFactData1() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_iRoundEndFunFactData1")); }
    int m_iRoundEndFunFactData2() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_iRoundEndFunFactData2")); }
    int m_iRoundEndFunFactData3() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_iRoundEndFunFactData3")); }
    uintptr_t m_sRoundEndMessage() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSGameRules", "m_sRoundEndMessage")); }
    int m_iRoundEndPlayerCount() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_iRoundEndPlayerCount")); }
    bool m_bRoundEndNoMusic() { return read<bool>(baseAddr + offsets_instance.get("C_CSGameRules", "m_bRoundEndNoMusic")); }
    int m_iRoundEndLegacy() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_iRoundEndLegacy")); }
    uint8_t m_nRoundEndCount() { return read<uint8_t>(baseAddr + offsets_instance.get("C_CSGameRules", "m_nRoundEndCount")); }
    int m_iRoundStartRoundNumber() { return read<int>(baseAddr + offsets_instance.get("C_CSGameRules", "m_iRoundStartRoundNumber")); }
    uint8_t m_nRoundStartCount() { return read<uint8_t>(baseAddr + offsets_instance.get("C_CSGameRules", "m_nRoundStartCount")); }
    uintptr_t m_flLastPerfSampleTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSGameRules", "m_flLastPerfSampleTime")); }
};
