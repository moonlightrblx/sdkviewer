#pragma once
#include "../memory.h"

class EventClientPollNetworking_t  {
public:
    uintptr_t baseAddr;

    EventClientPollNetworking_t() { baseAddr = 0; }
    EventClientPollNetworking_t(uintptr_t base) : baseAddr(base) {}

    int m_nTickCount() { return read<int>(baseAddr + offsets_instance.get("EventClientPollNetworking_t", "m_nTickCount")); }
};
