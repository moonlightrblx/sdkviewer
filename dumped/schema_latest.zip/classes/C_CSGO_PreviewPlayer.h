#pragma once
#include "../memory.h"

class C_CSGO_PreviewPlayer {
public:
 uintptr_t baseAddr;
 C_CSGO_PreviewPlayer() : baseAddr(0){}
 C_CSGO_PreviewPlayer(uintptr_t b):baseAddr(b){}
 uintptr_t m_animgraphCharacterModeString(){return SCHEMA_TYPE(uintptr_t,0x3F10);}
 uintptr_t m_flInitialModelScale(){return SCHEMA_TYPE(uintptr_t,0x3F18);}
};
