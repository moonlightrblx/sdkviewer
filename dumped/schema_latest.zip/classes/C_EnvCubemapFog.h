#pragma once
#include "../memory.h"

class C_EnvCubemapFog {
public:
 uintptr_t baseAddr;
 C_EnvCubemapFog() : baseAddr(0){}
 C_EnvCubemapFog(uintptr_t b):baseAddr(b){}
 uintptr_t m_flEndDistance(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_flStartDistance(){return SCHEMA_TYPE(uintptr_t,0x5FC);}
 uintptr_t m_flFogFalloffExponent(){return SCHEMA_TYPE(uintptr_t,0x600);}
 uintptr_t m_bHeightFogEnabled(){return SCHEMA_TYPE(uintptr_t,0x604);}
 uintptr_t m_flFogHeightWidth(){return SCHEMA_TYPE(uintptr_t,0x608);}
 uintptr_t m_flFogHeightEnd(){return SCHEMA_TYPE(uintptr_t,0x60C);}
 uintptr_t m_flFogHeightStart(){return SCHEMA_TYPE(uintptr_t,0x610);}
 uintptr_t m_flFogHeightExponent(){return SCHEMA_TYPE(uintptr_t,0x614);}
 uintptr_t m_flLODBias(){return SCHEMA_TYPE(uintptr_t,0x618);}
 uintptr_t m_bActive(){return SCHEMA_TYPE(uintptr_t,0x61C);}
 uintptr_t m_bStartDisabled(){return SCHEMA_TYPE(uintptr_t,0x61D);}
 uintptr_t m_flFogMaxOpacity(){return SCHEMA_TYPE(uintptr_t,0x620);}
 uintptr_t m_nCubemapSourceType(){return SCHEMA_TYPE(uintptr_t,0x624);}
 uintptr_t m_hSkyMaterial(){return SCHEMA_TYPE(uintptr_t,0x628);}
 uintptr_t m_iszSkyEntity(){return SCHEMA_TYPE(uintptr_t,0x630);}
 uintptr_t m_hFogCubemapTexture(){return SCHEMA_TYPE(uintptr_t,0x638);}
 uintptr_t m_bHasHeightFogEnd(){return SCHEMA_TYPE(uintptr_t,0x640);}
 uintptr_t m_bFirstTime(){return SCHEMA_TYPE(uintptr_t,0x641);}
};
