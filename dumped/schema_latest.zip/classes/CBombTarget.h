#pragma once
#include "../memory.h"

class CBombTarget {
public:
 uintptr_t baseAddr;
 CBombTarget() : baseAddr(0){}
 CBombTarget(uintptr_t b):baseAddr(b){}
 uintptr_t m_bBombPlantedHere(){return SCHEMA_TYPE(uintptr_t,0xFF0);}
};
