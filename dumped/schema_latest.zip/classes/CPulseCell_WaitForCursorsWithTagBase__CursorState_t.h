#pragma once
#include "../memory.h"

class CPulseCell_WaitForCursorsWithTagBase__CursorState_t {
public:
 uintptr_t baseAddr;
 CPulseCell_WaitForCursorsWithTagBase__CursorState_t() : baseAddr(0){}
 CPulseCell_WaitForCursorsWithTagBase__CursorState_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_TagName(){return SCHEMA_TYPE(uintptr_t,0x0);}
};
