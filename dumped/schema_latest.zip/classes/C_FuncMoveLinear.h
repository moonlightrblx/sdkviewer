#pragma once
#include "../memory.h"

class C_FuncMoveLinear {
public:
 uintptr_t baseAddr;
 C_FuncMoveLinear() : baseAddr(0){}
 C_FuncMoveLinear(uintptr_t b):baseAddr(b){}
};
