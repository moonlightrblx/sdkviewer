#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_FuncConveyor  {
public:
    uintptr_t baseAddr;

    C_FuncConveyor() { baseAddr = client_base(); }
    C_FuncConveyor(uintptr_t base) : baseAddr(base) {}

    Vector3 m_vecMoveDirEntitySpace() { return read<Vector3>(baseAddr + offsets_instance.get("C_FuncConveyor", "m_vecMoveDirEntitySpace")); }
    float m_flTargetSpeed() { return read<float>(baseAddr + offsets_instance.get("C_FuncConveyor", "m_flTargetSpeed")); }
    uintptr_t m_nTransitionStartTick() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_FuncConveyor", "m_nTransitionStartTick")); }
    int m_nTransitionDurationTicks() { return read<int>(baseAddr + offsets_instance.get("C_FuncConveyor", "m_nTransitionDurationTicks")); }
    float m_flTransitionStartSpeed() { return read<float>(baseAddr + offsets_instance.get("C_FuncConveyor", "m_flTransitionStartSpeed")); }
    Vector3 m_hConveyorModels() { return read<Vector3>(baseAddr + offsets_instance.get("C_FuncConveyor", "m_hConveyorModels")); }
    float m_flCurrentConveyorOffset() { return read<float>(baseAddr + offsets_instance.get("C_FuncConveyor", "m_flCurrentConveyorOffset")); }
    float m_flCurrentConveyorSpeed() { return read<float>(baseAddr + offsets_instance.get("C_FuncConveyor", "m_flCurrentConveyorSpeed")); }
};
