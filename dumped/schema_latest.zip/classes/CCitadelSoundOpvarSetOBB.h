#pragma once
#include "../memory.h"

class CCitadelSoundOpvarSetOBB {
public:
 uintptr_t baseAddr;
 CCitadelSoundOpvarSetOBB() : baseAddr(0){}
 CCitadelSoundOpvarSetOBB(uintptr_t b):baseAddr(b){}
 uintptr_t m_iszStackName(){return SCHEMA_TYPE(uintptr_t,0x610);}
 uintptr_t m_iszOperatorName(){return SCHEMA_TYPE(uintptr_t,0x618);}
 uintptr_t m_iszOpvarName(){return SCHEMA_TYPE(uintptr_t,0x620);}
 uintptr_t m_vDistanceInnerMins(){return SCHEMA_TYPE(uintptr_t,0x628);}
 uintptr_t m_vDistanceInnerMaxs(){return SCHEMA_TYPE(uintptr_t,0x634);}
 uintptr_t m_vDistanceOuterMins(){return SCHEMA_TYPE(uintptr_t,0x640);}
 uintptr_t m_vDistanceOuterMaxs(){return SCHEMA_TYPE(uintptr_t,0x64C);}
 uintptr_t m_nAABBDirection(){return SCHEMA_TYPE(uintptr_t,0x658);}
};
