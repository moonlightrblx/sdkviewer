#pragma once
#include "../memory.h"

class C_HostageCarriableProp  {
public:
    uintptr_t baseAddr;

    C_HostageCarriableProp() { baseAddr = client_base(); }
    C_HostageCarriableProp(uintptr_t base) : baseAddr(base) {}

};
