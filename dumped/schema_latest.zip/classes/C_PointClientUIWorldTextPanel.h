#pragma once
#include "../memory.h"

class C_PointClientUIWorldTextPanel {
public:
 uintptr_t baseAddr;
 C_PointClientUIWorldTextPanel() : baseAddr(0){}
 C_PointClientUIWorldTextPanel(uintptr_t b):baseAddr(b){}
 uintptr_t m_messageText(){return SCHEMA_TYPE(uintptr_t,0x1100);}
};
