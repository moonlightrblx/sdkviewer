#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_EnvWindVolume  {
public:
    uintptr_t baseAddr;

    C_EnvWindVolume() { baseAddr = client_base(); }
    C_EnvWindVolume(uintptr_t base) : baseAddr(base) {}

    bool m_bActive() { return read<bool>(baseAddr + offsets_instance.get("C_EnvWindVolume", "m_bActive")); }
    Vector3 m_vBoxMins() { return read<Vector3>(baseAddr + offsets_instance.get("C_EnvWindVolume", "m_vBoxMins")); }
    Vector3 m_vBoxMaxs() { return read<Vector3>(baseAddr + offsets_instance.get("C_EnvWindVolume", "m_vBoxMaxs")); }
    bool m_bStartDisabled() { return read<bool>(baseAddr + offsets_instance.get("C_EnvWindVolume", "m_bStartDisabled")); }
    int m_nShape() { return read<int>(baseAddr + offsets_instance.get("C_EnvWindVolume", "m_nShape")); }
    float m_fWindSpeedMultiplier() { return read<float>(baseAddr + offsets_instance.get("C_EnvWindVolume", "m_fWindSpeedMultiplier")); }
    float m_fWindTurbulenceMultiplier() { return read<float>(baseAddr + offsets_instance.get("C_EnvWindVolume", "m_fWindTurbulenceMultiplier")); }
    float m_fWindSpeedVariationMultiplier() { return read<float>(baseAddr + offsets_instance.get("C_EnvWindVolume", "m_fWindSpeedVariationMultiplier")); }
    float m_fWindDirectionVariationMultiplier() { return read<float>(baseAddr + offsets_instance.get("C_EnvWindVolume", "m_fWindDirectionVariationMultiplier")); }
};
