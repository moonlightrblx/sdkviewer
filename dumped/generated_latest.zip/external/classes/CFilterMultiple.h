#pragma once
#include "../memory.h"

class CFilterMultiple  {
public:
    uintptr_t baseAddr;

    CFilterMultiple() { baseAddr = client_base(); }
    CFilterMultiple(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_nFilterType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CFilterMultiple", "m_nFilterType")); }
    uintptr_t m_iFilterName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CFilterMultiple", "m_iFilterName")); }
    C_BaseEntity* m_hFilter() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("CFilterMultiple", "m_hFilter")); }
};
