#pragma once
#include "../memory.h"

class C_SoundOpvarSetPointEntity {
public:
 uintptr_t baseAddr;
 C_SoundOpvarSetPointEntity() : baseAddr(0){}
 C_SoundOpvarSetPointEntity(uintptr_t b):baseAddr(b){}
};
