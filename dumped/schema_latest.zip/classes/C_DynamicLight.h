#pragma once
#include "../memory.h"

class C_DynamicLight {
public:
 uintptr_t baseAddr;
 C_DynamicLight() : baseAddr(0){}
 C_DynamicLight(uintptr_t b):baseAddr(b){}
 uintptr_t m_Flags(){return SCHEMA_TYPE(uintptr_t,0xEB0);}
 uintptr_t m_LightStyle(){return SCHEMA_TYPE(uintptr_t,0xEB1);}
 uintptr_t m_Radius(){return SCHEMA_TYPE(uintptr_t,0xEB4);}
 uintptr_t m_Exponent(){return SCHEMA_TYPE(uintptr_t,0xEB8);}
 uintptr_t m_InnerAngle(){return SCHEMA_TYPE(uintptr_t,0xEBC);}
 uintptr_t m_OuterAngle(){return SCHEMA_TYPE(uintptr_t,0xEC0);}
 uintptr_t m_SpotRadius(){return SCHEMA_TYPE(uintptr_t,0xEC4);}
};
