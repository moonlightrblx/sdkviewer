#pragma once
#include "../memory.h"

class C_CSWeaponBaseGun {
public:
 uintptr_t baseAddr;
 C_CSWeaponBaseGun() : baseAddr(0){}
 C_CSWeaponBaseGun(uintptr_t b):baseAddr(b){}
 uintptr_t m_zoomLevel(){return SCHEMA_TYPE(uintptr_t,0x1F80);}
 uintptr_t m_iBurstShotsRemaining(){return SCHEMA_TYPE(uintptr_t,0x1F84);}
 uintptr_t m_iSilencerBodygroup(){return SCHEMA_TYPE(uintptr_t,0x1F88);}
 uintptr_t m_silencedModelIndex(){return SCHEMA_TYPE(uintptr_t,0x1F98);}
 uintptr_t m_inPrecache(){return SCHEMA_TYPE(uintptr_t,0x1F9C);}
 uintptr_t m_bNeedsBoltAction(){return SCHEMA_TYPE(uintptr_t,0x1F9D);}
 uintptr_t m_nRevolverCylinderIdx(){return SCHEMA_TYPE(uintptr_t,0x1FA0);}
};
