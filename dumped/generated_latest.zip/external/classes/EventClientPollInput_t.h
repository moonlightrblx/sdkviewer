#pragma once
#include "../memory.h"
#include "../classes/EngineLoopState_t.h"

class EventClientPollInput_t  {
public:
    uintptr_t baseAddr;

    EventClientPollInput_t() { baseAddr = 0; }
    EventClientPollInput_t(uintptr_t base) : baseAddr(base) {}

    EngineLoopState_t m_LoopState() { return read<EngineLoopState_t>(baseAddr + offsets_instance.get("EventClientPollInput_t", "m_LoopState")); }
    float m_flRealTime() { return read<float>(baseAddr + offsets_instance.get("EventClientPollInput_t", "m_flRealTime")); }
};
