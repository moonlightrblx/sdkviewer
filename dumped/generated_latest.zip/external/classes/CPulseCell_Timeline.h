#pragma once
#include "../memory.h"
#include "../classes/CPulse_ResumePoint.h"
#include "../types/Vector3.h"

class CPulseCell_Timeline  {
public:
    uintptr_t baseAddr;

    CPulseCell_Timeline() { baseAddr = 0; }
    CPulseCell_Timeline(uintptr_t base) : baseAddr(base) {}

    Vector3 m_TimelineEvents() { return read<Vector3>(baseAddr + offsets_instance.get("CPulseCell_Timeline", "m_TimelineEvents")); }
    bool m_bWaitForChildOutflows() { return read<bool>(baseAddr + offsets_instance.get("CPulseCell_Timeline", "m_bWaitForChildOutflows")); }
    CPulse_ResumePoint m_OnFinished() { return read<CPulse_ResumePoint>(baseAddr + offsets_instance.get("CPulseCell_Timeline", "m_OnFinished")); }
    CPulse_ResumePoint m_OnCanceled() { return read<CPulse_ResumePoint>(baseAddr + offsets_instance.get("CPulseCell_Timeline", "m_OnCanceled")); }
};
