#pragma once
#include "../memory.h"

class CPulseCell_Base {
public:
 uintptr_t baseAddr;
 CPulseCell_Base() : baseAddr(0){}
 CPulseCell_Base(uintptr_t b):baseAddr(b){}
 uintptr_t m_nEditorNodeID(){return SCHEMA_TYPE(uintptr_t,0x8);}
};
