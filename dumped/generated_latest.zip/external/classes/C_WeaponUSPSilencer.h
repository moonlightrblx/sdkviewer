#pragma once
#include "../memory.h"

class C_WeaponUSPSilencer  {
public:
    uintptr_t baseAddr;

    C_WeaponUSPSilencer() { baseAddr = client_base(); }
    C_WeaponUSPSilencer(uintptr_t base) : baseAddr(base) {}

};
