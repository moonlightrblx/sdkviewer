#pragma once
#include "../memory.h"

class CPulseGameBlackboard  {
public:
    uintptr_t baseAddr;

    CPulseGameBlackboard() { baseAddr = 0; }
    CPulseGameBlackboard(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_strGraphName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseGameBlackboard", "m_strGraphName")); }
    uintptr_t m_strStateBlob() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseGameBlackboard", "m_strStateBlob")); }
};
