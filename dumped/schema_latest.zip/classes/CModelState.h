#pragma once
#include "../memory.h"

class CModelState {
public:
 uintptr_t baseAddr;
 CModelState() : baseAddr(0){}
 CModelState(uintptr_t b):baseAddr(b){}
 uintptr_t m_hModel(){return SCHEMA_TYPE(uintptr_t,0xD0);}
 uintptr_t m_ModelName(){return SCHEMA_TYPE(uintptr_t,0xD8);}
 uintptr_t m_bClientClothCreationSuppressed(){return SCHEMA_TYPE(uintptr_t,0x1A9);}
 uintptr_t m_MeshGroupMask(){return SCHEMA_TYPE(uintptr_t,0x250);}
 uintptr_t m_nBodyGroupChoices(){return SCHEMA_TYPE(uintptr_t,0x2A0);}
 uintptr_t m_nIdealMotionType(){return SCHEMA_TYPE(uintptr_t,0x2EA);}
 uintptr_t m_nForceLOD(){return SCHEMA_TYPE(uintptr_t,0x2EB);}
 uintptr_t m_nClothUpdateFlags(){return SCHEMA_TYPE(uintptr_t,0x2EC);}
};
