#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_SoundEventAABBEntity  {
public:
    uintptr_t baseAddr;

    C_SoundEventAABBEntity() { baseAddr = client_base(); }
    C_SoundEventAABBEntity(uintptr_t base) : baseAddr(base) {}

    Vector3 m_vMins() { return read<Vector3>(baseAddr + offsets_instance.get("C_SoundEventAABBEntity", "m_vMins")); }
    Vector3 m_vMaxs() { return read<Vector3>(baseAddr + offsets_instance.get("C_SoundEventAABBEntity", "m_vMaxs")); }
};
