#pragma once
#include "../memory.h"

class C_PostProcessingVolume  {
public:
    uintptr_t baseAddr;

    C_PostProcessingVolume() { baseAddr = client_base(); }
    C_PostProcessingVolume(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_hPostSettings() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_PostProcessingVolume", "m_hPostSettings")); }
    float m_flFadeDuration() { return read<float>(baseAddr + offsets_instance.get("C_PostProcessingVolume", "m_flFadeDuration")); }
    float m_flMinLogExposure() { return read<float>(baseAddr + offsets_instance.get("C_PostProcessingVolume", "m_flMinLogExposure")); }
    float m_flMaxLogExposure() { return read<float>(baseAddr + offsets_instance.get("C_PostProcessingVolume", "m_flMaxLogExposure")); }
    float m_flMinExposure() { return read<float>(baseAddr + offsets_instance.get("C_PostProcessingVolume", "m_flMinExposure")); }
    float m_flMaxExposure() { return read<float>(baseAddr + offsets_instance.get("C_PostProcessingVolume", "m_flMaxExposure")); }
    float m_flExposureCompensation() { return read<float>(baseAddr + offsets_instance.get("C_PostProcessingVolume", "m_flExposureCompensation")); }
    float m_flExposureFadeSpeedUp() { return read<float>(baseAddr + offsets_instance.get("C_PostProcessingVolume", "m_flExposureFadeSpeedUp")); }
    float m_flExposureFadeSpeedDown() { return read<float>(baseAddr + offsets_instance.get("C_PostProcessingVolume", "m_flExposureFadeSpeedDown")); }
    float m_flTonemapEVSmoothingRange() { return read<float>(baseAddr + offsets_instance.get("C_PostProcessingVolume", "m_flTonemapEVSmoothingRange")); }
    bool m_bMaster() { return read<bool>(baseAddr + offsets_instance.get("C_PostProcessingVolume", "m_bMaster")); }
    bool m_bExposureControl() { return read<bool>(baseAddr + offsets_instance.get("C_PostProcessingVolume", "m_bExposureControl")); }
};
