#pragma once
#include "../memory.h"

class CPulseCell_Outflow_CycleShuffled__InstanceState_t {
public:
 uintptr_t baseAddr;
 CPulseCell_Outflow_CycleShuffled__InstanceState_t() : baseAddr(0){}
 CPulseCell_Outflow_CycleShuffled__InstanceState_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_Shuffle(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_nNextShuffle(){return SCHEMA_TYPE(uintptr_t,0x20);}
};
