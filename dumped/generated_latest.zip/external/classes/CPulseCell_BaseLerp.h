#pragma once
#include "../memory.h"
#include "../classes/CPulse_ResumePoint.h"

class CPulseCell_BaseLerp  {
public:
    uintptr_t baseAddr;

    CPulseCell_BaseLerp() { baseAddr = 0; }
    CPulseCell_BaseLerp(uintptr_t base) : baseAddr(base) {}

    CPulse_ResumePoint m_WakeResume() { return read<CPulse_ResumePoint>(baseAddr + offsets_instance.get("CPulseCell_BaseLerp", "m_WakeResume")); }
};
