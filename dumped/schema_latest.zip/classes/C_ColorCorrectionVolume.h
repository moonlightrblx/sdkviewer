#pragma once
#include "../memory.h"

class C_ColorCorrectionVolume {
public:
 uintptr_t baseAddr;
 C_ColorCorrectionVolume() : baseAddr(0){}
 C_ColorCorrectionVolume(uintptr_t b):baseAddr(b){}
 uintptr_t m_LastEnterWeight(){return SCHEMA_TYPE(uintptr_t,0xFF0);}
 uintptr_t m_LastEnterTime(){return SCHEMA_TYPE(uintptr_t,0xFF4);}
 uintptr_t m_LastExitWeight(){return SCHEMA_TYPE(uintptr_t,0xFF8);}
 uintptr_t m_LastExitTime(){return SCHEMA_TYPE(uintptr_t,0xFFC);}
 uintptr_t m_bEnabled(){return SCHEMA_TYPE(uintptr_t,0x1000);}
 uintptr_t m_MaxWeight(){return SCHEMA_TYPE(uintptr_t,0x1004);}
 uintptr_t m_FadeDuration(){return SCHEMA_TYPE(uintptr_t,0x1008);}
 uintptr_t m_Weight(){return SCHEMA_TYPE(uintptr_t,0x100C);}
 uintptr_t m_lookupFilename(){return SCHEMA_TYPE(uintptr_t,0x1010);}
};
