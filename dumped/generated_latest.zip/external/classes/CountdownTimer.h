#pragma once
#include "../memory.h"

class CountdownTimer  {
public:
    uintptr_t baseAddr;

    CountdownTimer() { baseAddr = client_base(); }
    CountdownTimer(uintptr_t base) : baseAddr(base) {}

    float m_duration() { return read<float>(baseAddr + offsets_instance.get("CountdownTimer", "m_duration")); }
    uintptr_t m_timestamp() { return read<uintptr_t>(baseAddr + offsets_instance.get("CountdownTimer", "m_timestamp")); }
    float m_timescale() { return read<float>(baseAddr + offsets_instance.get("CountdownTimer", "m_timescale")); }
    uintptr_t m_nWorldGroupId() { return read<uintptr_t>(baseAddr + offsets_instance.get("CountdownTimer", "m_nWorldGroupId")); }
};
