#pragma once
#include "../memory.h"

class C_AK47 {
public:
 uintptr_t baseAddr;
 C_AK47() : baseAddr(0){}
 C_AK47(uintptr_t b):baseAddr(b){}
};
