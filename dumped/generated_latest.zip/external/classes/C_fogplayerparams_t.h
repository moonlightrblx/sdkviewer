#pragma once
#include "../memory.h"

class C_fogplayerparams_t  {
public:
    uintptr_t baseAddr;

    C_fogplayerparams_t() { baseAddr = client_base(); }
    C_fogplayerparams_t(uintptr_t base) : baseAddr(base) {}

    C_FogController* m_hCtrl() { return read<C_FogController*>(baseAddr + offsets_instance.get("C_fogplayerparams_t", "m_hCtrl")); }
    float m_flTransitionTime() { return read<float>(baseAddr + offsets_instance.get("C_fogplayerparams_t", "m_flTransitionTime")); }
    uintptr_t m_OldColor() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_fogplayerparams_t", "m_OldColor")); }
    float m_flOldStart() { return read<float>(baseAddr + offsets_instance.get("C_fogplayerparams_t", "m_flOldStart")); }
    float m_flOldEnd() { return read<float>(baseAddr + offsets_instance.get("C_fogplayerparams_t", "m_flOldEnd")); }
    float m_flOldMaxDensity() { return read<float>(baseAddr + offsets_instance.get("C_fogplayerparams_t", "m_flOldMaxDensity")); }
    float m_flOldHDRColorScale() { return read<float>(baseAddr + offsets_instance.get("C_fogplayerparams_t", "m_flOldHDRColorScale")); }
    float m_flOldFarZ() { return read<float>(baseAddr + offsets_instance.get("C_fogplayerparams_t", "m_flOldFarZ")); }
    uintptr_t m_NewColor() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_fogplayerparams_t", "m_NewColor")); }
    float m_flNewStart() { return read<float>(baseAddr + offsets_instance.get("C_fogplayerparams_t", "m_flNewStart")); }
    float m_flNewEnd() { return read<float>(baseAddr + offsets_instance.get("C_fogplayerparams_t", "m_flNewEnd")); }
    float m_flNewMaxDensity() { return read<float>(baseAddr + offsets_instance.get("C_fogplayerparams_t", "m_flNewMaxDensity")); }
    float m_flNewHDRColorScale() { return read<float>(baseAddr + offsets_instance.get("C_fogplayerparams_t", "m_flNewHDRColorScale")); }
    float m_flNewFarZ() { return read<float>(baseAddr + offsets_instance.get("C_fogplayerparams_t", "m_flNewFarZ")); }
};
