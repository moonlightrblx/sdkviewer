#pragma once
#include "../memory.h"

class CRagdollManager {
public:
 uintptr_t baseAddr;
 CRagdollManager() : baseAddr(0){}
 CRagdollManager(uintptr_t b):baseAddr(b){}
 uintptr_t m_iCurrentMaxRagdollCount(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
};
