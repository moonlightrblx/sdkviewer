#pragma once
#include "../memory.h"

class C_TriggerBuoyancy  {
public:
    uintptr_t baseAddr;

    C_TriggerBuoyancy() { baseAddr = client_base(); }
    C_TriggerBuoyancy(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_BuoyancyHelper() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_TriggerBuoyancy", "m_BuoyancyHelper")); }
    float m_flFluidDensity() { return read<float>(baseAddr + offsets_instance.get("C_TriggerBuoyancy", "m_flFluidDensity")); }
};
