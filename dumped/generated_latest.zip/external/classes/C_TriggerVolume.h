#pragma once
#include "../memory.h"

class C_TriggerVolume  {
public:
    uintptr_t baseAddr;

    C_TriggerVolume() { baseAddr = 0; }
    C_TriggerVolume(uintptr_t base) : baseAddr(base) {}

};
