#pragma once
#include "../memory.h"

class CEntityIOOutput {
public:
 uintptr_t baseAddr;
 CEntityIOOutput() : baseAddr(0){}
 CEntityIOOutput(uintptr_t b):baseAddr(b){}
 uintptr_t m_Value(){return SCHEMA_TYPE(uintptr_t,0x18);}
};
