#pragma once
#include "../memory.h"

class C_FuncElectrifiedVolume {
public:
 uintptr_t baseAddr;
 C_FuncElectrifiedVolume() : baseAddr(0){}
 C_FuncElectrifiedVolume(uintptr_t b):baseAddr(b){}
 uintptr_t m_nAmbientEffect(){return SCHEMA_TYPE(uintptr_t,0xEB0);}
 uintptr_t m_EffectName(){return SCHEMA_TYPE(uintptr_t,0xEB8);}
 uintptr_t m_bState(){return SCHEMA_TYPE(uintptr_t,0xEC0);}
};
