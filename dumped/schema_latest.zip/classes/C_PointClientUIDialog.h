#pragma once
#include "../memory.h"

class C_PointClientUIDialog {
public:
 uintptr_t baseAddr;
 C_PointClientUIDialog() : baseAddr(0){}
 C_PointClientUIDialog(uintptr_t b):baseAddr(b){}
 uintptr_t m_hActivator(){return SCHEMA_TYPE(uintptr_t,0xEE0);}
 uintptr_t m_bStartEnabled(){return SCHEMA_TYPE(uintptr_t,0xEE4);}
};
