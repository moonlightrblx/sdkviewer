#pragma once
#include "../memory.h"

class C_CSGO_EndOfMatchLineupStart {
public:
 uintptr_t baseAddr;
 C_CSGO_EndOfMatchLineupStart() : baseAddr(0){}
 C_CSGO_EndOfMatchLineupStart(uintptr_t b):baseAddr(b){}
};
