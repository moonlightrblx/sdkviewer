#pragma once
#include "../memory.h"

class CBasePlayerControllerAPI  {
public:
    uintptr_t baseAddr;

    CBasePlayerControllerAPI() { baseAddr = client_base(); }
    CBasePlayerControllerAPI(uintptr_t base) : baseAddr(base) {}

};
