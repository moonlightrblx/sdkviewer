#pragma once
#include "../memory.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"

class CPlayer_MovementServices  {
public:
    uintptr_t baseAddr;

    CPlayer_MovementServices() { baseAddr = client_base(); }
    CPlayer_MovementServices(uintptr_t base) : baseAddr(base) {}

    int m_nImpulse() { return read<int>(baseAddr + offsets_instance.get("CPlayer_MovementServices", "m_nImpulse")); }
    uintptr_t m_nButtons() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPlayer_MovementServices", "m_nButtons")); }
    uintptr_t m_nQueuedButtonDownMask() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPlayer_MovementServices", "m_nQueuedButtonDownMask")); }
    uintptr_t m_nQueuedButtonChangeMask() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPlayer_MovementServices", "m_nQueuedButtonChangeMask")); }
    uintptr_t m_nButtonDoublePressed() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPlayer_MovementServices", "m_nButtonDoublePressed")); }
    int m_pButtonPressedCmdNumber() { return read<int>(baseAddr + offsets_instance.get("CPlayer_MovementServices", "m_pButtonPressedCmdNumber")); }
    int m_nLastCommandNumberProcessed() { return read<int>(baseAddr + offsets_instance.get("CPlayer_MovementServices", "m_nLastCommandNumberProcessed")); }
    uintptr_t m_nToggleButtonDownMask() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPlayer_MovementServices", "m_nToggleButtonDownMask")); }
    float m_flMaxspeed() { return read<float>(baseAddr + offsets_instance.get("CPlayer_MovementServices", "m_flMaxspeed")); }
    float m_arrForceSubtickMoveWhen() { return read<float>(baseAddr + offsets_instance.get("CPlayer_MovementServices", "m_arrForceSubtickMoveWhen")); }
    float m_flForwardMove() { return read<float>(baseAddr + offsets_instance.get("CPlayer_MovementServices", "m_flForwardMove")); }
    float m_flLeftMove() { return read<float>(baseAddr + offsets_instance.get("CPlayer_MovementServices", "m_flLeftMove")); }
    float m_flUpMove() { return read<float>(baseAddr + offsets_instance.get("CPlayer_MovementServices", "m_flUpMove")); }
    Vector3 m_vecLastMovementImpulses() { return read<Vector3>(baseAddr + offsets_instance.get("CPlayer_MovementServices", "m_vecLastMovementImpulses")); }
    QAngle m_vecOldViewAngles() { return read<QAngle>(baseAddr + offsets_instance.get("CPlayer_MovementServices", "m_vecOldViewAngles")); }
};
