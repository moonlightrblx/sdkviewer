#pragma once
#include "../memory.h"
#include "../classes/CNetworkVarChainer.h"

class CCSGameModeRules  {
public:
    uintptr_t baseAddr;

    CCSGameModeRules() { baseAddr = 0; }
    CCSGameModeRules(uintptr_t base) : baseAddr(base) {}

    CNetworkVarChainer __m_pChainEntity() { return read<CNetworkVarChainer>(baseAddr + offsets_instance.get("CCSGameModeRules", "__m_pChainEntity")); }
};
