#pragma once
#include "../memory.h"

class C_EnvDecal  {
public:
    uintptr_t baseAddr;

    C_EnvDecal() { baseAddr = client_base(); }
    C_EnvDecal(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_hDecalMaterial() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvDecal", "m_hDecalMaterial")); }
    float m_flWidth() { return read<float>(baseAddr + offsets_instance.get("C_EnvDecal", "m_flWidth")); }
    float m_flHeight() { return read<float>(baseAddr + offsets_instance.get("C_EnvDecal", "m_flHeight")); }
    float m_flDepth() { return read<float>(baseAddr + offsets_instance.get("C_EnvDecal", "m_flDepth")); }
    int m_nRenderOrder() { return read<int>(baseAddr + offsets_instance.get("C_EnvDecal", "m_nRenderOrder")); }
    bool m_bProjectOnWorld() { return read<bool>(baseAddr + offsets_instance.get("C_EnvDecal", "m_bProjectOnWorld")); }
    bool m_bProjectOnCharacters() { return read<bool>(baseAddr + offsets_instance.get("C_EnvDecal", "m_bProjectOnCharacters")); }
    bool m_bProjectOnWater() { return read<bool>(baseAddr + offsets_instance.get("C_EnvDecal", "m_bProjectOnWater")); }
    float m_flDepthSortBias() { return read<float>(baseAddr + offsets_instance.get("C_EnvDecal", "m_flDepthSortBias")); }
};
