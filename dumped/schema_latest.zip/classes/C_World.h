#pragma once
#include "../memory.h"

class C_World {
public:
 uintptr_t baseAddr;
 C_World() : baseAddr(0){}
 C_World(uintptr_t b):baseAddr(b){}
};
