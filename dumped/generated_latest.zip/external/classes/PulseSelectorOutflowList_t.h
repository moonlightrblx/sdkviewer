#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class PulseSelectorOutflowList_t  {
public:
    uintptr_t baseAddr;

    PulseSelectorOutflowList_t() { baseAddr = client_base(); }
    PulseSelectorOutflowList_t(uintptr_t base) : baseAddr(base) {}

    Vector3 m_Outflows() { return read<Vector3>(baseAddr + offsets_instance.get("PulseSelectorOutflowList_t", "m_Outflows")); }
};
