#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_PointClientUIHUD  {
public:
    uintptr_t baseAddr;

    C_PointClientUIHUD() { baseAddr = 0; }
    C_PointClientUIHUD(uintptr_t base) : baseAddr(base) {}

    bool m_bCheckCSSClasses() { return read<bool>(baseAddr + offsets_instance.get("C_PointClientUIHUD", "m_bCheckCSSClasses")); }
    bool m_bIgnoreInput() { return read<bool>(baseAddr + offsets_instance.get("C_PointClientUIHUD", "m_bIgnoreInput")); }
    float m_flWidth() { return read<float>(baseAddr + offsets_instance.get("C_PointClientUIHUD", "m_flWidth")); }
    float m_flHeight() { return read<float>(baseAddr + offsets_instance.get("C_PointClientUIHUD", "m_flHeight")); }
    float m_flDPI() { return read<float>(baseAddr + offsets_instance.get("C_PointClientUIHUD", "m_flDPI")); }
    float m_flInteractDistance() { return read<float>(baseAddr + offsets_instance.get("C_PointClientUIHUD", "m_flInteractDistance")); }
    float m_flDepthOffset() { return read<float>(baseAddr + offsets_instance.get("C_PointClientUIHUD", "m_flDepthOffset")); }
    int m_unOwnerContext() { return read<int>(baseAddr + offsets_instance.get("C_PointClientUIHUD", "m_unOwnerContext")); }
    int m_unHorizontalAlign() { return read<int>(baseAddr + offsets_instance.get("C_PointClientUIHUD", "m_unHorizontalAlign")); }
    int m_unVerticalAlign() { return read<int>(baseAddr + offsets_instance.get("C_PointClientUIHUD", "m_unVerticalAlign")); }
    int m_unOrientation() { return read<int>(baseAddr + offsets_instance.get("C_PointClientUIHUD", "m_unOrientation")); }
    bool m_bAllowInteractionFromAllSceneWorlds() { return read<bool>(baseAddr + offsets_instance.get("C_PointClientUIHUD", "m_bAllowInteractionFromAllSceneWorlds")); }
    Vector3 m_vecCSSClasses() { return read<Vector3>(baseAddr + offsets_instance.get("C_PointClientUIHUD", "m_vecCSSClasses")); }
};
