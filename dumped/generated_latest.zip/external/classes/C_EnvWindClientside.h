#pragma once
#include "../memory.h"
#include "../classes/C_EnvWindShared.h"

class C_EnvWindClientside  {
public:
    uintptr_t baseAddr;

    C_EnvWindClientside() { baseAddr = 0; }
    C_EnvWindClientside(uintptr_t base) : baseAddr(base) {}

    C_EnvWindShared m_EnvWindShared() { return read<C_EnvWindShared>(baseAddr + offsets_instance.get("C_EnvWindClientside", "m_EnvWindShared")); }
};
