#pragma once
#include "../memory.h"

class C_EnvWindController {
public:
 uintptr_t baseAddr;
 C_EnvWindController() : baseAddr(0){}
 C_EnvWindController(uintptr_t b):baseAddr(b){}
 uintptr_t m_EnvWindShared(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_fDirectionVariation(){return SCHEMA_TYPE(uintptr_t,0x6F0);}
 uintptr_t m_fSpeedVariation(){return SCHEMA_TYPE(uintptr_t,0x6F4);}
 uintptr_t m_fTurbulence(){return SCHEMA_TYPE(uintptr_t,0x6F8);}
 uintptr_t m_fVolumeHalfExtentXY(){return SCHEMA_TYPE(uintptr_t,0x6FC);}
 uintptr_t m_fVolumeHalfExtentZ(){return SCHEMA_TYPE(uintptr_t,0x700);}
 uintptr_t m_nVolumeResolutionXY(){return SCHEMA_TYPE(uintptr_t,0x704);}
 uintptr_t m_nVolumeResolutionZ(){return SCHEMA_TYPE(uintptr_t,0x708);}
 uintptr_t m_nClipmapLevels(){return SCHEMA_TYPE(uintptr_t,0x70C);}
 uintptr_t m_bIsMaster(){return SCHEMA_TYPE(uintptr_t,0x710);}
 uintptr_t m_bFirstTime(){return SCHEMA_TYPE(uintptr_t,0x711);}
};
