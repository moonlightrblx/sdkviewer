#pragma once
#include "../memory.h"

class C_Chicken {
public:
 uintptr_t baseAddr;
 C_Chicken() : baseAddr(0){}
 C_Chicken(uintptr_t b):baseAddr(b){}
 uintptr_t m_hHolidayHatAddon(){return SCHEMA_TYPE(uintptr_t,0x1428);}
 uintptr_t m_jumpedThisFrame(){return SCHEMA_TYPE(uintptr_t,0x142C);}
 uintptr_t m_leader(){return SCHEMA_TYPE(uintptr_t,0x1430);}
 uintptr_t m_AttributeManager(){return SCHEMA_TYPE(uintptr_t,0x1438);}
 uintptr_t m_bAttributesInitialized(){return SCHEMA_TYPE(uintptr_t,0x1910);}
 uintptr_t m_hWaterWakeParticles(){return SCHEMA_TYPE(uintptr_t,0x1914);}
 uintptr_t m_bIsPreviewModel(){return SCHEMA_TYPE(uintptr_t,0x1918);}
};
