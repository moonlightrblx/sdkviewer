#pragma once
#include "../memory.h"

class CFilterMassGreater  {
public:
    uintptr_t baseAddr;

    CFilterMassGreater() { baseAddr = 0; }
    CFilterMassGreater(uintptr_t base) : baseAddr(base) {}

    float m_fFilterMass() { return read<float>(baseAddr + offsets_instance.get("CFilterMassGreater", "m_fFilterMass")); }
};
