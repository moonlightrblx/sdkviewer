#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_EnvVolumetricFogVolume  {
public:
    uintptr_t baseAddr;

    C_EnvVolumetricFogVolume() { baseAddr = client_base(); }
    C_EnvVolumetricFogVolume(uintptr_t base) : baseAddr(base) {}

    bool m_bActive() { return read<bool>(baseAddr + offsets_instance.get("C_EnvVolumetricFogVolume", "m_bActive")); }
    Vector3 m_vBoxMins() { return read<Vector3>(baseAddr + offsets_instance.get("C_EnvVolumetricFogVolume", "m_vBoxMins")); }
    Vector3 m_vBoxMaxs() { return read<Vector3>(baseAddr + offsets_instance.get("C_EnvVolumetricFogVolume", "m_vBoxMaxs")); }
    bool m_bStartDisabled() { return read<bool>(baseAddr + offsets_instance.get("C_EnvVolumetricFogVolume", "m_bStartDisabled")); }
    bool m_bIndirectUseLPVs() { return read<bool>(baseAddr + offsets_instance.get("C_EnvVolumetricFogVolume", "m_bIndirectUseLPVs")); }
    float m_flStrength() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogVolume", "m_flStrength")); }
    int m_nFalloffShape() { return read<int>(baseAddr + offsets_instance.get("C_EnvVolumetricFogVolume", "m_nFalloffShape")); }
    float m_flFalloffExponent() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogVolume", "m_flFalloffExponent")); }
    float m_flHeightFogDepth() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogVolume", "m_flHeightFogDepth")); }
    float m_fHeightFogEdgeWidth() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogVolume", "m_fHeightFogEdgeWidth")); }
    float m_fIndirectLightStrength() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogVolume", "m_fIndirectLightStrength")); }
    float m_fSunLightStrength() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogVolume", "m_fSunLightStrength")); }
    float m_fNoiseStrength() { return read<float>(baseAddr + offsets_instance.get("C_EnvVolumetricFogVolume", "m_fNoiseStrength")); }
    uintptr_t m_TintColor() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvVolumetricFogVolume", "m_TintColor")); }
    bool m_bOverrideTintColor() { return read<bool>(baseAddr + offsets_instance.get("C_EnvVolumetricFogVolume", "m_bOverrideTintColor")); }
    bool m_bOverrideIndirectLightStrength() { return read<bool>(baseAddr + offsets_instance.get("C_EnvVolumetricFogVolume", "m_bOverrideIndirectLightStrength")); }
    bool m_bOverrideSunLightStrength() { return read<bool>(baseAddr + offsets_instance.get("C_EnvVolumetricFogVolume", "m_bOverrideSunLightStrength")); }
    bool m_bOverrideNoiseStrength() { return read<bool>(baseAddr + offsets_instance.get("C_EnvVolumetricFogVolume", "m_bOverrideNoiseStrength")); }
};
