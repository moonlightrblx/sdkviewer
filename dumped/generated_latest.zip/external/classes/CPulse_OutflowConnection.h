#pragma once
#include "../memory.h"

class CPulse_OutflowConnection  {
public:
    uintptr_t baseAddr;

    CPulse_OutflowConnection() { baseAddr = 0; }
    CPulse_OutflowConnection(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_SourceOutflowName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulse_OutflowConnection", "m_SourceOutflowName")); }
    uintptr_t m_nDestChunk() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulse_OutflowConnection", "m_nDestChunk")); }
    int m_nInstruction() { return read<int>(baseAddr + offsets_instance.get("CPulse_OutflowConnection", "m_nInstruction")); }
    uintptr_t m_OutflowRegisterMap() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulse_OutflowConnection", "m_OutflowRegisterMap")); }
};
