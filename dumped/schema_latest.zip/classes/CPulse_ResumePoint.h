#pragma once
#include "../memory.h"

class CPulse_ResumePoint {
public:
 uintptr_t baseAddr;
 CPulse_ResumePoint() : baseAddr(0){}
 CPulse_ResumePoint(uintptr_t b):baseAddr(b){}
};
