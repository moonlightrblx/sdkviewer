#pragma once
#include "../memory.h"

class CPulseCell_Value_Gradient {
public:
 uintptr_t baseAddr;
 CPulseCell_Value_Gradient() : baseAddr(0){}
 CPulseCell_Value_Gradient(uintptr_t b):baseAddr(b){}
 uintptr_t m_Gradient(){return SCHEMA_TYPE(uintptr_t,0x48);}
};
