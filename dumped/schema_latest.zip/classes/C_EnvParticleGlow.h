#pragma once
#include "../memory.h"

class C_EnvParticleGlow {
public:
 uintptr_t baseAddr;
 C_EnvParticleGlow() : baseAddr(0){}
 C_EnvParticleGlow(uintptr_t b):baseAddr(b){}
 uintptr_t m_flAlphaScale(){return SCHEMA_TYPE(uintptr_t,0x1460);}
 uintptr_t m_flRadiusScale(){return SCHEMA_TYPE(uintptr_t,0x1464);}
 uintptr_t m_flSelfIllumScale(){return SCHEMA_TYPE(uintptr_t,0x1468);}
 uintptr_t m_ColorTint(){return SCHEMA_TYPE(uintptr_t,0x146C);}
 uintptr_t m_hTextureOverride(){return SCHEMA_TYPE(uintptr_t,0x1470);}
};
