#pragma once
#include "../memory.h"

class C_PhysPropClientside {
public:
 uintptr_t baseAddr;
 C_PhysPropClientside() : baseAddr(0){}
 C_PhysPropClientside(uintptr_t b):baseAddr(b){}
 uintptr_t m_flTouchDelta(){return SCHEMA_TYPE(uintptr_t,0x1300);}
 uintptr_t m_fDeathTime(){return SCHEMA_TYPE(uintptr_t,0x1304);}
 uintptr_t m_vecDamagePosition(){return SCHEMA_TYPE(uintptr_t,0x1308);}
 uintptr_t m_vecDamageDirection(){return SCHEMA_TYPE(uintptr_t,0x1314);}
 uintptr_t m_nDamageType(){return SCHEMA_TYPE(uintptr_t,0x1320);}
};
