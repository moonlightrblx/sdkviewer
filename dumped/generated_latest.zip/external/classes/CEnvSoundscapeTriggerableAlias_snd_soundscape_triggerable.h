#pragma once
#include "../memory.h"

class CEnvSoundscapeTriggerableAlias_snd_soundscape_triggerable  {
public:
    uintptr_t baseAddr;

    CEnvSoundscapeTriggerableAlias_snd_soundscape_triggerable() { baseAddr = client_base(); }
    CEnvSoundscapeTriggerableAlias_snd_soundscape_triggerable(uintptr_t base) : baseAddr(base) {}

};
