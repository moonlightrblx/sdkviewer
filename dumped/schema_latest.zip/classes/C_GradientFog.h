#pragma once
#include "../memory.h"

class C_GradientFog {
public:
 uintptr_t baseAddr;
 C_GradientFog() : baseAddr(0){}
 C_GradientFog(uintptr_t b):baseAddr(b){}
 uintptr_t m_hGradientFogTexture(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_flFogStartDistance(){return SCHEMA_TYPE(uintptr_t,0x600);}
 uintptr_t m_flFogEndDistance(){return SCHEMA_TYPE(uintptr_t,0x604);}
 uintptr_t m_bHeightFogEnabled(){return SCHEMA_TYPE(uintptr_t,0x608);}
 uintptr_t m_flFogStartHeight(){return SCHEMA_TYPE(uintptr_t,0x60C);}
 uintptr_t m_flFogEndHeight(){return SCHEMA_TYPE(uintptr_t,0x610);}
 uintptr_t m_flFarZ(){return SCHEMA_TYPE(uintptr_t,0x614);}
 uintptr_t m_flFogMaxOpacity(){return SCHEMA_TYPE(uintptr_t,0x618);}
 uintptr_t m_flFogFalloffExponent(){return SCHEMA_TYPE(uintptr_t,0x61C);}
 uintptr_t m_flFogVerticalExponent(){return SCHEMA_TYPE(uintptr_t,0x620);}
 uintptr_t m_fogColor(){return SCHEMA_TYPE(uintptr_t,0x624);}
 uintptr_t m_flFogStrength(){return SCHEMA_TYPE(uintptr_t,0x628);}
 uintptr_t m_flFadeTime(){return SCHEMA_TYPE(uintptr_t,0x62C);}
 uintptr_t m_bStartDisabled(){return SCHEMA_TYPE(uintptr_t,0x630);}
 uintptr_t m_bIsEnabled(){return SCHEMA_TYPE(uintptr_t,0x631);}
 uintptr_t m_bGradientFogNeedsTextures(){return SCHEMA_TYPE(uintptr_t,0x632);}
};
