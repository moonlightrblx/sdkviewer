#pragma once
#include "../memory.h"

class CPathQueryComponent  {
public:
    uintptr_t baseAddr;

    CPathQueryComponent() { baseAddr = client_base(); }
    CPathQueryComponent(uintptr_t base) : baseAddr(base) {}

};
