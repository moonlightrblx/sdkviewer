#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_BulletHitModel  {
public:
    uintptr_t baseAddr;

    C_BulletHitModel() { baseAddr = client_base(); }
    C_BulletHitModel(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_matLocal() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BulletHitModel", "m_matLocal")); }
    int m_iBoneIndex() { return read<int>(baseAddr + offsets_instance.get("C_BulletHitModel", "m_iBoneIndex")); }
    C_BaseEntity* m_hPlayerParent() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_BulletHitModel", "m_hPlayerParent")); }
    bool m_bIsHit() { return read<bool>(baseAddr + offsets_instance.get("C_BulletHitModel", "m_bIsHit")); }
    float m_flTimeCreated() { return read<float>(baseAddr + offsets_instance.get("C_BulletHitModel", "m_flTimeCreated")); }
    Vector3 m_vecStartPos() { return read<Vector3>(baseAddr + offsets_instance.get("C_BulletHitModel", "m_vecStartPos")); }
};
