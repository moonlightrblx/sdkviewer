#pragma once
#include "../memory.h"

class CPulseCell_WaitForCursorsWithTag {
public:
 uintptr_t baseAddr;
 CPulseCell_WaitForCursorsWithTag() : baseAddr(0){}
 CPulseCell_WaitForCursorsWithTag(uintptr_t b):baseAddr(b){}
 uintptr_t m_bTagSelfWhenComplete(){return SCHEMA_TYPE(uintptr_t,0x98);}
 uintptr_t m_nDesiredKillPriority(){return SCHEMA_TYPE(uintptr_t,0x9C);}
};
