#pragma once
#include "../memory.h"

class CPulse_InvokeBinding  {
public:
    uintptr_t baseAddr;

    CPulse_InvokeBinding() { baseAddr = client_base(); }
    CPulse_InvokeBinding(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_RegisterMap() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulse_InvokeBinding", "m_RegisterMap")); }
    uintptr_t m_FuncName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulse_InvokeBinding", "m_FuncName")); }
    uintptr_t m_nCellIndex() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulse_InvokeBinding", "m_nCellIndex")); }
    uintptr_t m_nSrcChunk() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulse_InvokeBinding", "m_nSrcChunk")); }
    int m_nSrcInstruction() { return read<int>(baseAddr + offsets_instance.get("CPulse_InvokeBinding", "m_nSrcInstruction")); }
};
