#pragma once
#include "../memory.h"

class C_WeaponBaseItem  {
public:
    uintptr_t baseAddr;

    C_WeaponBaseItem() { baseAddr = 0; }
    C_WeaponBaseItem(uintptr_t base) : baseAddr(base) {}

    bool m_bSequenceInProgress() { return read<bool>(baseAddr + offsets_instance.get("C_WeaponBaseItem", "m_bSequenceInProgress")); }
    bool m_bRedraw() { return read<bool>(baseAddr + offsets_instance.get("C_WeaponBaseItem", "m_bRedraw")); }
};
