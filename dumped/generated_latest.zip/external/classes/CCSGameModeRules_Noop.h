#pragma once
#include "../memory.h"

class CCSGameModeRules_Noop  {
public:
    uintptr_t baseAddr;

    CCSGameModeRules_Noop() { baseAddr = client_base(); }
    CCSGameModeRules_Noop(uintptr_t base) : baseAddr(base) {}

};
