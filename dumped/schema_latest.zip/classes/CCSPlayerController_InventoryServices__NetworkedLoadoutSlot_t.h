#pragma once
#include "../memory.h"

class CCSPlayerController_InventoryServices__NetworkedLoadoutSlot_t {
public:
 uintptr_t baseAddr;
 CCSPlayerController_InventoryServices__NetworkedLoadoutSlot_t() : baseAddr(0){}
 CCSPlayerController_InventoryServices__NetworkedLoadoutSlot_t(uintptr_t b):baseAddr(b){}
 uintptr_t pItem(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t team(){return SCHEMA_TYPE(uintptr_t,0x8);}
 uintptr_t slot(){return SCHEMA_TYPE(uintptr_t,0xA);}
};
