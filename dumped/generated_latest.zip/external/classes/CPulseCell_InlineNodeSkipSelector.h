#pragma once
#include "../memory.h"

class CPulseCell_InlineNodeSkipSelector  {
public:
    uintptr_t baseAddr;

    CPulseCell_InlineNodeSkipSelector() { baseAddr = client_base(); }
    CPulseCell_InlineNodeSkipSelector(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_nFlowNodeID() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_InlineNodeSkipSelector", "m_nFlowNodeID")); }
    bool m_bAnd() { return read<bool>(baseAddr + offsets_instance.get("CPulseCell_InlineNodeSkipSelector", "m_bAnd")); }
    uintptr_t m_PassOutflow() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_InlineNodeSkipSelector", "m_PassOutflow")); }
    uintptr_t m_FailOutflow() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_InlineNodeSkipSelector", "m_FailOutflow")); }
};
