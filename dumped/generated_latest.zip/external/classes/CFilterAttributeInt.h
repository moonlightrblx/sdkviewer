#pragma once
#include "../memory.h"

class CFilterAttributeInt  {
public:
    uintptr_t baseAddr;

    CFilterAttributeInt() { baseAddr = client_base(); }
    CFilterAttributeInt(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_sAttributeName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CFilterAttributeInt", "m_sAttributeName")); }
};
