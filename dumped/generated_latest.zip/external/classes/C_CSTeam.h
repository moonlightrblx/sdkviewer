#pragma once
#include "../memory.h"

class C_CSTeam  {
public:
    uintptr_t baseAddr;

    C_CSTeam() { baseAddr = client_base(); }
    C_CSTeam(uintptr_t base) : baseAddr(base) {}

    char* m_szTeamMatchStat() { return read<char*>(baseAddr + offsets_instance.get("C_CSTeam", "m_szTeamMatchStat")); }
    int m_numMapVictories() { return read<int>(baseAddr + offsets_instance.get("C_CSTeam", "m_numMapVictories")); }
    bool m_bSurrendered() { return read<bool>(baseAddr + offsets_instance.get("C_CSTeam", "m_bSurrendered")); }
    int m_scoreFirstHalf() { return read<int>(baseAddr + offsets_instance.get("C_CSTeam", "m_scoreFirstHalf")); }
    int m_scoreSecondHalf() { return read<int>(baseAddr + offsets_instance.get("C_CSTeam", "m_scoreSecondHalf")); }
    int m_scoreOvertime() { return read<int>(baseAddr + offsets_instance.get("C_CSTeam", "m_scoreOvertime")); }
    char* m_szClanTeamname() { return read<char*>(baseAddr + offsets_instance.get("C_CSTeam", "m_szClanTeamname")); }
    int m_iClanID() { return read<int>(baseAddr + offsets_instance.get("C_CSTeam", "m_iClanID")); }
    char* m_szTeamFlagImage() { return read<char*>(baseAddr + offsets_instance.get("C_CSTeam", "m_szTeamFlagImage")); }
    char* m_szTeamLogoImage() { return read<char*>(baseAddr + offsets_instance.get("C_CSTeam", "m_szTeamLogoImage")); }
};
