#pragma once
#include "../memory.h"
#include "../classes/CountdownTimer.h"
#include "../classes/EntitySpottedState_t.h"
#include "../classes/GameTime_t.h"
#include "../types/Vector3.h"
class CBasePlayerController;
class C_BaseEntity;
class C_CSPlayerPawn;

class C_Hostage  {
public:
    uintptr_t baseAddr;

    C_Hostage() { baseAddr = 0; }
    C_Hostage(uintptr_t base) : baseAddr(base) {}

    EntitySpottedState_t m_entitySpottedState() { return read<EntitySpottedState_t>(baseAddr + offsets_instance.get("C_Hostage", "m_entitySpottedState")); }
    C_BaseEntity* m_leader() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_Hostage", "m_leader")); }
    CountdownTimer m_reuseTimer() { return read<CountdownTimer>(baseAddr + offsets_instance.get("C_Hostage", "m_reuseTimer")); }
    Vector3 m_vel() { return read<Vector3>(baseAddr + offsets_instance.get("C_Hostage", "m_vel")); }
    bool m_isRescued() { return read<bool>(baseAddr + offsets_instance.get("C_Hostage", "m_isRescued")); }
    bool m_jumpedThisFrame() { return read<bool>(baseAddr + offsets_instance.get("C_Hostage", "m_jumpedThisFrame")); }
    int m_nHostageState() { return read<int>(baseAddr + offsets_instance.get("C_Hostage", "m_nHostageState")); }
    bool m_bHandsHaveBeenCut() { return read<bool>(baseAddr + offsets_instance.get("C_Hostage", "m_bHandsHaveBeenCut")); }
    C_CSPlayerPawn* m_hHostageGrabber() { return read<C_CSPlayerPawn*>(baseAddr + offsets_instance.get("C_Hostage", "m_hHostageGrabber")); }
    GameTime_t m_fLastGrabTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_Hostage", "m_fLastGrabTime")); }
    Vector3 m_vecGrabbedPos() { return read<Vector3>(baseAddr + offsets_instance.get("C_Hostage", "m_vecGrabbedPos")); }
    GameTime_t m_flRescueStartTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_Hostage", "m_flRescueStartTime")); }
    GameTime_t m_flGrabSuccessTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_Hostage", "m_flGrabSuccessTime")); }
    GameTime_t m_flDropStartTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_Hostage", "m_flDropStartTime")); }
    GameTime_t m_flDeadOrRescuedTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_Hostage", "m_flDeadOrRescuedTime")); }
    CountdownTimer m_blinkTimer() { return read<CountdownTimer>(baseAddr + offsets_instance.get("C_Hostage", "m_blinkTimer")); }
    Vector3 m_lookAt() { return read<Vector3>(baseAddr + offsets_instance.get("C_Hostage", "m_lookAt")); }
    CountdownTimer m_lookAroundTimer() { return read<CountdownTimer>(baseAddr + offsets_instance.get("C_Hostage", "m_lookAroundTimer")); }
    bool m_isInit() { return read<bool>(baseAddr + offsets_instance.get("C_Hostage", "m_isInit")); }
    uintptr_t m_eyeAttachment() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_Hostage", "m_eyeAttachment")); }
    uintptr_t m_chestAttachment() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_Hostage", "m_chestAttachment")); }
    CBasePlayerController* m_pPredictionOwner() { return read<CBasePlayerController*>(baseAddr + offsets_instance.get("C_Hostage", "m_pPredictionOwner")); }
    GameTime_t m_fNewestAlphaThinkTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_Hostage", "m_fNewestAlphaThinkTime")); }
};
