#pragma once
#include "../memory.h"
#include "../classes/VPhysicsCollisionAttribute_t.h"
#include "../types/Vector3.h"

class CCollisionProperty  {
public:
    uintptr_t baseAddr;

    CCollisionProperty() { baseAddr = 0; }
    CCollisionProperty(uintptr_t base) : baseAddr(base) {}

    VPhysicsCollisionAttribute_t m_collisionAttribute() { return read<VPhysicsCollisionAttribute_t>(baseAddr + offsets_instance.get("CCollisionProperty", "m_collisionAttribute")); }
    Vector3 m_vecMins() { return read<Vector3>(baseAddr + offsets_instance.get("CCollisionProperty", "m_vecMins")); }
    Vector3 m_vecMaxs() { return read<Vector3>(baseAddr + offsets_instance.get("CCollisionProperty", "m_vecMaxs")); }
    uint8_t m_usSolidFlags() { return read<uint8_t>(baseAddr + offsets_instance.get("CCollisionProperty", "m_usSolidFlags")); }
    uintptr_t m_nSolidType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCollisionProperty", "m_nSolidType")); }
    uint8_t m_triggerBloat() { return read<uint8_t>(baseAddr + offsets_instance.get("CCollisionProperty", "m_triggerBloat")); }
    uintptr_t m_nSurroundType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCollisionProperty", "m_nSurroundType")); }
    uint8_t m_CollisionGroup() { return read<uint8_t>(baseAddr + offsets_instance.get("CCollisionProperty", "m_CollisionGroup")); }
    uint8_t m_nEnablePhysics() { return read<uint8_t>(baseAddr + offsets_instance.get("CCollisionProperty", "m_nEnablePhysics")); }
    float m_flBoundingRadius() { return read<float>(baseAddr + offsets_instance.get("CCollisionProperty", "m_flBoundingRadius")); }
    Vector3 m_vecSpecifiedSurroundingMins() { return read<Vector3>(baseAddr + offsets_instance.get("CCollisionProperty", "m_vecSpecifiedSurroundingMins")); }
    Vector3 m_vecSpecifiedSurroundingMaxs() { return read<Vector3>(baseAddr + offsets_instance.get("CCollisionProperty", "m_vecSpecifiedSurroundingMaxs")); }
    Vector3 m_vecSurroundingMaxs() { return read<Vector3>(baseAddr + offsets_instance.get("CCollisionProperty", "m_vecSurroundingMaxs")); }
    Vector3 m_vecSurroundingMins() { return read<Vector3>(baseAddr + offsets_instance.get("CCollisionProperty", "m_vecSurroundingMins")); }
    Vector3 m_vCapsuleCenter1() { return read<Vector3>(baseAddr + offsets_instance.get("CCollisionProperty", "m_vCapsuleCenter1")); }
    Vector3 m_vCapsuleCenter2() { return read<Vector3>(baseAddr + offsets_instance.get("CCollisionProperty", "m_vCapsuleCenter2")); }
    float m_flCapsuleRadius() { return read<float>(baseAddr + offsets_instance.get("CCollisionProperty", "m_flCapsuleRadius")); }
};
