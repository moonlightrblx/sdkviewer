#pragma once
#include "../memory.h"

class CCSGameModeRules  {
public:
    uintptr_t baseAddr;

    CCSGameModeRules() { baseAddr = client_base(); }
    CCSGameModeRules(uintptr_t base) : baseAddr(base) {}

    uintptr_t __m_pChainEntity() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSGameModeRules", "__m_pChainEntity")); }
};
