#pragma once
#include "../memory.h"

class CSkeletonInstance {
public:
 uintptr_t baseAddr;
 CSkeletonInstance() : baseAddr(0){}
 CSkeletonInstance(uintptr_t b):baseAddr(b){}
 uintptr_t m_modelState(){return SCHEMA_TYPE(uintptr_t,0x190);}
 uintptr_t m_bIsAnimationEnabled(){return SCHEMA_TYPE(uintptr_t,0x490);}
 uintptr_t m_bUseParentRenderBounds(){return SCHEMA_TYPE(uintptr_t,0x491);}
 uintptr_t m_bDisableSolidCollisionsForHierarchy(){return SCHEMA_TYPE(uintptr_t,0x492);}
 uintptr_t m_bDirtyMotionType(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_bIsGeneratingLatchedParentSpaceState(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_materialGroup(){return SCHEMA_TYPE(uintptr_t,0x494);}
 uintptr_t m_nHitboxSet(){return SCHEMA_TYPE(uintptr_t,0x498);}
};
