#pragma once
#include "../memory.h"

class EngineLoopState_t  {
public:
    uintptr_t baseAddr;

    EngineLoopState_t() { baseAddr = 0; }
    EngineLoopState_t(uintptr_t base) : baseAddr(base) {}

    int m_nPlatWindowWidth() { return read<int>(baseAddr + offsets_instance.get("EngineLoopState_t", "m_nPlatWindowWidth")); }
    int m_nPlatWindowHeight() { return read<int>(baseAddr + offsets_instance.get("EngineLoopState_t", "m_nPlatWindowHeight")); }
    int m_nRenderWidth() { return read<int>(baseAddr + offsets_instance.get("EngineLoopState_t", "m_nRenderWidth")); }
    int m_nRenderHeight() { return read<int>(baseAddr + offsets_instance.get("EngineLoopState_t", "m_nRenderHeight")); }
};
