#pragma once
#include <windows.h>
#include <tlhelp32.h>
#include <cstdint>
#include <cstddef>
#include <string>
#include "../updater/updater.h"

inline DWORD get_process_id(const char* name){ /* unchanged */ return 0; }
inline uintptr_t get_module_base(DWORD pid,const char* name){ return 0; }
inline HANDLE get_process_handle(){ return nullptr; }
inline uintptr_t client_base(){ return 0; }
inline uintptr_t engine_base(){ return 0; }

template<typename T> inline T read(uintptr_t addr){ return T{}; }
template<typename T> inline void write(uintptr_t addr,T value){}

inline c_offsets offsets_instance;
