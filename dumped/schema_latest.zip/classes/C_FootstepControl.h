#pragma once
#include "../memory.h"

class C_FootstepControl {
public:
 uintptr_t baseAddr;
 C_FootstepControl() : baseAddr(0){}
 C_FootstepControl(uintptr_t b):baseAddr(b){}
 uintptr_t m_source(){return SCHEMA_TYPE(uintptr_t,0xFF0);}
 uintptr_t m_destination(){return SCHEMA_TYPE(uintptr_t,0xFF8);}
};
