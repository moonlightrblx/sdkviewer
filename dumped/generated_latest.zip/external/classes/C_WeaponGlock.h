#pragma once
#include "../memory.h"

class C_WeaponGlock  {
public:
    uintptr_t baseAddr;

    C_WeaponGlock() { baseAddr = client_base(); }
    C_WeaponGlock(uintptr_t base) : baseAddr(base) {}

};
