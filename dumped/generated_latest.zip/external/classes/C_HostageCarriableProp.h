#pragma once
#include "../memory.h"

class C_HostageCarriableProp  {
public:
    uintptr_t baseAddr;

    C_HostageCarriableProp() { baseAddr = 0; }
    C_HostageCarriableProp(uintptr_t base) : baseAddr(base) {}

};
