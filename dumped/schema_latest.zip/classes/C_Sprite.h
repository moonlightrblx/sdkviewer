#pragma once
#include "../memory.h"

class C_Sprite {
public:
 uintptr_t baseAddr;
 C_Sprite() : baseAddr(0){}
 C_Sprite(uintptr_t b):baseAddr(b){}
 uintptr_t m_hSpriteMaterial(){return SCHEMA_TYPE(uintptr_t,0xEB0);}
 uintptr_t m_hAttachedToEntity(){return SCHEMA_TYPE(uintptr_t,0xEB8);}
 uintptr_t m_nAttachment(){return SCHEMA_TYPE(uintptr_t,0xEBC);}
 uintptr_t m_flSpriteFramerate(){return SCHEMA_TYPE(uintptr_t,0xEC0);}
 uintptr_t m_flFrame(){return SCHEMA_TYPE(uintptr_t,0xEC4);}
 uintptr_t m_flDieTime(){return SCHEMA_TYPE(uintptr_t,0xEC8);}
 uintptr_t m_nBrightness(){return SCHEMA_TYPE(uintptr_t,0xED8);}
 uintptr_t m_flBrightnessDuration(){return SCHEMA_TYPE(uintptr_t,0xEDC);}
 uintptr_t m_flSpriteScale(){return SCHEMA_TYPE(uintptr_t,0xEE0);}
 uintptr_t m_flScaleDuration(){return SCHEMA_TYPE(uintptr_t,0xEE4);}
 uintptr_t m_bWorldSpaceScale(){return SCHEMA_TYPE(uintptr_t,0xEE8);}
 uintptr_t m_flGlowProxySize(){return SCHEMA_TYPE(uintptr_t,0xEEC);}
 uintptr_t m_flHDRColorScale(){return SCHEMA_TYPE(uintptr_t,0xEF0);}
 uintptr_t m_flLastTime(){return SCHEMA_TYPE(uintptr_t,0xEF4);}
 uintptr_t m_flMaxFrame(){return SCHEMA_TYPE(uintptr_t,0xEF8);}
 uintptr_t m_flStartScale(){return SCHEMA_TYPE(uintptr_t,0xEFC);}
 uintptr_t m_flDestScale(){return SCHEMA_TYPE(uintptr_t,0xF00);}
 uintptr_t m_flScaleTimeStart(){return SCHEMA_TYPE(uintptr_t,0xF04);}
 uintptr_t m_nStartBrightness(){return SCHEMA_TYPE(uintptr_t,0xF08);}
 uintptr_t m_nDestBrightness(){return SCHEMA_TYPE(uintptr_t,0xF0C);}
 uintptr_t m_flBrightnessTimeStart(){return SCHEMA_TYPE(uintptr_t,0xF10);}
 uintptr_t m_nSpriteWidth(){return SCHEMA_TYPE(uintptr_t,0xF20);}
 uintptr_t m_nSpriteHeight(){return SCHEMA_TYPE(uintptr_t,0xF24);}
};
