#pragma once
#include "../memory.h"

class CFilterMassGreater {
public:
 uintptr_t baseAddr;
 CFilterMassGreater() : baseAddr(0){}
 CFilterMassGreater(uintptr_t b):baseAddr(b){}
 uintptr_t m_fFilterMass(){return SCHEMA_TYPE(uintptr_t,0x650);}
};
