#pragma once
#include "../memory.h"

class CNetworkVarChainer {
public:
 uintptr_t baseAddr;
 CNetworkVarChainer() : baseAddr(0){}
 CNetworkVarChainer(uintptr_t b):baseAddr(b){}
 uintptr_t m_PathIndex(){return SCHEMA_TYPE(uintptr_t,0x20);}
};
