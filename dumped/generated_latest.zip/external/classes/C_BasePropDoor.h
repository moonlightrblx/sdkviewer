#pragma once
#include "../memory.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"

class C_BasePropDoor  {
public:
    uintptr_t baseAddr;

    C_BasePropDoor() { baseAddr = 0; }
    C_BasePropDoor(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_eDoorState() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BasePropDoor", "m_eDoorState")); }
    bool m_modelChanged() { return read<bool>(baseAddr + offsets_instance.get("C_BasePropDoor", "m_modelChanged")); }
    bool m_bLocked() { return read<bool>(baseAddr + offsets_instance.get("C_BasePropDoor", "m_bLocked")); }
    bool m_bNoNPCs() { return read<bool>(baseAddr + offsets_instance.get("C_BasePropDoor", "m_bNoNPCs")); }
    Vector3 m_closedPosition() { return read<Vector3>(baseAddr + offsets_instance.get("C_BasePropDoor", "m_closedPosition")); }
    QAngle m_closedAngles() { return read<QAngle>(baseAddr + offsets_instance.get("C_BasePropDoor", "m_closedAngles")); }
    C_BasePropDoor* m_hMaster() { return read<C_BasePropDoor*>(baseAddr + offsets_instance.get("C_BasePropDoor", "m_hMaster")); }
    Vector3 m_vWhereToSetLightingOrigin() { return read<Vector3>(baseAddr + offsets_instance.get("C_BasePropDoor", "m_vWhereToSetLightingOrigin")); }
};
