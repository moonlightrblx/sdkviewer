#pragma once
#include "../memory.h"

class CPathSimpleAPI  {
public:
    uintptr_t baseAddr;

    CPathSimpleAPI() { baseAddr = 0; }
    CPathSimpleAPI(uintptr_t base) : baseAddr(base) {}

};
