#pragma once
#include "../memory.h"

class CEnvSoundscapeTriggerableAlias_snd_soundscape_triggerable {
public:
 uintptr_t baseAddr;
 CEnvSoundscapeTriggerableAlias_snd_soundscape_triggerable() : baseAddr(0){}
 CEnvSoundscapeTriggerableAlias_snd_soundscape_triggerable(uintptr_t b):baseAddr(b){}
};
