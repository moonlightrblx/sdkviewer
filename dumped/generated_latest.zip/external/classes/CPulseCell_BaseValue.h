#pragma once
#include "../memory.h"

class CPulseCell_BaseValue  {
public:
    uintptr_t baseAddr;

    CPulseCell_BaseValue() { baseAddr = client_base(); }
    CPulseCell_BaseValue(uintptr_t base) : baseAddr(base) {}

};
