#pragma once
#include "../memory.h"

class CPulseCell_BooleanSwitchState  {
public:
    uintptr_t baseAddr;

    CPulseCell_BooleanSwitchState() { baseAddr = client_base(); }
    CPulseCell_BooleanSwitchState(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_Condition() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_BooleanSwitchState", "m_Condition")); }
    uintptr_t m_SubGraph() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_BooleanSwitchState", "m_SubGraph")); }
    uintptr_t m_WhenTrue() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_BooleanSwitchState", "m_WhenTrue")); }
    uintptr_t m_WhenFalse() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_BooleanSwitchState", "m_WhenFalse")); }
};
