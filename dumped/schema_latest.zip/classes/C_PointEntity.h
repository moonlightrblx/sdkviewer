#pragma once
#include "../memory.h"

class C_PointEntity {
public:
 uintptr_t baseAddr;
 C_PointEntity() : baseAddr(0){}
 C_PointEntity(uintptr_t b):baseAddr(b){}
};
