#pragma once
#include "../memory.h"

class C_CS2HudModelBase  {
public:
    uintptr_t baseAddr;

    C_CS2HudModelBase() { baseAddr = client_base(); }
    C_CS2HudModelBase(uintptr_t base) : baseAddr(base) {}

};
