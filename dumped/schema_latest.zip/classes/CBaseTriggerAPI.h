#pragma once
#include "../memory.h"

class CBaseTriggerAPI {
public:
 uintptr_t baseAddr;
 CBaseTriggerAPI() : baseAddr(0){}
 CBaseTriggerAPI(uintptr_t b):baseAddr(b){}
};
