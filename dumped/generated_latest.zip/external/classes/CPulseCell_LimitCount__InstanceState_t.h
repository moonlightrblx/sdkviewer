#pragma once
#include "../memory.h"

class CPulseCell_LimitCount__InstanceState_t  {
public:
    uintptr_t baseAddr;

    CPulseCell_LimitCount__InstanceState_t() { baseAddr = 0; }
    CPulseCell_LimitCount__InstanceState_t(uintptr_t base) : baseAddr(base) {}

    int m_nCurrentCount() { return read<int>(baseAddr + offsets_instance.get("CPulseCell_LimitCount__InstanceState_t", "m_nCurrentCount")); }
};
