#pragma once
#include "../memory.h"
#include "../types/Vector3.h"
class C_BaseEntity;

class C_RagdollProp  {
public:
    uintptr_t baseAddr;

    C_RagdollProp() { baseAddr = 0; }
    C_RagdollProp(uintptr_t base) : baseAddr(base) {}

    bool m_ragEnabled() { return read<bool>(baseAddr + offsets_instance.get("C_RagdollProp", "m_ragEnabled")); }
    Vector3 m_ragPos() { return read<Vector3>(baseAddr + offsets_instance.get("C_RagdollProp", "m_ragPos")); }
    Vector3 m_ragAngles() { return read<Vector3>(baseAddr + offsets_instance.get("C_RagdollProp", "m_ragAngles")); }
    float m_flBlendWeight() { return read<float>(baseAddr + offsets_instance.get("C_RagdollProp", "m_flBlendWeight")); }
    C_BaseEntity* m_hRagdollSource() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_RagdollProp", "m_hRagdollSource")); }
    uintptr_t m_iEyeAttachment() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_RagdollProp", "m_iEyeAttachment")); }
    float m_flBlendWeightCurrent() { return read<float>(baseAddr + offsets_instance.get("C_RagdollProp", "m_flBlendWeightCurrent")); }
    int m_parentPhysicsBoneIndices() { return read<int>(baseAddr + offsets_instance.get("C_RagdollProp", "m_parentPhysicsBoneIndices")); }
    int m_worldSpaceBoneComputationOrder() { return read<int>(baseAddr + offsets_instance.get("C_RagdollProp", "m_worldSpaceBoneComputationOrder")); }
};
