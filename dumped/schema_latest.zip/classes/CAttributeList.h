#pragma once
#include "../memory.h"

class CAttributeList {
public:
 uintptr_t baseAddr;
 CAttributeList() : baseAddr(0){}
 CAttributeList(uintptr_t b):baseAddr(b){}
 uintptr_t m_Attributes(){return SCHEMA_TYPE(uintptr_t,0x8);}
 uintptr_t m_pManager(){return SCHEMA_TYPE(uintptr_t,0x70);}
};
