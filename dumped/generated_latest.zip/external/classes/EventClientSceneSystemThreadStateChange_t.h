#pragma once
#include "../memory.h"

class EventClientSceneSystemThreadStateChange_t  {
public:
    uintptr_t baseAddr;

    EventClientSceneSystemThreadStateChange_t() { baseAddr = 0; }
    EventClientSceneSystemThreadStateChange_t(uintptr_t base) : baseAddr(base) {}

    bool m_bThreadsActive() { return read<bool>(baseAddr + offsets_instance.get("EventClientSceneSystemThreadStateChange_t", "m_bThreadsActive")); }
};
