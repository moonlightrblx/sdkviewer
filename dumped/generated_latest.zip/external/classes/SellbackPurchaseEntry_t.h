#pragma once
#include "../memory.h"

class SellbackPurchaseEntry_t  {
public:
    uintptr_t baseAddr;

    SellbackPurchaseEntry_t() { baseAddr = client_base(); }
    SellbackPurchaseEntry_t(uintptr_t base) : baseAddr(base) {}

    uint16_t m_unDefIdx() { return read<uint16_t>(baseAddr + offsets_instance.get("SellbackPurchaseEntry_t", "m_unDefIdx")); }
    int m_nCost() { return read<int>(baseAddr + offsets_instance.get("SellbackPurchaseEntry_t", "m_nCost")); }
    int m_nPrevArmor() { return read<int>(baseAddr + offsets_instance.get("SellbackPurchaseEntry_t", "m_nPrevArmor")); }
    bool m_bPrevHelmet() { return read<bool>(baseAddr + offsets_instance.get("SellbackPurchaseEntry_t", "m_bPrevHelmet")); }
    uintptr_t m_hItem() { return read<uintptr_t>(baseAddr + offsets_instance.get("SellbackPurchaseEntry_t", "m_hItem")); }
};
