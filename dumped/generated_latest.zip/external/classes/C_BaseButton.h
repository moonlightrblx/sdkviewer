#pragma once
#include "../memory.h"
class C_BaseModelEntity;

class C_BaseButton  {
public:
    uintptr_t baseAddr;

    C_BaseButton() { baseAddr = 0; }
    C_BaseButton(uintptr_t base) : baseAddr(base) {}

    C_BaseModelEntity* m_glowEntity() { return read<C_BaseModelEntity*>(baseAddr + offsets_instance.get("C_BaseButton", "m_glowEntity")); }
    bool m_usable() { return read<bool>(baseAddr + offsets_instance.get("C_BaseButton", "m_usable")); }
    uintptr_t m_szDisplayText() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseButton", "m_szDisplayText")); }
};
