#pragma once
#include "../memory.h"

class C_WeaponXM1014 {
public:
 uintptr_t baseAddr;
 C_WeaponXM1014() : baseAddr(0){}
 C_WeaponXM1014(uintptr_t b):baseAddr(b){}
};
