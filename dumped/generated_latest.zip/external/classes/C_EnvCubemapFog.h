#pragma once
#include "../memory.h"

class C_EnvCubemapFog  {
public:
    uintptr_t baseAddr;

    C_EnvCubemapFog() { baseAddr = client_base(); }
    C_EnvCubemapFog(uintptr_t base) : baseAddr(base) {}

    float m_flEndDistance() { return read<float>(baseAddr + offsets_instance.get("C_EnvCubemapFog", "m_flEndDistance")); }
    float m_flStartDistance() { return read<float>(baseAddr + offsets_instance.get("C_EnvCubemapFog", "m_flStartDistance")); }
    float m_flFogFalloffExponent() { return read<float>(baseAddr + offsets_instance.get("C_EnvCubemapFog", "m_flFogFalloffExponent")); }
    bool m_bHeightFogEnabled() { return read<bool>(baseAddr + offsets_instance.get("C_EnvCubemapFog", "m_bHeightFogEnabled")); }
    float m_flFogHeightWidth() { return read<float>(baseAddr + offsets_instance.get("C_EnvCubemapFog", "m_flFogHeightWidth")); }
    float m_flFogHeightEnd() { return read<float>(baseAddr + offsets_instance.get("C_EnvCubemapFog", "m_flFogHeightEnd")); }
    float m_flFogHeightStart() { return read<float>(baseAddr + offsets_instance.get("C_EnvCubemapFog", "m_flFogHeightStart")); }
    float m_flFogHeightExponent() { return read<float>(baseAddr + offsets_instance.get("C_EnvCubemapFog", "m_flFogHeightExponent")); }
    float m_flLODBias() { return read<float>(baseAddr + offsets_instance.get("C_EnvCubemapFog", "m_flLODBias")); }
    bool m_bActive() { return read<bool>(baseAddr + offsets_instance.get("C_EnvCubemapFog", "m_bActive")); }
    bool m_bStartDisabled() { return read<bool>(baseAddr + offsets_instance.get("C_EnvCubemapFog", "m_bStartDisabled")); }
    float m_flFogMaxOpacity() { return read<float>(baseAddr + offsets_instance.get("C_EnvCubemapFog", "m_flFogMaxOpacity")); }
    int m_nCubemapSourceType() { return read<int>(baseAddr + offsets_instance.get("C_EnvCubemapFog", "m_nCubemapSourceType")); }
    uintptr_t m_hSkyMaterial() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvCubemapFog", "m_hSkyMaterial")); }
    uintptr_t m_iszSkyEntity() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvCubemapFog", "m_iszSkyEntity")); }
    uintptr_t m_hFogCubemapTexture() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvCubemapFog", "m_hFogCubemapTexture")); }
    bool m_bHasHeightFogEnd() { return read<bool>(baseAddr + offsets_instance.get("C_EnvCubemapFog", "m_bHasHeightFogEnd")); }
    bool m_bFirstTime() { return read<bool>(baseAddr + offsets_instance.get("C_EnvCubemapFog", "m_bFirstTime")); }
};
