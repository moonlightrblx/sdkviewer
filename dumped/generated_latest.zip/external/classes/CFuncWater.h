#pragma once
#include "../memory.h"
#include "../classes/CBuoyancyHelper.h"

class CFuncWater  {
public:
    uintptr_t baseAddr;

    CFuncWater() { baseAddr = 0; }
    CFuncWater(uintptr_t base) : baseAddr(base) {}

    CBuoyancyHelper m_BuoyancyHelper() { return read<CBuoyancyHelper>(baseAddr + offsets_instance.get("CFuncWater", "m_BuoyancyHelper")); }
};
