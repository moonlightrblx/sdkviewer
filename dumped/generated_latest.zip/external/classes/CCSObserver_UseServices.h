#pragma once
#include "../memory.h"

class CCSObserver_UseServices  {
public:
    uintptr_t baseAddr;

    CCSObserver_UseServices() { baseAddr = client_base(); }
    CCSObserver_UseServices(uintptr_t base) : baseAddr(base) {}

};
