#pragma once
#include "../memory.h"

class C_EnvWindVolume {
public:
 uintptr_t baseAddr;
 C_EnvWindVolume() : baseAddr(0){}
 C_EnvWindVolume(uintptr_t b):baseAddr(b){}
 uintptr_t m_bActive(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_vBoxMins(){return SCHEMA_TYPE(uintptr_t,0x5FC);}
 uintptr_t m_vBoxMaxs(){return SCHEMA_TYPE(uintptr_t,0x608);}
 uintptr_t m_bStartDisabled(){return SCHEMA_TYPE(uintptr_t,0x614);}
 uintptr_t m_nShape(){return SCHEMA_TYPE(uintptr_t,0x618);}
 uintptr_t m_fWindSpeedMultiplier(){return SCHEMA_TYPE(uintptr_t,0x61C);}
 uintptr_t m_fWindTurbulenceMultiplier(){return SCHEMA_TYPE(uintptr_t,0x620);}
 uintptr_t m_fWindSpeedVariationMultiplier(){return SCHEMA_TYPE(uintptr_t,0x624);}
 uintptr_t m_fWindDirectionVariationMultiplier(){return SCHEMA_TYPE(uintptr_t,0x628);}
};
