#pragma once
#include "../memory.h"

class CPlayer_WaterServices  {
public:
    uintptr_t baseAddr;

    CPlayer_WaterServices() { baseAddr = client_base(); }
    CPlayer_WaterServices(uintptr_t base) : baseAddr(base) {}

};
