#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class CCSPlayer_WaterServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_WaterServices() { baseAddr = 0; }
    CCSPlayer_WaterServices(uintptr_t base) : baseAddr(base) {}

    float m_flWaterJumpTime() { return read<float>(baseAddr + offsets_instance.get("CCSPlayer_WaterServices", "m_flWaterJumpTime")); }
    Vector3 m_vecWaterJumpVel() { return read<Vector3>(baseAddr + offsets_instance.get("CCSPlayer_WaterServices", "m_vecWaterJumpVel")); }
    float m_flSwimSoundTime() { return read<float>(baseAddr + offsets_instance.get("CCSPlayer_WaterServices", "m_flSwimSoundTime")); }
};
