#pragma once
#include "../memory.h"

class C_ShatterGlassShardPhysics {
public:
 uintptr_t baseAddr;
 C_ShatterGlassShardPhysics() : baseAddr(0){}
 C_ShatterGlassShardPhysics(uintptr_t b):baseAddr(b){}
 uintptr_t m_ShardDesc(){return SCHEMA_TYPE(uintptr_t,0x1318);}
};
