#pragma once
#include "../memory.h"

class C_RagdollProp {
public:
 uintptr_t baseAddr;
 C_RagdollProp() : baseAddr(0){}
 C_RagdollProp(uintptr_t b):baseAddr(b){}
 uintptr_t m_ragEnabled(){return SCHEMA_TYPE(uintptr_t,0x1160);}
 uintptr_t m_ragPos(){return SCHEMA_TYPE(uintptr_t,0x1178);}
 uintptr_t m_ragAngles(){return SCHEMA_TYPE(uintptr_t,0x1190);}
 uintptr_t m_flBlendWeight(){return SCHEMA_TYPE(uintptr_t,0x11A8);}
 uintptr_t m_hRagdollSource(){return SCHEMA_TYPE(uintptr_t,0x11AC);}
 uintptr_t m_iEyeAttachment(){return SCHEMA_TYPE(uintptr_t,0x11B0);}
 uintptr_t m_flBlendWeightCurrent(){return SCHEMA_TYPE(uintptr_t,0x11B4);}
 uintptr_t m_parentPhysicsBoneIndices(){return SCHEMA_TYPE(uintptr_t,0x11B8);}
 uintptr_t m_worldSpaceBoneComputationOrder(){return SCHEMA_TYPE(uintptr_t,0x11D0);}
};
