#pragma once
#include "../memory.h"

class CCSObserver_CameraServices  {
public:
    uintptr_t baseAddr;

    CCSObserver_CameraServices() { baseAddr = client_base(); }
    CCSObserver_CameraServices(uintptr_t base) : baseAddr(base) {}

};
