#pragma once
#include "../memory.h"

class C_LightDirectionalEntity {
public:
 uintptr_t baseAddr;
 C_LightDirectionalEntity() : baseAddr(0){}
 C_LightDirectionalEntity(uintptr_t b):baseAddr(b){}
};
