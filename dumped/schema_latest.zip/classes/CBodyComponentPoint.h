#pragma once
#include "../memory.h"

class CBodyComponentPoint {
public:
 uintptr_t baseAddr;
 CBodyComponentPoint() : baseAddr(0){}
 CBodyComponentPoint(uintptr_t b):baseAddr(b){}
 uintptr_t m_sceneNode(){return SCHEMA_TYPE(uintptr_t,0x80);}
};
