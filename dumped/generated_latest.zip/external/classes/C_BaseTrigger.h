#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_BaseTrigger  {
public:
    uintptr_t baseAddr;

    C_BaseTrigger() { baseAddr = client_base(); }
    C_BaseTrigger(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_OnStartTouch() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseTrigger", "m_OnStartTouch")); }
    uintptr_t m_OnStartTouchAll() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseTrigger", "m_OnStartTouchAll")); }
    uintptr_t m_OnEndTouch() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseTrigger", "m_OnEndTouch")); }
    uintptr_t m_OnEndTouchAll() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseTrigger", "m_OnEndTouchAll")); }
    uintptr_t m_OnTouching() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseTrigger", "m_OnTouching")); }
    uintptr_t m_OnTouchingEachEntity() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseTrigger", "m_OnTouchingEachEntity")); }
    uintptr_t m_OnNotTouching() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseTrigger", "m_OnNotTouching")); }
    Vector3 m_hTouchingEntities() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseTrigger", "m_hTouchingEntities")); }
    uintptr_t m_iFilterName() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseTrigger", "m_iFilterName")); }
    CBaseFilter* m_hFilter() { return read<CBaseFilter*>(baseAddr + offsets_instance.get("C_BaseTrigger", "m_hFilter")); }
    bool m_bDisabled() { return read<bool>(baseAddr + offsets_instance.get("C_BaseTrigger", "m_bDisabled")); }
};
