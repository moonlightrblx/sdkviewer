#pragma once
#include "../memory.h"

class C_BasePlayerPawn {
public:
 uintptr_t baseAddr;
 C_BasePlayerPawn() : baseAddr(0){}
 C_BasePlayerPawn(uintptr_t b):baseAddr(b){}
 uintptr_t m_pWeaponServices(){return SCHEMA_TYPE(uintptr_t,0x13F0);}
 uintptr_t m_pItemServices(){return SCHEMA_TYPE(uintptr_t,0x13F8);}
 uintptr_t m_pAutoaimServices(){return SCHEMA_TYPE(uintptr_t,0x1400);}
 uintptr_t m_pObserverServices(){return SCHEMA_TYPE(uintptr_t,0x1408);}
 uintptr_t m_pWaterServices(){return SCHEMA_TYPE(uintptr_t,0x1410);}
 uintptr_t m_pUseServices(){return SCHEMA_TYPE(uintptr_t,0x1418);}
 uintptr_t m_pFlashlightServices(){return SCHEMA_TYPE(uintptr_t,0x1420);}
 uintptr_t m_pCameraServices(){return SCHEMA_TYPE(uintptr_t,0x1428);}
 uintptr_t m_pMovementServices(){return SCHEMA_TYPE(uintptr_t,0x1430);}
 uintptr_t m_ServerViewAngleChanges(){return SCHEMA_TYPE(uintptr_t,0x1440);}
 uintptr_t v_angle(){return SCHEMA_TYPE(uintptr_t,0x14A8);}
 uintptr_t v_anglePrevious(){return SCHEMA_TYPE(uintptr_t,0x14B4);}
 uintptr_t m_iHideHUD(){return SCHEMA_TYPE(uintptr_t,0x14C0);}
 uintptr_t m_skybox3d(){return SCHEMA_TYPE(uintptr_t,0x14C8);}
 uintptr_t m_flDeathTime(){return SCHEMA_TYPE(uintptr_t,0x1558);}
 uintptr_t m_vecPredictionError(){return SCHEMA_TYPE(uintptr_t,0x155C);}
 uintptr_t m_flPredictionErrorTime(){return SCHEMA_TYPE(uintptr_t,0x1568);}
 uintptr_t m_vecLastCameraSetupLocalOrigin(){return SCHEMA_TYPE(uintptr_t,0x1588);}
 uintptr_t m_flLastCameraSetupTime(){return SCHEMA_TYPE(uintptr_t,0x1594);}
 uintptr_t m_flFOVSensitivityAdjust(){return SCHEMA_TYPE(uintptr_t,0x1598);}
 uintptr_t m_flMouseSensitivity(){return SCHEMA_TYPE(uintptr_t,0x159C);}
 uintptr_t m_vOldOrigin(){return SCHEMA_TYPE(uintptr_t,0x15A0);}
 uintptr_t m_flOldSimulationTime(){return SCHEMA_TYPE(uintptr_t,0x15AC);}
 uintptr_t m_nLastExecutedCommandNumber(){return SCHEMA_TYPE(uintptr_t,0x15B0);}
 uintptr_t m_nLastExecutedCommandTick(){return SCHEMA_TYPE(uintptr_t,0x15B4);}
 uintptr_t m_hController(){return SCHEMA_TYPE(uintptr_t,0x15B8);}
 uintptr_t m_hDefaultController(){return SCHEMA_TYPE(uintptr_t,0x15BC);}
 uintptr_t m_bIsSwappingToPredictableController(){return SCHEMA_TYPE(uintptr_t,0x15C0);}
};
