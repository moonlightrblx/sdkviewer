#pragma once
#include "../memory.h"

class C_PortraitWorldCallbackHandler  {
public:
    uintptr_t baseAddr;

    C_PortraitWorldCallbackHandler() { baseAddr = 0; }
    C_PortraitWorldCallbackHandler(uintptr_t base) : baseAddr(base) {}

};
