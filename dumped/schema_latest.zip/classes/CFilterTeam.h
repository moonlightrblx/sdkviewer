#pragma once
#include "../memory.h"

class CFilterTeam {
public:
 uintptr_t baseAddr;
 CFilterTeam() : baseAddr(0){}
 CFilterTeam(uintptr_t b):baseAddr(b){}
 uintptr_t m_iFilterTeam(){return SCHEMA_TYPE(uintptr_t,0x650);}
};
