#pragma once
#include "../memory.h"

class C_WeaponSSG08  {
public:
    uintptr_t baseAddr;

    C_WeaponSSG08() { baseAddr = 0; }
    C_WeaponSSG08(uintptr_t base) : baseAddr(base) {}

};
