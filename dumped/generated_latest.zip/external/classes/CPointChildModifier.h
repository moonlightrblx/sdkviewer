#pragma once
#include "../memory.h"

class CPointChildModifier  {
public:
    uintptr_t baseAddr;

    CPointChildModifier() { baseAddr = client_base(); }
    CPointChildModifier(uintptr_t base) : baseAddr(base) {}

    bool m_bOrphanInsteadOfDeletingChildrenOnRemove() { return read<bool>(baseAddr + offsets_instance.get("CPointChildModifier", "m_bOrphanInsteadOfDeletingChildrenOnRemove")); }
};
