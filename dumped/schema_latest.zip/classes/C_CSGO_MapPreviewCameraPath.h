#pragma once
#include "../memory.h"

class C_CSGO_MapPreviewCameraPath {
public:
 uintptr_t baseAddr;
 C_CSGO_MapPreviewCameraPath() : baseAddr(0){}
 C_CSGO_MapPreviewCameraPath(uintptr_t b):baseAddr(b){}
 uintptr_t m_flZFar(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_flZNear(){return SCHEMA_TYPE(uintptr_t,0x5FC);}
 uintptr_t m_bLoop(){return SCHEMA_TYPE(uintptr_t,0x600);}
 uintptr_t m_bVerticalFOV(){return SCHEMA_TYPE(uintptr_t,0x601);}
 uintptr_t m_bConstantSpeed(){return SCHEMA_TYPE(uintptr_t,0x602);}
 uintptr_t m_flDuration(){return SCHEMA_TYPE(uintptr_t,0x604);}
 uintptr_t m_flPathLength(){return SCHEMA_TYPE(uintptr_t,0x648);}
 uintptr_t m_flPathDuration(){return SCHEMA_TYPE(uintptr_t,0x64C);}
 uintptr_t m_bDofEnabled(){return SCHEMA_TYPE(uintptr_t,0x664);}
 uintptr_t m_flDofNearBlurry(){return SCHEMA_TYPE(uintptr_t,0x668);}
 uintptr_t m_flDofNearCrisp(){return SCHEMA_TYPE(uintptr_t,0x66C);}
 uintptr_t m_flDofFarCrisp(){return SCHEMA_TYPE(uintptr_t,0x670);}
 uintptr_t m_flDofFarBlurry(){return SCHEMA_TYPE(uintptr_t,0x674);}
 uintptr_t m_flDofTiltToGround(){return SCHEMA_TYPE(uintptr_t,0x678);}
};
