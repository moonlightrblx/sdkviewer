#pragma once
#include "../memory.h"

class CPulseCell_WaitForCursorsWithTagBase  {
public:
    uintptr_t baseAddr;

    CPulseCell_WaitForCursorsWithTagBase() { baseAddr = client_base(); }
    CPulseCell_WaitForCursorsWithTagBase(uintptr_t base) : baseAddr(base) {}

    int m_nCursorsAllowedToWait() { return read<int>(baseAddr + offsets_instance.get("CPulseCell_WaitForCursorsWithTagBase", "m_nCursorsAllowedToWait")); }
    uintptr_t m_WaitComplete() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_WaitForCursorsWithTagBase", "m_WaitComplete")); }
};
