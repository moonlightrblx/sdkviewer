#pragma once
#include "../memory.h"

class CBodyComponent {
public:
 uintptr_t baseAddr;
 CBodyComponent() : baseAddr(0){}
 CBodyComponent(uintptr_t b):baseAddr(b){}
 uintptr_t m_pSceneNode(){return SCHEMA_TYPE(uintptr_t,0x8);}
 uintptr_t __m_pChainEntity(){return SCHEMA_TYPE(uintptr_t,0x48);}
};
