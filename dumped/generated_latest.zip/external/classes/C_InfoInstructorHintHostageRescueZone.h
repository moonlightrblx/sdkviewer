#pragma once
#include "../memory.h"

class C_InfoInstructorHintHostageRescueZone  {
public:
    uintptr_t baseAddr;

    C_InfoInstructorHintHostageRescueZone() { baseAddr = client_base(); }
    C_InfoInstructorHintHostageRescueZone(uintptr_t base) : baseAddr(base) {}

};
