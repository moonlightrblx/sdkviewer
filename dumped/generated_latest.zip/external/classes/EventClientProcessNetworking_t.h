#pragma once
#include "../memory.h"

class EventClientProcessNetworking_t  {
public:
    uintptr_t baseAddr;

    EventClientProcessNetworking_t() { baseAddr = 0; }
    EventClientProcessNetworking_t(uintptr_t base) : baseAddr(base) {}

    int m_nTickCount() { return read<int>(baseAddr + offsets_instance.get("EventClientProcessNetworking_t", "m_nTickCount")); }
};
