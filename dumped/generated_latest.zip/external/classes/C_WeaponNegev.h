#pragma once
#include "../memory.h"

class C_WeaponNegev  {
public:
    uintptr_t baseAddr;

    C_WeaponNegev() { baseAddr = client_base(); }
    C_WeaponNegev(uintptr_t base) : baseAddr(base) {}

};
