#pragma once
#include "../memory.h"

class CBodyComponentPoint  {
public:
    uintptr_t baseAddr;

    CBodyComponentPoint() { baseAddr = client_base(); }
    CBodyComponentPoint(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_sceneNode() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBodyComponentPoint", "m_sceneNode")); }
};
