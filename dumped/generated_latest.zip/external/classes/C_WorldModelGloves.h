#pragma once
#include "../memory.h"

class C_WorldModelGloves  {
public:
    uintptr_t baseAddr;

    C_WorldModelGloves() { baseAddr = client_base(); }
    C_WorldModelGloves(uintptr_t base) : baseAddr(base) {}

};
