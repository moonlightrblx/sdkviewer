#pragma once
#include "../memory.h"

class C_Item {
public:
 uintptr_t baseAddr;
 C_Item() : baseAddr(0){}
 C_Item(uintptr_t b):baseAddr(b){}
 uintptr_t m_pReticleHintTextName(){return SCHEMA_TYPE(uintptr_t,0x18E0);}
};
