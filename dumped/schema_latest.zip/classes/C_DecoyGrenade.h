#pragma once
#include "../memory.h"

class C_DecoyGrenade {
public:
 uintptr_t baseAddr;
 C_DecoyGrenade() : baseAddr(0){}
 C_DecoyGrenade(uintptr_t b):baseAddr(b){}
};
