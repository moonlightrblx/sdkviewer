#pragma once
#include "../memory.h"

class C_HEGrenadeProjectile  {
public:
    uintptr_t baseAddr;

    C_HEGrenadeProjectile() { baseAddr = 0; }
    C_HEGrenadeProjectile(uintptr_t base) : baseAddr(base) {}

};
