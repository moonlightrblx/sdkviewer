#pragma once
#include "../memory.h"

class CPulseCell_Inflow_EventHandler  {
public:
    uintptr_t baseAddr;

    CPulseCell_Inflow_EventHandler() { baseAddr = client_base(); }
    CPulseCell_Inflow_EventHandler(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_EventName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Inflow_EventHandler", "m_EventName")); }
};
