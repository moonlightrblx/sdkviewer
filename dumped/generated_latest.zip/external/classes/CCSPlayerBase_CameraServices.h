#pragma once
#include "../memory.h"
#include "../classes/GameTime_t.h"
class C_BaseEntity;

class CCSPlayerBase_CameraServices  {
public:
    uintptr_t baseAddr;

    CCSPlayerBase_CameraServices() { baseAddr = 0; }
    CCSPlayerBase_CameraServices(uintptr_t base) : baseAddr(base) {}

    int m_iFOV() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerBase_CameraServices", "m_iFOV")); }
    int m_iFOVStart() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerBase_CameraServices", "m_iFOVStart")); }
    GameTime_t m_flFOVTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("CCSPlayerBase_CameraServices", "m_flFOVTime")); }
    float m_flFOVRate() { return read<float>(baseAddr + offsets_instance.get("CCSPlayerBase_CameraServices", "m_flFOVRate")); }
    C_BaseEntity* m_hZoomOwner() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("CCSPlayerBase_CameraServices", "m_hZoomOwner")); }
    float m_flLastShotFOV() { return read<float>(baseAddr + offsets_instance.get("CCSPlayerBase_CameraServices", "m_flLastShotFOV")); }
};
