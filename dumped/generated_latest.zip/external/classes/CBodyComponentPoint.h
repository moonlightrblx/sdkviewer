#pragma once
#include "../memory.h"
#include "../classes/CGameSceneNode.h"

class CBodyComponentPoint  {
public:
    uintptr_t baseAddr;

    CBodyComponentPoint() { baseAddr = 0; }
    CBodyComponentPoint(uintptr_t base) : baseAddr(base) {}

    CGameSceneNode m_sceneNode() { return read<CGameSceneNode>(baseAddr + offsets_instance.get("CBodyComponentPoint", "m_sceneNode")); }
};
