#pragma once
#include "../memory.h"

class CPulseCell_Outflow_CycleShuffled__InstanceState_t  {
public:
    uintptr_t baseAddr;

    CPulseCell_Outflow_CycleShuffled__InstanceState_t() { baseAddr = 0; }
    CPulseCell_Outflow_CycleShuffled__InstanceState_t(uintptr_t base) : baseAddr(base) {}

    uint8_t m_Shuffle() { return read<uint8_t>(baseAddr + offsets_instance.get("CPulseCell_Outflow_CycleShuffled__InstanceState_t", "m_Shuffle")); }
    int m_nNextShuffle() { return read<int>(baseAddr + offsets_instance.get("CPulseCell_Outflow_CycleShuffled__InstanceState_t", "m_nNextShuffle")); }
};
