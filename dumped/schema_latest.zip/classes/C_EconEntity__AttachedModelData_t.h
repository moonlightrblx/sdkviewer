#pragma once
#include "../memory.h"

class C_EconEntity__AttachedModelData_t {
public:
 uintptr_t baseAddr;
 C_EconEntity__AttachedModelData_t() : baseAddr(0){}
 C_EconEntity__AttachedModelData_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_iModelDisplayFlags(){return SCHEMA_TYPE(uintptr_t,0x0);}
};
