#pragma once
#include "../memory.h"

class CInfoDynamicShadowHint {
public:
 uintptr_t baseAddr;
 CInfoDynamicShadowHint() : baseAddr(0){}
 CInfoDynamicShadowHint(uintptr_t b):baseAddr(b){}
 uintptr_t m_bDisabled(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_flRange(){return SCHEMA_TYPE(uintptr_t,0x5FC);}
 uintptr_t m_nImportance(){return SCHEMA_TYPE(uintptr_t,0x600);}
 uintptr_t m_nLightChoice(){return SCHEMA_TYPE(uintptr_t,0x604);}
 uintptr_t m_hLight(){return SCHEMA_TYPE(uintptr_t,0x608);}
};
