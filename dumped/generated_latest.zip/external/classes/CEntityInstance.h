#pragma once
#include "../memory.h"
class CEntityIdentity;
class CScriptComponent;

class CEntityInstance  {
public:
    uintptr_t baseAddr;

    CEntityInstance() { baseAddr = 0; }
    CEntityInstance(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_iszPrivateVScripts() { return read<uintptr_t>(baseAddr + offsets_instance.get("CEntityInstance", "m_iszPrivateVScripts")); }
    CEntityIdentity* m_pEntity() { return read<CEntityIdentity*>(baseAddr + offsets_instance.get("CEntityInstance", "m_pEntity")); }
    CScriptComponent* m_CScriptComponent() { return read<CScriptComponent*>(baseAddr + offsets_instance.get("CEntityInstance", "m_CScriptComponent")); }
};
