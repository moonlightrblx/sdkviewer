#pragma once
#include "../memory.h"

class C_WeaponBaseItem {
public:
 uintptr_t baseAddr;
 C_WeaponBaseItem() : baseAddr(0){}
 C_WeaponBaseItem(uintptr_t b):baseAddr(b){}
 uintptr_t m_bSequenceInProgress(){return SCHEMA_TYPE(uintptr_t,0x1F80);}
 uintptr_t m_bRedraw(){return SCHEMA_TYPE(uintptr_t,0x1F81);}
};
