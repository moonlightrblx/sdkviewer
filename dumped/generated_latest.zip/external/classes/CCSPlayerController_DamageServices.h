#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class CCSPlayerController_DamageServices  {
public:
    uintptr_t baseAddr;

    CCSPlayerController_DamageServices() { baseAddr = 0; }
    CCSPlayerController_DamageServices(uintptr_t base) : baseAddr(base) {}

    int m_nSendUpdate() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController_DamageServices", "m_nSendUpdate")); }
    Vector3 m_DamageList() { return read<Vector3>(baseAddr + offsets_instance.get("CCSPlayerController_DamageServices", "m_DamageList")); }
};
