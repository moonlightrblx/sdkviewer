#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_FuncLadder  {
public:
    uintptr_t baseAddr;

    C_FuncLadder() { baseAddr = client_base(); }
    C_FuncLadder(uintptr_t base) : baseAddr(base) {}

    Vector3 m_vecLadderDir() { return read<Vector3>(baseAddr + offsets_instance.get("C_FuncLadder", "m_vecLadderDir")); }
    Vector3 m_Dismounts() { return read<Vector3>(baseAddr + offsets_instance.get("C_FuncLadder", "m_Dismounts")); }
    Vector3 m_vecLocalTop() { return read<Vector3>(baseAddr + offsets_instance.get("C_FuncLadder", "m_vecLocalTop")); }
    Vector3 m_vecPlayerMountPositionTop() { return read<Vector3>(baseAddr + offsets_instance.get("C_FuncLadder", "m_vecPlayerMountPositionTop")); }
    Vector3 m_vecPlayerMountPositionBottom() { return read<Vector3>(baseAddr + offsets_instance.get("C_FuncLadder", "m_vecPlayerMountPositionBottom")); }
    float m_flAutoRideSpeed() { return read<float>(baseAddr + offsets_instance.get("C_FuncLadder", "m_flAutoRideSpeed")); }
    bool m_bDisabled() { return read<bool>(baseAddr + offsets_instance.get("C_FuncLadder", "m_bDisabled")); }
    bool m_bFakeLadder() { return read<bool>(baseAddr + offsets_instance.get("C_FuncLadder", "m_bFakeLadder")); }
    bool m_bHasSlack() { return read<bool>(baseAddr + offsets_instance.get("C_FuncLadder", "m_bHasSlack")); }
};
