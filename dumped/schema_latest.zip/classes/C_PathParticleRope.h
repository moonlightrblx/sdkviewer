#pragma once
#include "../memory.h"

class C_PathParticleRope {
public:
 uintptr_t baseAddr;
 C_PathParticleRope() : baseAddr(0){}
 C_PathParticleRope(uintptr_t b):baseAddr(b){}
 uintptr_t m_bStartActive(){return SCHEMA_TYPE(uintptr_t,0x600);}
 uintptr_t m_flMaxSimulationTime(){return SCHEMA_TYPE(uintptr_t,0x604);}
 uintptr_t m_iszEffectName(){return SCHEMA_TYPE(uintptr_t,0x608);}
 uintptr_t m_PathNodes_Name(){return SCHEMA_TYPE(uintptr_t,0x610);}
 uintptr_t m_flParticleSpacing(){return SCHEMA_TYPE(uintptr_t,0x628);}
 uintptr_t m_flSlack(){return SCHEMA_TYPE(uintptr_t,0x62C);}
 uintptr_t m_flRadius(){return SCHEMA_TYPE(uintptr_t,0x630);}
 uintptr_t m_ColorTint(){return SCHEMA_TYPE(uintptr_t,0x634);}
 uintptr_t m_nEffectState(){return SCHEMA_TYPE(uintptr_t,0x638);}
 uintptr_t m_iEffectIndex(){return SCHEMA_TYPE(uintptr_t,0x640);}
 uintptr_t m_PathNodes_Position(){return SCHEMA_TYPE(uintptr_t,0x648);}
 uintptr_t m_PathNodes_TangentIn(){return SCHEMA_TYPE(uintptr_t,0x660);}
 uintptr_t m_PathNodes_TangentOut(){return SCHEMA_TYPE(uintptr_t,0x678);}
 uintptr_t m_PathNodes_Color(){return SCHEMA_TYPE(uintptr_t,0x690);}
 uintptr_t m_PathNodes_PinEnabled(){return SCHEMA_TYPE(uintptr_t,0x6A8);}
 uintptr_t m_PathNodes_RadiusScale(){return SCHEMA_TYPE(uintptr_t,0x6C0);}
};
