#pragma once
#include "../memory.h"

class C_MultiplayRules {
public:
 uintptr_t baseAddr;
 C_MultiplayRules() : baseAddr(0){}
 C_MultiplayRules(uintptr_t b):baseAddr(b){}
};
