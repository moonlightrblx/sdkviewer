#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class CPulseCell_Inflow_Method  {
public:
    uintptr_t baseAddr;

    CPulseCell_Inflow_Method() { baseAddr = client_base(); }
    CPulseCell_Inflow_Method(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_MethodName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Inflow_Method", "m_MethodName")); }
    uintptr_t m_Description() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Inflow_Method", "m_Description")); }
    bool m_bIsPublic() { return read<bool>(baseAddr + offsets_instance.get("CPulseCell_Inflow_Method", "m_bIsPublic")); }
    uintptr_t m_ReturnType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Inflow_Method", "m_ReturnType")); }
    Vector3 m_Args() { return read<Vector3>(baseAddr + offsets_instance.get("CPulseCell_Inflow_Method", "m_Args")); }
};
