#pragma once
#include "../memory.h"

class C_BaseCSGrenade {
public:
 uintptr_t baseAddr;
 C_BaseCSGrenade() : baseAddr(0){}
 C_BaseCSGrenade(uintptr_t b):baseAddr(b){}
 uintptr_t m_bClientPredictDelete(){return SCHEMA_TYPE(uintptr_t,0x1F80);}
 uintptr_t m_bRedraw(){return SCHEMA_TYPE(uintptr_t,0x1F81);}
 uintptr_t m_bIsHeldByPlayer(){return SCHEMA_TYPE(uintptr_t,0x1F82);}
 uintptr_t m_bPinPulled(){return SCHEMA_TYPE(uintptr_t,0x1F83);}
 uintptr_t m_bJumpThrow(){return SCHEMA_TYPE(uintptr_t,0x1F84);}
 uintptr_t m_bThrowAnimating(){return SCHEMA_TYPE(uintptr_t,0x1F85);}
 uintptr_t m_fThrowTime(){return SCHEMA_TYPE(uintptr_t,0x1F88);}
 uintptr_t m_flThrowStrength(){return SCHEMA_TYPE(uintptr_t,0x1F90);}
 uintptr_t m_fDropTime(){return SCHEMA_TYPE(uintptr_t,0x2008);}
 uintptr_t m_fPinPullTime(){return SCHEMA_TYPE(uintptr_t,0x200C);}
 uintptr_t m_bJustPulledPin(){return SCHEMA_TYPE(uintptr_t,0x2010);}
 uintptr_t m_nNextHoldTick(){return SCHEMA_TYPE(uintptr_t,0x2014);}
 uintptr_t m_flNextHoldFrac(){return SCHEMA_TYPE(uintptr_t,0x2018);}
 uintptr_t m_hSwitchToWeaponAfterThrow(){return SCHEMA_TYPE(uintptr_t,0x201C);}
};
