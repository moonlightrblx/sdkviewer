#pragma once
#include "../memory.h"

class C_NametagModule  {
public:
    uintptr_t baseAddr;

    C_NametagModule() { baseAddr = 0; }
    C_NametagModule(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_strNametagString() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_NametagModule", "m_strNametagString")); }
};
