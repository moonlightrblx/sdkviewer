#pragma once
#include "../memory.h"

class EventClientSceneSystemThreadStateChange_t {
public:
 uintptr_t baseAddr;
 EventClientSceneSystemThreadStateChange_t() : baseAddr(0){}
 EventClientSceneSystemThreadStateChange_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_bThreadsActive(){return SCHEMA_TYPE(uintptr_t,0x0);}
};
