#pragma once
#include "../memory.h"

class C_SingleplayRules  {
public:
    uintptr_t baseAddr;

    C_SingleplayRules() { baseAddr = client_base(); }
    C_SingleplayRules(uintptr_t base) : baseAddr(base) {}

};
