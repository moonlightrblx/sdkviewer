#pragma once
#include "../memory.h"

class CGameSceneNode {
public:
 uintptr_t baseAddr;
 CGameSceneNode() : baseAddr(0){}
 CGameSceneNode(uintptr_t b):baseAddr(b){}
 uintptr_t m_nodeToWorld(){return SCHEMA_TYPE(uintptr_t,0x10);}
 uintptr_t m_pOwner(){return SCHEMA_TYPE(uintptr_t,0x30);}
 uintptr_t m_pParent(){return SCHEMA_TYPE(uintptr_t,0x38);}
 uintptr_t m_pChild(){return SCHEMA_TYPE(uintptr_t,0x40);}
 uintptr_t m_pNextSibling(){return SCHEMA_TYPE(uintptr_t,0x48);}
 uintptr_t m_hParent(){return SCHEMA_TYPE(uintptr_t,0x78);}
 uintptr_t m_vecOrigin(){return SCHEMA_TYPE(uintptr_t,0x88);}
 uintptr_t m_angRotation(){return SCHEMA_TYPE(uintptr_t,0xC0);}
 uintptr_t m_flScale(){return SCHEMA_TYPE(uintptr_t,0xCC);}
 uintptr_t m_vecAbsOrigin(){return SCHEMA_TYPE(uintptr_t,0xD0);}
 uintptr_t m_angAbsRotation(){return SCHEMA_TYPE(uintptr_t,0xDC);}
 uintptr_t m_flAbsScale(){return SCHEMA_TYPE(uintptr_t,0xE8);}
 uintptr_t m_vecWrappedLocalOrigin(){return SCHEMA_TYPE(uintptr_t,0xEC);}
 uintptr_t m_angWrappedLocalRotation(){return SCHEMA_TYPE(uintptr_t,0xF8);}
 uintptr_t m_flWrappedScale(){return SCHEMA_TYPE(uintptr_t,0x104);}
 uintptr_t m_nParentAttachmentOrBone(){return SCHEMA_TYPE(uintptr_t,0x108);}
 uintptr_t m_bDebugAbsOriginChanges(){return SCHEMA_TYPE(uintptr_t,0x10A);}
 uintptr_t m_bDormant(){return SCHEMA_TYPE(uintptr_t,0x10B);}
 uintptr_t m_bForceParentToBeNetworked(){return SCHEMA_TYPE(uintptr_t,0x10C);}
 uintptr_t m_bDirtyHierarchy(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_bDirtyBoneMergeInfo(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_bNetworkedPositionChanged(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_bNetworkedAnglesChanged(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_bNetworkedScaleChanged(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_bWillBeCallingPostDataUpdate(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_bBoneMergeFlex(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_nLatchAbsOrigin(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_bDirtyBoneMergeBoneToRoot(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_nHierarchicalDepth(){return SCHEMA_TYPE(uintptr_t,0x10F);}
 uintptr_t m_nHierarchyType(){return SCHEMA_TYPE(uintptr_t,0x110);}
 uintptr_t m_nDoNotSetAnimTimeInInvalidatePhysicsCount(){return SCHEMA_TYPE(uintptr_t,0x111);}
 uintptr_t m_name(){return SCHEMA_TYPE(uintptr_t,0x114);}
 uintptr_t m_hierarchyAttachName(){return SCHEMA_TYPE(uintptr_t,0x158);}
 uintptr_t m_flZOffset(){return SCHEMA_TYPE(uintptr_t,0x15C);}
 uintptr_t m_flClientLocalScale(){return SCHEMA_TYPE(uintptr_t,0x160);}
 uintptr_t m_vRenderOrigin(){return SCHEMA_TYPE(uintptr_t,0x164);}
};
