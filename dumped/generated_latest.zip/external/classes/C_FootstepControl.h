#pragma once
#include "../memory.h"

class C_FootstepControl  {
public:
    uintptr_t baseAddr;

    C_FootstepControl() { baseAddr = 0; }
    C_FootstepControl(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_source() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_FootstepControl", "m_source")); }
    uintptr_t m_destination() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_FootstepControl", "m_destination")); }
};
