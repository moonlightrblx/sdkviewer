#pragma once
#include "../memory.h"

class C_CSGO_TeamPreviewCharacterPosition {
public:
 uintptr_t baseAddr;
 C_CSGO_TeamPreviewCharacterPosition() : baseAddr(0){}
 C_CSGO_TeamPreviewCharacterPosition(uintptr_t b):baseAddr(b){}
 uintptr_t m_nVariant(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_nRandom(){return SCHEMA_TYPE(uintptr_t,0x5FC);}
 uintptr_t m_nOrdinal(){return SCHEMA_TYPE(uintptr_t,0x600);}
 uintptr_t m_sWeaponName(){return SCHEMA_TYPE(uintptr_t,0x608);}
 uintptr_t m_xuid(){return SCHEMA_TYPE(uintptr_t,0x610);}
 uintptr_t m_agentItem(){return SCHEMA_TYPE(uintptr_t,0x618);}
 uintptr_t m_glovesItem(){return SCHEMA_TYPE(uintptr_t,0xA90);}
 uintptr_t m_weaponItem(){return SCHEMA_TYPE(uintptr_t,0xF08);}
};
