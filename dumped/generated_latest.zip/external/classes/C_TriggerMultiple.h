#pragma once
#include "../memory.h"

class C_TriggerMultiple  {
public:
    uintptr_t baseAddr;

    C_TriggerMultiple() { baseAddr = 0; }
    C_TriggerMultiple(uintptr_t base) : baseAddr(base) {}

};
