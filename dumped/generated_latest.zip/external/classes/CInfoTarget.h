#pragma once
#include "../memory.h"

class CInfoTarget  {
public:
    uintptr_t baseAddr;

    CInfoTarget() { baseAddr = client_base(); }
    CInfoTarget(uintptr_t base) : baseAddr(base) {}

};
