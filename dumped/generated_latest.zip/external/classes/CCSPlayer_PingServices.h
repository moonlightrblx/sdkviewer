#pragma once
#include "../memory.h"
class C_PlayerPing;

class CCSPlayer_PingServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_PingServices() { baseAddr = 0; }
    CCSPlayer_PingServices(uintptr_t base) : baseAddr(base) {}

    C_PlayerPing* m_hPlayerPing() { return read<C_PlayerPing*>(baseAddr + offsets_instance.get("CCSPlayer_PingServices", "m_hPlayerPing")); }
};
