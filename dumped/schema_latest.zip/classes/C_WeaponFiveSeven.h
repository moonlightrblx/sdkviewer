#pragma once
#include "../memory.h"

class C_WeaponFiveSeven {
public:
 uintptr_t baseAddr;
 C_WeaponFiveSeven() : baseAddr(0){}
 C_WeaponFiveSeven(uintptr_t b):baseAddr(b){}
};
