#pragma once
#include "../memory.h"

class C_SceneEntity__QueuedEvents_t {
public:
 uintptr_t baseAddr;
 C_SceneEntity__QueuedEvents_t() : baseAddr(0){}
 C_SceneEntity__QueuedEvents_t(uintptr_t b):baseAddr(b){}
 uintptr_t starttime(){return SCHEMA_TYPE(uintptr_t,0x0);}
};
