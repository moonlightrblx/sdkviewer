#pragma once
#include "../memory.h"

class CFuncRetakeBarrier  {
public:
    uintptr_t baseAddr;

    CFuncRetakeBarrier() { baseAddr = client_base(); }
    CFuncRetakeBarrier(uintptr_t base) : baseAddr(base) {}

};
