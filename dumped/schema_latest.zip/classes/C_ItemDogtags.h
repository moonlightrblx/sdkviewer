#pragma once
#include "../memory.h"

class C_ItemDogtags {
public:
 uintptr_t baseAddr;
 C_ItemDogtags() : baseAddr(0){}
 C_ItemDogtags(uintptr_t b):baseAddr(b){}
 uintptr_t m_OwningPlayer(){return SCHEMA_TYPE(uintptr_t,0x19E0);}
 uintptr_t m_KillingPlayer(){return SCHEMA_TYPE(uintptr_t,0x19E4);}
};
