#pragma once
#include "../memory.h"

class C_PlayerVisibility {
public:
 uintptr_t baseAddr;
 C_PlayerVisibility() : baseAddr(0){}
 C_PlayerVisibility(uintptr_t b):baseAddr(b){}
 uintptr_t m_flVisibilityStrength(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_flFogDistanceMultiplier(){return SCHEMA_TYPE(uintptr_t,0x5FC);}
 uintptr_t m_flFogMaxDensityMultiplier(){return SCHEMA_TYPE(uintptr_t,0x600);}
 uintptr_t m_flFadeTime(){return SCHEMA_TYPE(uintptr_t,0x604);}
 uintptr_t m_bStartDisabled(){return SCHEMA_TYPE(uintptr_t,0x608);}
 uintptr_t m_bIsEnabled(){return SCHEMA_TYPE(uintptr_t,0x609);}
};
