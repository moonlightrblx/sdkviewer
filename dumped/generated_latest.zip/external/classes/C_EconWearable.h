#pragma once
#include "../memory.h"

class C_EconWearable  {
public:
    uintptr_t baseAddr;

    C_EconWearable() { baseAddr = 0; }
    C_EconWearable(uintptr_t base) : baseAddr(base) {}

    int m_nForceSkin() { return read<int>(baseAddr + offsets_instance.get("C_EconWearable", "m_nForceSkin")); }
    bool m_bAlwaysAllow() { return read<bool>(baseAddr + offsets_instance.get("C_EconWearable", "m_bAlwaysAllow")); }
};
