#pragma once
#include "../memory.h"

class C_PointClientUIWorldTextPanel  {
public:
    uintptr_t baseAddr;

    C_PointClientUIWorldTextPanel() { baseAddr = 0; }
    C_PointClientUIWorldTextPanel(uintptr_t base) : baseAddr(base) {}

    char* m_messageText() { return read<char*>(baseAddr + offsets_instance.get("C_PointClientUIWorldTextPanel", "m_messageText")); }
};
