#pragma once
#include "../memory.h"

class CPulseCell_LimitCount__Criteria_t  {
public:
    uintptr_t baseAddr;

    CPulseCell_LimitCount__Criteria_t() { baseAddr = client_base(); }
    CPulseCell_LimitCount__Criteria_t(uintptr_t base) : baseAddr(base) {}

    bool m_bLimitCountPasses() { return read<bool>(baseAddr + offsets_instance.get("CPulseCell_LimitCount__Criteria_t", "m_bLimitCountPasses")); }
};
