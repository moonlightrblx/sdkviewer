#pragma once
#include "../memory.h"
#include "../classes/C_AttributeContainer.h"
#include "../classes/EntitySpottedState_t.h"
#include "../classes/GameTime_t.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"
class CBasePlayerController;
class C_CSPlayerPawn;
class C_Multimeter;

class C_PlantedC4  {
public:
    uintptr_t baseAddr;

    C_PlantedC4() { baseAddr = 0; }
    C_PlantedC4(uintptr_t base) : baseAddr(base) {}

    bool m_bBombTicking() { return read<bool>(baseAddr + offsets_instance.get("C_PlantedC4", "m_bBombTicking")); }
    int m_nBombSite() { return read<int>(baseAddr + offsets_instance.get("C_PlantedC4", "m_nBombSite")); }
    int m_nSourceSoundscapeHash() { return read<int>(baseAddr + offsets_instance.get("C_PlantedC4", "m_nSourceSoundscapeHash")); }
    EntitySpottedState_t m_entitySpottedState() { return read<EntitySpottedState_t>(baseAddr + offsets_instance.get("C_PlantedC4", "m_entitySpottedState")); }
    GameTime_t m_flNextGlow() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_PlantedC4", "m_flNextGlow")); }
    GameTime_t m_flNextBeep() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_PlantedC4", "m_flNextBeep")); }
    GameTime_t m_flC4Blow() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_PlantedC4", "m_flC4Blow")); }
    bool m_bCannotBeDefused() { return read<bool>(baseAddr + offsets_instance.get("C_PlantedC4", "m_bCannotBeDefused")); }
    bool m_bHasExploded() { return read<bool>(baseAddr + offsets_instance.get("C_PlantedC4", "m_bHasExploded")); }
    float m_flTimerLength() { return read<float>(baseAddr + offsets_instance.get("C_PlantedC4", "m_flTimerLength")); }
    bool m_bBeingDefused() { return read<bool>(baseAddr + offsets_instance.get("C_PlantedC4", "m_bBeingDefused")); }
    float m_bTriggerWarning() { return read<float>(baseAddr + offsets_instance.get("C_PlantedC4", "m_bTriggerWarning")); }
    float m_bExplodeWarning() { return read<float>(baseAddr + offsets_instance.get("C_PlantedC4", "m_bExplodeWarning")); }
    bool m_bC4Activated() { return read<bool>(baseAddr + offsets_instance.get("C_PlantedC4", "m_bC4Activated")); }
    bool m_bTenSecWarning() { return read<bool>(baseAddr + offsets_instance.get("C_PlantedC4", "m_bTenSecWarning")); }
    float m_flDefuseLength() { return read<float>(baseAddr + offsets_instance.get("C_PlantedC4", "m_flDefuseLength")); }
    GameTime_t m_flDefuseCountDown() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_PlantedC4", "m_flDefuseCountDown")); }
    bool m_bBombDefused() { return read<bool>(baseAddr + offsets_instance.get("C_PlantedC4", "m_bBombDefused")); }
    C_CSPlayerPawn* m_hBombDefuser() { return read<C_CSPlayerPawn*>(baseAddr + offsets_instance.get("C_PlantedC4", "m_hBombDefuser")); }
    C_AttributeContainer m_AttributeManager() { return read<C_AttributeContainer>(baseAddr + offsets_instance.get("C_PlantedC4", "m_AttributeManager")); }
    C_Multimeter* m_hDefuserMultimeter() { return read<C_Multimeter*>(baseAddr + offsets_instance.get("C_PlantedC4", "m_hDefuserMultimeter")); }
    GameTime_t m_flNextRadarFlashTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_PlantedC4", "m_flNextRadarFlashTime")); }
    bool m_bRadarFlash() { return read<bool>(baseAddr + offsets_instance.get("C_PlantedC4", "m_bRadarFlash")); }
    C_CSPlayerPawn* m_pBombDefuser() { return read<C_CSPlayerPawn*>(baseAddr + offsets_instance.get("C_PlantedC4", "m_pBombDefuser")); }
    GameTime_t m_fLastDefuseTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_PlantedC4", "m_fLastDefuseTime")); }
    CBasePlayerController* m_pPredictionOwner() { return read<CBasePlayerController*>(baseAddr + offsets_instance.get("C_PlantedC4", "m_pPredictionOwner")); }
    Vector3 m_vecC4ExplodeSpectatePos() { return read<Vector3>(baseAddr + offsets_instance.get("C_PlantedC4", "m_vecC4ExplodeSpectatePos")); }
    QAngle m_vecC4ExplodeSpectateAng() { return read<QAngle>(baseAddr + offsets_instance.get("C_PlantedC4", "m_vecC4ExplodeSpectateAng")); }
    float m_flC4ExplodeSpectateDuration() { return read<float>(baseAddr + offsets_instance.get("C_PlantedC4", "m_flC4ExplodeSpectateDuration")); }
};
