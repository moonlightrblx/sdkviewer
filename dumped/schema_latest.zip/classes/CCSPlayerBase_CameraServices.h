#pragma once
#include "../memory.h"

class CCSPlayerBase_CameraServices {
public:
 uintptr_t baseAddr;
 CCSPlayerBase_CameraServices() : baseAddr(0){}
 CCSPlayerBase_CameraServices(uintptr_t b):baseAddr(b){}
 uintptr_t m_iFOV(){return SCHEMA_TYPE(uintptr_t,0x288);}
 uintptr_t m_iFOVStart(){return SCHEMA_TYPE(uintptr_t,0x28C);}
 uintptr_t m_flFOVTime(){return SCHEMA_TYPE(uintptr_t,0x290);}
 uintptr_t m_flFOVRate(){return SCHEMA_TYPE(uintptr_t,0x294);}
 uintptr_t m_hZoomOwner(){return SCHEMA_TYPE(uintptr_t,0x298);}
 uintptr_t m_flLastShotFOV(){return SCHEMA_TYPE(uintptr_t,0x29C);}
};
