#pragma once
#include "../memory.h"

class C_CSMinimapBoundary {
public:
 uintptr_t baseAddr;
 C_CSMinimapBoundary() : baseAddr(0){}
 C_CSMinimapBoundary(uintptr_t b):baseAddr(b){}
};
