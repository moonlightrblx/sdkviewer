#pragma once
#include "../memory.h"

class C_SoundOpvarSetPointBase  {
public:
    uintptr_t baseAddr;

    C_SoundOpvarSetPointBase() { baseAddr = 0; }
    C_SoundOpvarSetPointBase(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_iszStackName() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_SoundOpvarSetPointBase", "m_iszStackName")); }
    uintptr_t m_iszOperatorName() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_SoundOpvarSetPointBase", "m_iszOperatorName")); }
    uintptr_t m_iszOpvarName() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_SoundOpvarSetPointBase", "m_iszOpvarName")); }
    int m_iOpvarIndex() { return read<int>(baseAddr + offsets_instance.get("C_SoundOpvarSetPointBase", "m_iOpvarIndex")); }
    bool m_bUseAutoCompare() { return read<bool>(baseAddr + offsets_instance.get("C_SoundOpvarSetPointBase", "m_bUseAutoCompare")); }
};
