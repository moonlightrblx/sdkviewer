#pragma once
#include "../memory.h"

class C_CSGO_TeamSelectTerroristPosition  {
public:
    uintptr_t baseAddr;

    C_CSGO_TeamSelectTerroristPosition() { baseAddr = client_base(); }
    C_CSGO_TeamSelectTerroristPosition(uintptr_t base) : baseAddr(base) {}

};
