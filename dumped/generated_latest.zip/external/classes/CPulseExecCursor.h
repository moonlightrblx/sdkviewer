#pragma once
#include "../memory.h"

class CPulseExecCursor  {
public:
    uintptr_t baseAddr;

    CPulseExecCursor() { baseAddr = client_base(); }
    CPulseExecCursor(uintptr_t base) : baseAddr(base) {}

};
