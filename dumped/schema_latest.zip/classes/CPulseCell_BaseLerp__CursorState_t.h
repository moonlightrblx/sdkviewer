#pragma once
#include "../memory.h"

class CPulseCell_BaseLerp__CursorState_t {
public:
 uintptr_t baseAddr;
 CPulseCell_BaseLerp__CursorState_t() : baseAddr(0){}
 CPulseCell_BaseLerp__CursorState_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_StartTime(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_EndTime(){return SCHEMA_TYPE(uintptr_t,0x4);}
};
