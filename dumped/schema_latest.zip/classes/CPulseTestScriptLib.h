#pragma once
#include "../memory.h"

class CPulseTestScriptLib {
public:
 uintptr_t baseAddr;
 CPulseTestScriptLib() : baseAddr(0){}
 CPulseTestScriptLib(uintptr_t b):baseAddr(b){}
};
