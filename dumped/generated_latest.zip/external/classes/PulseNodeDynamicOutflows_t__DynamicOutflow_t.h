#pragma once
#include "../memory.h"

class PulseNodeDynamicOutflows_t__DynamicOutflow_t  {
public:
    uintptr_t baseAddr;

    PulseNodeDynamicOutflows_t__DynamicOutflow_t() { baseAddr = client_base(); }
    PulseNodeDynamicOutflows_t__DynamicOutflow_t(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_OutflowID() { return read<uintptr_t>(baseAddr + offsets_instance.get("PulseNodeDynamicOutflows_t__DynamicOutflow_t", "m_OutflowID")); }
    uintptr_t m_Connection() { return read<uintptr_t>(baseAddr + offsets_instance.get("PulseNodeDynamicOutflows_t__DynamicOutflow_t", "m_Connection")); }
};
