#pragma once
#include "../memory.h"

class C_WeaponAug {
public:
 uintptr_t baseAddr;
 C_WeaponAug() : baseAddr(0){}
 C_WeaponAug(uintptr_t b):baseAddr(b){}
};
