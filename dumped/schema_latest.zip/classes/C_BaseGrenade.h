#pragma once
#include "../memory.h"

class C_BaseGrenade {
public:
 uintptr_t baseAddr;
 C_BaseGrenade() : baseAddr(0){}
 C_BaseGrenade(uintptr_t b):baseAddr(b){}
 uintptr_t m_bHasWarnedAI(){return SCHEMA_TYPE(uintptr_t,0x1368);}
 uintptr_t m_bIsSmokeGrenade(){return SCHEMA_TYPE(uintptr_t,0x1369);}
 uintptr_t m_bIsLive(){return SCHEMA_TYPE(uintptr_t,0x136A);}
 uintptr_t m_DmgRadius(){return SCHEMA_TYPE(uintptr_t,0x136C);}
 uintptr_t m_flDetonateTime(){return SCHEMA_TYPE(uintptr_t,0x1370);}
 uintptr_t m_flWarnAITime(){return SCHEMA_TYPE(uintptr_t,0x1374);}
 uintptr_t m_flDamage(){return SCHEMA_TYPE(uintptr_t,0x1378);}
 uintptr_t m_iszBounceSound(){return SCHEMA_TYPE(uintptr_t,0x1380);}
 uintptr_t m_ExplosionSound(){return SCHEMA_TYPE(uintptr_t,0x1388);}
 uintptr_t m_hThrower(){return SCHEMA_TYPE(uintptr_t,0x1394);}
 uintptr_t m_flNextAttack(){return SCHEMA_TYPE(uintptr_t,0x13AC);}
 uintptr_t m_hOriginalThrower(){return SCHEMA_TYPE(uintptr_t,0x13B0);}
};
