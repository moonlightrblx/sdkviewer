#pragma once
#include "../memory.h"

class C_WeaponRevolver  {
public:
    uintptr_t baseAddr;

    C_WeaponRevolver() { baseAddr = 0; }
    C_WeaponRevolver(uintptr_t base) : baseAddr(base) {}

};
