#pragma once
#include "../memory.h"

class CCSPointScriptEntity  {
public:
    uintptr_t baseAddr;

    CCSPointScriptEntity() { baseAddr = client_base(); }
    CCSPointScriptEntity(uintptr_t base) : baseAddr(base) {}

};
