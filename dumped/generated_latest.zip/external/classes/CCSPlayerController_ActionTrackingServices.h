#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class CCSPlayerController_ActionTrackingServices  {
public:
    uintptr_t baseAddr;

    CCSPlayerController_ActionTrackingServices() { baseAddr = client_base(); }
    CCSPlayerController_ActionTrackingServices(uintptr_t base) : baseAddr(base) {}

    Vector3 m_perRoundStats() { return read<Vector3>(baseAddr + offsets_instance.get("CCSPlayerController_ActionTrackingServices", "m_perRoundStats")); }
    uintptr_t m_matchStats() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSPlayerController_ActionTrackingServices", "m_matchStats")); }
    int m_iNumRoundKills() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController_ActionTrackingServices", "m_iNumRoundKills")); }
    int m_iNumRoundKillsHeadshots() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController_ActionTrackingServices", "m_iNumRoundKillsHeadshots")); }
    float m_flTotalRoundDamageDealt() { return read<float>(baseAddr + offsets_instance.get("CCSPlayerController_ActionTrackingServices", "m_flTotalRoundDamageDealt")); }
};
