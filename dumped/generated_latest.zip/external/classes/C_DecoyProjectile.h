#pragma once
#include "../memory.h"

class C_DecoyProjectile  {
public:
    uintptr_t baseAddr;

    C_DecoyProjectile() { baseAddr = client_base(); }
    C_DecoyProjectile(uintptr_t base) : baseAddr(base) {}

    int m_nDecoyShotTick() { return read<int>(baseAddr + offsets_instance.get("C_DecoyProjectile", "m_nDecoyShotTick")); }
    int m_nClientLastKnownDecoyShotTick() { return read<int>(baseAddr + offsets_instance.get("C_DecoyProjectile", "m_nClientLastKnownDecoyShotTick")); }
    uintptr_t m_flTimeParticleEffectSpawn() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_DecoyProjectile", "m_flTimeParticleEffectSpawn")); }
};
