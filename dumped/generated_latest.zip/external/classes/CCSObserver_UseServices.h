#pragma once
#include "../memory.h"

class CCSObserver_UseServices  {
public:
    uintptr_t baseAddr;

    CCSObserver_UseServices() { baseAddr = 0; }
    CCSObserver_UseServices(uintptr_t base) : baseAddr(base) {}

};
