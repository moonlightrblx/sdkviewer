#pragma once
#include "../memory.h"

class CBodyComponentSkeletonInstance {
public:
 uintptr_t baseAddr;
 CBodyComponentSkeletonInstance() : baseAddr(0){}
 CBodyComponentSkeletonInstance(uintptr_t b):baseAddr(b){}
 uintptr_t m_skeletonInstance(){return SCHEMA_TYPE(uintptr_t,0x80);}
};
