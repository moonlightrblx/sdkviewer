#pragma once
#include "../memory.h"

class CHitboxComponent  {
public:
    uintptr_t baseAddr;

    CHitboxComponent() { baseAddr = 0; }
    CHitboxComponent(uintptr_t base) : baseAddr(base) {}

    float m_flBoundsExpandRadius() { return read<float>(baseAddr + offsets_instance.get("CHitboxComponent", "m_flBoundsExpandRadius")); }
};
