#pragma once
#include "../memory.h"

class C_ClientRagdoll {
public:
 uintptr_t baseAddr;
 C_ClientRagdoll() : baseAddr(0){}
 C_ClientRagdoll(uintptr_t b):baseAddr(b){}
 uintptr_t m_bFadeOut(){return SCHEMA_TYPE(uintptr_t,0x1158);}
 uintptr_t m_bImportant(){return SCHEMA_TYPE(uintptr_t,0x1159);}
 uintptr_t m_flEffectTime(){return SCHEMA_TYPE(uintptr_t,0x115C);}
 uintptr_t m_gibDespawnTime(){return SCHEMA_TYPE(uintptr_t,0x1160);}
 uintptr_t m_iCurrentFriction(){return SCHEMA_TYPE(uintptr_t,0x1164);}
 uintptr_t m_iMinFriction(){return SCHEMA_TYPE(uintptr_t,0x1168);}
 uintptr_t m_iMaxFriction(){return SCHEMA_TYPE(uintptr_t,0x116C);}
 uintptr_t m_iFrictionAnimState(){return SCHEMA_TYPE(uintptr_t,0x1170);}
 uintptr_t m_bReleaseRagdoll(){return SCHEMA_TYPE(uintptr_t,0x1174);}
 uintptr_t m_iEyeAttachment(){return SCHEMA_TYPE(uintptr_t,0x1175);}
 uintptr_t m_bFadingOut(){return SCHEMA_TYPE(uintptr_t,0x1176);}
 uintptr_t m_flScaleEnd(){return SCHEMA_TYPE(uintptr_t,0x1178);}
 uintptr_t m_flScaleTimeStart(){return SCHEMA_TYPE(uintptr_t,0x11A0);}
 uintptr_t m_flScaleTimeEnd(){return SCHEMA_TYPE(uintptr_t,0x11C8);}
};
