#pragma once
#include "../memory.h"

class C_DecoyGrenade  {
public:
    uintptr_t baseAddr;

    C_DecoyGrenade() { baseAddr = client_base(); }
    C_DecoyGrenade(uintptr_t base) : baseAddr(base) {}

};
