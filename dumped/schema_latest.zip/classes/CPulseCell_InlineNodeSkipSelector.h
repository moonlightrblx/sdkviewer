#pragma once
#include "../memory.h"

class CPulseCell_InlineNodeSkipSelector {
public:
 uintptr_t baseAddr;
 CPulseCell_InlineNodeSkipSelector() : baseAddr(0){}
 CPulseCell_InlineNodeSkipSelector(uintptr_t b):baseAddr(b){}
 uintptr_t m_nFlowNodeID(){return SCHEMA_TYPE(uintptr_t,0x48);}
 uintptr_t m_bAnd(){return SCHEMA_TYPE(uintptr_t,0x4C);}
 uintptr_t m_PassOutflow(){return SCHEMA_TYPE(uintptr_t,0x50);}
 uintptr_t m_FailOutflow(){return SCHEMA_TYPE(uintptr_t,0x68);}
};
