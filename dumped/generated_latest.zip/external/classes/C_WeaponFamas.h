#pragma once
#include "../memory.h"

class C_WeaponFamas  {
public:
    uintptr_t baseAddr;

    C_WeaponFamas() { baseAddr = client_base(); }
    C_WeaponFamas(uintptr_t base) : baseAddr(base) {}

};
