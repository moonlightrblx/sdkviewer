#pragma once
#include "../memory.h"

class CEntityComponent  {
public:
    uintptr_t baseAddr;

    CEntityComponent() { baseAddr = client_base(); }
    CEntityComponent(uintptr_t base) : baseAddr(base) {}

};
