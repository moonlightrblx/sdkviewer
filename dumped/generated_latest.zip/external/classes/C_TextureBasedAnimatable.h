#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_TextureBasedAnimatable  {
public:
    uintptr_t baseAddr;

    C_TextureBasedAnimatable() { baseAddr = 0; }
    C_TextureBasedAnimatable(uintptr_t base) : baseAddr(base) {}

    bool m_bLoop() { return read<bool>(baseAddr + offsets_instance.get("C_TextureBasedAnimatable", "m_bLoop")); }
    float m_flFPS() { return read<float>(baseAddr + offsets_instance.get("C_TextureBasedAnimatable", "m_flFPS")); }
    uintptr_t m_hPositionKeys() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_TextureBasedAnimatable", "m_hPositionKeys")); }
    uintptr_t m_hRotationKeys() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_TextureBasedAnimatable", "m_hRotationKeys")); }
    Vector3 m_vAnimationBoundsMin() { return read<Vector3>(baseAddr + offsets_instance.get("C_TextureBasedAnimatable", "m_vAnimationBoundsMin")); }
    Vector3 m_vAnimationBoundsMax() { return read<Vector3>(baseAddr + offsets_instance.get("C_TextureBasedAnimatable", "m_vAnimationBoundsMax")); }
    float m_flStartTime() { return read<float>(baseAddr + offsets_instance.get("C_TextureBasedAnimatable", "m_flStartTime")); }
    float m_flStartFrame() { return read<float>(baseAddr + offsets_instance.get("C_TextureBasedAnimatable", "m_flStartFrame")); }
};
