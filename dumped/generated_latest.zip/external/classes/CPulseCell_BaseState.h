#pragma once
#include "../memory.h"

class CPulseCell_BaseState  {
public:
    uintptr_t baseAddr;

    CPulseCell_BaseState() { baseAddr = 0; }
    CPulseCell_BaseState(uintptr_t base) : baseAddr(base) {}

};
