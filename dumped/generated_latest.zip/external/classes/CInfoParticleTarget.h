#pragma once
#include "../memory.h"

class CInfoParticleTarget  {
public:
    uintptr_t baseAddr;

    CInfoParticleTarget() { baseAddr = client_base(); }
    CInfoParticleTarget(uintptr_t base) : baseAddr(base) {}

};
