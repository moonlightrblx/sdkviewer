#pragma once
#include "../memory.h"

class CCSObserver_MovementServices  {
public:
    uintptr_t baseAddr;

    CCSObserver_MovementServices() { baseAddr = 0; }
    CCSObserver_MovementServices(uintptr_t base) : baseAddr(base) {}

};
