#pragma once
#include "../memory.h"

class EventFrameBoundary_t {
public:
 uintptr_t baseAddr;
 EventFrameBoundary_t() : baseAddr(0){}
 EventFrameBoundary_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_flFrameTime(){return SCHEMA_TYPE(uintptr_t,0x0);}
};
