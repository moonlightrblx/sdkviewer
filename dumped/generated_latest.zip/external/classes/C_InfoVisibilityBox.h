#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_InfoVisibilityBox  {
public:
    uintptr_t baseAddr;

    C_InfoVisibilityBox() { baseAddr = 0; }
    C_InfoVisibilityBox(uintptr_t base) : baseAddr(base) {}

    int m_nMode() { return read<int>(baseAddr + offsets_instance.get("C_InfoVisibilityBox", "m_nMode")); }
    Vector3 m_vBoxSize() { return read<Vector3>(baseAddr + offsets_instance.get("C_InfoVisibilityBox", "m_vBoxSize")); }
    bool m_bEnabled() { return read<bool>(baseAddr + offsets_instance.get("C_InfoVisibilityBox", "m_bEnabled")); }
};
