#pragma once
#include "../memory.h"

class CPulse_BlackboardReference  {
public:
    uintptr_t baseAddr;

    CPulse_BlackboardReference() { baseAddr = client_base(); }
    CPulse_BlackboardReference(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_hBlackboardResource() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulse_BlackboardReference", "m_hBlackboardResource")); }
    uintptr_t m_BlackboardResource() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulse_BlackboardReference", "m_BlackboardResource")); }
    uintptr_t m_nNodeID() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulse_BlackboardReference", "m_nNodeID")); }
    uintptr_t m_NodeName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulse_BlackboardReference", "m_NodeName")); }
};
