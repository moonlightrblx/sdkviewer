#pragma once
#include "../memory.h"

class C_CSObserverPawn {
public:
 uintptr_t baseAddr;
 C_CSObserverPawn() : baseAddr(0){}
 C_CSObserverPawn(uintptr_t b):baseAddr(b){}
 uintptr_t m_hDetectParentChange(){return SCHEMA_TYPE(uintptr_t,0x1668);}
};
