#pragma once
#include "../memory.h"

class PredictedDamageTag_t  {
public:
    uintptr_t baseAddr;

    PredictedDamageTag_t() { baseAddr = client_base(); }
    PredictedDamageTag_t(uintptr_t base) : baseAddr(base) {}

    uintptr_t nTagTick() { return read<uintptr_t>(baseAddr + offsets_instance.get("PredictedDamageTag_t", "nTagTick")); }
    float flFlinchModSmall() { return read<float>(baseAddr + offsets_instance.get("PredictedDamageTag_t", "flFlinchModSmall")); }
    float flFlinchModLarge() { return read<float>(baseAddr + offsets_instance.get("PredictedDamageTag_t", "flFlinchModLarge")); }
    float flFriendlyFireDamageReductionRatio() { return read<float>(baseAddr + offsets_instance.get("PredictedDamageTag_t", "flFriendlyFireDamageReductionRatio")); }
};
