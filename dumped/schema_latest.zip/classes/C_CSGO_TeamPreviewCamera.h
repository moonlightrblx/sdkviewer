#pragma once
#include "../memory.h"

class C_CSGO_TeamPreviewCamera {
public:
 uintptr_t baseAddr;
 C_CSGO_TeamPreviewCamera() : baseAddr(0){}
 C_CSGO_TeamPreviewCamera(uintptr_t b):baseAddr(b){}
 uintptr_t m_nVariant(){return SCHEMA_TYPE(uintptr_t,0x680);}
};
