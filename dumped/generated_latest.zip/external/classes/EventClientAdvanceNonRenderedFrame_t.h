#pragma once
#include "../memory.h"

class EventClientAdvanceNonRenderedFrame_t  {
public:
    uintptr_t baseAddr;

    EventClientAdvanceNonRenderedFrame_t() { baseAddr = 0; }
    EventClientAdvanceNonRenderedFrame_t(uintptr_t base) : baseAddr(base) {}

};
