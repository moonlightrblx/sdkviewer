#pragma once
#include "../memory.h"

class CPulseCell_Unknown {
public:
 uintptr_t baseAddr;
 CPulseCell_Unknown() : baseAddr(0){}
 CPulseCell_Unknown(uintptr_t b):baseAddr(b){}
 uintptr_t m_UnknownKeys(){return SCHEMA_TYPE(uintptr_t,0x48);}
};
