#pragma once
#include "../memory.h"

class CWaterSplasher {
public:
 uintptr_t baseAddr;
 CWaterSplasher() : baseAddr(0){}
 CWaterSplasher(uintptr_t b):baseAddr(b){}
};
