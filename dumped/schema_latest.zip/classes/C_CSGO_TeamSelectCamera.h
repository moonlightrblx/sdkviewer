#pragma once
#include "../memory.h"

class C_CSGO_TeamSelectCamera {
public:
 uintptr_t baseAddr;
 C_CSGO_TeamSelectCamera() : baseAddr(0){}
 C_CSGO_TeamSelectCamera(uintptr_t b):baseAddr(b){}
};
