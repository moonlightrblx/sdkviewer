#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_RagdollPropAttached  {
public:
    uintptr_t baseAddr;

    C_RagdollPropAttached() { baseAddr = 0; }
    C_RagdollPropAttached(uintptr_t base) : baseAddr(base) {}

    int m_boneIndexAttached() { return read<int>(baseAddr + offsets_instance.get("C_RagdollPropAttached", "m_boneIndexAttached")); }
    int m_ragdollAttachedObjectIndex() { return read<int>(baseAddr + offsets_instance.get("C_RagdollPropAttached", "m_ragdollAttachedObjectIndex")); }
    Vector3 m_attachmentPointBoneSpace() { return read<Vector3>(baseAddr + offsets_instance.get("C_RagdollPropAttached", "m_attachmentPointBoneSpace")); }
    Vector3 m_attachmentPointRagdollSpace() { return read<Vector3>(baseAddr + offsets_instance.get("C_RagdollPropAttached", "m_attachmentPointRagdollSpace")); }
    Vector3 m_vecOffset() { return read<Vector3>(baseAddr + offsets_instance.get("C_RagdollPropAttached", "m_vecOffset")); }
    float m_parentTime() { return read<float>(baseAddr + offsets_instance.get("C_RagdollPropAttached", "m_parentTime")); }
    bool m_bHasParent() { return read<bool>(baseAddr + offsets_instance.get("C_RagdollPropAttached", "m_bHasParent")); }
};
