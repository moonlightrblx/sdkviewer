#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_CSPlayerResource  {
public:
    uintptr_t baseAddr;

    C_CSPlayerResource() { baseAddr = 0; }
    C_CSPlayerResource(uintptr_t base) : baseAddr(base) {}

    bool m_bHostageAlive() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerResource", "m_bHostageAlive")); }
    bool m_isHostageFollowingSomeone() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerResource", "m_isHostageFollowingSomeone")); }
    uintptr_t m_iHostageEntityIDs() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CSPlayerResource", "m_iHostageEntityIDs")); }
    Vector3 m_bombsiteCenterA() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSPlayerResource", "m_bombsiteCenterA")); }
    Vector3 m_bombsiteCenterB() { return read<Vector3>(baseAddr + offsets_instance.get("C_CSPlayerResource", "m_bombsiteCenterB")); }
    int m_hostageRescueX() { return read<int>(baseAddr + offsets_instance.get("C_CSPlayerResource", "m_hostageRescueX")); }
    int m_hostageRescueY() { return read<int>(baseAddr + offsets_instance.get("C_CSPlayerResource", "m_hostageRescueY")); }
    int m_hostageRescueZ() { return read<int>(baseAddr + offsets_instance.get("C_CSPlayerResource", "m_hostageRescueZ")); }
    bool m_bEndMatchNextMapAllVoted() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerResource", "m_bEndMatchNextMapAllVoted")); }
    bool m_foundGoalPositions() { return read<bool>(baseAddr + offsets_instance.get("C_CSPlayerResource", "m_foundGoalPositions")); }
};
