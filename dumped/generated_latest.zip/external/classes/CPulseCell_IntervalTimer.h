#pragma once
#include "../memory.h"

class CPulseCell_IntervalTimer  {
public:
    uintptr_t baseAddr;

    CPulseCell_IntervalTimer() { baseAddr = client_base(); }
    CPulseCell_IntervalTimer(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_Completed() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_IntervalTimer", "m_Completed")); }
    uintptr_t m_OnInterval() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_IntervalTimer", "m_OnInterval")); }
};
