#pragma once
#include "../memory.h"

class EventAppShutdown_t {
public:
 uintptr_t baseAddr;
 EventAppShutdown_t() : baseAddr(0){}
 EventAppShutdown_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_nDummy0(){return SCHEMA_TYPE(uintptr_t,0x0);}
};
