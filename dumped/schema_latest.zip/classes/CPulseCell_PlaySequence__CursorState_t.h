#pragma once
#include "../memory.h"

class CPulseCell_PlaySequence__CursorState_t {
public:
 uintptr_t baseAddr;
 CPulseCell_PlaySequence__CursorState_t() : baseAddr(0){}
 CPulseCell_PlaySequence__CursorState_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_hTarget(){return SCHEMA_TYPE(uintptr_t,0x0);}
};
