#pragma once
#include "../memory.h"
#include "../classes/GameTime_t.h"
#include "../types/Vector3.h"

class C_BaseCSGrenadeProjectile  {
public:
    uintptr_t baseAddr;

    C_BaseCSGrenadeProjectile() { baseAddr = 0; }
    C_BaseCSGrenadeProjectile(uintptr_t base) : baseAddr(base) {}

    Vector3 m_vInitialPosition() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseCSGrenadeProjectile", "m_vInitialPosition")); }
    Vector3 m_vInitialVelocity() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseCSGrenadeProjectile", "m_vInitialVelocity")); }
    int m_nBounces() { return read<int>(baseAddr + offsets_instance.get("C_BaseCSGrenadeProjectile", "m_nBounces")); }
    uintptr_t m_nExplodeEffectIndex() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseCSGrenadeProjectile", "m_nExplodeEffectIndex")); }
    int m_nExplodeEffectTickBegin() { return read<int>(baseAddr + offsets_instance.get("C_BaseCSGrenadeProjectile", "m_nExplodeEffectTickBegin")); }
    Vector3 m_vecExplodeEffectOrigin() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseCSGrenadeProjectile", "m_vecExplodeEffectOrigin")); }
    GameTime_t m_flSpawnTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_BaseCSGrenadeProjectile", "m_flSpawnTime")); }
    Vector3 vecLastTrailLinePos() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseCSGrenadeProjectile", "vecLastTrailLinePos")); }
    GameTime_t flNextTrailLineTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_BaseCSGrenadeProjectile", "flNextTrailLineTime")); }
    bool m_bExplodeEffectBegan() { return read<bool>(baseAddr + offsets_instance.get("C_BaseCSGrenadeProjectile", "m_bExplodeEffectBegan")); }
    bool m_bCanCreateGrenadeTrail() { return read<bool>(baseAddr + offsets_instance.get("C_BaseCSGrenadeProjectile", "m_bCanCreateGrenadeTrail")); }
    uintptr_t m_nSnapshotTrajectoryEffectIndex() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseCSGrenadeProjectile", "m_nSnapshotTrajectoryEffectIndex")); }
    uintptr_t m_hSnapshotTrajectoryParticleSnapshot() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseCSGrenadeProjectile", "m_hSnapshotTrajectoryParticleSnapshot")); }
    Vector3 m_arrTrajectoryTrailPoints() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseCSGrenadeProjectile", "m_arrTrajectoryTrailPoints")); }
    float m_arrTrajectoryTrailPointCreationTimes() { return read<float>(baseAddr + offsets_instance.get("C_BaseCSGrenadeProjectile", "m_arrTrajectoryTrailPointCreationTimes")); }
    float m_flTrajectoryTrailEffectCreationTime() { return read<float>(baseAddr + offsets_instance.get("C_BaseCSGrenadeProjectile", "m_flTrajectoryTrailEffectCreationTime")); }
};
