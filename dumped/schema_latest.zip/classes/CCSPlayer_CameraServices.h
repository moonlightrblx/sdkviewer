#pragma once
#include "../memory.h"

class CCSPlayer_CameraServices {
public:
 uintptr_t baseAddr;
 CCSPlayer_CameraServices() : baseAddr(0){}
 CCSPlayer_CameraServices(uintptr_t b):baseAddr(b){}
 uintptr_t m_flDeathCamTilt(){return SCHEMA_TYPE(uintptr_t,0x2A0);}
 uintptr_t m_vClientScopeInaccuracy(){return SCHEMA_TYPE(uintptr_t,0x2A8);}
};
