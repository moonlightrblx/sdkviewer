#pragma once
#include "../memory.h"

class C_Beam {
public:
 uintptr_t baseAddr;
 C_Beam() : baseAddr(0){}
 C_Beam(uintptr_t b):baseAddr(b){}
 uintptr_t m_flFrameRate(){return SCHEMA_TYPE(uintptr_t,0xEB0);}
 uintptr_t m_flHDRColorScale(){return SCHEMA_TYPE(uintptr_t,0xEB4);}
 uintptr_t m_flFireTime(){return SCHEMA_TYPE(uintptr_t,0xEB8);}
 uintptr_t m_flDamage(){return SCHEMA_TYPE(uintptr_t,0xEBC);}
 uintptr_t m_nNumBeamEnts(){return SCHEMA_TYPE(uintptr_t,0xEC0);}
 uintptr_t m_queryHandleHalo(){return SCHEMA_TYPE(uintptr_t,0xEC4);}
 uintptr_t m_hBaseMaterial(){return SCHEMA_TYPE(uintptr_t,0xEE8);}
 uintptr_t m_nHaloIndex(){return SCHEMA_TYPE(uintptr_t,0xEF0);}
 uintptr_t m_nBeamType(){return SCHEMA_TYPE(uintptr_t,0xEF8);}
 uintptr_t m_nBeamFlags(){return SCHEMA_TYPE(uintptr_t,0xEFC);}
 uintptr_t m_hAttachEntity(){return SCHEMA_TYPE(uintptr_t,0xF00);}
 uintptr_t m_nAttachIndex(){return SCHEMA_TYPE(uintptr_t,0xF28);}
 uintptr_t m_fWidth(){return SCHEMA_TYPE(uintptr_t,0xF34);}
 uintptr_t m_fEndWidth(){return SCHEMA_TYPE(uintptr_t,0xF38);}
 uintptr_t m_fFadeLength(){return SCHEMA_TYPE(uintptr_t,0xF3C);}
 uintptr_t m_fHaloScale(){return SCHEMA_TYPE(uintptr_t,0xF40);}
 uintptr_t m_fAmplitude(){return SCHEMA_TYPE(uintptr_t,0xF44);}
 uintptr_t m_fStartFrame(){return SCHEMA_TYPE(uintptr_t,0xF48);}
 uintptr_t m_fSpeed(){return SCHEMA_TYPE(uintptr_t,0xF4C);}
 uintptr_t m_flFrame(){return SCHEMA_TYPE(uintptr_t,0xF50);}
 uintptr_t m_nClipStyle(){return SCHEMA_TYPE(uintptr_t,0xF54);}
 uintptr_t m_bTurnedOff(){return SCHEMA_TYPE(uintptr_t,0xF58);}
 uintptr_t m_vecEndPos(){return SCHEMA_TYPE(uintptr_t,0xF5C);}
 uintptr_t m_hEndEntity(){return SCHEMA_TYPE(uintptr_t,0xF68);}
};
