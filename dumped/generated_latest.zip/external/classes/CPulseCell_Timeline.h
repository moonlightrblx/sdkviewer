#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class CPulseCell_Timeline  {
public:
    uintptr_t baseAddr;

    CPulseCell_Timeline() { baseAddr = client_base(); }
    CPulseCell_Timeline(uintptr_t base) : baseAddr(base) {}

    Vector3 m_TimelineEvents() { return read<Vector3>(baseAddr + offsets_instance.get("CPulseCell_Timeline", "m_TimelineEvents")); }
    bool m_bWaitForChildOutflows() { return read<bool>(baseAddr + offsets_instance.get("CPulseCell_Timeline", "m_bWaitForChildOutflows")); }
    uintptr_t m_OnFinished() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Timeline", "m_OnFinished")); }
    uintptr_t m_OnCanceled() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Timeline", "m_OnCanceled")); }
};
