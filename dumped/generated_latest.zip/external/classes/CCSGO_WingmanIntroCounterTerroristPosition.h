#pragma once
#include "../memory.h"

class CCSGO_WingmanIntroCounterTerroristPosition  {
public:
    uintptr_t baseAddr;

    CCSGO_WingmanIntroCounterTerroristPosition() { baseAddr = client_base(); }
    CCSGO_WingmanIntroCounterTerroristPosition(uintptr_t base) : baseAddr(base) {}

};
