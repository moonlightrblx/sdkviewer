#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class sky3dparams_t  {
public:
    uintptr_t baseAddr;

    sky3dparams_t() { baseAddr = client_base(); }
    sky3dparams_t(uintptr_t base) : baseAddr(base) {}

    uintptr_t scale() { return read<uintptr_t>(baseAddr + offsets_instance.get("sky3dparams_t", "scale")); }
    Vector3 origin() { return read<Vector3>(baseAddr + offsets_instance.get("sky3dparams_t", "origin")); }
    bool bClip3DSkyBoxNearToWorldFar() { return read<bool>(baseAddr + offsets_instance.get("sky3dparams_t", "bClip3DSkyBoxNearToWorldFar")); }
    float flClip3DSkyBoxNearToWorldFarOffset() { return read<float>(baseAddr + offsets_instance.get("sky3dparams_t", "flClip3DSkyBoxNearToWorldFarOffset")); }
    uintptr_t fog() { return read<uintptr_t>(baseAddr + offsets_instance.get("sky3dparams_t", "fog")); }
    uintptr_t m_nWorldGroupID() { return read<uintptr_t>(baseAddr + offsets_instance.get("sky3dparams_t", "m_nWorldGroupID")); }
};
