#pragma once
#include "../memory.h"

class C_GlobalLight  {
public:
    uintptr_t baseAddr;

    C_GlobalLight() { baseAddr = 0; }
    C_GlobalLight(uintptr_t base) : baseAddr(base) {}

    uint16_t m_WindClothForceHandle() { return read<uint16_t>(baseAddr + offsets_instance.get("C_GlobalLight", "m_WindClothForceHandle")); }
};
