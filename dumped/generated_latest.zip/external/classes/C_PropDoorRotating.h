#pragma once
#include "../memory.h"

class C_PropDoorRotating  {
public:
    uintptr_t baseAddr;

    C_PropDoorRotating() { baseAddr = client_base(); }
    C_PropDoorRotating(uintptr_t base) : baseAddr(base) {}

};
