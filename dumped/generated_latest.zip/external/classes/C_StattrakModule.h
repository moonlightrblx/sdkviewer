#pragma once
#include "../memory.h"

class C_StattrakModule  {
public:
    uintptr_t baseAddr;

    C_StattrakModule() { baseAddr = client_base(); }
    C_StattrakModule(uintptr_t base) : baseAddr(base) {}

    bool m_bKnife() { return read<bool>(baseAddr + offsets_instance.get("C_StattrakModule", "m_bKnife")); }
};
