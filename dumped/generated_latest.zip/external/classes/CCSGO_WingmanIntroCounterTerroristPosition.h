#pragma once
#include "../memory.h"

class CCSGO_WingmanIntroCounterTerroristPosition  {
public:
    uintptr_t baseAddr;

    CCSGO_WingmanIntroCounterTerroristPosition() { baseAddr = 0; }
    CCSGO_WingmanIntroCounterTerroristPosition(uintptr_t base) : baseAddr(base) {}

};
