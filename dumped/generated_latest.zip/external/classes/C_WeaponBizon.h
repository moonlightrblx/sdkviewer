#pragma once
#include "../memory.h"

class C_WeaponBizon  {
public:
    uintptr_t baseAddr;

    C_WeaponBizon() { baseAddr = client_base(); }
    C_WeaponBizon(uintptr_t base) : baseAddr(base) {}

};
