#pragma once
#include "../memory.h"

class C_SoundAreaEntityBase {
public:
 uintptr_t baseAddr;
 C_SoundAreaEntityBase() : baseAddr(0){}
 C_SoundAreaEntityBase(uintptr_t b):baseAddr(b){}
 uintptr_t m_bDisabled(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_bWasEnabled(){return SCHEMA_TYPE(uintptr_t,0x600);}
 uintptr_t m_iszSoundAreaType(){return SCHEMA_TYPE(uintptr_t,0x608);}
 uintptr_t m_vPos(){return SCHEMA_TYPE(uintptr_t,0x610);}
};
