#pragma once
#include "../memory.h"

class C_WaterBullet {
public:
 uintptr_t baseAddr;
 C_WaterBullet() : baseAddr(0){}
 C_WaterBullet(uintptr_t b):baseAddr(b){}
};
