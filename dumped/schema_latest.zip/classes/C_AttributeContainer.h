#pragma once
#include "../memory.h"

class C_AttributeContainer {
public:
 uintptr_t baseAddr;
 C_AttributeContainer() : baseAddr(0){}
 C_AttributeContainer(uintptr_t b):baseAddr(b){}
 uintptr_t m_Item(){return SCHEMA_TYPE(uintptr_t,0x50);}
 uintptr_t m_iExternalItemProviderRegisteredToken(){return SCHEMA_TYPE(uintptr_t,0x4C8);}
 uintptr_t m_ullRegisteredAsItemID(){return SCHEMA_TYPE(uintptr_t,0x4D0);}
};
