#pragma once
#include "../memory.h"

class CScriptComponent {
public:
 uintptr_t baseAddr;
 CScriptComponent() : baseAddr(0){}
 CScriptComponent(uintptr_t b):baseAddr(b){}
 uintptr_t m_scriptClassName(){return SCHEMA_TYPE(uintptr_t,0x30);}
};
