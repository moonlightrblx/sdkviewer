#pragma once
#include "../memory.h"

class CPlayer_FlashlightServices  {
public:
    uintptr_t baseAddr;

    CPlayer_FlashlightServices() { baseAddr = 0; }
    CPlayer_FlashlightServices(uintptr_t base) : baseAddr(base) {}

};
