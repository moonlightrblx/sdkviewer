#pragma once
#include "../memory.h"

class C_EnvDetailController  {
public:
    uintptr_t baseAddr;

    C_EnvDetailController() { baseAddr = 0; }
    C_EnvDetailController(uintptr_t base) : baseAddr(base) {}

    float m_flFadeStartDist() { return read<float>(baseAddr + offsets_instance.get("C_EnvDetailController", "m_flFadeStartDist")); }
    float m_flFadeEndDist() { return read<float>(baseAddr + offsets_instance.get("C_EnvDetailController", "m_flFadeEndDist")); }
};
