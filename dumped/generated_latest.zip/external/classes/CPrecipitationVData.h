#pragma once
#include "../memory.h"

class CPrecipitationVData  {
public:
    uintptr_t baseAddr;

    CPrecipitationVData() { baseAddr = 0; }
    CPrecipitationVData(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_szParticlePrecipitationEffect() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPrecipitationVData", "m_szParticlePrecipitationEffect")); }
    float m_flInnerDistance() { return read<float>(baseAddr + offsets_instance.get("CPrecipitationVData", "m_flInnerDistance")); }
    uintptr_t m_nAttachType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPrecipitationVData", "m_nAttachType")); }
    bool m_bBatchSameVolumeType() { return read<bool>(baseAddr + offsets_instance.get("CPrecipitationVData", "m_bBatchSameVolumeType")); }
    int m_nRTEnvCP() { return read<int>(baseAddr + offsets_instance.get("CPrecipitationVData", "m_nRTEnvCP")); }
    int m_nRTEnvCPComponent() { return read<int>(baseAddr + offsets_instance.get("CPrecipitationVData", "m_nRTEnvCPComponent")); }
    uintptr_t m_szModifier() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPrecipitationVData", "m_szModifier")); }
};
