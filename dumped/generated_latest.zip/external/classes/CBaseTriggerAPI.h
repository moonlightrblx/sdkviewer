#pragma once
#include "../memory.h"

class CBaseTriggerAPI  {
public:
    uintptr_t baseAddr;

    CBaseTriggerAPI() { baseAddr = client_base(); }
    CBaseTriggerAPI(uintptr_t base) : baseAddr(base) {}

};
