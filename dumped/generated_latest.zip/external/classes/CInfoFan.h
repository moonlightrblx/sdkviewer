#pragma once
#include "../memory.h"

class CInfoFan  {
public:
    uintptr_t baseAddr;

    CInfoFan() { baseAddr = client_base(); }
    CInfoFan(uintptr_t base) : baseAddr(base) {}

    float m_fFanForceMaxRadius() { return read<float>(baseAddr + offsets_instance.get("CInfoFan", "m_fFanForceMaxRadius")); }
    float m_fFanForceMinRadius() { return read<float>(baseAddr + offsets_instance.get("CInfoFan", "m_fFanForceMinRadius")); }
    float m_flCurveDistRange() { return read<float>(baseAddr + offsets_instance.get("CInfoFan", "m_flCurveDistRange")); }
    uintptr_t m_FanForceCurveString() { return read<uintptr_t>(baseAddr + offsets_instance.get("CInfoFan", "m_FanForceCurveString")); }
};
