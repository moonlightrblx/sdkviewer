#pragma once
#include "../memory.h"

class C_SoundOpvarSetOBBEntity  {
public:
    uintptr_t baseAddr;

    C_SoundOpvarSetOBBEntity() { baseAddr = 0; }
    C_SoundOpvarSetOBBEntity(uintptr_t base) : baseAddr(base) {}

};
