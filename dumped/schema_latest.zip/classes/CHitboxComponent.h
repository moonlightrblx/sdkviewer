#pragma once
#include "../memory.h"

class CHitboxComponent {
public:
 uintptr_t baseAddr;
 CHitboxComponent() : baseAddr(0){}
 CHitboxComponent(uintptr_t b):baseAddr(b){}
 uintptr_t m_flBoundsExpandRadius(){return SCHEMA_TYPE(uintptr_t,0x14);}
};
