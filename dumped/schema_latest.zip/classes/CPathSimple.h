#pragma once
#include "../memory.h"

class CPathSimple {
public:
 uintptr_t baseAddr;
 CPathSimple() : baseAddr(0){}
 CPathSimple(uintptr_t b):baseAddr(b){}
 uintptr_t m_CPathQueryComponent(){return SCHEMA_TYPE(uintptr_t,0x600);}
 uintptr_t m_pathString(){return SCHEMA_TYPE(uintptr_t,0x6F0);}
 uintptr_t m_bClosedLoop(){return SCHEMA_TYPE(uintptr_t,0x6F8);}
};
