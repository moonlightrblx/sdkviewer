#pragma once
#include "../memory.h"

class CPulseAnimFuncs {
public:
 uintptr_t baseAddr;
 CPulseAnimFuncs() : baseAddr(0){}
 CPulseAnimFuncs(uintptr_t b):baseAddr(b){}
};
