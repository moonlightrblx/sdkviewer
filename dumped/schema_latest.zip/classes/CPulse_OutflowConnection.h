#pragma once
#include "../memory.h"

class CPulse_OutflowConnection {
public:
 uintptr_t baseAddr;
 CPulse_OutflowConnection() : baseAddr(0){}
 CPulse_OutflowConnection(uintptr_t b):baseAddr(b){}
 uintptr_t m_SourceOutflowName(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_nDestChunk(){return SCHEMA_TYPE(uintptr_t,0x10);}
 uintptr_t m_nInstruction(){return SCHEMA_TYPE(uintptr_t,0x14);}
 uintptr_t m_OutflowRegisterMap(){return SCHEMA_TYPE(uintptr_t,0x18);}
};
