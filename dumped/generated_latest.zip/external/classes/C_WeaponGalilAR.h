#pragma once
#include "../memory.h"

class C_WeaponGalilAR  {
public:
    uintptr_t baseAddr;

    C_WeaponGalilAR() { baseAddr = client_base(); }
    C_WeaponGalilAR(uintptr_t base) : baseAddr(base) {}

};
