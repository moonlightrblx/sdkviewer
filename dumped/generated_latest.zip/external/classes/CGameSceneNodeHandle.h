#pragma once
#include "../memory.h"

class CGameSceneNodeHandle  {
public:
    uintptr_t baseAddr;

    CGameSceneNodeHandle() { baseAddr = client_base(); }
    CGameSceneNodeHandle(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_hOwner() { return read<uintptr_t>(baseAddr + offsets_instance.get("CGameSceneNodeHandle", "m_hOwner")); }
    uintptr_t m_name() { return read<uintptr_t>(baseAddr + offsets_instance.get("CGameSceneNodeHandle", "m_name")); }
};
