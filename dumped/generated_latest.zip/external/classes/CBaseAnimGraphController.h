#pragma once
#include "../memory.h"
#include "../classes/CAnimGraphNetworkedVariables.h"
#include "../classes/GameTime_t.h"

class CBaseAnimGraphController  {
public:
    uintptr_t baseAddr;

    CBaseAnimGraphController() { baseAddr = 0; }
    CBaseAnimGraphController(uintptr_t base) : baseAddr(base) {}

    CAnimGraphNetworkedVariables m_animGraphNetworkedVars() { return read<CAnimGraphNetworkedVariables>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_animGraphNetworkedVars")); }
    bool m_bSequenceFinished() { return read<bool>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_bSequenceFinished")); }
    float m_flSoundSyncTime() { return read<float>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_flSoundSyncTime")); }
    int m_nActiveIKChainMask() { return read<int>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_nActiveIKChainMask")); }
    uintptr_t m_hSequence() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_hSequence")); }
    GameTime_t m_flSeqStartTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_flSeqStartTime")); }
    float m_flSeqFixedCycle() { return read<float>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_flSeqFixedCycle")); }
    uintptr_t m_nAnimLoopMode() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_nAnimLoopMode")); }
    uintptr_t m_flPlaybackRate() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_flPlaybackRate")); }
    uintptr_t m_nNotifyState() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_nNotifyState")); }
    bool m_bNetworkedAnimationInputsChanged() { return read<bool>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_bNetworkedAnimationInputsChanged")); }
    bool m_bNetworkedSequenceChanged() { return read<bool>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_bNetworkedSequenceChanged")); }
    bool m_bLastUpdateSkipped() { return read<bool>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_bLastUpdateSkipped")); }
    GameTime_t m_flPrevAnimUpdateTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_flPrevAnimUpdateTime")); }
    uintptr_t m_hGraphDefinitionAG2() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_hGraphDefinitionAG2")); }
    bool m_bIsUsingAG2() { return read<bool>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_bIsUsingAG2")); }
    uint8_t m_serializedPoseRecipeAG2() { return read<uint8_t>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_serializedPoseRecipeAG2")); }
    int m_nSerializePoseRecipeSizeAG2() { return read<int>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_nSerializePoseRecipeSizeAG2")); }
    int m_nSerializePoseRecipeVersionAG2() { return read<int>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_nSerializePoseRecipeVersionAG2")); }
    uint8_t m_nGraphCreationFlagsAG2() { return read<uint8_t>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_nGraphCreationFlagsAG2")); }
    int m_nServerGraphDefReloadCountAG2() { return read<int>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_nServerGraphDefReloadCountAG2")); }
    int m_nServerSerializationContextIteration() { return read<int>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_nServerSerializationContextIteration")); }
};
