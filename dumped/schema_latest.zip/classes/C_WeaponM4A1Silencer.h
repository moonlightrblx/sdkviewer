#pragma once
#include "../memory.h"

class C_WeaponM4A1Silencer {
public:
 uintptr_t baseAddr;
 C_WeaponM4A1Silencer() : baseAddr(0){}
 C_WeaponM4A1Silencer(uintptr_t b):baseAddr(b){}
};
