#pragma once
#include "../memory.h"

class C_KeychainModule  {
public:
    uintptr_t baseAddr;

    C_KeychainModule() { baseAddr = 0; }
    C_KeychainModule(uintptr_t base) : baseAddr(base) {}

    int m_nKeychainDefID() { return read<int>(baseAddr + offsets_instance.get("C_KeychainModule", "m_nKeychainDefID")); }
    int m_nKeychainSeed() { return read<int>(baseAddr + offsets_instance.get("C_KeychainModule", "m_nKeychainSeed")); }
};
