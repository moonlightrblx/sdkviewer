#pragma once
#include "../memory.h"

class CSpriteOriented  {
public:
    uintptr_t baseAddr;

    CSpriteOriented() { baseAddr = client_base(); }
    CSpriteOriented(uintptr_t base) : baseAddr(base) {}

};
