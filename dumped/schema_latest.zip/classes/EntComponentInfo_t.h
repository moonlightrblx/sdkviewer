#pragma once
#include "../memory.h"

class EntComponentInfo_t {
public:
 uintptr_t baseAddr;
 EntComponentInfo_t() : baseAddr(0){}
 EntComponentInfo_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_pName(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_pCPPClassname(){return SCHEMA_TYPE(uintptr_t,0x8);}
 uintptr_t m_pNetworkDataReferencedDescription(){return SCHEMA_TYPE(uintptr_t,0x10);}
 uintptr_t m_pNetworkDataReferencedPtrPropDescription(){return SCHEMA_TYPE(uintptr_t,0x18);}
 uintptr_t m_nRuntimeIndex(){return SCHEMA_TYPE(uintptr_t,0x20);}
 uintptr_t m_nFlags(){return SCHEMA_TYPE(uintptr_t,0x24);}
 uintptr_t m_pBaseClassComponentHelper(){return SCHEMA_TYPE(uintptr_t,0x60);}
};
