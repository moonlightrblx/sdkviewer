#pragma once
#include "../memory.h"

class C_NetTestBaseCombatCharacter {
public:
 uintptr_t baseAddr;
 C_NetTestBaseCombatCharacter() : baseAddr(0){}
 C_NetTestBaseCombatCharacter(uintptr_t b):baseAddr(b){}
};
