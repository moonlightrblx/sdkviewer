#pragma once
#include "../memory.h"
class EntComponentInfo_t;

class CEntityComponentHelper  {
public:
    uintptr_t baseAddr;

    CEntityComponentHelper() { baseAddr = 0; }
    CEntityComponentHelper(uintptr_t base) : baseAddr(base) {}

    int m_flags() { return read<int>(baseAddr + offsets_instance.get("CEntityComponentHelper", "m_flags")); }
    EntComponentInfo_t* m_pInfo() { return read<EntComponentInfo_t*>(baseAddr + offsets_instance.get("CEntityComponentHelper", "m_pInfo")); }
    int m_nPriority() { return read<int>(baseAddr + offsets_instance.get("CEntityComponentHelper", "m_nPriority")); }
    CEntityComponentHelper* m_pNext() { return read<CEntityComponentHelper*>(baseAddr + offsets_instance.get("CEntityComponentHelper", "m_pNext")); }
};
