#pragma once
#include "../memory.h"

class EventClientPreSimulate_t {
public:
 uintptr_t baseAddr;
 EventClientPreSimulate_t() : baseAddr(0){}
 EventClientPreSimulate_t(uintptr_t b):baseAddr(b){}
};
