#pragma once
#include "../memory.h"

class CPointOffScreenIndicatorUi {
public:
 uintptr_t baseAddr;
 CPointOffScreenIndicatorUi() : baseAddr(0){}
 CPointOffScreenIndicatorUi(uintptr_t b):baseAddr(b){}
 uintptr_t m_bBeenEnabled(){return SCHEMA_TYPE(uintptr_t,0x1100);}
 uintptr_t m_bHide(){return SCHEMA_TYPE(uintptr_t,0x1101);}
 uintptr_t m_flSeenTargetTime(){return SCHEMA_TYPE(uintptr_t,0x1104);}
 uintptr_t m_pTargetPanel(){return SCHEMA_TYPE(uintptr_t,0x1108);}
};
