#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_PointClientUIWorldPanel  {
public:
    uintptr_t baseAddr;

    C_PointClientUIWorldPanel() { baseAddr = client_base(); }
    C_PointClientUIWorldPanel(uintptr_t base) : baseAddr(base) {}

    bool m_bForceRecreateNextUpdate() { return read<bool>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_bForceRecreateNextUpdate")); }
    bool m_bMoveViewToPlayerNextThink() { return read<bool>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_bMoveViewToPlayerNextThink")); }
    bool m_bCheckCSSClasses() { return read<bool>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_bCheckCSSClasses")); }
    uintptr_t m_anchorDeltaTransform() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_anchorDeltaTransform")); }
    CPointOffScreenIndicatorUi* m_pOffScreenIndicator() { return read<CPointOffScreenIndicatorUi*>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_pOffScreenIndicator")); }
    bool m_bIgnoreInput() { return read<bool>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_bIgnoreInput")); }
    bool m_bLit() { return read<bool>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_bLit")); }
    bool m_bFollowPlayerAcrossTeleport() { return read<bool>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_bFollowPlayerAcrossTeleport")); }
    float m_flWidth() { return read<float>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_flWidth")); }
    float m_flHeight() { return read<float>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_flHeight")); }
    float m_flDPI() { return read<float>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_flDPI")); }
    float m_flInteractDistance() { return read<float>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_flInteractDistance")); }
    float m_flDepthOffset() { return read<float>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_flDepthOffset")); }
    int m_unOwnerContext() { return read<int>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_unOwnerContext")); }
    int m_unHorizontalAlign() { return read<int>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_unHorizontalAlign")); }
    int m_unVerticalAlign() { return read<int>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_unVerticalAlign")); }
    int m_unOrientation() { return read<int>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_unOrientation")); }
    bool m_bAllowInteractionFromAllSceneWorlds() { return read<bool>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_bAllowInteractionFromAllSceneWorlds")); }
    Vector3 m_vecCSSClasses() { return read<Vector3>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_vecCSSClasses")); }
    bool m_bOpaque() { return read<bool>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_bOpaque")); }
    bool m_bNoDepth() { return read<bool>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_bNoDepth")); }
    bool m_bVisibleWhenParentNoDraw() { return read<bool>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_bVisibleWhenParentNoDraw")); }
    bool m_bRenderBackface() { return read<bool>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_bRenderBackface")); }
    bool m_bUseOffScreenIndicator() { return read<bool>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_bUseOffScreenIndicator")); }
    bool m_bExcludeFromSaveGames() { return read<bool>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_bExcludeFromSaveGames")); }
    bool m_bGrabbable() { return read<bool>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_bGrabbable")); }
    bool m_bOnlyRenderToTexture() { return read<bool>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_bOnlyRenderToTexture")); }
    bool m_bDisableMipGen() { return read<bool>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_bDisableMipGen")); }
    int m_nExplicitImageLayout() { return read<int>(baseAddr + offsets_instance.get("C_PointClientUIWorldPanel", "m_nExplicitImageLayout")); }
};
