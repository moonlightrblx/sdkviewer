#pragma once
#include "../memory.h"

class CPulseCell_Step_DebugLog  {
public:
    uintptr_t baseAddr;

    CPulseCell_Step_DebugLog() { baseAddr = client_base(); }
    CPulseCell_Step_DebugLog(uintptr_t base) : baseAddr(base) {}

};
