#pragma once
#include "../memory.h"

class C_WeaponMAC10  {
public:
    uintptr_t baseAddr;

    C_WeaponMAC10() { baseAddr = client_base(); }
    C_WeaponMAC10(uintptr_t base) : baseAddr(base) {}

};
