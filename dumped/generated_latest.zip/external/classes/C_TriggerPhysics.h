#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_TriggerPhysics  {
public:
    uintptr_t baseAddr;

    C_TriggerPhysics() { baseAddr = 0; }
    C_TriggerPhysics(uintptr_t base) : baseAddr(base) {}

    float m_gravityScale() { return read<float>(baseAddr + offsets_instance.get("C_TriggerPhysics", "m_gravityScale")); }
    float m_linearLimit() { return read<float>(baseAddr + offsets_instance.get("C_TriggerPhysics", "m_linearLimit")); }
    float m_linearDamping() { return read<float>(baseAddr + offsets_instance.get("C_TriggerPhysics", "m_linearDamping")); }
    float m_angularLimit() { return read<float>(baseAddr + offsets_instance.get("C_TriggerPhysics", "m_angularLimit")); }
    float m_angularDamping() { return read<float>(baseAddr + offsets_instance.get("C_TriggerPhysics", "m_angularDamping")); }
    float m_linearForce() { return read<float>(baseAddr + offsets_instance.get("C_TriggerPhysics", "m_linearForce")); }
    float m_flFrequency() { return read<float>(baseAddr + offsets_instance.get("C_TriggerPhysics", "m_flFrequency")); }
    float m_flDampingRatio() { return read<float>(baseAddr + offsets_instance.get("C_TriggerPhysics", "m_flDampingRatio")); }
    Vector3 m_vecLinearForcePointAt() { return read<Vector3>(baseAddr + offsets_instance.get("C_TriggerPhysics", "m_vecLinearForcePointAt")); }
    bool m_bCollapseToForcePoint() { return read<bool>(baseAddr + offsets_instance.get("C_TriggerPhysics", "m_bCollapseToForcePoint")); }
    Vector3 m_vecLinearForcePointAtWorld() { return read<Vector3>(baseAddr + offsets_instance.get("C_TriggerPhysics", "m_vecLinearForcePointAtWorld")); }
    Vector3 m_vecLinearForceDirection() { return read<Vector3>(baseAddr + offsets_instance.get("C_TriggerPhysics", "m_vecLinearForceDirection")); }
    bool m_bConvertToDebrisWhenPossible() { return read<bool>(baseAddr + offsets_instance.get("C_TriggerPhysics", "m_bConvertToDebrisWhenPossible")); }
};
