#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_EnvWindShared  {
public:
    uintptr_t baseAddr;

    C_EnvWindShared() { baseAddr = client_base(); }
    C_EnvWindShared(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_flStartTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvWindShared", "m_flStartTime")); }
    int m_iWindSeed() { return read<int>(baseAddr + offsets_instance.get("C_EnvWindShared", "m_iWindSeed")); }
    uint16_t m_iMinWind() { return read<uint16_t>(baseAddr + offsets_instance.get("C_EnvWindShared", "m_iMinWind")); }
    uint16_t m_iMaxWind() { return read<uint16_t>(baseAddr + offsets_instance.get("C_EnvWindShared", "m_iMaxWind")); }
    int m_windRadius() { return read<int>(baseAddr + offsets_instance.get("C_EnvWindShared", "m_windRadius")); }
    uint16_t m_iMinGust() { return read<uint16_t>(baseAddr + offsets_instance.get("C_EnvWindShared", "m_iMinGust")); }
    uint16_t m_iMaxGust() { return read<uint16_t>(baseAddr + offsets_instance.get("C_EnvWindShared", "m_iMaxGust")); }
    float m_flMinGustDelay() { return read<float>(baseAddr + offsets_instance.get("C_EnvWindShared", "m_flMinGustDelay")); }
    float m_flMaxGustDelay() { return read<float>(baseAddr + offsets_instance.get("C_EnvWindShared", "m_flMaxGustDelay")); }
    float m_flGustDuration() { return read<float>(baseAddr + offsets_instance.get("C_EnvWindShared", "m_flGustDuration")); }
    uint16_t m_iGustDirChange() { return read<uint16_t>(baseAddr + offsets_instance.get("C_EnvWindShared", "m_iGustDirChange")); }
    uint16_t m_iInitialWindDir() { return read<uint16_t>(baseAddr + offsets_instance.get("C_EnvWindShared", "m_iInitialWindDir")); }
    float m_flInitialWindSpeed() { return read<float>(baseAddr + offsets_instance.get("C_EnvWindShared", "m_flInitialWindSpeed")); }
    Vector3 m_location() { return read<Vector3>(baseAddr + offsets_instance.get("C_EnvWindShared", "m_location")); }
    C_BaseEntity* m_hEntOwner() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_EnvWindShared", "m_hEntOwner")); }
};
