#pragma once
#include "../memory.h"

class CFilterModel  {
public:
    uintptr_t baseAddr;

    CFilterModel() { baseAddr = 0; }
    CFilterModel(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_iFilterModel() { return read<uintptr_t>(baseAddr + offsets_instance.get("CFilterModel", "m_iFilterModel")); }
};
