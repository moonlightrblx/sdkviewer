#pragma once
#include "../memory.h"
#include "../classes/CEntityIOOutput.h"
#include "../types/Vector3.h"
class CBaseFilter;

class C_BaseTrigger  {
public:
    uintptr_t baseAddr;

    C_BaseTrigger() { baseAddr = 0; }
    C_BaseTrigger(uintptr_t base) : baseAddr(base) {}

    CEntityIOOutput m_OnStartTouch() { return read<CEntityIOOutput>(baseAddr + offsets_instance.get("C_BaseTrigger", "m_OnStartTouch")); }
    CEntityIOOutput m_OnStartTouchAll() { return read<CEntityIOOutput>(baseAddr + offsets_instance.get("C_BaseTrigger", "m_OnStartTouchAll")); }
    CEntityIOOutput m_OnEndTouch() { return read<CEntityIOOutput>(baseAddr + offsets_instance.get("C_BaseTrigger", "m_OnEndTouch")); }
    CEntityIOOutput m_OnEndTouchAll() { return read<CEntityIOOutput>(baseAddr + offsets_instance.get("C_BaseTrigger", "m_OnEndTouchAll")); }
    CEntityIOOutput m_OnTouching() { return read<CEntityIOOutput>(baseAddr + offsets_instance.get("C_BaseTrigger", "m_OnTouching")); }
    CEntityIOOutput m_OnTouchingEachEntity() { return read<CEntityIOOutput>(baseAddr + offsets_instance.get("C_BaseTrigger", "m_OnTouchingEachEntity")); }
    CEntityIOOutput m_OnNotTouching() { return read<CEntityIOOutput>(baseAddr + offsets_instance.get("C_BaseTrigger", "m_OnNotTouching")); }
    Vector3 m_hTouchingEntities() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseTrigger", "m_hTouchingEntities")); }
    uintptr_t m_iFilterName() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseTrigger", "m_iFilterName")); }
    CBaseFilter* m_hFilter() { return read<CBaseFilter*>(baseAddr + offsets_instance.get("C_BaseTrigger", "m_hFilter")); }
    bool m_bDisabled() { return read<bool>(baseAddr + offsets_instance.get("C_BaseTrigger", "m_bDisabled")); }
};
