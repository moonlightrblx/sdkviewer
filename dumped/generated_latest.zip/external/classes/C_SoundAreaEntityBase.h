#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_SoundAreaEntityBase  {
public:
    uintptr_t baseAddr;

    C_SoundAreaEntityBase() { baseAddr = client_base(); }
    C_SoundAreaEntityBase(uintptr_t base) : baseAddr(base) {}

    bool m_bDisabled() { return read<bool>(baseAddr + offsets_instance.get("C_SoundAreaEntityBase", "m_bDisabled")); }
    bool m_bWasEnabled() { return read<bool>(baseAddr + offsets_instance.get("C_SoundAreaEntityBase", "m_bWasEnabled")); }
    uintptr_t m_iszSoundAreaType() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_SoundAreaEntityBase", "m_iszSoundAreaType")); }
    Vector3 m_vPos() { return read<Vector3>(baseAddr + offsets_instance.get("C_SoundAreaEntityBase", "m_vPos")); }
};
