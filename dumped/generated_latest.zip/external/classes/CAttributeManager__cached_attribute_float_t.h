#pragma once
#include "../memory.h"

class CAttributeManager__cached_attribute_float_t  {
public:
    uintptr_t baseAddr;

    CAttributeManager__cached_attribute_float_t() { baseAddr = client_base(); }
    CAttributeManager__cached_attribute_float_t(uintptr_t base) : baseAddr(base) {}

    float flIn() { return read<float>(baseAddr + offsets_instance.get("CAttributeManager__cached_attribute_float_t", "flIn")); }
    uintptr_t iAttribHook() { return read<uintptr_t>(baseAddr + offsets_instance.get("CAttributeManager__cached_attribute_float_t", "iAttribHook")); }
    float flOut() { return read<float>(baseAddr + offsets_instance.get("CAttributeManager__cached_attribute_float_t", "flOut")); }
};
