#pragma once
#include "../memory.h"
#include "../classes/GameTime_t.h"
#include "../types/Vector3.h"
class C_BaseEntity;

class C_PointValueRemapper  {
public:
    uintptr_t baseAddr;

    C_PointValueRemapper() { baseAddr = 0; }
    C_PointValueRemapper(uintptr_t base) : baseAddr(base) {}

    bool m_bDisabled() { return read<bool>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_bDisabled")); }
    bool m_bDisabledOld() { return read<bool>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_bDisabledOld")); }
    bool m_bUpdateOnClient() { return read<bool>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_bUpdateOnClient")); }
    uintptr_t m_nInputType() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_nInputType")); }
    C_BaseEntity* m_hRemapLineStart() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_hRemapLineStart")); }
    C_BaseEntity* m_hRemapLineEnd() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_hRemapLineEnd")); }
    float m_flMaximumChangePerSecond() { return read<float>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_flMaximumChangePerSecond")); }
    float m_flDisengageDistance() { return read<float>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_flDisengageDistance")); }
    float m_flEngageDistance() { return read<float>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_flEngageDistance")); }
    bool m_bRequiresUseKey() { return read<bool>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_bRequiresUseKey")); }
    uintptr_t m_nOutputType() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_nOutputType")); }
    Vector3 m_hOutputEntities() { return read<Vector3>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_hOutputEntities")); }
    uintptr_t m_nHapticsType() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_nHapticsType")); }
    uintptr_t m_nMomentumType() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_nMomentumType")); }
    float m_flMomentumModifier() { return read<float>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_flMomentumModifier")); }
    float m_flSnapValue() { return read<float>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_flSnapValue")); }
    float m_flCurrentMomentum() { return read<float>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_flCurrentMomentum")); }
    uintptr_t m_nRatchetType() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_nRatchetType")); }
    float m_flRatchetOffset() { return read<float>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_flRatchetOffset")); }
    float m_flInputOffset() { return read<float>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_flInputOffset")); }
    bool m_bEngaged() { return read<bool>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_bEngaged")); }
    bool m_bFirstUpdate() { return read<bool>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_bFirstUpdate")); }
    float m_flPreviousValue() { return read<float>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_flPreviousValue")); }
    GameTime_t m_flPreviousUpdateTickTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_flPreviousUpdateTickTime")); }
    Vector3 m_vecPreviousTestPoint() { return read<Vector3>(baseAddr + offsets_instance.get("C_PointValueRemapper", "m_vecPreviousTestPoint")); }
};
