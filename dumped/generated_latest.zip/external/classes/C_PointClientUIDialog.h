#pragma once
#include "../memory.h"
class C_BaseEntity;

class C_PointClientUIDialog  {
public:
    uintptr_t baseAddr;

    C_PointClientUIDialog() { baseAddr = 0; }
    C_PointClientUIDialog(uintptr_t base) : baseAddr(base) {}

    C_BaseEntity* m_hActivator() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_PointClientUIDialog", "m_hActivator")); }
    bool m_bStartEnabled() { return read<bool>(baseAddr + offsets_instance.get("C_PointClientUIDialog", "m_bStartEnabled")); }
};
