#pragma once
#include "../memory.h"

class CPulseCursorFuncs  {
public:
    uintptr_t baseAddr;

    CPulseCursorFuncs() { baseAddr = client_base(); }
    CPulseCursorFuncs(uintptr_t base) : baseAddr(base) {}

};
