#pragma once
#include "../memory.h"
#include "../classes/CPulse_ResumePoint.h"

class CPulseCell_WaitForCursorsWithTagBase  {
public:
    uintptr_t baseAddr;

    CPulseCell_WaitForCursorsWithTagBase() { baseAddr = 0; }
    CPulseCell_WaitForCursorsWithTagBase(uintptr_t base) : baseAddr(base) {}

    int m_nCursorsAllowedToWait() { return read<int>(baseAddr + offsets_instance.get("CPulseCell_WaitForCursorsWithTagBase", "m_nCursorsAllowedToWait")); }
    CPulse_ResumePoint m_WaitComplete() { return read<CPulse_ResumePoint>(baseAddr + offsets_instance.get("CPulseCell_WaitForCursorsWithTagBase", "m_WaitComplete")); }
};
