#pragma once
#include "../memory.h"

class C_BaseCombatCharacter {
public:
 uintptr_t baseAddr;
 C_BaseCombatCharacter() : baseAddr(0){}
 C_BaseCombatCharacter(uintptr_t b):baseAddr(b){}
 uintptr_t m_hMyWearables(){return SCHEMA_TYPE(uintptr_t,0x1368);}
 uintptr_t m_leftFootAttachment(){return SCHEMA_TYPE(uintptr_t,0x1380);}
 uintptr_t m_rightFootAttachment(){return SCHEMA_TYPE(uintptr_t,0x1381);}
 uintptr_t m_nWaterWakeMode(){return SCHEMA_TYPE(uintptr_t,0x1384);}
 uintptr_t m_flWaterWorldZ(){return SCHEMA_TYPE(uintptr_t,0x1388);}
 uintptr_t m_flWaterNextTraceTime(){return SCHEMA_TYPE(uintptr_t,0x138C);}
};
