#pragma once
#include "../memory.h"

class C_BaseClientUIEntity  {
public:
    uintptr_t baseAddr;

    C_BaseClientUIEntity() { baseAddr = 0; }
    C_BaseClientUIEntity(uintptr_t base) : baseAddr(base) {}

    bool m_bEnabled() { return read<bool>(baseAddr + offsets_instance.get("C_BaseClientUIEntity", "m_bEnabled")); }
    uintptr_t m_DialogXMLName() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseClientUIEntity", "m_DialogXMLName")); }
    uintptr_t m_PanelClassName() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseClientUIEntity", "m_PanelClassName")); }
    uintptr_t m_PanelID() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseClientUIEntity", "m_PanelID")); }
};
