#pragma once
#include "../memory.h"

class C_Hostage {
public:
 uintptr_t baseAddr;
 C_Hostage() : baseAddr(0){}
 C_Hostage(uintptr_t b):baseAddr(b){}
 uintptr_t m_entitySpottedState(){return SCHEMA_TYPE(uintptr_t,0x13F0);}
 uintptr_t m_leader(){return SCHEMA_TYPE(uintptr_t,0x1408);}
 uintptr_t m_reuseTimer(){return SCHEMA_TYPE(uintptr_t,0x1410);}
 uintptr_t m_vel(){return SCHEMA_TYPE(uintptr_t,0x1428);}
 uintptr_t m_isRescued(){return SCHEMA_TYPE(uintptr_t,0x1434);}
 uintptr_t m_jumpedThisFrame(){return SCHEMA_TYPE(uintptr_t,0x1435);}
 uintptr_t m_nHostageState(){return SCHEMA_TYPE(uintptr_t,0x1438);}
 uintptr_t m_bHandsHaveBeenCut(){return SCHEMA_TYPE(uintptr_t,0x143C);}
 uintptr_t m_hHostageGrabber(){return SCHEMA_TYPE(uintptr_t,0x1440);}
 uintptr_t m_fLastGrabTime(){return SCHEMA_TYPE(uintptr_t,0x1444);}
 uintptr_t m_vecGrabbedPos(){return SCHEMA_TYPE(uintptr_t,0x1448);}
 uintptr_t m_flRescueStartTime(){return SCHEMA_TYPE(uintptr_t,0x1454);}
 uintptr_t m_flGrabSuccessTime(){return SCHEMA_TYPE(uintptr_t,0x1458);}
 uintptr_t m_flDropStartTime(){return SCHEMA_TYPE(uintptr_t,0x145C);}
 uintptr_t m_flDeadOrRescuedTime(){return SCHEMA_TYPE(uintptr_t,0x1460);}
 uintptr_t m_blinkTimer(){return SCHEMA_TYPE(uintptr_t,0x1468);}
 uintptr_t m_lookAt(){return SCHEMA_TYPE(uintptr_t,0x1480);}
 uintptr_t m_lookAroundTimer(){return SCHEMA_TYPE(uintptr_t,0x1490);}
 uintptr_t m_isInit(){return SCHEMA_TYPE(uintptr_t,0x14A8);}
 uintptr_t m_eyeAttachment(){return SCHEMA_TYPE(uintptr_t,0x14A9);}
 uintptr_t m_chestAttachment(){return SCHEMA_TYPE(uintptr_t,0x14AA);}
 uintptr_t m_pPredictionOwner(){return SCHEMA_TYPE(uintptr_t,0x14B0);}
 uintptr_t m_fNewestAlphaThinkTime(){return SCHEMA_TYPE(uintptr_t,0x14B8);}
};
