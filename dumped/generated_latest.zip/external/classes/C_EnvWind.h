#pragma once
#include "../memory.h"

class C_EnvWind  {
public:
    uintptr_t baseAddr;

    C_EnvWind() { baseAddr = client_base(); }
    C_EnvWind(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_EnvWindShared() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvWind", "m_EnvWindShared")); }
};
