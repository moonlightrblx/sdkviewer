#pragma once
#include "../memory.h"

class C_BasePlayerWeapon {
public:
 uintptr_t baseAddr;
 C_BasePlayerWeapon() : baseAddr(0){}
 C_BasePlayerWeapon(uintptr_t b):baseAddr(b){}
 uintptr_t m_nNextPrimaryAttackTick(){return SCHEMA_TYPE(uintptr_t,0x18E0);}
 uintptr_t m_flNextPrimaryAttackTickRatio(){return SCHEMA_TYPE(uintptr_t,0x18E4);}
 uintptr_t m_nNextSecondaryAttackTick(){return SCHEMA_TYPE(uintptr_t,0x18E8);}
 uintptr_t m_flNextSecondaryAttackTickRatio(){return SCHEMA_TYPE(uintptr_t,0x18EC);}
 uintptr_t m_iClip1(){return SCHEMA_TYPE(uintptr_t,0x18F0);}
 uintptr_t m_iClip2(){return SCHEMA_TYPE(uintptr_t,0x18F4);}
 uintptr_t m_pReserveAmmo(){return SCHEMA_TYPE(uintptr_t,0x18F8);}
};
