#pragma once
#include "../memory.h"

class C_CSGameRulesProxy {
public:
 uintptr_t baseAddr;
 C_CSGameRulesProxy() : baseAddr(0){}
 C_CSGameRulesProxy(uintptr_t b):baseAddr(b){}
 uintptr_t m_pGameRules(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
};
