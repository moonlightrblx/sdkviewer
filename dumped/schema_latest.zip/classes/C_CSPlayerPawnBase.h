#pragma once
#include "../memory.h"

class C_CSPlayerPawnBase {
public:
 uintptr_t baseAddr;
 C_CSPlayerPawnBase() : baseAddr(0){}
 C_CSPlayerPawnBase(uintptr_t b):baseAddr(b){}
 uintptr_t m_pPingServices(){return SCHEMA_TYPE(uintptr_t,0x15D8);}
 uintptr_t m_previousPlayerState(){return SCHEMA_TYPE(uintptr_t,0x15E0);}
 uintptr_t m_iPlayerState(){return SCHEMA_TYPE(uintptr_t,0x15E4);}
 uintptr_t m_bHasMovedSinceSpawn(){return SCHEMA_TYPE(uintptr_t,0x15E8);}
 uintptr_t m_flLastSpawnTimeIndex(){return SCHEMA_TYPE(uintptr_t,0x15EC);}
 uintptr_t m_iProgressBarDuration(){return SCHEMA_TYPE(uintptr_t,0x15F0);}
 uintptr_t m_flProgressBarStartTime(){return SCHEMA_TYPE(uintptr_t,0x15F4);}
 uintptr_t m_flClientDeathTime(){return SCHEMA_TYPE(uintptr_t,0x15F8);}
 uintptr_t m_flFlashBangTime(){return SCHEMA_TYPE(uintptr_t,0x15FC);}
 uintptr_t m_flFlashScreenshotAlpha(){return SCHEMA_TYPE(uintptr_t,0x1600);}
 uintptr_t m_flFlashOverlayAlpha(){return SCHEMA_TYPE(uintptr_t,0x1604);}
 uintptr_t m_bFlashBuildUp(){return SCHEMA_TYPE(uintptr_t,0x1608);}
 uintptr_t m_bFlashDspHasBeenCleared(){return SCHEMA_TYPE(uintptr_t,0x1609);}
 uintptr_t m_bFlashScreenshotHasBeenGrabbed(){return SCHEMA_TYPE(uintptr_t,0x160A);}
 uintptr_t m_flFlashMaxAlpha(){return SCHEMA_TYPE(uintptr_t,0x160C);}
 uintptr_t m_flFlashDuration(){return SCHEMA_TYPE(uintptr_t,0x1610);}
 uintptr_t m_flClientHealthFadeChangeTimestamp(){return SCHEMA_TYPE(uintptr_t,0x1614);}
 uintptr_t m_nClientHealthFadeParityValue(){return SCHEMA_TYPE(uintptr_t,0x1618);}
 uintptr_t m_fNextThinkPushAway(){return SCHEMA_TYPE(uintptr_t,0x161C);}
 uintptr_t m_flCurrentMusicStartTime(){return SCHEMA_TYPE(uintptr_t,0x1624);}
 uintptr_t m_flMusicRoundStartTime(){return SCHEMA_TYPE(uintptr_t,0x1628);}
 uintptr_t m_bDeferStartMusicOnWarmup(){return SCHEMA_TYPE(uintptr_t,0x162C);}
 uintptr_t m_flLastSmokeOverlayAlpha(){return SCHEMA_TYPE(uintptr_t,0x1630);}
 uintptr_t m_flLastSmokeAge(){return SCHEMA_TYPE(uintptr_t,0x1634);}
 uintptr_t m_vLastSmokeOverlayColor(){return SCHEMA_TYPE(uintptr_t,0x1638);}
 uintptr_t m_hOriginalController(){return SCHEMA_TYPE(uintptr_t,0x1660);}
};
