#pragma once
#include "../memory.h"

class CEntityIdentity {
public:
 uintptr_t baseAddr;
 CEntityIdentity() : baseAddr(0){}
 CEntityIdentity(uintptr_t b):baseAddr(b){}
 uintptr_t m_nameStringableIndex(){return SCHEMA_TYPE(uintptr_t,0x14);}
 uintptr_t m_name(){return SCHEMA_TYPE(uintptr_t,0x18);}
 uintptr_t m_designerName(){return SCHEMA_TYPE(uintptr_t,0x20);}
 uintptr_t m_flags(){return SCHEMA_TYPE(uintptr_t,0x30);}
 uintptr_t m_worldGroupId(){return SCHEMA_TYPE(uintptr_t,0x38);}
 uintptr_t m_fDataObjectTypes(){return SCHEMA_TYPE(uintptr_t,0x3C);}
 uintptr_t m_PathIndex(){return SCHEMA_TYPE(uintptr_t,0x40);}
 uintptr_t m_pPrev(){return SCHEMA_TYPE(uintptr_t,0x50);}
 uintptr_t m_pNext(){return SCHEMA_TYPE(uintptr_t,0x58);}
 uintptr_t m_pPrevByClass(){return SCHEMA_TYPE(uintptr_t,0x60);}
 uintptr_t m_pNextByClass(){return SCHEMA_TYPE(uintptr_t,0x68);}
};
