#pragma once
#include "../memory.h"

class C_PointValueRemapper {
public:
 uintptr_t baseAddr;
 C_PointValueRemapper() : baseAddr(0){}
 C_PointValueRemapper(uintptr_t b):baseAddr(b){}
 uintptr_t m_bDisabled(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_bDisabledOld(){return SCHEMA_TYPE(uintptr_t,0x5F9);}
 uintptr_t m_bUpdateOnClient(){return SCHEMA_TYPE(uintptr_t,0x5FA);}
 uintptr_t m_nInputType(){return SCHEMA_TYPE(uintptr_t,0x5FC);}
 uintptr_t m_hRemapLineStart(){return SCHEMA_TYPE(uintptr_t,0x600);}
 uintptr_t m_hRemapLineEnd(){return SCHEMA_TYPE(uintptr_t,0x604);}
 uintptr_t m_flMaximumChangePerSecond(){return SCHEMA_TYPE(uintptr_t,0x608);}
 uintptr_t m_flDisengageDistance(){return SCHEMA_TYPE(uintptr_t,0x60C);}
 uintptr_t m_flEngageDistance(){return SCHEMA_TYPE(uintptr_t,0x610);}
 uintptr_t m_bRequiresUseKey(){return SCHEMA_TYPE(uintptr_t,0x614);}
 uintptr_t m_nOutputType(){return SCHEMA_TYPE(uintptr_t,0x618);}
 uintptr_t m_hOutputEntities(){return SCHEMA_TYPE(uintptr_t,0x620);}
 uintptr_t m_nHapticsType(){return SCHEMA_TYPE(uintptr_t,0x638);}
 uintptr_t m_nMomentumType(){return SCHEMA_TYPE(uintptr_t,0x63C);}
 uintptr_t m_flMomentumModifier(){return SCHEMA_TYPE(uintptr_t,0x640);}
 uintptr_t m_flSnapValue(){return SCHEMA_TYPE(uintptr_t,0x644);}
 uintptr_t m_flCurrentMomentum(){return SCHEMA_TYPE(uintptr_t,0x648);}
 uintptr_t m_nRatchetType(){return SCHEMA_TYPE(uintptr_t,0x64C);}
 uintptr_t m_flRatchetOffset(){return SCHEMA_TYPE(uintptr_t,0x650);}
 uintptr_t m_flInputOffset(){return SCHEMA_TYPE(uintptr_t,0x654);}
 uintptr_t m_bEngaged(){return SCHEMA_TYPE(uintptr_t,0x658);}
 uintptr_t m_bFirstUpdate(){return SCHEMA_TYPE(uintptr_t,0x659);}
 uintptr_t m_flPreviousValue(){return SCHEMA_TYPE(uintptr_t,0x65C);}
 uintptr_t m_flPreviousUpdateTickTime(){return SCHEMA_TYPE(uintptr_t,0x660);}
 uintptr_t m_vecPreviousTestPoint(){return SCHEMA_TYPE(uintptr_t,0x664);}
};
