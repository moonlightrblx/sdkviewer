#pragma once
#include "../memory.h"

class CSPerRoundStats_t  {
public:
    uintptr_t baseAddr;

    CSPerRoundStats_t() { baseAddr = client_base(); }
    CSPerRoundStats_t(uintptr_t base) : baseAddr(base) {}

    int m_iKills() { return read<int>(baseAddr + offsets_instance.get("CSPerRoundStats_t", "m_iKills")); }
    int m_iDeaths() { return read<int>(baseAddr + offsets_instance.get("CSPerRoundStats_t", "m_iDeaths")); }
    int m_iAssists() { return read<int>(baseAddr + offsets_instance.get("CSPerRoundStats_t", "m_iAssists")); }
    int m_iDamage() { return read<int>(baseAddr + offsets_instance.get("CSPerRoundStats_t", "m_iDamage")); }
    int m_iEquipmentValue() { return read<int>(baseAddr + offsets_instance.get("CSPerRoundStats_t", "m_iEquipmentValue")); }
    int m_iMoneySaved() { return read<int>(baseAddr + offsets_instance.get("CSPerRoundStats_t", "m_iMoneySaved")); }
    int m_iKillReward() { return read<int>(baseAddr + offsets_instance.get("CSPerRoundStats_t", "m_iKillReward")); }
    int m_iLiveTime() { return read<int>(baseAddr + offsets_instance.get("CSPerRoundStats_t", "m_iLiveTime")); }
    int m_iHeadShotKills() { return read<int>(baseAddr + offsets_instance.get("CSPerRoundStats_t", "m_iHeadShotKills")); }
    int m_iObjective() { return read<int>(baseAddr + offsets_instance.get("CSPerRoundStats_t", "m_iObjective")); }
    int m_iCashEarned() { return read<int>(baseAddr + offsets_instance.get("CSPerRoundStats_t", "m_iCashEarned")); }
    int m_iUtilityDamage() { return read<int>(baseAddr + offsets_instance.get("CSPerRoundStats_t", "m_iUtilityDamage")); }
    int m_iEnemiesFlashed() { return read<int>(baseAddr + offsets_instance.get("CSPerRoundStats_t", "m_iEnemiesFlashed")); }
};
