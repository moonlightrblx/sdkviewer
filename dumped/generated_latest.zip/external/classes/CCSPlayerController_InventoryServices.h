#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class CCSPlayerController_InventoryServices  {
public:
    uintptr_t baseAddr;

    CCSPlayerController_InventoryServices() { baseAddr = client_base(); }
    CCSPlayerController_InventoryServices(uintptr_t base) : baseAddr(base) {}

    Vector3 m_vecNetworkableLoadout() { return read<Vector3>(baseAddr + offsets_instance.get("CCSPlayerController_InventoryServices", "m_vecNetworkableLoadout")); }
    uint16_t m_unMusicID() { return read<uint16_t>(baseAddr + offsets_instance.get("CCSPlayerController_InventoryServices", "m_unMusicID")); }
    uintptr_t m_rank() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSPlayerController_InventoryServices", "m_rank")); }
    int m_nPersonaDataPublicLevel() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController_InventoryServices", "m_nPersonaDataPublicLevel")); }
    int m_nPersonaDataPublicCommendsLeader() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController_InventoryServices", "m_nPersonaDataPublicCommendsLeader")); }
    int m_nPersonaDataPublicCommendsTeacher() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController_InventoryServices", "m_nPersonaDataPublicCommendsTeacher")); }
    int m_nPersonaDataPublicCommendsFriendly() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController_InventoryServices", "m_nPersonaDataPublicCommendsFriendly")); }
    int m_nPersonaDataXpTrailLevel() { return read<int>(baseAddr + offsets_instance.get("CCSPlayerController_InventoryServices", "m_nPersonaDataXpTrailLevel")); }
    Vector3 m_vecServerAuthoritativeWeaponSlots() { return read<Vector3>(baseAddr + offsets_instance.get("CCSPlayerController_InventoryServices", "m_vecServerAuthoritativeWeaponSlots")); }
};
