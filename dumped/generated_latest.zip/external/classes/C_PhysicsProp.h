#pragma once
#include "../memory.h"

class C_PhysicsProp  {
public:
    uintptr_t baseAddr;

    C_PhysicsProp() { baseAddr = 0; }
    C_PhysicsProp(uintptr_t base) : baseAddr(base) {}

    bool m_bAwake() { return read<bool>(baseAddr + offsets_instance.get("C_PhysicsProp", "m_bAwake")); }
};
