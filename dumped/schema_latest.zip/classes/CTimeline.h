#pragma once
#include "../memory.h"

class CTimeline {
public:
 uintptr_t baseAddr;
 CTimeline() : baseAddr(0){}
 CTimeline(uintptr_t b):baseAddr(b){}
 uintptr_t m_flValues(){return SCHEMA_TYPE(uintptr_t,0x10);}
 uintptr_t m_nValueCounts(){return SCHEMA_TYPE(uintptr_t,0x110);}
 uintptr_t m_nBucketCount(){return SCHEMA_TYPE(uintptr_t,0x210);}
 uintptr_t m_flInterval(){return SCHEMA_TYPE(uintptr_t,0x214);}
 uintptr_t m_flFinalValue(){return SCHEMA_TYPE(uintptr_t,0x218);}
 uintptr_t m_nCompressionType(){return SCHEMA_TYPE(uintptr_t,0x21C);}
 uintptr_t m_bStopped(){return SCHEMA_TYPE(uintptr_t,0x220);}
};
