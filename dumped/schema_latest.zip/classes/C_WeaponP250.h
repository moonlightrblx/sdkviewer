#pragma once
#include "../memory.h"

class C_WeaponP250 {
public:
 uintptr_t baseAddr;
 C_WeaponP250() : baseAddr(0){}
 C_WeaponP250(uintptr_t b):baseAddr(b){}
};
