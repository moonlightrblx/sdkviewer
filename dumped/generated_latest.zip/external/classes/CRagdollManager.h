#pragma once
#include "../memory.h"

class CRagdollManager  {
public:
    uintptr_t baseAddr;

    CRagdollManager() { baseAddr = 0; }
    CRagdollManager(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_iCurrentMaxRagdollCount() { return read<uintptr_t>(baseAddr + offsets_instance.get("CRagdollManager", "m_iCurrentMaxRagdollCount")); }
};
