#pragma once
#include "../memory.h"

class CFilterMassGreater  {
public:
    uintptr_t baseAddr;

    CFilterMassGreater() { baseAddr = client_base(); }
    CFilterMassGreater(uintptr_t base) : baseAddr(base) {}

    float m_fFilterMass() { return read<float>(baseAddr + offsets_instance.get("CFilterMassGreater", "m_fFilterMass")); }
};
