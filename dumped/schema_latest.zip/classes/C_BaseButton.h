#pragma once
#include "../memory.h"

class C_BaseButton {
public:
 uintptr_t baseAddr;
 C_BaseButton() : baseAddr(0){}
 C_BaseButton(uintptr_t b):baseAddr(b){}
 uintptr_t m_glowEntity(){return SCHEMA_TYPE(uintptr_t,0xEB0);}
 uintptr_t m_usable(){return SCHEMA_TYPE(uintptr_t,0xEB4);}
 uintptr_t m_szDisplayText(){return SCHEMA_TYPE(uintptr_t,0xEB8);}
};
