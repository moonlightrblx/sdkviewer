#pragma once
#include "../memory.h"

class C_CSGO_CounterTerroristWingmanIntroCamera  {
public:
    uintptr_t baseAddr;

    C_CSGO_CounterTerroristWingmanIntroCamera() { baseAddr = client_base(); }
    C_CSGO_CounterTerroristWingmanIntroCamera(uintptr_t base) : baseAddr(base) {}

};
