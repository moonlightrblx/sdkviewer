#pragma once
#include "../memory.h"

class CBasePlayerController {
public:
 uintptr_t baseAddr;
 CBasePlayerController() : baseAddr(0){}
 CBasePlayerController(uintptr_t b):baseAddr(b){}
 uintptr_t m_CommandContext(){return SCHEMA_TYPE(uintptr_t,0x600);}
 uintptr_t m_nInButtonsWhichAreToggles(){return SCHEMA_TYPE(uintptr_t,0x6A8);}
 uintptr_t m_nTickBase(){return SCHEMA_TYPE(uintptr_t,0x6B0);}
 uintptr_t m_hPawn(){return SCHEMA_TYPE(uintptr_t,0x6B4);}
 uintptr_t m_bKnownTeamMismatch(){return SCHEMA_TYPE(uintptr_t,0x6B8);}
 uintptr_t m_hPredictedPawn(){return SCHEMA_TYPE(uintptr_t,0x6BC);}
 uintptr_t m_nSplitScreenSlot(){return SCHEMA_TYPE(uintptr_t,0x6C0);}
 uintptr_t m_hSplitOwner(){return SCHEMA_TYPE(uintptr_t,0x6C4);}
 uintptr_t m_hSplitScreenPlayers(){return SCHEMA_TYPE(uintptr_t,0x6C8);}
 uintptr_t m_bIsHLTV(){return SCHEMA_TYPE(uintptr_t,0x6E0);}
 uintptr_t m_iConnected(){return SCHEMA_TYPE(uintptr_t,0x6E4);}
 uintptr_t m_iszPlayerName(){return SCHEMA_TYPE(uintptr_t,0x6E8);}
 uintptr_t m_steamID(){return SCHEMA_TYPE(uintptr_t,0x770);}
 uintptr_t m_bIsLocalPlayerController(){return SCHEMA_TYPE(uintptr_t,0x778);}
 uintptr_t m_bNoClipEnabled(){return SCHEMA_TYPE(uintptr_t,0x779);}
 uintptr_t m_iDesiredFOV(){return SCHEMA_TYPE(uintptr_t,0x77C);}
};
