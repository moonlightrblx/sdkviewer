#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class CCSWeaponBaseVData  {
public:
    uintptr_t baseAddr;

    CCSWeaponBaseVData() { baseAddr = 0; }
    CCSWeaponBaseVData(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_WeaponType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_WeaponType")); }
    uintptr_t m_WeaponCategory() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_WeaponCategory")); }
    uintptr_t m_szModel_AG2() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_szModel_AG2")); }
    uintptr_t m_szAnimSkeleton() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_szAnimSkeleton")); }
    Vector3 m_vecMuzzlePos0() { return read<Vector3>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_vecMuzzlePos0")); }
    Vector3 m_vecMuzzlePos1() { return read<Vector3>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_vecMuzzlePos1")); }
    uintptr_t m_szTracerParticle() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_szTracerParticle")); }
    uintptr_t m_GearSlot() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_GearSlot")); }
    int m_GearSlotPosition() { return read<int>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_GearSlotPosition")); }
    uintptr_t m_DefaultLoadoutSlot() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_DefaultLoadoutSlot")); }
    int m_nPrice() { return read<int>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_nPrice")); }
    int m_nKillAward() { return read<int>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_nKillAward")); }
    int m_nPrimaryReserveAmmoMax() { return read<int>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_nPrimaryReserveAmmoMax")); }
    int m_nSecondaryReserveAmmoMax() { return read<int>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_nSecondaryReserveAmmoMax")); }
    bool m_bMeleeWeapon() { return read<bool>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_bMeleeWeapon")); }
    bool m_bHasBurstMode() { return read<bool>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_bHasBurstMode")); }
    bool m_bIsRevolver() { return read<bool>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_bIsRevolver")); }
    bool m_bCannotShootUnderwater() { return read<bool>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_bCannotShootUnderwater")); }
    uintptr_t m_szName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_szName")); }
    uintptr_t m_eSilencerType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_eSilencerType")); }
    int m_nCrosshairMinDistance() { return read<int>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_nCrosshairMinDistance")); }
    int m_nCrosshairDeltaDistance() { return read<int>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_nCrosshairDeltaDistance")); }
    bool m_bIsFullAuto() { return read<bool>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_bIsFullAuto")); }
    int m_nNumBullets() { return read<int>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_nNumBullets")); }
    bool m_bReloadsSingleShells() { return read<bool>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_bReloadsSingleShells")); }
    uintptr_t m_flCycleTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flCycleTime")); }
    uintptr_t m_flMaxSpeed() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flMaxSpeed")); }
    uintptr_t m_flSpread() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flSpread")); }
    uintptr_t m_flInaccuracyCrouch() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flInaccuracyCrouch")); }
    uintptr_t m_flInaccuracyStand() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flInaccuracyStand")); }
    uintptr_t m_flInaccuracyJump() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flInaccuracyJump")); }
    uintptr_t m_flInaccuracyLand() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flInaccuracyLand")); }
    uintptr_t m_flInaccuracyLadder() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flInaccuracyLadder")); }
    uintptr_t m_flInaccuracyFire() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flInaccuracyFire")); }
    uintptr_t m_flInaccuracyMove() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flInaccuracyMove")); }
    uintptr_t m_flRecoilAngle() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flRecoilAngle")); }
    uintptr_t m_flRecoilAngleVariance() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flRecoilAngleVariance")); }
    uintptr_t m_flRecoilMagnitude() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flRecoilMagnitude")); }
    uintptr_t m_flRecoilMagnitudeVariance() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flRecoilMagnitudeVariance")); }
    uintptr_t m_nTracerFrequency() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_nTracerFrequency")); }
    float m_flInaccuracyJumpInitial() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flInaccuracyJumpInitial")); }
    float m_flInaccuracyJumpApex() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flInaccuracyJumpApex")); }
    float m_flInaccuracyReload() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flInaccuracyReload")); }
    float m_flDeployDuration() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flDeployDuration")); }
    float m_flDisallowAttackAfterReloadStartDuration() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flDisallowAttackAfterReloadStartDuration")); }
    int m_nBurstShotCount() { return read<int>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_nBurstShotCount")); }
    bool m_bAllowBurstHolster() { return read<bool>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_bAllowBurstHolster")); }
    int m_nRecoilSeed() { return read<int>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_nRecoilSeed")); }
    int m_nSpreadSeed() { return read<int>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_nSpreadSeed")); }
    float m_flAttackMovespeedFactor() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flAttackMovespeedFactor")); }
    float m_flInaccuracyPitchShift() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flInaccuracyPitchShift")); }
    float m_flInaccuracyAltSoundThreshold() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flInaccuracyAltSoundThreshold")); }
    uintptr_t m_szUseRadioSubtitle() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_szUseRadioSubtitle")); }
    bool m_bUnzoomsAfterShot() { return read<bool>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_bUnzoomsAfterShot")); }
    bool m_bHideViewModelWhenZoomed() { return read<bool>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_bHideViewModelWhenZoomed")); }
    int m_nZoomLevels() { return read<int>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_nZoomLevels")); }
    int m_nZoomFOV1() { return read<int>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_nZoomFOV1")); }
    int m_nZoomFOV2() { return read<int>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_nZoomFOV2")); }
    float m_flZoomTime0() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flZoomTime0")); }
    float m_flZoomTime1() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flZoomTime1")); }
    float m_flZoomTime2() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flZoomTime2")); }
    float m_flIronSightPullUpSpeed() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flIronSightPullUpSpeed")); }
    float m_flIronSightPutDownSpeed() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flIronSightPutDownSpeed")); }
    float m_flIronSightFOV() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flIronSightFOV")); }
    float m_flIronSightPivotForward() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flIronSightPivotForward")); }
    float m_flIronSightLooseness() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flIronSightLooseness")); }
    int m_nDamage() { return read<int>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_nDamage")); }
    float m_flHeadshotMultiplier() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flHeadshotMultiplier")); }
    float m_flArmorRatio() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flArmorRatio")); }
    float m_flPenetration() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flPenetration")); }
    float m_flRange() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flRange")); }
    float m_flRangeModifier() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flRangeModifier")); }
    float m_flFlinchVelocityModifierLarge() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flFlinchVelocityModifierLarge")); }
    float m_flFlinchVelocityModifierSmall() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flFlinchVelocityModifierSmall")); }
    float m_flRecoveryTimeCrouch() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flRecoveryTimeCrouch")); }
    float m_flRecoveryTimeStand() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flRecoveryTimeStand")); }
    float m_flRecoveryTimeCrouchFinal() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flRecoveryTimeCrouchFinal")); }
    float m_flRecoveryTimeStandFinal() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flRecoveryTimeStandFinal")); }
    int m_nRecoveryTransitionStartBullet() { return read<int>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_nRecoveryTransitionStartBullet")); }
    int m_nRecoveryTransitionEndBullet() { return read<int>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_nRecoveryTransitionEndBullet")); }
    float m_flThrowVelocity() { return read<float>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_flThrowVelocity")); }
    Vector3 m_vSmokeColor() { return read<Vector3>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_vSmokeColor")); }
    uintptr_t m_szAnimClass() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSWeaponBaseVData", "m_szAnimClass")); }
};
