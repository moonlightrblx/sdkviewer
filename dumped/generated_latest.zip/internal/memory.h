#pragma once
#include <cstdint>
#include <cstddef>
#include "../updater/updater.h"

template<typename T>
inline T read(uintptr_t addr) { return *(T*)(addr); }

template<typename T>
inline void write(uintptr_t addr, T value) { *(T*)(addr)=value; }

inline c_offsets offsets_instance;
