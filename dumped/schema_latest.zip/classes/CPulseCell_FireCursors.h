#pragma once
#include "../memory.h"

class CPulseCell_FireCursors {
public:
 uintptr_t baseAddr;
 CPulseCell_FireCursors() : baseAddr(0){}
 CPulseCell_FireCursors(uintptr_t b):baseAddr(b){}
 uintptr_t m_Outflows(){return SCHEMA_TYPE(uintptr_t,0x48);}
 uintptr_t m_bWaitForChildOutflows(){return SCHEMA_TYPE(uintptr_t,0x60);}
 uintptr_t m_OnFinished(){return SCHEMA_TYPE(uintptr_t,0x68);}
 uintptr_t m_OnCanceled(){return SCHEMA_TYPE(uintptr_t,0xB0);}
};
