#pragma once
#include "../memory.h"

class CCSPlayer_ItemServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_ItemServices() { baseAddr = client_base(); }
    CCSPlayer_ItemServices(uintptr_t base) : baseAddr(base) {}

    bool m_bHasDefuser() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayer_ItemServices", "m_bHasDefuser")); }
    bool m_bHasHelmet() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayer_ItemServices", "m_bHasHelmet")); }
};
