#pragma once
#include "../memory.h"
#include "../classes/CPathQueryComponent.h"

class CPathSimple  {
public:
    uintptr_t baseAddr;

    CPathSimple() { baseAddr = 0; }
    CPathSimple(uintptr_t base) : baseAddr(base) {}

    CPathQueryComponent m_CPathQueryComponent() { return read<CPathQueryComponent>(baseAddr + offsets_instance.get("CPathSimple", "m_CPathQueryComponent")); }
    uintptr_t m_pathString() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPathSimple", "m_pathString")); }
    bool m_bClosedLoop() { return read<bool>(baseAddr + offsets_instance.get("CPathSimple", "m_bClosedLoop")); }
};
