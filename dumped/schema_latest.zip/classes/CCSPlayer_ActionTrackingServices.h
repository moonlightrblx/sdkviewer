#pragma once
#include "../memory.h"

class CCSPlayer_ActionTrackingServices {
public:
 uintptr_t baseAddr;
 CCSPlayer_ActionTrackingServices() : baseAddr(0){}
 CCSPlayer_ActionTrackingServices(uintptr_t b):baseAddr(b){}
 uintptr_t m_hLastWeaponBeforeC4AutoSwitch(){return SCHEMA_TYPE(uintptr_t,0x40);}
 uintptr_t m_bIsRescuing(){return SCHEMA_TYPE(uintptr_t,0x44);}
 uintptr_t m_weaponPurchasesThisMatch(){return SCHEMA_TYPE(uintptr_t,0x48);}
 uintptr_t m_weaponPurchasesThisRound(){return SCHEMA_TYPE(uintptr_t,0xB8);}
};
