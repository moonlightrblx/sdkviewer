#pragma once
#include "../memory.h"
class C_CSPlayerPawn;

class C_RetakeGameRules  {
public:
    uintptr_t baseAddr;

    C_RetakeGameRules() { baseAddr = 0; }
    C_RetakeGameRules(uintptr_t base) : baseAddr(base) {}

    int m_nMatchSeed() { return read<int>(baseAddr + offsets_instance.get("C_RetakeGameRules", "m_nMatchSeed")); }
    bool m_bBlockersPresent() { return read<bool>(baseAddr + offsets_instance.get("C_RetakeGameRules", "m_bBlockersPresent")); }
    bool m_bRoundInProgress() { return read<bool>(baseAddr + offsets_instance.get("C_RetakeGameRules", "m_bRoundInProgress")); }
    int m_iFirstSecondHalfRound() { return read<int>(baseAddr + offsets_instance.get("C_RetakeGameRules", "m_iFirstSecondHalfRound")); }
    int m_iBombSite() { return read<int>(baseAddr + offsets_instance.get("C_RetakeGameRules", "m_iBombSite")); }
    C_CSPlayerPawn* m_hBombPlanter() { return read<C_CSPlayerPawn*>(baseAddr + offsets_instance.get("C_RetakeGameRules", "m_hBombPlanter")); }
};
