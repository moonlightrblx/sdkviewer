#pragma once
#include "../memory.h"

class C_Multimeter {
public:
 uintptr_t baseAddr;
 C_Multimeter() : baseAddr(0){}
 C_Multimeter(uintptr_t b):baseAddr(b){}
 uintptr_t m_hTargetC4(){return SCHEMA_TYPE(uintptr_t,0x1160);}
};
