#pragma once
#include "../memory.h"

class C_PointWorldText  {
public:
    uintptr_t baseAddr;

    C_PointWorldText() { baseAddr = client_base(); }
    C_PointWorldText(uintptr_t base) : baseAddr(base) {}

    bool m_bForceRecreateNextUpdate() { return read<bool>(baseAddr + offsets_instance.get("C_PointWorldText", "m_bForceRecreateNextUpdate")); }
    char* m_messageText() { return read<char*>(baseAddr + offsets_instance.get("C_PointWorldText", "m_messageText")); }
    char* m_FontName() { return read<char*>(baseAddr + offsets_instance.get("C_PointWorldText", "m_FontName")); }
    char* m_BackgroundMaterialName() { return read<char*>(baseAddr + offsets_instance.get("C_PointWorldText", "m_BackgroundMaterialName")); }
    bool m_bEnabled() { return read<bool>(baseAddr + offsets_instance.get("C_PointWorldText", "m_bEnabled")); }
    bool m_bFullbright() { return read<bool>(baseAddr + offsets_instance.get("C_PointWorldText", "m_bFullbright")); }
    float m_flWorldUnitsPerPx() { return read<float>(baseAddr + offsets_instance.get("C_PointWorldText", "m_flWorldUnitsPerPx")); }
    float m_flFontSize() { return read<float>(baseAddr + offsets_instance.get("C_PointWorldText", "m_flFontSize")); }
    float m_flDepthOffset() { return read<float>(baseAddr + offsets_instance.get("C_PointWorldText", "m_flDepthOffset")); }
    bool m_bDrawBackground() { return read<bool>(baseAddr + offsets_instance.get("C_PointWorldText", "m_bDrawBackground")); }
    float m_flBackgroundBorderWidth() { return read<float>(baseAddr + offsets_instance.get("C_PointWorldText", "m_flBackgroundBorderWidth")); }
    float m_flBackgroundBorderHeight() { return read<float>(baseAddr + offsets_instance.get("C_PointWorldText", "m_flBackgroundBorderHeight")); }
    float m_flBackgroundWorldToUV() { return read<float>(baseAddr + offsets_instance.get("C_PointWorldText", "m_flBackgroundWorldToUV")); }
    uintptr_t m_Color() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_PointWorldText", "m_Color")); }
    uintptr_t m_nJustifyHorizontal() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_PointWorldText", "m_nJustifyHorizontal")); }
    uintptr_t m_nJustifyVertical() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_PointWorldText", "m_nJustifyVertical")); }
    uintptr_t m_nReorientMode() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_PointWorldText", "m_nReorientMode")); }
};
