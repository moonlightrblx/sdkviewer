#pragma once
#include "../memory.h"

class C_EnvCubemap {
public:
 uintptr_t baseAddr;
 C_EnvCubemap() : baseAddr(0){}
 C_EnvCubemap(uintptr_t b):baseAddr(b){}
 uintptr_t m_Entity_hCubemapTexture(){return SCHEMA_TYPE(uintptr_t,0x678);}
 uintptr_t m_Entity_bCustomCubemapTexture(){return SCHEMA_TYPE(uintptr_t,0x680);}
 uintptr_t m_Entity_flInfluenceRadius(){return SCHEMA_TYPE(uintptr_t,0x684);}
 uintptr_t m_Entity_vBoxProjectMins(){return SCHEMA_TYPE(uintptr_t,0x688);}
 uintptr_t m_Entity_vBoxProjectMaxs(){return SCHEMA_TYPE(uintptr_t,0x694);}
 uintptr_t m_Entity_bMoveable(){return SCHEMA_TYPE(uintptr_t,0x6A0);}
 uintptr_t m_Entity_nHandshake(){return SCHEMA_TYPE(uintptr_t,0x6A4);}
 uintptr_t m_Entity_nEnvCubeMapArrayIndex(){return SCHEMA_TYPE(uintptr_t,0x6A8);}
 uintptr_t m_Entity_nPriority(){return SCHEMA_TYPE(uintptr_t,0x6AC);}
 uintptr_t m_Entity_flEdgeFadeDist(){return SCHEMA_TYPE(uintptr_t,0x6B0);}
 uintptr_t m_Entity_vEdgeFadeDists(){return SCHEMA_TYPE(uintptr_t,0x6B4);}
 uintptr_t m_Entity_flDiffuseScale(){return SCHEMA_TYPE(uintptr_t,0x6C0);}
 uintptr_t m_Entity_bStartDisabled(){return SCHEMA_TYPE(uintptr_t,0x6C4);}
 uintptr_t m_Entity_bDefaultEnvMap(){return SCHEMA_TYPE(uintptr_t,0x6C5);}
 uintptr_t m_Entity_bDefaultSpecEnvMap(){return SCHEMA_TYPE(uintptr_t,0x6C6);}
 uintptr_t m_Entity_bIndoorCubeMap(){return SCHEMA_TYPE(uintptr_t,0x6C7);}
 uintptr_t m_Entity_bCopyDiffuseFromDefaultCubemap(){return SCHEMA_TYPE(uintptr_t,0x6C8);}
 uintptr_t m_Entity_bEnabled(){return SCHEMA_TYPE(uintptr_t,0x6D8);}
};
