#pragma once
#include "../memory.h"

class C_WorldModelGloves {
public:
 uintptr_t baseAddr;
 C_WorldModelGloves() : baseAddr(0){}
 C_WorldModelGloves(uintptr_t b):baseAddr(b){}
};
