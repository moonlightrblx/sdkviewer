#pragma once
#include "../memory.h"

class CPulseCell_BaseFlow  {
public:
    uintptr_t baseAddr;

    CPulseCell_BaseFlow() { baseAddr = client_base(); }
    CPulseCell_BaseFlow(uintptr_t base) : baseAddr(base) {}

};
