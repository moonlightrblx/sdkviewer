#pragma once
#include "../memory.h"

class CPlayer_WaterServices {
public:
 uintptr_t baseAddr;
 CPlayer_WaterServices() : baseAddr(0){}
 CPlayer_WaterServices(uintptr_t b):baseAddr(b){}
};
