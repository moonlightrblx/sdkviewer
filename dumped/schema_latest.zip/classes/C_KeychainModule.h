#pragma once
#include "../memory.h"

class C_KeychainModule {
public:
 uintptr_t baseAddr;
 C_KeychainModule() : baseAddr(0){}
 C_KeychainModule(uintptr_t b):baseAddr(b){}
 uintptr_t m_nKeychainDefID(){return SCHEMA_TYPE(uintptr_t,0x1160);}
 uintptr_t m_nKeychainSeed(){return SCHEMA_TYPE(uintptr_t,0x1164);}
};
