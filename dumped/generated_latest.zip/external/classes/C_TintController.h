#pragma once
#include "../memory.h"

class C_TintController  {
public:
    uintptr_t baseAddr;

    C_TintController() { baseAddr = 0; }
    C_TintController(uintptr_t base) : baseAddr(base) {}

};
