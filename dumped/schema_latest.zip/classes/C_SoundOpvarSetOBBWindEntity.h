#pragma once
#include "../memory.h"

class C_SoundOpvarSetOBBWindEntity {
public:
 uintptr_t baseAddr;
 C_SoundOpvarSetOBBWindEntity() : baseAddr(0){}
 C_SoundOpvarSetOBBWindEntity(uintptr_t b):baseAddr(b){}
};
