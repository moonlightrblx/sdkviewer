#pragma once
#include "../memory.h"

class CCSGO_WingmanIntroTerroristPosition  {
public:
    uintptr_t baseAddr;

    CCSGO_WingmanIntroTerroristPosition() { baseAddr = 0; }
    CCSGO_WingmanIntroTerroristPosition(uintptr_t base) : baseAddr(base) {}

};
