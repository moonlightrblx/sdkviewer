#pragma once
#include "../memory.h"
#include "../classes/C_AttributeContainer.h"
class CBaseAnimGraph;
class C_CSPlayerPawn;

class C_Chicken  {
public:
    uintptr_t baseAddr;

    C_Chicken() { baseAddr = 0; }
    C_Chicken(uintptr_t base) : baseAddr(base) {}

    CBaseAnimGraph* m_hHolidayHatAddon() { return read<CBaseAnimGraph*>(baseAddr + offsets_instance.get("C_Chicken", "m_hHolidayHatAddon")); }
    bool m_jumpedThisFrame() { return read<bool>(baseAddr + offsets_instance.get("C_Chicken", "m_jumpedThisFrame")); }
    C_CSPlayerPawn* m_leader() { return read<C_CSPlayerPawn*>(baseAddr + offsets_instance.get("C_Chicken", "m_leader")); }
    C_AttributeContainer m_AttributeManager() { return read<C_AttributeContainer>(baseAddr + offsets_instance.get("C_Chicken", "m_AttributeManager")); }
    bool m_bAttributesInitialized() { return read<bool>(baseAddr + offsets_instance.get("C_Chicken", "m_bAttributesInitialized")); }
    uintptr_t m_hWaterWakeParticles() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_Chicken", "m_hWaterWakeParticles")); }
    bool m_bIsPreviewModel() { return read<bool>(baseAddr + offsets_instance.get("C_Chicken", "m_bIsPreviewModel")); }
};
