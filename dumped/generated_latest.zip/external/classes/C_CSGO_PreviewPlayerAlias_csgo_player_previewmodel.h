#pragma once
#include "../memory.h"

class C_CSGO_PreviewPlayerAlias_csgo_player_previewmodel  {
public:
    uintptr_t baseAddr;

    C_CSGO_PreviewPlayerAlias_csgo_player_previewmodel() { baseAddr = client_base(); }
    C_CSGO_PreviewPlayerAlias_csgo_player_previewmodel(uintptr_t base) : baseAddr(base) {}

};
