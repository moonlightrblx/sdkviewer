#pragma once
#include "../memory.h"

class CPulseCell_BaseLerp {
public:
 uintptr_t baseAddr;
 CPulseCell_BaseLerp() : baseAddr(0){}
 CPulseCell_BaseLerp(uintptr_t b):baseAddr(b){}
 uintptr_t m_WakeResume(){return SCHEMA_TYPE(uintptr_t,0x48);}
};
