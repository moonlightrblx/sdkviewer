#pragma once
#include "../memory.h"

class CPulseCell_Step_EntFire  {
public:
    uintptr_t baseAddr;

    CPulseCell_Step_EntFire() { baseAddr = 0; }
    CPulseCell_Step_EntFire(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_Input() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Step_EntFire", "m_Input")); }
};
