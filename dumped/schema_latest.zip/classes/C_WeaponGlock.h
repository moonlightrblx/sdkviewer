#pragma once
#include "../memory.h"

class C_WeaponGlock {
public:
 uintptr_t baseAddr;
 C_WeaponGlock() : baseAddr(0){}
 C_WeaponGlock(uintptr_t b):baseAddr(b){}
};
