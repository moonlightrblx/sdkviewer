#pragma once
#include "../memory.h"

class CBodyComponentBaseAnimGraph {
public:
 uintptr_t baseAddr;
 CBodyComponentBaseAnimGraph() : baseAddr(0){}
 CBodyComponentBaseAnimGraph(uintptr_t b):baseAddr(b){}
 uintptr_t m_animationController(){return SCHEMA_TYPE(uintptr_t,0x5B0);}
};
