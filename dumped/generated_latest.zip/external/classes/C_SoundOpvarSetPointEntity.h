#pragma once
#include "../memory.h"

class C_SoundOpvarSetPointEntity  {
public:
    uintptr_t baseAddr;

    C_SoundOpvarSetPointEntity() { baseAddr = client_base(); }
    C_SoundOpvarSetPointEntity(uintptr_t base) : baseAddr(base) {}

};
