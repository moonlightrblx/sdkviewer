#pragma once
#include "../memory.h"

class C_EnvWind {
public:
 uintptr_t baseAddr;
 C_EnvWind() : baseAddr(0){}
 C_EnvWind(uintptr_t b):baseAddr(b){}
 uintptr_t m_EnvWindShared(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
};
