#pragma once
#include "../memory.h"

class CBasePlayerVData {
public:
 uintptr_t baseAddr;
 CBasePlayerVData() : baseAddr(0){}
 CBasePlayerVData(uintptr_t b):baseAddr(b){}
 uintptr_t m_sModelName(){return SCHEMA_TYPE(uintptr_t,0x28);}
 uintptr_t m_flHeadDamageMultiplier(){return SCHEMA_TYPE(uintptr_t,0x108);}
 uintptr_t m_flChestDamageMultiplier(){return SCHEMA_TYPE(uintptr_t,0x118);}
 uintptr_t m_flStomachDamageMultiplier(){return SCHEMA_TYPE(uintptr_t,0x128);}
 uintptr_t m_flArmDamageMultiplier(){return SCHEMA_TYPE(uintptr_t,0x138);}
 uintptr_t m_flLegDamageMultiplier(){return SCHEMA_TYPE(uintptr_t,0x148);}
 uintptr_t m_flHoldBreathTime(){return SCHEMA_TYPE(uintptr_t,0x158);}
 uintptr_t m_flDrowningDamageInterval(){return SCHEMA_TYPE(uintptr_t,0x15C);}
 uintptr_t m_nDrowningDamageInitial(){return SCHEMA_TYPE(uintptr_t,0x160);}
 uintptr_t m_nDrowningDamageMax(){return SCHEMA_TYPE(uintptr_t,0x164);}
 uintptr_t m_nWaterSpeed(){return SCHEMA_TYPE(uintptr_t,0x168);}
 uintptr_t m_flUseRange(){return SCHEMA_TYPE(uintptr_t,0x16C);}
 uintptr_t m_flUseAngleTolerance(){return SCHEMA_TYPE(uintptr_t,0x170);}
 uintptr_t m_flCrouchTime(){return SCHEMA_TYPE(uintptr_t,0x174);}
};
