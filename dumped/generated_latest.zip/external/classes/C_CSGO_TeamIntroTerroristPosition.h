#pragma once
#include "../memory.h"

class C_CSGO_TeamIntroTerroristPosition  {
public:
    uintptr_t baseAddr;

    C_CSGO_TeamIntroTerroristPosition() { baseAddr = 0; }
    C_CSGO_TeamIntroTerroristPosition(uintptr_t base) : baseAddr(base) {}

};
