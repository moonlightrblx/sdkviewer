#pragma once
#include "../memory.h"

class CCSGameModeRules_Noop  {
public:
    uintptr_t baseAddr;

    CCSGameModeRules_Noop() { baseAddr = 0; }
    CCSGameModeRules_Noop(uintptr_t base) : baseAddr(base) {}

};
