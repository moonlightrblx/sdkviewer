#pragma once
#include "../memory.h"

class audioparams_t {
public:
 uintptr_t baseAddr;
 audioparams_t() : baseAddr(0){}
 audioparams_t(uintptr_t b):baseAddr(b){}
 uintptr_t localSound(){return SCHEMA_TYPE(uintptr_t,0x8);}
 uintptr_t soundscapeIndex(){return SCHEMA_TYPE(uintptr_t,0x68);}
 uintptr_t localBits(){return SCHEMA_TYPE(uintptr_t,0x6C);}
 uintptr_t soundscapeEntityListIndex(){return SCHEMA_TYPE(uintptr_t,0x70);}
 uintptr_t soundEventHash(){return SCHEMA_TYPE(uintptr_t,0x74);}
};
