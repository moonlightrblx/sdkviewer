#pragma once
#include "../memory.h"

class CPulseCell_BaseLerp__CursorState_t  {
public:
    uintptr_t baseAddr;

    CPulseCell_BaseLerp__CursorState_t() { baseAddr = client_base(); }
    CPulseCell_BaseLerp__CursorState_t(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_StartTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_BaseLerp__CursorState_t", "m_StartTime")); }
    uintptr_t m_EndTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_BaseLerp__CursorState_t", "m_EndTime")); }
};
