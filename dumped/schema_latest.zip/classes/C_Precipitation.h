#pragma once
#include "../memory.h"

class C_Precipitation {
public:
 uintptr_t baseAddr;
 C_Precipitation() : baseAddr(0){}
 C_Precipitation(uintptr_t b):baseAddr(b){}
 uintptr_t m_flDensity(){return SCHEMA_TYPE(uintptr_t,0xFF0);}
 uintptr_t m_flParticleInnerDist(){return SCHEMA_TYPE(uintptr_t,0x1000);}
 uintptr_t m_pParticleDef(){return SCHEMA_TYPE(uintptr_t,0x1008);}
 uintptr_t m_tParticlePrecipTraceTimer(){return SCHEMA_TYPE(uintptr_t,0x1030);}
 uintptr_t m_bActiveParticlePrecipEmitter(){return SCHEMA_TYPE(uintptr_t,0x1038);}
 uintptr_t m_bParticlePrecipInitialized(){return SCHEMA_TYPE(uintptr_t,0x1039);}
 uintptr_t m_bHasSimulatedSinceLastSceneObjectUpdate(){return SCHEMA_TYPE(uintptr_t,0x103A);}
 uintptr_t m_nAvailableSheetSequencesMaxIndex(){return SCHEMA_TYPE(uintptr_t,0x103C);}
};
