#pragma once
#include "../memory.h"

class CSkeletonInstance  {
public:
    uintptr_t baseAddr;

    CSkeletonInstance() { baseAddr = client_base(); }
    CSkeletonInstance(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_modelState() { return read<uintptr_t>(baseAddr + offsets_instance.get("CSkeletonInstance", "m_modelState")); }
    bool m_bIsAnimationEnabled() { return read<bool>(baseAddr + offsets_instance.get("CSkeletonInstance", "m_bIsAnimationEnabled")); }
    bool m_bUseParentRenderBounds() { return read<bool>(baseAddr + offsets_instance.get("CSkeletonInstance", "m_bUseParentRenderBounds")); }
    bool m_bDisableSolidCollisionsForHierarchy() { return read<bool>(baseAddr + offsets_instance.get("CSkeletonInstance", "m_bDisableSolidCollisionsForHierarchy")); }
    uintptr_t m_bDirtyMotionType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CSkeletonInstance", "m_bDirtyMotionType")); }
    uintptr_t m_bIsGeneratingLatchedParentSpaceState() { return read<uintptr_t>(baseAddr + offsets_instance.get("CSkeletonInstance", "m_bIsGeneratingLatchedParentSpaceState")); }
    uintptr_t m_materialGroup() { return read<uintptr_t>(baseAddr + offsets_instance.get("CSkeletonInstance", "m_materialGroup")); }
    uint8_t m_nHitboxSet() { return read<uint8_t>(baseAddr + offsets_instance.get("CSkeletonInstance", "m_nHitboxSet")); }
};
