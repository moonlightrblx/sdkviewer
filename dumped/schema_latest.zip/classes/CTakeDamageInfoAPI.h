#pragma once
#include "../memory.h"

class CTakeDamageInfoAPI {
public:
 uintptr_t baseAddr;
 CTakeDamageInfoAPI() : baseAddr(0){}
 CTakeDamageInfoAPI(uintptr_t b):baseAddr(b){}
};
