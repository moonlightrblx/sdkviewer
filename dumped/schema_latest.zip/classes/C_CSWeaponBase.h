#pragma once
#include "../memory.h"

class C_CSWeaponBase {
public:
 uintptr_t baseAddr;
 C_CSWeaponBase() : baseAddr(0){}
 C_CSWeaponBase(uintptr_t b):baseAddr(b){}
 uintptr_t m_iWeaponGameplayAnimState(){return SCHEMA_TYPE(uintptr_t,0x1970);}
 uintptr_t m_flWeaponGameplayAnimStateTimestamp(){return SCHEMA_TYPE(uintptr_t,0x1974);}
 uintptr_t m_flInspectCancelCompleteTime(){return SCHEMA_TYPE(uintptr_t,0x1978);}
 uintptr_t m_bInspectPending(){return SCHEMA_TYPE(uintptr_t,0x197C);}
 uintptr_t m_bInspectShouldLoop(){return SCHEMA_TYPE(uintptr_t,0x197D);}
 uintptr_t m_flCrosshairDistance(){return SCHEMA_TYPE(uintptr_t,0x19A8);}
 uintptr_t m_iAmmoLastCheck(){return SCHEMA_TYPE(uintptr_t,0x19AC);}
 uintptr_t m_nLastEmptySoundCmdNum(){return SCHEMA_TYPE(uintptr_t,0x19B0);}
 uintptr_t m_bFireOnEmpty(){return SCHEMA_TYPE(uintptr_t,0x19B4);}
 uintptr_t m_OnPlayerPickup(){return SCHEMA_TYPE(uintptr_t,0x19B8);}
 uintptr_t m_weaponMode(){return SCHEMA_TYPE(uintptr_t,0x19E0);}
 uintptr_t m_flTurningInaccuracyDelta(){return SCHEMA_TYPE(uintptr_t,0x19E4);}
 uintptr_t m_vecTurningInaccuracyEyeDirLast(){return SCHEMA_TYPE(uintptr_t,0x19E8);}
 uintptr_t m_flTurningInaccuracy(){return SCHEMA_TYPE(uintptr_t,0x19F4);}
 uintptr_t m_fAccuracyPenalty(){return SCHEMA_TYPE(uintptr_t,0x19F8);}
 uintptr_t m_flLastAccuracyUpdateTime(){return SCHEMA_TYPE(uintptr_t,0x19FC);}
 uintptr_t m_fAccuracySmoothedForZoom(){return SCHEMA_TYPE(uintptr_t,0x1A00);}
 uintptr_t m_iRecoilIndex(){return SCHEMA_TYPE(uintptr_t,0x1A04);}
 uintptr_t m_flRecoilIndex(){return SCHEMA_TYPE(uintptr_t,0x1A08);}
 uintptr_t m_bBurstMode(){return SCHEMA_TYPE(uintptr_t,0x1A0C);}
 uintptr_t m_flLastBurstModeChangeTime(){return SCHEMA_TYPE(uintptr_t,0x1A10);}
 uintptr_t m_nPostponeFireReadyTicks(){return SCHEMA_TYPE(uintptr_t,0x1A14);}
 uintptr_t m_flPostponeFireReadyFrac(){return SCHEMA_TYPE(uintptr_t,0x1A18);}
 uintptr_t m_bInReload(){return SCHEMA_TYPE(uintptr_t,0x1A1C);}
 uintptr_t m_flDroppedAtTime(){return SCHEMA_TYPE(uintptr_t,0x1A20);}
 uintptr_t m_bIsHauledBack(){return SCHEMA_TYPE(uintptr_t,0x1A24);}
 uintptr_t m_bSilencerOn(){return SCHEMA_TYPE(uintptr_t,0x1A25);}
 uintptr_t m_flTimeSilencerSwitchComplete(){return SCHEMA_TYPE(uintptr_t,0x1A28);}
 uintptr_t m_iOriginalTeamNumber(){return SCHEMA_TYPE(uintptr_t,0x1A2C);}
 uintptr_t m_iMostRecentTeamNumber(){return SCHEMA_TYPE(uintptr_t,0x1A30);}
 uintptr_t m_bDroppedNearBuyZone(){return SCHEMA_TYPE(uintptr_t,0x1A34);}
 uintptr_t m_flNextAttackRenderTimeOffset(){return SCHEMA_TYPE(uintptr_t,0x1A38);}
 uintptr_t m_bClearWeaponIdentifyingUGC(){return SCHEMA_TYPE(uintptr_t,0x1AD8);}
 uintptr_t m_bVisualsDataSet(){return SCHEMA_TYPE(uintptr_t,0x1AD9);}
 uintptr_t m_bUIWeapon(){return SCHEMA_TYPE(uintptr_t,0x1ADA);}
 uintptr_t m_nCustomEconReloadEventId(){return SCHEMA_TYPE(uintptr_t,0x1ADC);}
 uintptr_t m_nextPrevOwnerUseTime(){return SCHEMA_TYPE(uintptr_t,0x1AE8);}
 uintptr_t m_hPrevOwner(){return SCHEMA_TYPE(uintptr_t,0x1AEC);}
 uintptr_t m_nDropTick(){return SCHEMA_TYPE(uintptr_t,0x1AF0);}
 uintptr_t m_bWasActiveWeaponWhenDropped(){return SCHEMA_TYPE(uintptr_t,0x1AF4);}
 uintptr_t m_donated(){return SCHEMA_TYPE(uintptr_t,0x1B14);}
 uintptr_t m_fLastShotTime(){return SCHEMA_TYPE(uintptr_t,0x1B18);}
 uintptr_t m_bWasOwnedByCT(){return SCHEMA_TYPE(uintptr_t,0x1B1C);}
 uintptr_t m_bWasOwnedByTerrorist(){return SCHEMA_TYPE(uintptr_t,0x1B1D);}
 uintptr_t m_flNextClientFireBulletTime(){return SCHEMA_TYPE(uintptr_t,0x1B20);}
 uintptr_t m_flNextClientFireBulletTime_Repredict(){return SCHEMA_TYPE(uintptr_t,0x1B24);}
 uintptr_t m_IronSightController(){return SCHEMA_TYPE(uintptr_t,0x1C90);}
 uintptr_t m_iIronSightMode(){return SCHEMA_TYPE(uintptr_t,0x1D40);}
 uintptr_t m_flLastLOSTraceFailureTime(){return SCHEMA_TYPE(uintptr_t,0x1D58);}
 uintptr_t m_flWatTickOffset(){return SCHEMA_TYPE(uintptr_t,0x1DB8);}
 uintptr_t m_flLastShakeTime(){return SCHEMA_TYPE(uintptr_t,0x1DCC);}
};
