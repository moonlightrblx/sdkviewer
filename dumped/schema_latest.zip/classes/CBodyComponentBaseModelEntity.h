#pragma once
#include "../memory.h"

class CBodyComponentBaseModelEntity {
public:
 uintptr_t baseAddr;
 CBodyComponentBaseModelEntity() : baseAddr(0){}
 CBodyComponentBaseModelEntity(uintptr_t b):baseAddr(b){}
};
