#pragma once
#include "../memory.h"
#include "../classes/GameTime_t.h"
#include "../classes/sky3dparams_t.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"
class CBasePlayerController;
class CPlayer_AutoaimServices;
class CPlayer_CameraServices;
class CPlayer_FlashlightServices;
class CPlayer_ItemServices;
class CPlayer_MovementServices;
class CPlayer_ObserverServices;
class CPlayer_UseServices;
class CPlayer_WaterServices;
class CPlayer_WeaponServices;

class C_BasePlayerPawn  {
public:
    uintptr_t baseAddr;

    C_BasePlayerPawn() { baseAddr = 0; }
    C_BasePlayerPawn(uintptr_t base) : baseAddr(base) {}

    CPlayer_WeaponServices* m_pWeaponServices() { return read<CPlayer_WeaponServices*>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_pWeaponServices")); }
    CPlayer_ItemServices* m_pItemServices() { return read<CPlayer_ItemServices*>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_pItemServices")); }
    CPlayer_AutoaimServices* m_pAutoaimServices() { return read<CPlayer_AutoaimServices*>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_pAutoaimServices")); }
    CPlayer_ObserverServices* m_pObserverServices() { return read<CPlayer_ObserverServices*>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_pObserverServices")); }
    CPlayer_WaterServices* m_pWaterServices() { return read<CPlayer_WaterServices*>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_pWaterServices")); }
    CPlayer_UseServices* m_pUseServices() { return read<CPlayer_UseServices*>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_pUseServices")); }
    CPlayer_FlashlightServices* m_pFlashlightServices() { return read<CPlayer_FlashlightServices*>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_pFlashlightServices")); }
    CPlayer_CameraServices* m_pCameraServices() { return read<CPlayer_CameraServices*>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_pCameraServices")); }
    CPlayer_MovementServices* m_pMovementServices() { return read<CPlayer_MovementServices*>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_pMovementServices")); }
    Vector3 m_ServerViewAngleChanges() { return read<Vector3>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_ServerViewAngleChanges")); }
    QAngle v_angle() { return read<QAngle>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "v_angle")); }
    QAngle v_anglePrevious() { return read<QAngle>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "v_anglePrevious")); }
    int m_iHideHUD() { return read<int>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_iHideHUD")); }
    sky3dparams_t m_skybox3d() { return read<sky3dparams_t>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_skybox3d")); }
    GameTime_t m_flDeathTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_flDeathTime")); }
    Vector3 m_vecPredictionError() { return read<Vector3>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_vecPredictionError")); }
    GameTime_t m_flPredictionErrorTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_flPredictionErrorTime")); }
    Vector3 m_vecLastCameraSetupLocalOrigin() { return read<Vector3>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_vecLastCameraSetupLocalOrigin")); }
    GameTime_t m_flLastCameraSetupTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_flLastCameraSetupTime")); }
    float m_flFOVSensitivityAdjust() { return read<float>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_flFOVSensitivityAdjust")); }
    float m_flMouseSensitivity() { return read<float>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_flMouseSensitivity")); }
    Vector3 m_vOldOrigin() { return read<Vector3>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_vOldOrigin")); }
    float m_flOldSimulationTime() { return read<float>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_flOldSimulationTime")); }
    int m_nLastExecutedCommandNumber() { return read<int>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_nLastExecutedCommandNumber")); }
    int m_nLastExecutedCommandTick() { return read<int>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_nLastExecutedCommandTick")); }
    CBasePlayerController* m_hController() { return read<CBasePlayerController*>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_hController")); }
    CBasePlayerController* m_hDefaultController() { return read<CBasePlayerController*>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_hDefaultController")); }
    bool m_bIsSwappingToPredictableController() { return read<bool>(baseAddr + offsets_instance.get("C_BasePlayerPawn", "m_bIsSwappingToPredictableController")); }
};
