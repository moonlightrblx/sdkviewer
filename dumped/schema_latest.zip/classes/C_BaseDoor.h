#pragma once
#include "../memory.h"

class C_BaseDoor {
public:
 uintptr_t baseAddr;
 C_BaseDoor() : baseAddr(0){}
 C_BaseDoor(uintptr_t b):baseAddr(b){}
 uintptr_t m_bIsUsable(){return SCHEMA_TYPE(uintptr_t,0xEB0);}
};
