#pragma once
#include "../memory.h"

class C_CSWeaponBaseGun  {
public:
    uintptr_t baseAddr;

    C_CSWeaponBaseGun() { baseAddr = client_base(); }
    C_CSWeaponBaseGun(uintptr_t base) : baseAddr(base) {}

    int m_zoomLevel() { return read<int>(baseAddr + offsets_instance.get("C_CSWeaponBaseGun", "m_zoomLevel")); }
    int m_iBurstShotsRemaining() { return read<int>(baseAddr + offsets_instance.get("C_CSWeaponBaseGun", "m_iBurstShotsRemaining")); }
    int m_iSilencerBodygroup() { return read<int>(baseAddr + offsets_instance.get("C_CSWeaponBaseGun", "m_iSilencerBodygroup")); }
    int m_silencedModelIndex() { return read<int>(baseAddr + offsets_instance.get("C_CSWeaponBaseGun", "m_silencedModelIndex")); }
    bool m_inPrecache() { return read<bool>(baseAddr + offsets_instance.get("C_CSWeaponBaseGun", "m_inPrecache")); }
    bool m_bNeedsBoltAction() { return read<bool>(baseAddr + offsets_instance.get("C_CSWeaponBaseGun", "m_bNeedsBoltAction")); }
    int m_nRevolverCylinderIdx() { return read<int>(baseAddr + offsets_instance.get("C_CSWeaponBaseGun", "m_nRevolverCylinderIdx")); }
};
