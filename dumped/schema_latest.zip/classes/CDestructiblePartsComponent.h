#pragma once
#include "../memory.h"

class CDestructiblePartsComponent {
public:
 uintptr_t baseAddr;
 CDestructiblePartsComponent() : baseAddr(0){}
 CDestructiblePartsComponent(uintptr_t b):baseAddr(b){}
 uintptr_t __m_pChainEntity(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_vecDamageTakenByHitGroup(){return SCHEMA_TYPE(uintptr_t,0x48);}
 uintptr_t m_hOwner(){return SCHEMA_TYPE(uintptr_t,0x60);}
 uintptr_t m_nLastHitDamageLevel(){return SCHEMA_TYPE(uintptr_t,0x64);}
};
