#pragma once
#include "../memory.h"

class C_VoteController {
public:
 uintptr_t baseAddr;
 C_VoteController() : baseAddr(0){}
 C_VoteController(uintptr_t b):baseAddr(b){}
 uintptr_t m_iActiveIssueIndex(){return SCHEMA_TYPE(uintptr_t,0x608);}
 uintptr_t m_iOnlyTeamToVote(){return SCHEMA_TYPE(uintptr_t,0x60C);}
 uintptr_t m_nVoteOptionCount(){return SCHEMA_TYPE(uintptr_t,0x610);}
 uintptr_t m_nPotentialVotes(){return SCHEMA_TYPE(uintptr_t,0x624);}
 uintptr_t m_bVotesDirty(){return SCHEMA_TYPE(uintptr_t,0x628);}
 uintptr_t m_bTypeDirty(){return SCHEMA_TYPE(uintptr_t,0x629);}
 uintptr_t m_bIsYesNoVote(){return SCHEMA_TYPE(uintptr_t,0x62A);}
};
