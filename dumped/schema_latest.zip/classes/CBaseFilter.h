#pragma once
#include "../memory.h"

class CBaseFilter {
public:
 uintptr_t baseAddr;
 CBaseFilter() : baseAddr(0){}
 CBaseFilter(uintptr_t b):baseAddr(b){}
 uintptr_t m_bNegated(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_OnPass(){return SCHEMA_TYPE(uintptr_t,0x600);}
 uintptr_t m_OnFail(){return SCHEMA_TYPE(uintptr_t,0x628);}
};
