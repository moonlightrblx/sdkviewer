#pragma once
#include "../memory.h"

class CEnvSoundscapeProxyAlias_snd_soundscape_proxy  {
public:
    uintptr_t baseAddr;

    CEnvSoundscapeProxyAlias_snd_soundscape_proxy() { baseAddr = client_base(); }
    CEnvSoundscapeProxyAlias_snd_soundscape_proxy(uintptr_t base) : baseAddr(base) {}

};
