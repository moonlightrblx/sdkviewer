#pragma once
#include "../memory.h"

class C_CSWeaponBaseShotgun  {
public:
    uintptr_t baseAddr;

    C_CSWeaponBaseShotgun() { baseAddr = client_base(); }
    C_CSWeaponBaseShotgun(uintptr_t base) : baseAddr(base) {}

};
