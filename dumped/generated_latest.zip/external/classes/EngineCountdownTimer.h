#pragma once
#include "../memory.h"

class EngineCountdownTimer  {
public:
    uintptr_t baseAddr;

    EngineCountdownTimer() { baseAddr = 0; }
    EngineCountdownTimer(uintptr_t base) : baseAddr(base) {}

    float m_duration() { return read<float>(baseAddr + offsets_instance.get("EngineCountdownTimer", "m_duration")); }
    float m_timestamp() { return read<float>(baseAddr + offsets_instance.get("EngineCountdownTimer", "m_timestamp")); }
    float m_timescale() { return read<float>(baseAddr + offsets_instance.get("EngineCountdownTimer", "m_timescale")); }
};
