#pragma once
#include "../memory.h"

class CRenderComponent {
public:
 uintptr_t baseAddr;
 CRenderComponent() : baseAddr(0){}
 CRenderComponent(uintptr_t b):baseAddr(b){}
 uintptr_t __m_pChainEntity(){return SCHEMA_TYPE(uintptr_t,0x10);}
 uintptr_t m_bIsRenderingWithViewModels(){return SCHEMA_TYPE(uintptr_t,0x50);}
 uintptr_t m_nSplitscreenFlags(){return SCHEMA_TYPE(uintptr_t,0x54);}
 uintptr_t m_bEnableRendering(){return SCHEMA_TYPE(uintptr_t,0x58);}
 uintptr_t m_bInterpolationReadyToDraw(){return SCHEMA_TYPE(uintptr_t,0xA8);}
};
