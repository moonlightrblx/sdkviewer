#pragma once
#include "../memory.h"

class C_TeamplayRules {
public:
 uintptr_t baseAddr;
 C_TeamplayRules() : baseAddr(0){}
 C_TeamplayRules(uintptr_t b):baseAddr(b){}
};
