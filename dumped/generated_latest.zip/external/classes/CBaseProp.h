#pragma once
#include "../memory.h"

class CBaseProp  {
public:
    uintptr_t baseAddr;

    CBaseProp() { baseAddr = 0; }
    CBaseProp(uintptr_t base) : baseAddr(base) {}

    bool m_bModelOverrodeBlockLOS() { return read<bool>(baseAddr + offsets_instance.get("CBaseProp", "m_bModelOverrodeBlockLOS")); }
    int m_iShapeType() { return read<int>(baseAddr + offsets_instance.get("CBaseProp", "m_iShapeType")); }
    bool m_bConformToCollisionBounds() { return read<bool>(baseAddr + offsets_instance.get("CBaseProp", "m_bConformToCollisionBounds")); }
    uintptr_t m_mPreferredCatchTransform() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBaseProp", "m_mPreferredCatchTransform")); }
};
