#pragma once
#include "../memory.h"

class CNetworkVarChainer  {
public:
    uintptr_t baseAddr;

    CNetworkVarChainer() { baseAddr = 0; }
    CNetworkVarChainer(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_PathIndex() { return read<uintptr_t>(baseAddr + offsets_instance.get("CNetworkVarChainer", "m_PathIndex")); }
};
