#pragma once
#include "../memory.h"

class C_DynamicPropAlias_dynamic_prop  {
public:
    uintptr_t baseAddr;

    C_DynamicPropAlias_dynamic_prop() { baseAddr = client_base(); }
    C_DynamicPropAlias_dynamic_prop(uintptr_t base) : baseAddr(base) {}

};
