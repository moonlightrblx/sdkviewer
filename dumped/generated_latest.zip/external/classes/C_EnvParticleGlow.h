#pragma once
#include "../memory.h"

class C_EnvParticleGlow  {
public:
    uintptr_t baseAddr;

    C_EnvParticleGlow() { baseAddr = client_base(); }
    C_EnvParticleGlow(uintptr_t base) : baseAddr(base) {}

    float m_flAlphaScale() { return read<float>(baseAddr + offsets_instance.get("C_EnvParticleGlow", "m_flAlphaScale")); }
    float m_flRadiusScale() { return read<float>(baseAddr + offsets_instance.get("C_EnvParticleGlow", "m_flRadiusScale")); }
    float m_flSelfIllumScale() { return read<float>(baseAddr + offsets_instance.get("C_EnvParticleGlow", "m_flSelfIllumScale")); }
    uintptr_t m_ColorTint() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvParticleGlow", "m_ColorTint")); }
    uintptr_t m_hTextureOverride() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvParticleGlow", "m_hTextureOverride")); }
};
