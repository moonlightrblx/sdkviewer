#pragma once
#include "../memory.h"

class C_SoundEventSphereEntity  {
public:
    uintptr_t baseAddr;

    C_SoundEventSphereEntity() { baseAddr = 0; }
    C_SoundEventSphereEntity(uintptr_t base) : baseAddr(base) {}

    float m_flRadius() { return read<float>(baseAddr + offsets_instance.get("C_SoundEventSphereEntity", "m_flRadius")); }
};
