#pragma once
#include "../memory.h"

class CPulseCell_Unknown  {
public:
    uintptr_t baseAddr;

    CPulseCell_Unknown() { baseAddr = 0; }
    CPulseCell_Unknown(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_UnknownKeys() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Unknown", "m_UnknownKeys")); }
};
