#pragma once
#include "../memory.h"

class CPlayer_MovementServices_Humanoid {
public:
 uintptr_t baseAddr;
 CPlayer_MovementServices_Humanoid() : baseAddr(0){}
 CPlayer_MovementServices_Humanoid(uintptr_t b):baseAddr(b){}
 uintptr_t m_flStepSoundTime(){return SCHEMA_TYPE(uintptr_t,0x238);}
 uintptr_t m_flFallVelocity(){return SCHEMA_TYPE(uintptr_t,0x23C);}
 uintptr_t m_bInCrouch(){return SCHEMA_TYPE(uintptr_t,0x240);}
 uintptr_t m_nCrouchState(){return SCHEMA_TYPE(uintptr_t,0x244);}
 uintptr_t m_flCrouchTransitionStartTime(){return SCHEMA_TYPE(uintptr_t,0x248);}
 uintptr_t m_bDucked(){return SCHEMA_TYPE(uintptr_t,0x24C);}
 uintptr_t m_bDucking(){return SCHEMA_TYPE(uintptr_t,0x24D);}
 uintptr_t m_bInDuckJump(){return SCHEMA_TYPE(uintptr_t,0x24E);}
 uintptr_t m_groundNormal(){return SCHEMA_TYPE(uintptr_t,0x250);}
 uintptr_t m_flSurfaceFriction(){return SCHEMA_TYPE(uintptr_t,0x25C);}
 uintptr_t m_surfaceProps(){return SCHEMA_TYPE(uintptr_t,0x260);}
 uintptr_t m_nStepside(){return SCHEMA_TYPE(uintptr_t,0x270);}
};
