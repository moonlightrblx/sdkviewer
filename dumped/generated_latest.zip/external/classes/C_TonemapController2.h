#pragma once
#include "../memory.h"

class C_TonemapController2  {
public:
    uintptr_t baseAddr;

    C_TonemapController2() { baseAddr = client_base(); }
    C_TonemapController2(uintptr_t base) : baseAddr(base) {}

    float m_flAutoExposureMin() { return read<float>(baseAddr + offsets_instance.get("C_TonemapController2", "m_flAutoExposureMin")); }
    float m_flAutoExposureMax() { return read<float>(baseAddr + offsets_instance.get("C_TonemapController2", "m_flAutoExposureMax")); }
    float m_flExposureAdaptationSpeedUp() { return read<float>(baseAddr + offsets_instance.get("C_TonemapController2", "m_flExposureAdaptationSpeedUp")); }
    float m_flExposureAdaptationSpeedDown() { return read<float>(baseAddr + offsets_instance.get("C_TonemapController2", "m_flExposureAdaptationSpeedDown")); }
    float m_flTonemapEVSmoothingRange() { return read<float>(baseAddr + offsets_instance.get("C_TonemapController2", "m_flTonemapEVSmoothingRange")); }
};
