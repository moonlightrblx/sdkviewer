#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class CCitadelSoundOpvarSetOBB  {
public:
    uintptr_t baseAddr;

    CCitadelSoundOpvarSetOBB() { baseAddr = 0; }
    CCitadelSoundOpvarSetOBB(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_iszStackName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCitadelSoundOpvarSetOBB", "m_iszStackName")); }
    uintptr_t m_iszOperatorName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCitadelSoundOpvarSetOBB", "m_iszOperatorName")); }
    uintptr_t m_iszOpvarName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCitadelSoundOpvarSetOBB", "m_iszOpvarName")); }
    Vector3 m_vDistanceInnerMins() { return read<Vector3>(baseAddr + offsets_instance.get("CCitadelSoundOpvarSetOBB", "m_vDistanceInnerMins")); }
    Vector3 m_vDistanceInnerMaxs() { return read<Vector3>(baseAddr + offsets_instance.get("CCitadelSoundOpvarSetOBB", "m_vDistanceInnerMaxs")); }
    Vector3 m_vDistanceOuterMins() { return read<Vector3>(baseAddr + offsets_instance.get("CCitadelSoundOpvarSetOBB", "m_vDistanceOuterMins")); }
    Vector3 m_vDistanceOuterMaxs() { return read<Vector3>(baseAddr + offsets_instance.get("CCitadelSoundOpvarSetOBB", "m_vDistanceOuterMaxs")); }
    int m_nAABBDirection() { return read<int>(baseAddr + offsets_instance.get("CCitadelSoundOpvarSetOBB", "m_nAABBDirection")); }
};
