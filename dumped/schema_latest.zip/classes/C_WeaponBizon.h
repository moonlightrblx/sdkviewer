#pragma once
#include "../memory.h"

class C_WeaponBizon {
public:
 uintptr_t baseAddr;
 C_WeaponBizon() : baseAddr(0){}
 C_WeaponBizon(uintptr_t b):baseAddr(b){}
};
