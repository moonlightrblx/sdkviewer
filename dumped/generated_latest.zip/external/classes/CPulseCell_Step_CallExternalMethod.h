#pragma once
#include "../memory.h"
#include "../classes/CPulse_ResumePoint.h"
#include "../types/Vector3.h"

class CPulseCell_Step_CallExternalMethod  {
public:
    uintptr_t baseAddr;

    CPulseCell_Step_CallExternalMethod() { baseAddr = 0; }
    CPulseCell_Step_CallExternalMethod(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_MethodName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Step_CallExternalMethod", "m_MethodName")); }
    uintptr_t m_GameBlackboard() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Step_CallExternalMethod", "m_GameBlackboard")); }
    Vector3 m_ExpectedArgs() { return read<Vector3>(baseAddr + offsets_instance.get("CPulseCell_Step_CallExternalMethod", "m_ExpectedArgs")); }
    uintptr_t m_nAsyncCallMode() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Step_CallExternalMethod", "m_nAsyncCallMode")); }
    CPulse_ResumePoint m_OnFinished() { return read<CPulse_ResumePoint>(baseAddr + offsets_instance.get("CPulseCell_Step_CallExternalMethod", "m_OnFinished")); }
};
