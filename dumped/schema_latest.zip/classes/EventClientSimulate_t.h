#pragma once
#include "../memory.h"

class EventClientSimulate_t {
public:
 uintptr_t baseAddr;
 EventClientSimulate_t() : baseAddr(0){}
 EventClientSimulate_t(uintptr_t b):baseAddr(b){}
};
