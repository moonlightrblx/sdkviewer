#pragma once
#include "../memory.h"

class CPathQueryComponent {
public:
 uintptr_t baseAddr;
 CPathQueryComponent() : baseAddr(0){}
 CPathQueryComponent(uintptr_t b):baseAddr(b){}
};
