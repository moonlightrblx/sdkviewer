#pragma once
#include "../memory.h"

class CEmptyEntityInstance {
public:
 uintptr_t baseAddr;
 CEmptyEntityInstance() : baseAddr(0){}
 CEmptyEntityInstance(uintptr_t b):baseAddr(b){}
};
