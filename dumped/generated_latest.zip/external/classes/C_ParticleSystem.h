#pragma once
#include "../memory.h"
#include "../classes/GameTime_t.h"
#include "../types/Vector3.h"
class C_BaseEntity;

class C_ParticleSystem  {
public:
    uintptr_t baseAddr;

    C_ParticleSystem() { baseAddr = 0; }
    C_ParticleSystem(uintptr_t base) : baseAddr(base) {}

    char* m_szSnapshotFileName() { return read<char*>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_szSnapshotFileName")); }
    bool m_bActive() { return read<bool>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_bActive")); }
    bool m_bFrozen() { return read<bool>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_bFrozen")); }
    float m_flFreezeTransitionDuration() { return read<float>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_flFreezeTransitionDuration")); }
    int m_nStopType() { return read<int>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_nStopType")); }
    bool m_bAnimateDuringGameplayPause() { return read<bool>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_bAnimateDuringGameplayPause")); }
    uintptr_t m_iEffectIndex() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_iEffectIndex")); }
    GameTime_t m_flStartTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_flStartTime")); }
    float m_flPreSimTime() { return read<float>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_flPreSimTime")); }
    Vector3 m_vServerControlPoints() { return read<Vector3>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_vServerControlPoints")); }
    uint8_t m_iServerControlPointAssignments() { return read<uint8_t>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_iServerControlPointAssignments")); }
    C_BaseEntity* m_hControlPointEnts() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_hControlPointEnts")); }
    bool m_bNoSave() { return read<bool>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_bNoSave")); }
    bool m_bNoFreeze() { return read<bool>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_bNoFreeze")); }
    bool m_bNoRamp() { return read<bool>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_bNoRamp")); }
    bool m_bStartActive() { return read<bool>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_bStartActive")); }
    uintptr_t m_iszEffectName() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_iszEffectName")); }
    uintptr_t m_iszControlPointNames() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_iszControlPointNames")); }
    int m_nDataCP() { return read<int>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_nDataCP")); }
    Vector3 m_vecDataCPValue() { return read<Vector3>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_vecDataCPValue")); }
    int m_nTintCP() { return read<int>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_nTintCP")); }
    uintptr_t m_clrTint() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_clrTint")); }
    bool m_bOldActive() { return read<bool>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_bOldActive")); }
    bool m_bOldFrozen() { return read<bool>(baseAddr + offsets_instance.get("C_ParticleSystem", "m_bOldFrozen")); }
};
