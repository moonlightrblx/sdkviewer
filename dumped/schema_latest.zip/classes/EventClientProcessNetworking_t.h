#pragma once
#include "../memory.h"

class EventClientProcessNetworking_t {
public:
 uintptr_t baseAddr;
 EventClientProcessNetworking_t() : baseAddr(0){}
 EventClientProcessNetworking_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_nTickCount(){return SCHEMA_TYPE(uintptr_t,0x0);}
};
