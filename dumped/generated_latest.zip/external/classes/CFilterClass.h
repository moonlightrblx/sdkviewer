#pragma once
#include "../memory.h"

class CFilterClass  {
public:
    uintptr_t baseAddr;

    CFilterClass() { baseAddr = 0; }
    CFilterClass(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_iFilterClass() { return read<uintptr_t>(baseAddr + offsets_instance.get("CFilterClass", "m_iFilterClass")); }
};
