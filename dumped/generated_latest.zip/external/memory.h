#pragma once
#include <windows.h>
#include <tlhelp32.h>
#include <cstdint>
#include <cstddef>
#include <string>
#include "../updater/updater.h"

inline DWORD get_process_id(const char* name)
{{
    PROCESSENTRY32 entry{{}}; entry.dwSize = sizeof(entry);
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
    DWORD pid = 0;
    if (Process32First(snapshot, &entry)) do {{ if (!_stricmp(entry.szExeFile,name)){{ pid=entry.th32ProcessID; break;}} }} while(Process32Next(snapshot,&entry));
    CloseHandle(snapshot); return pid;
}}

inline uintptr_t get_module_base(DWORD pid,const char* name)
{{
    MODULEENTRY32 entry{{}}; entry.dwSize=sizeof(entry);
    HANDLE snapshot=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE|TH32CS_SNAPMODULE32,pid);
    uintptr_t base=0;
    if(Module32First(snapshot,&entry)) do {{if(!_stricmp(entry.szModule,name)){{ base=(uintptr_t)entry.modBaseAddr; break;}} }} while(Module32Next(snapshot,&entry));
    CloseHandle(snapshot); return base;
}}

inline HANDLE get_process_handle(){{ static HANDLE proc=nullptr; if(!proc){{ DWORD pid=get_process_id("cs2.exe"); proc=OpenProcess(PROCESS_ALL_ACCESS,FALSE,pid);}} return proc; }}
inline uintptr_t client_base(){{ static uintptr_t base=0; if(!base){{ DWORD pid=get_process_id("cs2.exe"); base=get_module_base(pid,"client.dll");}} return base; }}
inline uintptr_t engine_base(){{ static uintptr_t base=0; if(!base){{ DWORD pid=get_process_id("cs2.exe"); base=get_module_base(pid,"engine2.dll");}} return base; }}

template<typename T> inline T read(uintptr_t addr){{ T buffer{{}}; ReadProcessMemory(get_process_handle(),(LPCVOID)addr,&buffer,sizeof(T),nullptr); return buffer; }}
template<typename T> inline void write(uintptr_t addr,T value){{ WriteProcessMemory(get_process_handle(),(LPVOID)addr,&value,sizeof(T),nullptr); }}

inline bool is_in_game(){{ uintptr_t ep=read<uintptr_t>(engine_base()+offsets_instance.get_flat("dwNetworkGameClient")); int state=read<int>(ep+offsets_instance.get_flat("dwNetworkGameClient_signOnState")); return state==6; }}

inline c_offsets offsets_instance;
