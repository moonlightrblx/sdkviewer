#pragma once
#include "../memory.h"

class C_PlantedC4 {
public:
 uintptr_t baseAddr;
 C_PlantedC4() : baseAddr(0){}
 C_PlantedC4(uintptr_t b):baseAddr(b){}
 uintptr_t m_bBombTicking(){return SCHEMA_TYPE(uintptr_t,0x1160);}
 uintptr_t m_nBombSite(){return SCHEMA_TYPE(uintptr_t,0x1164);}
 uintptr_t m_nSourceSoundscapeHash(){return SCHEMA_TYPE(uintptr_t,0x1168);}
 uintptr_t m_entitySpottedState(){return SCHEMA_TYPE(uintptr_t,0x1170);}
 uintptr_t m_flNextGlow(){return SCHEMA_TYPE(uintptr_t,0x1188);}
 uintptr_t m_flNextBeep(){return SCHEMA_TYPE(uintptr_t,0x118C);}
 uintptr_t m_flC4Blow(){return SCHEMA_TYPE(uintptr_t,0x1190);}
 uintptr_t m_bCannotBeDefused(){return SCHEMA_TYPE(uintptr_t,0x1194);}
 uintptr_t m_bHasExploded(){return SCHEMA_TYPE(uintptr_t,0x1195);}
 uintptr_t m_flTimerLength(){return SCHEMA_TYPE(uintptr_t,0x1198);}
 uintptr_t m_bBeingDefused(){return SCHEMA_TYPE(uintptr_t,0x119C);}
 uintptr_t m_bTriggerWarning(){return SCHEMA_TYPE(uintptr_t,0x11A0);}
 uintptr_t m_bExplodeWarning(){return SCHEMA_TYPE(uintptr_t,0x11A4);}
 uintptr_t m_bC4Activated(){return SCHEMA_TYPE(uintptr_t,0x11A8);}
 uintptr_t m_bTenSecWarning(){return SCHEMA_TYPE(uintptr_t,0x11A9);}
 uintptr_t m_flDefuseLength(){return SCHEMA_TYPE(uintptr_t,0x11AC);}
 uintptr_t m_flDefuseCountDown(){return SCHEMA_TYPE(uintptr_t,0x11B0);}
 uintptr_t m_bBombDefused(){return SCHEMA_TYPE(uintptr_t,0x11B4);}
 uintptr_t m_hBombDefuser(){return SCHEMA_TYPE(uintptr_t,0x11B8);}
 uintptr_t m_AttributeManager(){return SCHEMA_TYPE(uintptr_t,0x11C0);}
 uintptr_t m_hDefuserMultimeter(){return SCHEMA_TYPE(uintptr_t,0x1698);}
 uintptr_t m_flNextRadarFlashTime(){return SCHEMA_TYPE(uintptr_t,0x169C);}
 uintptr_t m_bRadarFlash(){return SCHEMA_TYPE(uintptr_t,0x16A0);}
 uintptr_t m_pBombDefuser(){return SCHEMA_TYPE(uintptr_t,0x16A4);}
 uintptr_t m_fLastDefuseTime(){return SCHEMA_TYPE(uintptr_t,0x16A8);}
 uintptr_t m_pPredictionOwner(){return SCHEMA_TYPE(uintptr_t,0x16B0);}
 uintptr_t m_vecC4ExplodeSpectatePos(){return SCHEMA_TYPE(uintptr_t,0x16B8);}
 uintptr_t m_vecC4ExplodeSpectateAng(){return SCHEMA_TYPE(uintptr_t,0x16C4);}
 uintptr_t m_flC4ExplodeSpectateDuration(){return SCHEMA_TYPE(uintptr_t,0x16D0);}
};
