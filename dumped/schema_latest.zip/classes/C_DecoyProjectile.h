#pragma once
#include "../memory.h"

class C_DecoyProjectile {
public:
 uintptr_t baseAddr;
 C_DecoyProjectile() : baseAddr(0){}
 C_DecoyProjectile(uintptr_t b):baseAddr(b){}
 uintptr_t m_nDecoyShotTick(){return SCHEMA_TYPE(uintptr_t,0x1450);}
 uintptr_t m_nClientLastKnownDecoyShotTick(){return SCHEMA_TYPE(uintptr_t,0x1454);}
 uintptr_t m_flTimeParticleEffectSpawn(){return SCHEMA_TYPE(uintptr_t,0x1478);}
};
