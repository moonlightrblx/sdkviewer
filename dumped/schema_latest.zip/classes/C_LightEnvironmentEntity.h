#pragma once
#include "../memory.h"

class C_LightEnvironmentEntity {
public:
 uintptr_t baseAddr;
 C_LightEnvironmentEntity() : baseAddr(0){}
 C_LightEnvironmentEntity(uintptr_t b):baseAddr(b){}
};
