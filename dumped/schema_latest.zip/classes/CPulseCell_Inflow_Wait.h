#pragma once
#include "../memory.h"

class CPulseCell_Inflow_Wait {
public:
 uintptr_t baseAddr;
 CPulseCell_Inflow_Wait() : baseAddr(0){}
 CPulseCell_Inflow_Wait(uintptr_t b):baseAddr(b){}
 uintptr_t m_WakeResume(){return SCHEMA_TYPE(uintptr_t,0x48);}
};
