#pragma once
#include "../memory.h"

class CPointOrient  {
public:
    uintptr_t baseAddr;

    CPointOrient() { baseAddr = client_base(); }
    CPointOrient(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_iszSpawnTargetName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPointOrient", "m_iszSpawnTargetName")); }
    C_BaseEntity* m_hTarget() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("CPointOrient", "m_hTarget")); }
    bool m_bActive() { return read<bool>(baseAddr + offsets_instance.get("CPointOrient", "m_bActive")); }
    uintptr_t m_nGoalDirection() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPointOrient", "m_nGoalDirection")); }
    uintptr_t m_nConstraint() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPointOrient", "m_nConstraint")); }
    float m_flMaxTurnRate() { return read<float>(baseAddr + offsets_instance.get("CPointOrient", "m_flMaxTurnRate")); }
    uintptr_t m_flLastGameTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPointOrient", "m_flLastGameTime")); }
};
