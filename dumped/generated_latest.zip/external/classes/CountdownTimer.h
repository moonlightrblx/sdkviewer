#pragma once
#include "../memory.h"
#include "../classes/GameTime_t.h"

class CountdownTimer  {
public:
    uintptr_t baseAddr;

    CountdownTimer() { baseAddr = 0; }
    CountdownTimer(uintptr_t base) : baseAddr(base) {}

    float m_duration() { return read<float>(baseAddr + offsets_instance.get("CountdownTimer", "m_duration")); }
    GameTime_t m_timestamp() { return read<GameTime_t>(baseAddr + offsets_instance.get("CountdownTimer", "m_timestamp")); }
    float m_timescale() { return read<float>(baseAddr + offsets_instance.get("CountdownTimer", "m_timescale")); }
    uintptr_t m_nWorldGroupId() { return read<uintptr_t>(baseAddr + offsets_instance.get("CountdownTimer", "m_nWorldGroupId")); }
};
