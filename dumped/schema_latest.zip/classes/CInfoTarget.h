#pragma once
#include "../memory.h"

class CInfoTarget {
public:
 uintptr_t baseAddr;
 CInfoTarget() : baseAddr(0){}
 CInfoTarget(uintptr_t b):baseAddr(b){}
};
