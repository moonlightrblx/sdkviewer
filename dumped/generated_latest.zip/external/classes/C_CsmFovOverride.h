#pragma once
#include "../memory.h"

class C_CsmFovOverride  {
public:
    uintptr_t baseAddr;

    C_CsmFovOverride() { baseAddr = client_base(); }
    C_CsmFovOverride(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_cameraName() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_CsmFovOverride", "m_cameraName")); }
    float m_flCsmFovOverrideValue() { return read<float>(baseAddr + offsets_instance.get("C_CsmFovOverride", "m_flCsmFovOverrideValue")); }
};
