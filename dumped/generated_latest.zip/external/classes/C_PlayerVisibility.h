#pragma once
#include "../memory.h"

class C_PlayerVisibility  {
public:
    uintptr_t baseAddr;

    C_PlayerVisibility() { baseAddr = client_base(); }
    C_PlayerVisibility(uintptr_t base) : baseAddr(base) {}

    float m_flVisibilityStrength() { return read<float>(baseAddr + offsets_instance.get("C_PlayerVisibility", "m_flVisibilityStrength")); }
    float m_flFogDistanceMultiplier() { return read<float>(baseAddr + offsets_instance.get("C_PlayerVisibility", "m_flFogDistanceMultiplier")); }
    float m_flFogMaxDensityMultiplier() { return read<float>(baseAddr + offsets_instance.get("C_PlayerVisibility", "m_flFogMaxDensityMultiplier")); }
    float m_flFadeTime() { return read<float>(baseAddr + offsets_instance.get("C_PlayerVisibility", "m_flFadeTime")); }
    bool m_bStartDisabled() { return read<bool>(baseAddr + offsets_instance.get("C_PlayerVisibility", "m_bStartDisabled")); }
    bool m_bIsEnabled() { return read<bool>(baseAddr + offsets_instance.get("C_PlayerVisibility", "m_bIsEnabled")); }
};
