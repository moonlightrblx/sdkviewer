#pragma once
#include "../memory.h"

class C_FuncTrackTrain {
public:
 uintptr_t baseAddr;
 C_FuncTrackTrain() : baseAddr(0){}
 C_FuncTrackTrain(uintptr_t b):baseAddr(b){}
 uintptr_t m_nLongAxis(){return SCHEMA_TYPE(uintptr_t,0xEB0);}
 uintptr_t m_flRadius(){return SCHEMA_TYPE(uintptr_t,0xEB4);}
 uintptr_t m_flLineLength(){return SCHEMA_TYPE(uintptr_t,0xEB8);}
};
