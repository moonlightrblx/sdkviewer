#pragma once
#include "../memory.h"

class CSPerRoundStats_t {
public:
 uintptr_t baseAddr;
 CSPerRoundStats_t() : baseAddr(0){}
 CSPerRoundStats_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_iKills(){return SCHEMA_TYPE(uintptr_t,0x30);}
 uintptr_t m_iDeaths(){return SCHEMA_TYPE(uintptr_t,0x34);}
 uintptr_t m_iAssists(){return SCHEMA_TYPE(uintptr_t,0x38);}
 uintptr_t m_iDamage(){return SCHEMA_TYPE(uintptr_t,0x3C);}
 uintptr_t m_iEquipmentValue(){return SCHEMA_TYPE(uintptr_t,0x40);}
 uintptr_t m_iMoneySaved(){return SCHEMA_TYPE(uintptr_t,0x44);}
 uintptr_t m_iKillReward(){return SCHEMA_TYPE(uintptr_t,0x48);}
 uintptr_t m_iLiveTime(){return SCHEMA_TYPE(uintptr_t,0x4C);}
 uintptr_t m_iHeadShotKills(){return SCHEMA_TYPE(uintptr_t,0x50);}
 uintptr_t m_iObjective(){return SCHEMA_TYPE(uintptr_t,0x54);}
 uintptr_t m_iCashEarned(){return SCHEMA_TYPE(uintptr_t,0x58);}
 uintptr_t m_iUtilityDamage(){return SCHEMA_TYPE(uintptr_t,0x5C);}
 uintptr_t m_iEnemiesFlashed(){return SCHEMA_TYPE(uintptr_t,0x60);}
};
