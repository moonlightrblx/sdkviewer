#pragma once
#include "../memory.h"

class CFilterAttributeInt {
public:
 uintptr_t baseAddr;
 CFilterAttributeInt() : baseAddr(0){}
 CFilterAttributeInt(uintptr_t b):baseAddr(b){}
 uintptr_t m_sAttributeName(){return SCHEMA_TYPE(uintptr_t,0x650);}
};
