#pragma once
#include "../memory.h"
#include "../classes/CPulse_ResumePoint.h"
#include "../classes/SignatureOutflow_Continue.h"

class CPulseCell_IntervalTimer  {
public:
    uintptr_t baseAddr;

    CPulseCell_IntervalTimer() { baseAddr = 0; }
    CPulseCell_IntervalTimer(uintptr_t base) : baseAddr(base) {}

    CPulse_ResumePoint m_Completed() { return read<CPulse_ResumePoint>(baseAddr + offsets_instance.get("CPulseCell_IntervalTimer", "m_Completed")); }
    SignatureOutflow_Continue m_OnInterval() { return read<SignatureOutflow_Continue>(baseAddr + offsets_instance.get("CPulseCell_IntervalTimer", "m_OnInterval")); }
};
