#pragma once
#include "../memory.h"

class CPulseCursorFuncs  {
public:
    uintptr_t baseAddr;

    CPulseCursorFuncs() { baseAddr = 0; }
    CPulseCursorFuncs(uintptr_t base) : baseAddr(base) {}

};
