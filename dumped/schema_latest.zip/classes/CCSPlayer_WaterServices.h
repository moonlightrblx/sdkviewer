#pragma once
#include "../memory.h"

class CCSPlayer_WaterServices {
public:
 uintptr_t baseAddr;
 CCSPlayer_WaterServices() : baseAddr(0){}
 CCSPlayer_WaterServices(uintptr_t b):baseAddr(b){}
 uintptr_t m_flWaterJumpTime(){return SCHEMA_TYPE(uintptr_t,0x40);}
 uintptr_t m_vecWaterJumpVel(){return SCHEMA_TYPE(uintptr_t,0x44);}
 uintptr_t m_flSwimSoundTime(){return SCHEMA_TYPE(uintptr_t,0x50);}
};
