#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_BreakableProp  {
public:
    uintptr_t baseAddr;

    C_BreakableProp() { baseAddr = client_base(); }
    C_BreakableProp(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_CPropDataComponent() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BreakableProp", "m_CPropDataComponent")); }
    uintptr_t m_OnStartDeath() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BreakableProp", "m_OnStartDeath")); }
    uintptr_t m_OnBreak() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BreakableProp", "m_OnBreak")); }
    float m_OnHealthChanged() { return read<float>(baseAddr + offsets_instance.get("C_BreakableProp", "m_OnHealthChanged")); }
    uintptr_t m_OnTakeDamage() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BreakableProp", "m_OnTakeDamage")); }
    float m_impactEnergyScale() { return read<float>(baseAddr + offsets_instance.get("C_BreakableProp", "m_impactEnergyScale")); }
    int m_iMinHealthDmg() { return read<int>(baseAddr + offsets_instance.get("C_BreakableProp", "m_iMinHealthDmg")); }
    float m_flPressureDelay() { return read<float>(baseAddr + offsets_instance.get("C_BreakableProp", "m_flPressureDelay")); }
    float m_flDefBurstScale() { return read<float>(baseAddr + offsets_instance.get("C_BreakableProp", "m_flDefBurstScale")); }
    Vector3 m_vDefBurstOffset() { return read<Vector3>(baseAddr + offsets_instance.get("C_BreakableProp", "m_vDefBurstOffset")); }
    C_BaseEntity* m_hBreaker() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_BreakableProp", "m_hBreaker")); }
    uintptr_t m_PerformanceMode() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BreakableProp", "m_PerformanceMode")); }
    uintptr_t m_flPreventDamageBeforeTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BreakableProp", "m_flPreventDamageBeforeTime")); }
    uintptr_t m_BreakableContentsType() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BreakableProp", "m_BreakableContentsType")); }
    uintptr_t m_strBreakableContentsPropGroupOverride() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BreakableProp", "m_strBreakableContentsPropGroupOverride")); }
    uintptr_t m_strBreakableContentsParticleOverride() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BreakableProp", "m_strBreakableContentsParticleOverride")); }
    bool m_bHasBreakPiecesOrCommands() { return read<bool>(baseAddr + offsets_instance.get("C_BreakableProp", "m_bHasBreakPiecesOrCommands")); }
    float m_explodeDamage() { return read<float>(baseAddr + offsets_instance.get("C_BreakableProp", "m_explodeDamage")); }
    float m_explodeRadius() { return read<float>(baseAddr + offsets_instance.get("C_BreakableProp", "m_explodeRadius")); }
    float m_explosionDelay() { return read<float>(baseAddr + offsets_instance.get("C_BreakableProp", "m_explosionDelay")); }
    uintptr_t m_explosionBuildupSound() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BreakableProp", "m_explosionBuildupSound")); }
    uintptr_t m_explosionCustomEffect() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BreakableProp", "m_explosionCustomEffect")); }
    uintptr_t m_explosionCustomSound() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BreakableProp", "m_explosionCustomSound")); }
    uintptr_t m_explosionModifier() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BreakableProp", "m_explosionModifier")); }
    C_BasePlayerPawn* m_hPhysicsAttacker() { return read<C_BasePlayerPawn*>(baseAddr + offsets_instance.get("C_BreakableProp", "m_hPhysicsAttacker")); }
    uintptr_t m_flLastPhysicsInfluenceTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BreakableProp", "m_flLastPhysicsInfluenceTime")); }
    float m_flDefaultFadeScale() { return read<float>(baseAddr + offsets_instance.get("C_BreakableProp", "m_flDefaultFadeScale")); }
    C_BaseEntity* m_hLastAttacker() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("C_BreakableProp", "m_hLastAttacker")); }
};
