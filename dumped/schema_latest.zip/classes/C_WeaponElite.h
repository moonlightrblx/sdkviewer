#pragma once
#include "../memory.h"

class C_WeaponElite {
public:
 uintptr_t baseAddr;
 C_WeaponElite() : baseAddr(0){}
 C_WeaponElite(uintptr_t b):baseAddr(b){}
};
