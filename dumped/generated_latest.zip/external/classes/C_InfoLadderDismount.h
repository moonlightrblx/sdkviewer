#pragma once
#include "../memory.h"

class C_InfoLadderDismount  {
public:
    uintptr_t baseAddr;

    C_InfoLadderDismount() { baseAddr = 0; }
    C_InfoLadderDismount(uintptr_t base) : baseAddr(base) {}

};
