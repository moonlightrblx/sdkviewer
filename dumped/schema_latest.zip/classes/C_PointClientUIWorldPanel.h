#pragma once
#include "../memory.h"

class C_PointClientUIWorldPanel {
public:
 uintptr_t baseAddr;
 C_PointClientUIWorldPanel() : baseAddr(0){}
 C_PointClientUIWorldPanel(uintptr_t b):baseAddr(b){}
 uintptr_t m_bForceRecreateNextUpdate(){return SCHEMA_TYPE(uintptr_t,0xEE8);}
 uintptr_t m_bMoveViewToPlayerNextThink(){return SCHEMA_TYPE(uintptr_t,0xEE9);}
 uintptr_t m_bCheckCSSClasses(){return SCHEMA_TYPE(uintptr_t,0xEEA);}
 uintptr_t m_anchorDeltaTransform(){return SCHEMA_TYPE(uintptr_t,0xEF0);}
 uintptr_t m_pOffScreenIndicator(){return SCHEMA_TYPE(uintptr_t,0x1080);}
 uintptr_t m_bIgnoreInput(){return SCHEMA_TYPE(uintptr_t,0x10A8);}
 uintptr_t m_bLit(){return SCHEMA_TYPE(uintptr_t,0x10A9);}
 uintptr_t m_bFollowPlayerAcrossTeleport(){return SCHEMA_TYPE(uintptr_t,0x10AA);}
 uintptr_t m_flWidth(){return SCHEMA_TYPE(uintptr_t,0x10AC);}
 uintptr_t m_flHeight(){return SCHEMA_TYPE(uintptr_t,0x10B0);}
 uintptr_t m_flDPI(){return SCHEMA_TYPE(uintptr_t,0x10B4);}
 uintptr_t m_flInteractDistance(){return SCHEMA_TYPE(uintptr_t,0x10B8);}
 uintptr_t m_flDepthOffset(){return SCHEMA_TYPE(uintptr_t,0x10BC);}
 uintptr_t m_unOwnerContext(){return SCHEMA_TYPE(uintptr_t,0x10C0);}
 uintptr_t m_unHorizontalAlign(){return SCHEMA_TYPE(uintptr_t,0x10C4);}
 uintptr_t m_unVerticalAlign(){return SCHEMA_TYPE(uintptr_t,0x10C8);}
 uintptr_t m_unOrientation(){return SCHEMA_TYPE(uintptr_t,0x10CC);}
 uintptr_t m_bAllowInteractionFromAllSceneWorlds(){return SCHEMA_TYPE(uintptr_t,0x10D0);}
 uintptr_t m_vecCSSClasses(){return SCHEMA_TYPE(uintptr_t,0x10D8);}
 uintptr_t m_bOpaque(){return SCHEMA_TYPE(uintptr_t,0x10F0);}
 uintptr_t m_bNoDepth(){return SCHEMA_TYPE(uintptr_t,0x10F1);}
 uintptr_t m_bVisibleWhenParentNoDraw(){return SCHEMA_TYPE(uintptr_t,0x10F2);}
 uintptr_t m_bRenderBackface(){return SCHEMA_TYPE(uintptr_t,0x10F3);}
 uintptr_t m_bUseOffScreenIndicator(){return SCHEMA_TYPE(uintptr_t,0x10F4);}
 uintptr_t m_bExcludeFromSaveGames(){return SCHEMA_TYPE(uintptr_t,0x10F5);}
 uintptr_t m_bGrabbable(){return SCHEMA_TYPE(uintptr_t,0x10F6);}
 uintptr_t m_bOnlyRenderToTexture(){return SCHEMA_TYPE(uintptr_t,0x10F7);}
 uintptr_t m_bDisableMipGen(){return SCHEMA_TYPE(uintptr_t,0x10F8);}
 uintptr_t m_nExplicitImageLayout(){return SCHEMA_TYPE(uintptr_t,0x10FC);}
};
