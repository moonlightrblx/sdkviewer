#pragma once
#include "../memory.h"

class C_EconWearable {
public:
 uintptr_t baseAddr;
 C_EconWearable() : baseAddr(0){}
 C_EconWearable(uintptr_t b):baseAddr(b){}
 uintptr_t m_nForceSkin(){return SCHEMA_TYPE(uintptr_t,0x18E0);}
 uintptr_t m_bAlwaysAllow(){return SCHEMA_TYPE(uintptr_t,0x18E4);}
};
