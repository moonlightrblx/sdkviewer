#pragma once
#include "../memory.h"

class CNetworkedSequenceOperation  {
public:
    uintptr_t baseAddr;

    CNetworkedSequenceOperation() { baseAddr = 0; }
    CNetworkedSequenceOperation(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_hSequence() { return read<uintptr_t>(baseAddr + offsets_instance.get("CNetworkedSequenceOperation", "m_hSequence")); }
    float m_flPrevCycle() { return read<float>(baseAddr + offsets_instance.get("CNetworkedSequenceOperation", "m_flPrevCycle")); }
    float m_flCycle() { return read<float>(baseAddr + offsets_instance.get("CNetworkedSequenceOperation", "m_flCycle")); }
    uintptr_t m_flWeight() { return read<uintptr_t>(baseAddr + offsets_instance.get("CNetworkedSequenceOperation", "m_flWeight")); }
    bool m_bSequenceChangeNetworked() { return read<bool>(baseAddr + offsets_instance.get("CNetworkedSequenceOperation", "m_bSequenceChangeNetworked")); }
    bool m_bDiscontinuity() { return read<bool>(baseAddr + offsets_instance.get("CNetworkedSequenceOperation", "m_bDiscontinuity")); }
    float m_flPrevCycleFromDiscontinuity() { return read<float>(baseAddr + offsets_instance.get("CNetworkedSequenceOperation", "m_flPrevCycleFromDiscontinuity")); }
    float m_flPrevCycleForAnimEventDetection() { return read<float>(baseAddr + offsets_instance.get("CNetworkedSequenceOperation", "m_flPrevCycleForAnimEventDetection")); }
};
