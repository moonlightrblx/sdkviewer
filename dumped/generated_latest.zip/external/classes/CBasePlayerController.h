#pragma once
#include "../memory.h"
#include "../types/Vector3.h"
class C_BasePlayerPawn;

class CBasePlayerController  {
public:
    uintptr_t baseAddr;

    CBasePlayerController() { baseAddr = 0; }
    CBasePlayerController(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_CommandContext() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBasePlayerController", "m_CommandContext")); }
    uintptr_t m_nInButtonsWhichAreToggles() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBasePlayerController", "m_nInButtonsWhichAreToggles")); }
    int m_nTickBase() { return read<int>(baseAddr + offsets_instance.get("CBasePlayerController", "m_nTickBase")); }
    C_BasePlayerPawn* m_hPawn() { return read<C_BasePlayerPawn*>(baseAddr + offsets_instance.get("CBasePlayerController", "m_hPawn")); }
    bool m_bKnownTeamMismatch() { return read<bool>(baseAddr + offsets_instance.get("CBasePlayerController", "m_bKnownTeamMismatch")); }
    C_BasePlayerPawn* m_hPredictedPawn() { return read<C_BasePlayerPawn*>(baseAddr + offsets_instance.get("CBasePlayerController", "m_hPredictedPawn")); }
    uintptr_t m_nSplitScreenSlot() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBasePlayerController", "m_nSplitScreenSlot")); }
    CBasePlayerController* m_hSplitOwner() { return read<CBasePlayerController*>(baseAddr + offsets_instance.get("CBasePlayerController", "m_hSplitOwner")); }
    Vector3 m_hSplitScreenPlayers() { return read<Vector3>(baseAddr + offsets_instance.get("CBasePlayerController", "m_hSplitScreenPlayers")); }
    bool m_bIsHLTV() { return read<bool>(baseAddr + offsets_instance.get("CBasePlayerController", "m_bIsHLTV")); }
    uintptr_t m_iConnected() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBasePlayerController", "m_iConnected")); }
    char* m_iszPlayerName() { return read<char*>(baseAddr + offsets_instance.get("CBasePlayerController", "m_iszPlayerName")); }
    uintptr_t m_steamID() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBasePlayerController", "m_steamID")); }
    bool m_bIsLocalPlayerController() { return read<bool>(baseAddr + offsets_instance.get("CBasePlayerController", "m_bIsLocalPlayerController")); }
    bool m_bNoClipEnabled() { return read<bool>(baseAddr + offsets_instance.get("CBasePlayerController", "m_bNoClipEnabled")); }
    int m_iDesiredFOV() { return read<int>(baseAddr + offsets_instance.get("CBasePlayerController", "m_iDesiredFOV")); }
};
