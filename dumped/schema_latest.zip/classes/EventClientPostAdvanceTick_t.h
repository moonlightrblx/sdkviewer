#pragma once
#include "../memory.h"

class EventClientPostAdvanceTick_t {
public:
 uintptr_t baseAddr;
 EventClientPostAdvanceTick_t() : baseAddr(0){}
 EventClientPostAdvanceTick_t(uintptr_t b):baseAddr(b){}
};
