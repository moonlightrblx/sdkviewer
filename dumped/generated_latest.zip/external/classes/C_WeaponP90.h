#pragma once
#include "../memory.h"

class C_WeaponP90  {
public:
    uintptr_t baseAddr;

    C_WeaponP90() { baseAddr = 0; }
    C_WeaponP90(uintptr_t base) : baseAddr(base) {}

};
